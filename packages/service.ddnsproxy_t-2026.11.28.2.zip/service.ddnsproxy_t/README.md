# DDNS Proxyᵀ (service.ddnsproxy_t)

Kodi service add-on (Kodi 21+) that turns the Kodi device into a small, password-protected
forward proxy reachable from the internet through a dynamic DNS host name.

## Features

- **Proxy engine:** [3proxy](https://github.com/3proxy/3proxy) 1.0.4, downloaded on first start from the official
  GitHub release. Its SHA256SUMS file must carry a valid OpenPGP signature from the bundled 3proxy release key
  (fingerprint pinned in `resources/engine.json`) and also match the checksum shipped with the add-on; the package
  is then checked against it (Windows x64, Linux x86-64 / aarch64 / armhf, e.g. LibreELEC). On Linux the
  PCRE2 library that 3proxy needs (missing on LibreELEC) is fetched from Debian, checked against a pinned
  SHA-256 and loaded from the engine directory. A self-provided
  binary can be configured instead.
- **Listeners:** HTTP proxy (CONNECT for HTTPS sites), optional HTTPS (TLS) proxy with an automatic local CA or
  a custom certificate, optional SOCKS5. All listeners require user name and password.
  Settings and Diagnostics show the proxy password unmasked. Kodi saves it in the add-on settings, and the
  service writes it in clear text to the generated `3proxy.cfg`. Protect the Kodi profile and its backups;
  redact the password from screenshots before sharing them. The add-on does not log the password or send it
  to external port checkers.
  Optionally, *Use one external port* dispatches these protocols on one shared TCP port; separate ports remain
  the default. Forward only the shared TCP port. SOCKS5 CONNECT works, but UDP ASSOC and BIND are disabled in
  this mode (there is no UDP forwarding). Typical Kodi streaming generally uses TCP, but applications requiring
  UDP, such as some using QUIC, or SOCKS BIND need another option. SOCKS4 is not dispatched. HTTP and SOCKS
  credentials remain plaintext; HTTPS proxy TLS protects them in transit.
  On Linux (including LibreELEC), the dispatcher uses randomly named abstract Unix sockets for HTTP and TLS;
  SOCKS uses an automatically allocated loopback TCP port because 3proxy 1.0.4 gives malformed SOCKS replies on
  Unix sockets. On Windows all backends use loopback TCP. Other local users/processes can access these
  internal listeners; treat the local device as trusted. 3proxy cannot see the real client IP in its logs and
  source ACLs. Authentication and destination restrictions still apply. Private TCP port selection has a brief
  bind handoff race; startup fails and retries on detected conflicts. A custom engine must support Unix listeners
  on Linux.
- **Destinations:** public internet only, with an optional [destination allow-list](#destination-allow-list).
- **Dynamic DNS:** two host entries; No-IP, DuckDNS, Dynu, deSEC, Cloudflare, FreeDNS (afraid.org) and any
  dyndns2-compatible service. Credentials are not checked as you type, and checks do not prevent saving.
  Saving changes to an enabled host can trigger a real background DNS update. *Test now* checks the saved
  settings and tries read-only validation where supported. If verification requires a real update request,
  it shows the proposed address and asks before sending its own update. Declining that prompt does not
  disable background updates. Diagnostics shows the recorded DDNS status and hostname match; it does not
  retest provider credentials.
- **Router:** optional port forwarding via PCP, NAT-PMP or UPnP IGD with lease renewal and removal on stop.
  Client setup and internet checks use the external port granted by an active automatic mapping; local
  checks and at-home client setup keep the local listener port. Without an automatic mapping, a manual
  same-port rule is assumed. If your manual external port differs, adjust the client yourself; automatic
  diagnostics cannot discover that rule.
- **Bandwidth statistics:** *Tools > Client bandwidth statistics* separates client uploads from downloads.
  Separate-port mode uses 3proxy payload counters (%O client upload, %I download) grouped by source IP;
  shared-port mode measures bytes relayed to/from each client IP and HTTP/TLS/SOCKS transport, including proxy
  protocol/authentication bytes and
  TLS overhead. Relay counts exclude TCP/IP headers and retransmissions and do not prove remote delivery; unlike
  3proxy payload counts they may include failed authentication attempts. Shared and direct totals are kept
  separately and never added together. Relay deltas are persisted during active transfers and after close;
  abrupt failure can lose about one second or 4 MiB per active connection; storage errors can lose more.
  Source IPs may identify a
  router/shared network, not an individual device. Statistics cover retained 3proxy logs or the latest seven
  daily dispatcher ledgers as applicable. Logs contain no proxy destinations or credentials; file read/write failures
  and unclassified historical 3proxy records are reported rather than silently treated as complete totals.
- **Diagnostics:** shows three separate states per port: *this device* (listening locally), *router*
  (forwarded automatically or manual) and *internet* (reachable / not reachable / check unavailable /
  cancelled / not checked). By default, opening Diagnostics requests an external TCP check against the
  public IPv4 address for each port accepting local connections, using its mapped external port if known.
  *Reachable* means a checker could connect to that address and port. It does not verify IPv6, the DDNS
  hostname, proxy login, certificate trust or whether a client can fetch a site. The internet check uses
  Globalping → Check-Host → PortChecker.co → CanYouSeeMe.org; these services learn the public IP and port, never
  credentials. It can be switched off under *Tools*. Also shown: proxy status, public IPv4/IPv6, DDNS host name
  match and router mapping details.
  An unavailable checker is reported as "check unavailable", never as "closed".
  If automatic forwarding fails, diagnostics identifies the affected TCP port and suggests a manual
  router/firewall rule to the device's LAN address when available. An existing rule may already work;
  mapping failure alone does not establish internet reachability, and forwarding cannot necessarily
  overcome CGNAT or other firewall restrictions.
- **Home address:** the public IPv4 published by DDNS is preferably read from the router (NAT-PMP, then UPnP
  IGD; read-only, no port mapping needed), with web services as fallback.
- All HTTP traffic of the add-on honours Kodi's network proxy settings: HTTP and SOCKS proxies are supported.
  Kodi's **HTTPS proxy type is currently unsupported**; requests fail explicitly instead of bypassing it.
  This concerns Kodi's outbound proxy setting, not this add-on's TLS listener for incoming clients.
  When Kodi uses a supported proxy, web services
  only see the proxy's address, so it is never published: IPv4 is taken from the router (NAT-PMP only,
  because UPnP is HTTP and would bypass the proxy), IPv6 from the device's own global address. Without a
  trustworthy address, DDNS updates pause and the reason is shown in Diagnostics and in the settings.

## Usage

Settings actions save changes before running and return to add-on settings when dismissed with Back/Esc.
Kodi reopens the Proxy category; its add-on settings API does not expose a category argument. Actions
opened from the add-on menu return to that menu, including after network-error messages. Back/Esc at
the main menu (or the settings screen itself) closes it normally.

1. Install the add-on and open its settings. A random proxy password is generated if none is set.
2. Configure and enable your DDNS host under *Dynamic DNS*. Use *Test now* if you want to check its settings.
3. **Before forwarding a port:** the default listener is plain HTTP on TCP `3128`; the HTTPS (TLS) proxy
   listener is off. Visiting an HTTPS site through a plain HTTP proxy does **not** encrypt your proxy login.
   For internet access, enable the TLS listener (default TCP `3129` in separate-port mode), configure your
   client to use an **HTTPS proxy**, and establish certificate trust as described below.
4. Forward only the intended TLS port on your router. If using automatic forwarding or a shared port,
   disable the HTTP and SOCKS listeners first for TLS-only access. Sharing a port does not add encryption
   to those protocols.
5. Open *Tools > Diagnostics* for local and external port status. The standalone *Check port* action always
   asks before contacting an external checker; it shares your public IP and port, never proxy credentials.
   To test the full setup, use *Client setup* for the external hostname and port, then fetch an allowed site
   through the proxy from a client outside your home network with certificate verification enabled.

Clients are ordinary proxy clients (browsers, OS proxy settings, curl ...). An HTTPS proxy encrypts the
connection **to the proxy**, separately from TLS to a destination site. Every client must trust the
proxy certificate's issuer and use a hostname or IP present in its certificate. Diagnostics and Client
setup check local certificate/key material and warn about trust; they cannot determine whether a remote
client trusts it or validate its complete chain. The automatic certificate uses a private CA, not
normally trusted by clients. *Client setup* exports its public CA; import it into each client's
appropriate trust store, if that client supports HTTPS proxy trust. Generated names include enabled
DDNS hostnames, the local IP and localhost, not the public IP. A regenerated CA must be imported again.

For a custom certificate, use a certificate with a suitable trusted chain and matching name, or explicitly
trust its self-signed certificate where supported. Client setup exports only public PEM certificates
from the configured certificate file; it may not contain the issuer CA, which must be obtained separately.
It never exports private keys or substitutes the automatic CA for a custom issuer. Export does not
itself install trust, and existing destination files are not overwritten.

The local CA publishes no revocation list, so Windows curl (Schannel) needs `--ssl-revoke-best-effort`, for example
`curl --ssl-revoke-best-effort --proxy https://home.example.net:3129 --proxy-cacert ca.crt -U user:pass https://example.com/`.

### Destination allow-list

In the add-on settings, go to **Proxy > Destinations > Only allow these sites (optional)** (`proxy.allowlist`).
An empty list (the default) puts no additional restrictions on where authenticated clients can connect.
If the list has valid entries, destinations that do not match are denied. This can limit misuse if your proxy
credentials leak; it does not replace a strong password or TLS.

Enter destination hosts or address ranges, not client addresses or URLs. Separate entries with commas, spaces
or semicolons. For example:

| Entry | What it matches |
| --- | --- |
| `example.com` | The domain itself and its subdomains, such as `www.example.com`. |
| `*.example.com` | Subdomains only, not `example.com` itself. |
| `1.1.1.1` | A single public IP address. |
| `1.1.1.0/24` | A public address range in CIDR notation. |

Domain entries match the hostname requested by the client. A request using an IP address directly needs an
IP or CIDR entry that matches it. A site may also need entries for separate CDN or sign-in domains.

The built-in blocks take precedence. Private, loopback, link-local, CGNAT, multicast and reserved IPv4/IPv6
ranges are denied even after DNS resolution, so a listed hostname that resolves to a private address is still
blocked. Internal names such as `localhost`, `*.local`, `*.lan` and `*.internal` are also denied.

Diagnostics warns about ignored invalid entries, such as malformed hostnames or CIDRs overlapping blocked
ranges. **If every entry is invalid, the proxy treats the list as empty and allows all otherwise permitted
public destinations.** Check Diagnostics after saving to make sure your entries were accepted.

## Versioning

Add-on versions are dates: `YYYY.MM.DD` (zero-padded) for the first version of a day, then `YYYY.MM.DD.1`,
`YYYY.MM.DD.2`, ... for further versions on the same day. The daily counter is independent for each add-on.
The bundled 3proxy engine keeps its own upstream version (see `resources/engine.json`).

## Development

```
py -m unittest discover -s tests
py tools\wsl_integration.py <path to linux 3proxy binary>   # end-to-end ACL/TLS/SOCKS test in WSL
```

## Licence

MIT, see [LICENSE](LICENSE). Third-party components: see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).