# -*- coding: utf-8 -*-
"""Interactive actions (RunScript entry point)."""
import os
import time

import xbmcgui

from . import bandwidth, config, core, ddns, kodi, netutil, portcheck, report, store, threeproxy, tls
from .httpclient import HttpClient, HttpError, PROXY_HTTPS

NAME = kodi.ADDON_NAME


def _settings_config():
    return config.load(kodi.Settings())


def _paths():
    return store.Paths(kodi.profile_dir())


def _status():
    return store.read_json(_paths().status, {})


def _client(user_agent=config.USER_AGENT, cookies=False):
    return HttpClient(kodi.kodi_proxy, user_agent, cookies=cookies)


def _kodi_proxy_text():
    try:
        proxy = kodi.kodi_proxy()
    except HttpError as exc:
        return str(exc)
    if proxy and proxy.type == PROXY_HTTPS:
        return '%s - unsupported; add-on HTTP requests are blocked, not sent directly' % proxy.describe()
    return proxy.describe() if proxy else ''


def _public_check_host(cfg, status):
    """(trusted public IPv4, reason it is missing)."""
    public = status.get('public') or {}
    if public.get('ipv4'):
        return public['ipv4'], ''
    public = core.public_addresses(cfg, _client(), need6=False)
    if public.get('ipv4'):
        return public['ipv4'], ''
    if public.get('paused'):
        return '', public['paused']
    return '', 'the public IPv4 address is unknown (%s)' % (public.get('ipv4_info') or public.get('error') or
                                                            'not detected')


def _internet_checks(cfg, status, listening):
    """Automatic checks of all locally listening ports; see report.connectivity for the result format."""
    if not cfg.proxy_enabled:
        return {'skipped': 'the proxy is switched off'}
    if not cfg.diag_internet:
        return {'skipped': 'switched off in the settings (Tools)'}
    pm = status.get('portmap') or {}
    ports = sorted(set(report.external_port(port, pm) for port in cfg.listener_ports() if listening.get(port)))
    if not ports:
        return {}
    dialog = xbmcgui.DialogProgress()
    dialog.create(NAME, 'Finding the public address...')
    try:
        host, reason = _public_check_host(cfg, status)
        if not host:
            return {'skipped': reason}
        started = time.time()

        def tick(progress):
            done = sum(1 for state in progress.values() if state == 'done')
            dialog.update(int(100.0 * done / len(progress)), 'Checking %s from the internet (%ds)\n%s' % (
                host, time.time() - started,
                ', '.join('%d: %s' % (port, progress[port]) for port in sorted(progress))))
            return dialog.iscanceled()

        results = portcheck.check_ports(lambda: _client(cookies=True), host, ports, tick)
    finally:
        dialog.close()
    return {'host': host, 'results': dict((port, {'state': final.state, 'service': final.service,
                                                  'detail': final.detail})
                                           for port, (final, _attempts) in results.items())}


def diagnostics():
    cfg = _settings_config()
    status = _status()
    listening = {}
    for _kind, port in cfg.public_listeners():
        listening[port] = netutil.tcp_listening(port) if cfg.proxy_enabled else None
    internet = _internet_checks(cfg, status, listening)
    cert_warnings, _ = tls.client_material(cfg, _paths().tls)
    text = report.diagnostics(status, cfg, listening, _kodi_proxy_text(), internet=internet,
                              local_ip=netutil.local_ip(), cert_warnings=cert_warnings)
    xbmcgui.Dialog().textviewer('%s - %s' % (NAME, kodi.localize(30400)), text, usemono=False)


def client_setup():
    cfg = _settings_config()
    status = _status()
    cert_warnings, material = tls.client_material(cfg, _paths().tls)
    text = report.client_setup(status, cfg, netutil.local_ip(), cert_warnings=cert_warnings)
    xbmcgui.Dialog().textviewer('%s - %s' % (NAME, kodi.localize(30402)), text)
    if material and xbmcgui.Dialog().yesno(NAME, 'Export public certificate material to a folder? '
                                                 'Private keys are never exported.'):
        filename = 'ddnsproxy_t-certificate.crt' if cfg.tls_mode == config.TLS_CUSTOM else 'ddnsproxy_t-ca.crt'
        target = xbmcgui.Dialog().browse(3, filename, 'files', '', False, False, '')
        if target:
            try:
                dest = os.path.join(target, filename)
                with open(dest, 'x', encoding='ascii', newline='\n') as handle:
                    handle.write(material)
                kodi.notify('Saved %s' % dest)
            except (IOError, OSError) as exc:
                xbmcgui.Dialog().ok(NAME, 'Export failed (existing files are not overwritten): %s' % exc)


def portcheck_ui():
    cfg = _settings_config()
    status = _status()
    ports = [(report.KIND_LABELS[k], p) for k, p in cfg.public_listeners()]
    if cfg.single_port and ports:
        ports = [('Shared proxy port', ports[0][1])]
    pm = status.get('portmap') or {}
    ports = [(label, report.external_port(port, pm)) for label, port in ports]
    if not ports:
        xbmcgui.Dialog().ok(NAME, 'No proxy listener is enabled.')
        return
    if len(ports) > 1:
        index = xbmcgui.Dialog().select('Which internet port?', ['%s - external port %d' % item for item in ports])
        if index < 0:
            return
        port = ports[index][1]
    else:
        port = ports[0][1]
    host, reason = _public_check_host(cfg, status)
    if not host:
        xbmcgui.Dialog().ok(NAME, 'The port cannot be checked: %s.' % reason)
        return
    if not xbmcgui.Dialog().yesno(NAME, 'An external service (Globalping, Check-Host, PortChecker.co or '
                                        'CanYouSeeMe.org) will try to connect to %s. No credentials are sent. '
                                        'Continue?' % netutil.host_port(host, port)):
        return
    dialog = xbmcgui.DialogProgress()
    dialog.create(NAME, 'Checking %s from the internet...' % netutil.host_port(host, port))

    def progress(index, total, checker):
        name = checker.__name__.replace('check_', '')
        dialog.update(int(100.0 * index / total), 'Asking %s...' % name)
        return dialog.iscanceled()

    try:
        final, attempts = portcheck.check_port(lambda: _client(cookies=True), host, port, progress)
    finally:
        dialog.close()
    if final.state == portcheck.OPEN:
        head = '[COLOR green]Port %d is reachable from the internet.[/COLOR]' % port
    elif final.state == portcheck.CLOSED:
        head = '[COLOR red]Port %d is NOT reachable from the internet.[/COLOR]' % port
        head += '\nCheck the router port forwarding (or enable UPnP/NAT-PMP in the settings), the firewall ' \
                'and whether your provider uses CGNAT.'
    else:
        head = '[COLOR orange]The check is unavailable right now - this does not mean the port is closed.[/COLOR]'
    lines = [head, '', 'Address checked: %s' % netutil.host_port(host, port), '']
    for attempt in attempts:
        lines.append('%s: %s %s' % (attempt.service, attempt.state, attempt.detail))
    xbmcgui.Dialog().textviewer('%s - %s' % (NAME, kodi.localize(30401)), '\n'.join(lines))


def test_ddns(slot):
    slot = int(slot)
    cfg = _settings_config()
    entry = cfg.ddns.get(slot)
    if entry is None:
        return
    provider = ddns.make_provider(entry, config.user_agent_for(entry.provider))
    title = '%s - DDNS %d (%s)' % (NAME, slot, provider.name)
    problems = provider.check()
    if problems:
        xbmcgui.Dialog().ok(title, '\n'.join(problems) + '\n\nThe settings were saved anyway.')
        return
    client = _client()
    busy = xbmcgui.DialogProgress()
    busy.create(title, 'Checking %s...' % entry.fqdn())
    try:
        result = provider.validate(client)
    finally:
        busy.close()
    if result.state != ddns.UNVERIFIED:
        _show_result(title, entry, result)
        if result.success:
            kodi.notify_service('ddns_reset:%d' % slot)
        return
    ip4 = ip6 = None
    busy = xbmcgui.DialogProgress()
    busy.create(title, 'Determining the home internet address...')
    try:
        public = core.public_addresses(cfg, client, need6=entry.ipv6)
    finally:
        busy.close()
    if entry.ipv4:
        ip4 = public.get('ipv4')
    if entry.ipv6:
        ip6 = public.get('ipv6')
    if entry.ipv4 and not ip4 and public.get('paused'):
        xbmcgui.Dialog().ok(title, '%s\n\n%s' % (result.message, public['paused']))
        return
    if not (ip4 or ip6):
        xbmcgui.Dialog().ok(title, '%s\n\nThe public IP address could not be detected, so no update can be '
                                   'sent.' % result.message)
        return
    addresses = ' / '.join(a for a in (ip4, ip6) if a)
    if not xbmcgui.Dialog().yesno(title, '%s\n\nSend a real update now? %s will point to %s.' % (
            result.message, entry.fqdn(), addresses)):
        return
    result = provider.update(client, ip4, ip6)
    _show_result(title, entry, result)
    kodi.notify_service('ddns_reset:%d' % slot)


def _show_result(title, entry, result):
    color = 'green' if result.success else ('orange' if result.state == ddns.UNVERIFIED else 'red')
    text = '[COLOR %s]%s[/COLOR]\n%s' % (color, ddns.STATE_LABELS.get(result.state, result.state), result.message)
    if result.detail:
        text += '\n\nProvider response: %s' % result.detail[:300]
    xbmcgui.Dialog().ok(title, text)


def install_engine():
    kodi.notify_service('reinstall')
    _wait_for_service('installing', 'Installing 3proxy...')


def regen_cert():
    if xbmcgui.Dialog().yesno(NAME, 'Regenerate the automatic TLS certificate? If the local CA is replaced, '
                                    'clients must trust the new CA. Custom certificates are not changed.'):
        kodi.notify_service('regen_cert')
        kodi.notify('Certificate will be regenerated by the service.')


def _wait_for_service(busy_state, message, timeout=240):
    dialog = xbmcgui.DialogProgress()
    dialog.create(NAME, message)
    start = time.time()
    seen_busy = False
    try:
        while time.time() - start < timeout and not dialog.iscanceled():
            state = _status().get('proxy', {})
            if state.get('state') == busy_state:
                seen_busy = True
            elif seen_busy or time.time() - start > 15:
                break
            dialog.update(int(100 * (time.time() - start) / timeout), state.get('message', message))
            time.sleep(1)
    finally:
        dialog.close()
    proxy = _status().get('proxy', {})
    xbmcgui.Dialog().ok(NAME, '%s\n%s' % (report.PROXY_STATES.get(proxy.get('state'), proxy.get('state')),
                                         proxy.get('message', '')))


def gen_password():
    password = threeproxy.generate_password()
    kodi.Settings().set_string('proxy.password', password)
    xbmcgui.Dialog().ok(NAME, 'New proxy password:\n[B]%s[/B]\n\nUpdate your clients.' % password)
    kodi.open_settings()


def show_log():
    paths = _paths()
    parts = []
    for path in (paths.latest_proxy_log(), paths.output_log):
        if path and os.path.isfile(path):
            parts.append('[B]%s[/B]\n%s' % (os.path.basename(path), _tail(path)))
    xbmcgui.Dialog().textviewer('%s - %s' % (NAME, kodi.localize(30405)),
                                '\n\n'.join(parts) or 'No log yet.', usemono=True)


def show_bandwidth_stats():
    cfg = _settings_config()
    paths = _paths()
    if cfg.single_port:
        stats = bandwidth.read_frontend_ledger(paths.frontend_traffic_logs())
        accounting = (_status().get('bandwidth') or {}).get('message', '')
        text = bandwidth.format_frontend_report(stats, status_error=accounting)
    else:
        stats = bandwidth.read_logs(paths.proxy_logs())
        text = bandwidth.format_report(stats)
    xbmcgui.Dialog().textviewer('%s - %s' % (NAME, kodi.localize(30418)), text, usemono=False)


def _tail(path, size=12000):
    with open(path, 'rb') as handle:
        handle.seek(0, os.SEEK_END)
        handle.seek(max(0, handle.tell() - size))
        return handle.read().decode('utf-8', 'replace')


MENU = (
    (30400, diagnostics),
    (30401, portcheck_ui),
    (30402, client_setup),
    (30403, lambda: test_ddns(1)),
    (30404, lambda: test_ddns(2)),
    (30405, show_log),
    (30418, show_bandwidth_stats),
    (30406, install_engine),
    (30407, regen_cert),
    (30408, kodi.open_settings),
)

ACTIONS = {
    'diagnostics': diagnostics,
    'portcheck': portcheck_ui,
    'client_setup': client_setup,
    'test_ddns': test_ddns,
    'show_log': show_log,
    'bandwidth_stats': show_bandwidth_stats,
    'install_engine': install_engine,
    'regen_cert': regen_cert,
    'gen_password': gen_password,
}


def menu():
    while True:
        index = xbmcgui.Dialog().select(NAME, [kodi.localize(label) for label, _ in MENU])
        if index < 0:
            return
        MENU[index][1]()
        if MENU[index][1] is kodi.open_settings:
            return


def run(argv):
    action = argv[0] if argv else ''
    func = ACTIONS.get(action)
    try:
        if func is None:
            menu()
        else:
            func(*argv[1:])
    except HttpError as exc:
        xbmcgui.Dialog().ok(NAME, 'Network error: %s' % exc)
