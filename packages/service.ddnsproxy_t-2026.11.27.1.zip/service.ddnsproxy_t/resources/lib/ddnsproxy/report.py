# -*- coding: utf-8 -*-
"""Plain-text reports for the UI (no Kodi imports)."""
import time

from . import config, ddns, portcheck

PROXY_STATES = {
    'running': 'Running', 'stopped': 'Stopped', 'disabled': 'Switched off', 'error': 'Error',
    'installing': 'Installing engine', 'starting': 'Starting',
}
KIND_LABELS = {'http': 'HTTP proxy', 'tls': 'HTTPS (TLS) proxy', 'socks': 'SOCKS5 proxy'}


def _age(ts, now):
    if not ts:
        return 'never'
    seconds = int(now - ts)
    if seconds < 90:
        return '%ds ago' % max(seconds, 0)
    if seconds < 5400:
        return '%d min ago' % (seconds // 60)
    if seconds < 172800:
        return '%d h ago' % (seconds // 3600)
    return time.strftime('%Y-%m-%d %H:%M', time.localtime(ts))


def _b(text):
    return '[B]%s[/B]' % text


def dns_match(info, public):
    """'match', 'mismatch' or 'unknown' for one DDNS status entry."""
    dns = info.get('dns') or {}
    verdicts = []
    for version, key in ((4, 'ipv4'), (6, 'ipv6')):
        addr = public.get(key)
        names = dns.get(str(version)) or dns.get(version) or []
        if addr and (names or version == 4):
            verdicts.append(addr in names)
    if not verdicts:
        return 'unknown'
    return 'match' if all(verdicts) else 'mismatch'


def external_port(port, pm):
    """Use the active router mapping; without one, assume a same-port manual rule."""
    if pm.get('enabled'):
        for mapping in pm.get('mappings') or []:
            if mapping.get('internal_port') == port:
                return mapping['external_port']
    return port


def _router_line(port, pm, local_ip):
    target = '%s port %d' % (local_ip or 'this device', port)
    if not pm.get('enabled'):
        return 'manual - if needed, forward TCP port %d to %s on the router/firewall' % (port, target)
    for mapping in pm.get('mappings', []):
        if mapping.get('internal_port') == port:
            return '[COLOR green]forwarded automatically[/COLOR] by %s (external port %s)' % (
                mapping.get('method'), mapping.get('external_port'))
    if any(err.startswith('port %d: ' % port) for err in pm.get('errors', [])):
        return ('[COLOR red]automatic forwarding failed[/COLOR] - if not already configured, '
                'forward TCP port %d to %s on the router/firewall (see Router port forwarding)' % (port, target))
    return 'automatic forwarding not active yet%s' % (' - %s' % pm['message'] if pm.get('message') else '')


def _internet_line(port, live, internet):
    if internet.get('skipped'):
        return '[COLOR orange]not checked[/COLOR] - %s' % internet['skipped']
    result = (internet.get('results') or {}).get(port)
    if live is False and result is None:
        return 'not checked - not listening on this device'
    if result is None:
        return 'not checked'
    state, service, detail = result.get('state'), result.get('service'), result.get('detail', '')
    if state == portcheck.OPEN:
        return '[COLOR green]reachable[/COLOR] (%s: %s)' % (service, detail)
    if state == portcheck.CLOSED:
        return '[COLOR red]not reachable[/COLOR] (%s: %s)' % (service, detail)
    if state == portcheck.CANCELLED:
        return '[COLOR orange]check cancelled[/COLOR] - unknown'
    return '[COLOR orange]check unavailable[/COLOR] - unknown, not the same as closed'


def connectivity(cfg, listening, internet, pm, local_ip=''):
    """Per-port states: this device, router forwarding and reachability from the internet."""
    lines = [_b('Connectivity')]
    if not cfg.proxy_enabled:
        lines.append('  The proxy is switched off.')
        return lines
    listeners = cfg.public_listeners()
    if cfg.single_port and listeners:
        listeners = [('shared', listeners[0][1])]
    if not listeners:
        lines.append('  No proxy listener is enabled.')
        return lines
    if internet.get('host'):
        lines.append('  Checked from the internet at %s' % internet['host'])
    for kind, port in listeners:
        live = listening.get(port)
        lines.append('  %s - port %d' % (KIND_LABELS.get(kind, 'Shared proxy (TCP)' if kind == 'shared' else kind), port))
        local = 'not checked' if live is None else (
            '[COLOR green]accepts connections[/COLOR]' if live else '[COLOR red]not listening[/COLOR]')
        lines.append('    This device: %s' % local)
        lines.append('    Router: %s' % _router_line(port, pm, local_ip))
        public_port = external_port(port, pm)
        if public_port != port:
            lines.append('    Internet endpoint: external TCP port %d -> local port %d' % (public_port, port))
        lines.append('    Internet: %s' % _internet_line(public_port, live, internet))
    if not pm.get('enabled') or pm.get('errors'):
        lines.append('  A manual rule may already exist; forwarding alone may not overcome CGNAT or firewall restrictions.')
    if internet.get('host') and not internet.get('skipped'):
        lines.append('  Internet checks: %s.' % portcheck.SERVICES)
        lines.append('  They learn the public address and port, never the proxy credentials.')
    return lines


def diagnostics(status, cfg, listening=None, kodi_proxy='', now=None, internet=None, local_ip='', cert_warnings=None):
    """listening: {port: bool} from a live local check; internet: see ui.diagnostics."""
    now = now or time.time()
    listening = listening or {}
    lines = connectivity(cfg, listening, internet or {}, status.get('portmap') or {}, local_ip)
    lines.append('')
    proxy = status.get('proxy', {})
    state = proxy.get('state', 'unknown')
    updated = status.get('updated')
    lines.append(_b('Proxy'))
    if not updated or now - updated > 30:
        lines.append('  [COLOR orange]The service has not reported for %s - is it running?[/COLOR]'
                     % _age(updated, now))
    lines.append('  State: %s - %s' % (PROXY_STATES.get(state, state), proxy.get('message', '')))
    eng = status.get('engine') or {}
    if eng:
        signed = ', signed release verified' if eng.get('signed_by') else ''
        lines.append('  Engine: 3proxy %s (%s%s)' % (eng.get('version', '?'), eng.get('asset') or eng.get('binary'),
                                                    signed))
    lines.append('  Platform: %s' % status.get('platform', '?'))
    tls = status.get('tls') or {}
    expected_mode = 'custom' if cfg.tls_mode == config.TLS_CUSTOM else 'auto'
    if cfg.tls_enabled and tls and tls.get('mode', 'auto') == expected_mode:
        if tls.get('mode') == 'custom':
            lines.append('  TLS: custom certificate %s' % tls.get('cert_file'))
        else:
            lines.append('  TLS: automatic certificate for %s (valid until %s)' % (
                ', '.join(tls.get('names', [])), tls.get('not_after', '?')))
    for msg in status.get('problems', []) + status.get('warnings', []) + (cert_warnings or []):
        lines.append('  [COLOR orange]%s[/COLOR]' % msg)

    public = status.get('public') or {}
    lines.append('')
    lines.append(_b('Internet address'))
    if public.get('error'):
        lines.append('  [COLOR red]%s[/COLOR]' % public['error'])
    lines.append('  IPv4: %s' % (public.get('ipv4') or 'unknown (%s)' % (public.get('ipv4_info') or 'not checked')))
    if public.get('ipv4') and public.get('ipv4_info', '').startswith('router'):
        lines.append('    from the %s' % public['ipv4_info'])
    if public.get('ipv6') or public.get('ipv6_info'):
        lines.append('  IPv6: %s' % (public.get('ipv6') or 'unknown (%s)' % public.get('ipv6_info')))
    if public.get('router_ipv4'):
        lines.append('  Router WAN address: %s (%s)' % (public['router_ipv4'], public.get('router_info', '')))
    elif public.get('router_info'):
        lines.append('  Router WAN address: not available (%s)' % public['router_info'])
    if public.get('via_proxy') and public.get('proxy_ipv4'):
        lines.append('  Address seen by web services (Kodi proxy): %s - never published' % public['proxy_ipv4'])
    for note in public.get('notes') or []:
        lines.append('  [COLOR orange]%s[/COLOR]' % note)
    if public.get('paused'):
        lines.append('  [COLOR orange]%s[/COLOR]' % public['paused'])
    if public.get('checked'):
        lines.append('  Checked %s' % _age(public['checked'], now))
    if kodi_proxy:
        lines.append('  Kodi network proxy: %s' % kodi_proxy)
        lines.append('  HTTP requests use supported Kodi proxies; unsupported types are blocked, never bypassed.')

    lines.append('')
    lines.append(_b('Dynamic DNS'))
    entries = status.get('ddns') or {}
    shown = False
    for slot in sorted(entries):
        info = entries[slot]
        if not info.get('enabled'):
            continue
        shown = True
        lines.append('  %s: %s (%s)' % (slot, info.get('hostname') or '(no hostname)', info.get('provider')))
        result = info.get('result')
        if result:
            res = ddns.Result.from_dict(result)
            color = 'green' if res.success else ('orange' if res.state == ddns.UNVERIFIED else 'red')
            lines.append('    Last update: [COLOR %s]%s[/COLOR] - %s (%s)' % (
                color, ddns.STATE_LABELS.get(res.state, res.state), res.message, _age(info.get('last_attempt'), now)))
        if info.get('blocked'):
            lines.append('    Updates stopped until the settings change or a test succeeds.')
        if info.get('note'):
            lines.append('    [COLOR orange]%s[/COLOR]' % info['note'])
        dns = info.get('dns') or {}
        resolved = (dns.get('4') or dns.get(4) or []) + (dns.get('6') or dns.get(6) or [])
        match = dns_match(info, public)
        label = {'match': '[COLOR green]matches the public address[/COLOR]',
                 'mismatch': '[COLOR orange]differs from the public address[/COLOR]',
                 'unknown': 'cannot compare'}[match]
        lines.append('    DNS: %s - %s' % (', '.join(resolved) or 'not resolvable', label))
    if not shown:
        lines.append('  No DDNS entry enabled.')

    pm = status.get('portmap') or {}
    lines.append('')
    lines.append(_b('Router port forwarding (UPnP / NAT-PMP / PCP)'))
    if not pm.get('enabled'):
        lines.append('  Off - configure forwarding manually if needed.')
    else:
        for mapping in pm.get('mappings', []):
            lines.append('  %s: port %d -> %d, lease %ss%s' % (
                mapping.get('method'), mapping.get('external_port'), mapping.get('internal_port'),
                mapping.get('lifetime'), ', router address %s' % mapping['external_ip']
                if mapping.get('external_ip') else ''))
        for err in pm.get('errors', []):
            lines.append('  [COLOR red]%s[/COLOR]' % err)
        if pm.get('message'):
            lines.append('  %s' % pm['message'])
        if not pm.get('mappings') and not pm.get('errors') and not pm.get('message'):
            lines.append('  Waiting for the first attempt.')
    return '\n'.join(lines)


def client_setup(status, cfg, local_ip, cert_warnings=None):
    public = status.get('public') or {}
    host = (cfg.hostnames() or [public.get('ipv4') or '<your public IP>'])[0]
    lines = [_b('Connect any standard proxy client with these values'), '']
    lines.append('  Username: %s' % cfg.username)
    lines.append('  Password: %s' % cfg.password)
    lines.append('')
    rows = []
    if cfg.http_enabled:
        rows.append(('HTTP proxy', 'http', cfg.shared_port if cfg.single_port else cfg.http_port))
    if cfg.tls_enabled:
        rows.append(('HTTPS proxy (TLS to the proxy)', 'https', cfg.shared_port if cfg.single_port else cfg.tls_port))
    if cfg.socks_enabled:
        rows.append(('SOCKS5 proxy', 'socks5h', cfg.shared_port if cfg.single_port else cfg.socks_port))
    for label, scheme, port in rows:
        public_port = external_port(port, status.get('portmap') or {})
        lines.append(_b(label))
        lines.append('  From the internet: %s port %d' % (host, public_port))
        if local_ip:
            lines.append('  At home: %s port %d' % (local_ip, port))
        lines.append('  URL form: %s://%s:<password>@%s:%d' % (scheme, cfg.username, host, public_port))
        lines.append('')
    lines.append('Internet ports use active automatic mappings. Without one, a manual rule is assumed to use '
                 'the same external and local port; adjust your client if your manual rule differs.')
    lines.append('')
    if cfg.tls_enabled:
        for warning in cert_warnings or []:
            lines.append('[COLOR orange]%s[/COLOR]' % warning)
        if cfg.tls_mode == config.TLS_CUSTOM:
            lines.append('Export contains only certificates from the configured file, not private keys. '
                         'It may not include the issuer CA; obtain that from your certificate provider.')
        else:
            lines.append('Export the public CA for clients that support it (e.g. curl --proxy-cacert; '
                         'on Windows also --ssl-revoke-best-effort).')
        lines.append('Not every client supports HTTPS proxies; plain HTTP does not protect the password.')
        lines.append('')
    if cfg.http_enabled and not cfg.tls_enabled:
        lines.append('[COLOR orange]Plain HTTP sends the password unencrypted. Enable the TLS listener for use '
                     'over the internet.[/COLOR]')
    if cfg.single_port:
        lines.append('Single-port SOCKS supports CONNECT only, not UDP or BIND. '
                     '3proxy logs do not show the original client IP.')
    lines.append('Only public internet destinations can be reached; your home network is blocked.')
    return '\n'.join(lines)
