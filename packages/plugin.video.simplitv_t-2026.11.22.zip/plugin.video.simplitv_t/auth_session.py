import hashlib
from contextlib import contextmanager
import json
import math
import os
import secrets
import sys
import threading
import time

import requests
from playback_media import media_files
from service_config import API_ROOT, PORTAL_ROOT, TENANT_CODENAME, service_scope


CACHE_PROPERTY = "simplitv_t.auth.session." + service_scope(API_ROOT, TENANT_CODENAME)
CACHE_SECONDS = 30 * 60
API_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0",
    "Content-type": "application/json;charset=utf-8",
    "X-Api-Date-Format": "iso", "X-Api-Camel-Case": "true",
    "Referer": PORTAL_ROOT + "/",
    "X-Tenant-Codename": TENANT_CODENAME
}


class AuthError(RuntimeError):
    pass


class AuthSession:
    def __init__(self, username, password, headers, window, log, session=None, lock_path=None):
        self.username = username
        self.password = password
        self.api_root = API_ROOT
        self.tenant = TENANT_CODENAME
        self.headers = dict(headers)
        self.headers["X-Tenant-Codename"] = self.tenant
        self.cache_property = "simplitv_t.auth.session." + service_scope(
            self.api_root, self.tenant)
        self.window = window
        self.log = log
        self.session = session if session is not None else requests.Session()
        self.lock_path = lock_path
        self.local_lock = threading.RLock()
        self.lock_depth = 0
        self.account = hashlib.sha256(
            json.dumps([self.api_root, self.tenant, username, password]).encode("utf-8")
        ).hexdigest()

    @contextmanager
    def _locked(self):
        with self.local_lock:
            if self.lock_depth:
                yield
                return
            lock_file = None
            try:
                if self.lock_path:
                    os.makedirs(os.path.dirname(self.lock_path), exist_ok=True)
                    lock_file = open(self.lock_path, "a+b")
                    if os.path.getsize(self.lock_path) == 0:
                        lock_file.write(b"\0")
                        lock_file.flush()
                    deadline = time.monotonic() + 90
                    while True:
                        try:
                            if os.name == "nt":
                                import msvcrt
                                lock_file.seek(0)
                                msvcrt.locking(lock_file.fileno(), msvcrt.LK_NBLCK, 1)
                            else:
                                import fcntl
                                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                            break
                        except OSError:
                            if time.monotonic() >= deadline:
                                raise AuthError("Timed out waiting for authentication preparation")
                            time.sleep(0.05)
                self.lock_depth = 1
                try:
                    yield
                finally:
                    self.lock_depth = 0
            except OSError:
                raise AuthError("Cannot access authentication preparation lock") from None
            finally:
                if lock_file is not None:
                    lock_file.close()

    def _cache(self):
        text = self.window.getProperty(self.cache_property)
        if not text:
            return {}
        try:
            cache = json.loads(text)
            valid = (
                isinstance(cache, dict)
                and cache.get("account") == self.account
                and isinstance(cache.get("expires"), (int, float))
                and math.isfinite(cache["expires"])
                and 0 < cache["expires"] - time.time() <= CACHE_SECONDS
                and isinstance(cache.get("token"), str)
                and bool(cache["token"])
                and isinstance(cache.get("device", ""), str)
            )
        except (ValueError, TypeError):
            valid = False
        if not valid:
            self.invalidate()
            return {}
        return cache

    def invalidate(self):
        self.window.clearProperty(self.cache_property)

    def _request(self, method, path, **kwargs):
        headers = dict(kwargs.pop("headers", self.headers))
        headers["X-Tenant-Codename"] = self.tenant
        try:
            response = self.session.request(
                method, self.api_root + path, timeout=15, allow_redirects=False,
                headers=headers, **kwargs
            )
        except requests.RequestException:
            # Request exceptions can contain URLs with tokens; never log their text.
            raise AuthError("simpliTV API connection failed") from None
        return response

    @staticmethod
    def _json(response):
        if not 200 <= response.status_code < 300:
            raise AuthError("simpliTV API returned HTTP {}".format(response.status_code))
        try:
            data = response.json()
        except ValueError:
            raise AuthError("simpliTV API returned invalid JSON") from None
        if not isinstance(data, dict):
            raise AuthError("simpliTV API returned an unexpected response")
        return data

    def token(self):
        with self._locked():
            return self._token()

    def _token(self):
        cache = self._cache()
        if cache:
            return cache["token"]
        response = self._request("POST", "/v1/OrsUser/Authenticate", data=json.dumps({
            "Login": self.username, "Password": self.password,
            "LongExpiration": "true", "platformCodename": "www"
        }))
        data = self._json(response)
        value = data.get("token")
        if not isinstance(value, str) or not value.strip():
            value = data.get("accessToken")
        if not isinstance(value, str) or not value.strip():
            raise AuthError("simpliTV login did not return a token")
        self.window.setProperty(self.cache_property, json.dumps({
            "account": self.account, "token": value,
            "expires": time.time() + CACHE_SECONDS, "device": ""
        }))
        return value

    def _devices(self, token):
        return self._request("GET", "/v1/Devices/GetDevices", params={
            "platformCodename": "www", "token": token
        })

    def devicekey(self):
        with self._locked():
            return self._devicekey()

    def _devicekey(self):
        token = self.token()
        cache = self._cache()
        if cache.get("device"):
            return cache["device"]
        response = self._devices(token)
        if response.status_code in (401, 403):
            self.log("Device lookup rejected authorization; refreshing once")
            self.invalidate()
            token = self.token()
            response = self._devices(token)
        devices = self._json(response).get("devices")
        if not isinstance(devices, list):
            raise AuthError("simpliTV returned an invalid device list")
        if not devices:
            response = self._request("POST", "/v1/Devices/RegisterDevice", data=json.dumps({
                "deviceKey": secrets.token_hex(16), "deviceName": "Firefox",
                "generalDeviceType": "2", "operatingSystem": "Windows",
                "platformCodename": "www", "pushToken": "",
                "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0",
                "userToken": token, "versionOs": "10"
            }))
            self._json(response)
            devices = self._json(self._devices(token)).get("devices")
        if not isinstance(devices, list) or not devices or not isinstance(devices[0], dict):
            raise AuthError("simpliTV did not return a registered device")
        key = devices[0].get("key")
        if not isinstance(key, str) or not key:
            raise AuthError("simpliTV did not return a device key")
        cache = self._cache()
        if cache and cache["token"] == token:
            cache["device"] = key
            self.window.setProperty(self.cache_property, json.dumps(cache))
        return key

    def acquire(self, codename, headers, require_success=False):
        with self._locked():
            return self._acquire(codename, headers, require_success)

    def _acquire(self, codename, headers, require_success=False):
        used_cache = bool(self._cache().get("device"))
        for attempt in range(2):
            key = self.devicekey()
            response = self._request("GET", "/v1/Player/AcquireContent", headers=headers,
                                     params={"platformCodename": "www", "deviceKey": key,
                                             "token": self.token(), "codename": codename})
            rejected = response.status_code in (401, 403)
            data = None if rejected else self._json(response)
            if require_success and not rejected:
                status = data.get("result", data.get("Result"))
                if not isinstance(status, dict) or status.get("success", status.get("Success")) is not True:
                    raise AuthError("simpliTV did not authorize catch-up playback")
            # The API can also return a failed acquisition as HTTP 200.
            if attempt == 0 and (rejected or (used_cache and not media_files(data))):
                self.log("Playback acquisition rejected cached session; refreshing once")
                self.invalidate()
                continue
            if rejected:
                self.invalidate()
                raise AuthError("simpliTV rejected playback authorization after refresh")
            if not media_files(data):
                raise AuthError("simpliTV returned no playable content")
            return data


def kodi_session():
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs

    addon = xbmcaddon.Addon("plugin.video.simplitv_t")
    return AuthSession(
        addon.getSetting("username"), addon.getSetting("password"), API_HEADERS,
        xbmcgui.Window(10000),
        lambda message: xbmc.log("[simpliTVᵀ] " + message, xbmc.LOGWARNING),
        lock_path=os.path.join(xbmcvfs.translatePath(addon.getAddonInfo("profile")), "auth.lock")
    )


def start_preparation(live_access=False):
    import xbmc
    import xbmcaddon

    addon = xbmcaddon.Addon("plugin.video.simplitv_t")
    script = os.path.join(addon.getAddonInfo("path"), "auth_session.py")
    xbmc.executebuiltin('RunScript("{}"{})'.format(script, ",live-access" if live_access else ""))


def prepare(live_access=False):
    import xbmc
    import xbmcaddon
    import xbmcgui

    session = kodi_session()
    try:
        if live_access:
            from channel_access import prepare_channel_grants, prepare_channel_branding, prepare_catchup_policy
            from live_cache import CHANNEL_SECONDS, LiveCache, LiveDataError

            cache = LiveCache(session.window, session.account, session.log)
            access = None
            try:
                access = prepare_channel_grants(session, cache, AuthError, CHANNEL_SECONDS)
            except (AuthError, LiveDataError) as error:
                session.log("Live channel access unavailable: {}".format(error))
            try:
                prepare_channel_branding(session, cache, CHANNEL_SECONDS,
                                         (access or {}).get("branding", {}))
            except LiveDataError as error:
                session.log("Live channel branding unavailable: {}".format(error))
            try:
                prepare_catchup_policy(session, cache, CHANNEL_SECONDS)
            except (AuthError, LiveDataError) as error:
                session.log("Catch-up policy unavailable: {}".format(type(error).__name__))
            return
        session.devicekey()
    except AuthError as error:
        xbmc.log("[simpliTVᵀ] Background preparation: " + str(error), xbmc.LOGERROR)
        addon = xbmcaddon.Addon("plugin.video.simplitv_t")
        xbmcgui.Dialog().notification(
            "simpliTVᵀ", "Anmeldung konnte nicht vorbereitet werden",
            addon.getAddonInfo("icon"), 5000
        )
    finally:
        session.session.close()


if __name__ == "__main__":
    prepare(live_access=sys.argv[1:] == ["live-access"])
