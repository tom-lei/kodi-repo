import datetime
import types
import unittest

from tv_behavior import ProgrammeBanner, StationHistory, live_target, programme_banner


class TvBehaviorTests(unittest.TestCase):
    def test_banner_progress_is_proportional_and_yields_to_seek_display(self):
        class Control:
            def __init__(self, *args, **kwargs):
                self.width = args[2]
                self.y, self.height = args[1], args[3]
                self.font = kwargs.get("font")

            def setWidth(self, width):
                self.width = width

            def setVisible(self, visible):
                self.visible = visible

            def setAnimations(self, _):
                pass

            def setLabel(self, label, **_):
                self.text = label

        window = types.SimpleNamespace(getWidth=lambda: 1920, getHeight=lambda: 1080,
                                       addControls=lambda _: None)
        gui = types.SimpleNamespace(ControlImage=Control, ControlLabel=Control)
        addon = types.SimpleNamespace(getAddonInfo=lambda _: "")
        banner = ProgrammeBanner(window, addon, gui, "font13", [], bottom=True,
                                 fonts=("font12", "font36_title", "font10"))
        self.assertEqual(banner.background.y + banner.background.height, 1080)
        station, title, following = banner.labels
        self.assertGreater(title.height, following.height)
        self.assertNotEqual(title.font, following.font)
        self.assertGreater(title.y, station.y + station.height)
        self.assertGreater(following.y, title.y + title.height)
        banner.show(("Station", "Current · until 21:00", "Next: News", 25))
        banner.update(True)
        self.assertTrue(banner.progress.visible)
        self.assertEqual(banner.progress.width, round(banner.track.width / 4))
        banner.update(False)
        self.assertFalse(any(control.visible for control in banner.controls))
        banner.show(("Station", "", "", 0))
        banner.update(True)
        self.assertTrue(banner.labels[0].visible)
        self.assertFalse(banner.track.visible)
        self.assertFalse(banner.progress.visible)

    def test_history_only_rotates_on_distinct_success(self):
        history = StationHistory()
        history.started("one")
        self.assertIsNone(history.target(["one", "two"]))
        history.started("two")
        history.started("two")
        self.assertEqual(history.target(["one", "two"]), "one")
        self.assertIsNone(history.target(["two"]))
        history.started("one")
        self.assertEqual(history.target(["one", "two"]), "two")

    def test_live_target_requires_current_seekable_live_stream_and_real_delay(self):
        enabled = {"Player.SeekEnabled"}
        kodi = types.SimpleNamespace(getCondVisibility=enabled.__contains__)
        player = types.SimpleNamespace(isPlayingVideo=lambda: True, getTime=lambda: 80,
                                       getTotalTime=lambda: 100)
        playback = dict(player=player, matches=lambda: True, live=True)
        self.assertEqual(live_target(playback, kodi), 100)
        player.getTime = lambda: 96
        self.assertIsNone(live_target(playback, kodi))
        player.getTime = lambda: 80
        enabled.add("Player.Seeking")
        self.assertIsNone(live_target(playback, kodi))
        enabled.remove("Player.Seeking")
        self.assertIsNone(live_target(dict(playback, matches=lambda: False), kodi))
        self.assertIsNone(live_target(dict(playback, live=False), kodi))

    def test_banner_uses_current_and_following_cached_entries(self):
        def event(code, start, stop, title):
            return dict(tileChannel={"codename": code}, start=start, stop=stop, title=title)

        stamp = "2026-11-20T20:"
        now = datetime.datetime.fromisoformat(stamp + "10:00+00:00").timestamp()
        current = event("one", stamp + "00:00Z", stamp + "20:00Z", "News")
        upcoming = event("one", stamp + "20:00Z", stamp + "50:00Z", "Movie")
        noise = event("two", stamp + "09:00Z", stamp + "20:00Z", "Other")
        station, title, next_title, progress = programme_banner(
            (noise, upcoming, current), "one", "Station", now)
        self.assertEqual(station, "Station")
        self.assertIn("News", title)
        self.assertEqual(next_title, "Next: Movie")
        self.assertEqual(progress, 50)
        self.assertEqual(programme_banner((noise, upcoming), "one", "Station", now),
                         ("Station", "", "", 0))
