import json
import os
import sys
import tempfile
import threading
import types
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    import requests
except ImportError:
    sys.modules["requests"] = types.SimpleNamespace(
        RequestException=type("RequestException", (Exception,), {})
    )
import auth_session


class Window:
    def __init__(self):
        self.values = {}

    def getProperty(self, name):
        return self.values.get(name, "")

    def setProperty(self, name, value):
        self.values[name] = value

    def clearProperty(self, name):
        self.values.pop(name, None)


def response(data, status=200):
    result = Mock(status_code=status)
    result.json.return_value = data
    return result


class AuthTests(unittest.TestCase):
    def test_background_preparation_and_playback_share_result(self):
        with tempfile.TemporaryDirectory() as folder:
            lock_path = os.path.join(folder, "auth.lock")
            started, release = threading.Event(), threading.Event()
            errors = []
            results = []

            def request(method, url, **kwargs):
                if url.endswith("Authenticate"):
                    started.set()
                    if not release.wait(5):
                        raise RuntimeError("Test preparation timed out")
                    return response({"token": "prepared-token"})
                if url.endswith("GetDevices"):
                    return response({"devices": [{"key": "prepared-device"}]})
                return response({"MediaFiles": [1]})

            self.session.request.side_effect = request
            background = auth_session.AuthSession(
                "test-user", "test-password", {}, self.window, self.log,
                self.session, lock_path=lock_path
            )
            foreground = auth_session.AuthSession(
                "test-user", "test-password", {}, self.window, self.log,
                self.session, lock_path=lock_path
            )

            def worker(operation):
                try:
                    results.append(operation())
                except Exception as error:
                    errors.append(error)

            preparing = threading.Thread(target=worker, args=(background.devicekey,))
            playing = threading.Thread(target=worker, args=(lambda: foreground.acquire("channel", {}),))
            preparing.start()
            try:
                self.assertTrue(started.wait(5))
                playing.start()
            finally:
                release.set()
                preparing.join(5)
                if playing.ident is not None:
                    playing.join(5)
            self.assertFalse(preparing.is_alive())
            self.assertFalse(playing.is_alive())
            self.assertEqual(errors, [])
            self.assertEqual(self.session.request.call_count, 3)
            self.assertIn("prepared-device", results)
            self.assertIn({"MediaFiles": [1]}, results)

    def test_failed_preparation_releases_lock_for_playback(self):
        with tempfile.TemporaryDirectory() as folder:
            lock_path = os.path.join(folder, "auth.lock")
            self.auth.lock_path = lock_path
            self.session.request.side_effect = [
                response({}, 500), response({"token": "test-token"}),
                response({"devices": [{"key": "test-device"}]})
            ]
            with self.assertRaises(auth_session.AuthError):
                self.auth.devicekey()
            foreground = self.client()
            foreground.lock_path = lock_path
            self.assertEqual(foreground.devicekey(), "test-device")

    def setUp(self):
        self.window = Window()
        self.session = Mock()
        self.log = Mock()
        self.auth = self.client()

    def client(self, password="test-password"):
        return auth_session.AuthSession(
            "test-user", password, {}, self.window, self.log, self.session
        )

    def prepare_cache(self):
        self.session.request.side_effect = [
            response({"token": "test-token"}),
            response({"devices": [{"key": "test-device"}]})
        ]
        self.assertEqual(self.auth.devicekey(), "test-device")
        self.session.reset_mock()
        self.session.request.side_effect = None

    def test_first_start_and_reuse_across_plugin_invocations(self):
        media = {"MediaFiles": [{"Formats": [{"Url": "test-stream"}]}]}
        self.session.request.side_effect = [
            response({"token": "test-token"}),
            response({"devices": [{"key": "test-device"}]}), response(media), response(media)
        ]
        self.assertEqual(self.auth.acquire("channel", {}), media)
        self.assertEqual(self.session.request.call_count, 3)
        self.assertEqual(self.client().acquire("next-channel", {}), media)
        self.assertEqual(self.session.request.call_count, 4)
        self.assertNotIn("test-password", self.window.getProperty(auth_session.CACHE_PROPERTY))

    def test_expiration_and_credentials_change(self):
        self.prepare_cache()
        cache = json.loads(self.window.getProperty(auth_session.CACHE_PROPERTY))
        with patch.object(auth_session.time, "time", return_value=cache["expires"] + 1):
            self.assertEqual(self.auth._cache(), {})
        self.prepare_cache()
        self.assertEqual(self.client("changed-password")._cache(), {})

    def test_access_token_is_only_a_nonblank_string_fallback(self):
        cases = [
            ({"token": "primary", "accessToken": "fallback"}, "primary"),
            ({"accessToken": "fallback"}, "fallback"),
            ({"token": [], "accessToken": "fallback"}, "fallback"),
            ({"token": " ", "accessToken": "fallback"}, "fallback"),
            ({"token": None, "accessToken": 123}, None),
            ({"accessToken": " "}, None),
        ]
        for data, expected in cases:
            with self.subTest(data=data):
                self.auth.invalidate()
                self.session.request.return_value = response(data)
                if expected is None:
                    with self.assertRaises(auth_session.AuthError):
                        self.auth.token()
                else:
                    self.assertEqual(self.auth.token(), expected)

    def test_lower_camel_media_does_not_refresh_or_change_scoped_headers(self):
        self.prepare_cache()
        media = {"MediaFiles": [], "mediaFiles": [{"formats": [{"url": "synthetic"}]}]}
        self.session.request.return_value = response(media)
        headers = {"Accept": "application/json", "X-Tenant-Codename": "unexpected"}
        self.assertEqual(self.auth.acquire("channel", headers), media)
        self.session.request.assert_called_once()
        self.assertEqual(self.session.request.call_args.kwargs["headers"],
                         {**headers, "X-Tenant-Codename": self.auth.tenant})
        self.assertEqual(headers["X-Tenant-Codename"], "unexpected")

    def test_rejection_refreshes_token_and_device_once(self):
        for status in (401, 403):
            with self.subTest(status=status):
                self.auth.invalidate()
                self.prepare_cache()
                media = {"MediaFiles": [1]}
                self.session.request.side_effect = [
                    response({}, status), response({"token": "new-token"}),
                    response({"devices": [{"key": "new-device"}]}), response(media)
                ]
                self.assertEqual(self.auth.acquire("channel", {}), media)
                self.assertEqual(self.session.request.call_count, 4)
                params = self.session.request.call_args.kwargs["params"]
                self.assertEqual(params["token"], "new-token")
                self.assertEqual(params["deviceKey"], "new-device")

    def test_catchup_requires_explicit_provider_success(self):
        self.prepare_cache()
        media = [{"Formats": [{"Url": "test-stream"}]}]
        for result in ({"Result": {"Success": True}, "MediaFiles": media},
                       {"result": {"success": True}, "mediaFiles": media}):
            self.session.request.reset_mock()
            self.session.request.return_value = response(result)
            self.assertEqual(self.auth.acquire("programme.1", {}, require_success=True), result)
            self.assertEqual(self.session.request.call_args.kwargs["params"]["codename"], "programme.1")
        for result in ({}, {"Result": {"Success": False}}, {"result": {"success": "true"}}):
            self.session.request.reset_mock()
            self.session.request.return_value = response(dict(result, MediaFiles=media))
            with self.assertRaises(auth_session.AuthError):
                self.auth.acquire("programme.1", {}, require_success=True)
            self.assertEqual(self.session.request.call_count, 1)

    def test_repeated_rejection_fails_and_clears_cache(self):
        self.prepare_cache()
        self.session.request.side_effect = [
            response({}, 401), response({"token": "new-token"}),
            response({"devices": [{"key": "new-device"}]}), response({}, 403)
        ]
        with self.assertRaises(auth_session.AuthError):
            self.auth.acquire("channel", {})
        self.assertEqual(self.session.request.call_count, 4)
        self.assertEqual(self.auth._cache(), {})

    def test_http_200_failed_cached_acquisition_refreshes_once(self):
        self.prepare_cache()
        self.session.request.side_effect = [
            response({"error": "rejected"}), response({"token": "new-token"}),
            response({"devices": [{"key": "new-device"}]}),
            response({"error": "still unavailable"})
        ]
        with self.assertRaises(auth_session.AuthError):
            self.auth.acquire("channel", {})
        self.assertEqual(self.session.request.call_count, 4)

    def test_server_failure_does_not_register_or_retry(self):
        self.prepare_cache()
        self.session.request.return_value = response({}, 500)
        with self.assertRaises(auth_session.AuthError):
            self.auth.acquire("channel", {})
        self.assertEqual(self.session.request.call_count, 1)

    def test_device_registration_only_for_empty_device_list(self):
        self.session.request.side_effect = [
            response({"token": "test-token"}), response({"devices": []}),
            response({}, 201), response({"devices": [{"key": "registered-device"}]})
        ]
        self.assertEqual(self.auth.devicekey(), "registered-device")
        self.assertEqual(self.session.request.call_count, 4)
        self.assertTrue(self.session.request.call_args_list[2].args[1].endswith("RegisterDevice"))

    def test_device_lookup_server_failure_does_not_register(self):
        self.session.request.side_effect = [
            response({"token": "test-token"}), response({}, 500)
        ]
        with self.assertRaises(auth_session.AuthError):
            self.auth.devicekey()
        self.assertEqual(self.session.request.call_count, 2)

    def test_network_errors_do_not_expose_token_urls(self):
        self.prepare_cache()
        self.session.request.side_effect = auth_session.requests.RequestException(
            "secret-token-in-url"
        )
        with self.assertRaises(auth_session.AuthError) as error:
            self.auth.acquire("channel", {})
        self.assertNotIn("secret-token", str(error.exception))


if __name__ == "__main__":
    unittest.main()
