import datetime
import json
import os
import sys
import tempfile
import threading
import time
import types
import unittest
import xml.etree.ElementTree as ET
from unittest import mock

ADDON_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ADDON_ROOT)

import guide
from guide import open_guide
from live_cache import LiveDataError


class Control:
    def __init__(self, x, y, width, height):
        if any(type(value) is not int for value in (x, y, width, height)):
            raise TypeError("integer argument expected for control geometry")
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self._id = None

    def getId(self):
        return self._id

    def setColorDiffuse(self, color):
        self.color = color

    def setVisible(self, visible):
        self.visible = visible

    def setAnimations(self, animations):
        self.animations = animations
        self.animation_updates = getattr(self, "animation_updates", 0) + 1

    def setPosition(self, x, y):
        self.x, self.y = x, y

    def setWidth(self, width):
        self.width = width

    def setHeight(self, height):
        self.height = height


class ControlImage(Control):
    def __init__(self, x, y, width, height, filename,
                 aspectRatio=0, colorDiffuse=None):
        super().__init__(x, y, width, height)
        self.filename = filename
        self.aspectRatio = aspectRatio
        self.colorDiffuse = colorDiffuse


class ControlLabel(Control):
    def __init__(self, x, y, width, height, label, font=None, textColor=None,
                 disabledColor=None, alignment=0, hasPath=False, angle=0):
        super().__init__(x, y, width, height)
        self.label = label
        self.font = font
        self.textColor = textColor
        self.disabledColor = disabledColor
        self.alignment = alignment

    def setLabel(self, label, shadowColor=""):
        self.label = label
        self.shadowColor = shadowColor


class ControlButton(Control):
    def __init__(self, x, y, width, height, label, focusTexture=None,
                 noFocusTexture=None, textOffsetX=10, textOffsetY=2,
                 alignment=0, font=None, textColor=None, disabledColor=None,
                 angle=0, shadowColor=None, focusedColor=None):
        super().__init__(x, y, width, height)
        self.label = label
        self.focusTexture = focusTexture
        self.noFocusTexture = noFocusTexture
        self.alignment = alignment
        self.textOffsetY = textOffsetY
        self.font = font
        self.textColor = textColor
        self.disabledColor = disabledColor
        self.focusedColor = focusedColor
        self.enabled = True

    def setEnabled(self, enabled):
        self.enabled = enabled

    def setLabel(self, label):
        self.label = label


class ControlTextBox(Control):
    def __init__(self, x, y, width, height, font=None, textColor=None):
        super().__init__(x, y, width, height)
        self.text = ""

    def setText(self, text):
        assert self.getId() is not None
        self.text = text


class WindowXMLDialog:
    constructor_args = None
    last_instance = None
    modal_callback = None
    dimensions = (1280, 720)

    def __new__(cls, xmlFilename, scriptPath, defaultSkin="Default",
                defaultRes="720p"):
        instance = object.__new__(cls)
        WindowXMLDialog.constructor_args = (
            xmlFilename, scriptPath, defaultSkin, defaultRes)
        WindowXMLDialog.last_instance = instance
        return instance

    def __init__(self, xmlFilename, scriptPath, defaultSkin="Default",
                 defaultRes="720p"):
        self.xmlFilename = xmlFilename
        self.scriptPath = scriptPath
        self.defaultSkin = defaultSkin
        self.defaultRes = defaultRes
        self._controls = []
        self._next_id = 3000
        self.focused_control = None
        self.focus_calls = 0
        self.removals = 0
        self.focus_messages = []
        self.focus_requests = []
        self.was_closed = False
        self.video = Control(0, 0, 312, 176)
        self.video_small = Control(0, 0, 216, 121)
        self.properties = {}

    def show(self):
        self.init_pending = True

    def getWidth(self):
        return self.dimensions[0]

    def getHeight(self):
        return self.dimensions[1]

    def addControl(self, control):
        control._id = self._next_id
        self._next_id += 1
        self._controls.append(control)

    def addControls(self, controls):
        for control in controls:
            self.addControl(control)

    def removeControls(self, controls):
        self.removals += len(controls)
        if self.focused_control in controls:
            self.focused_control = None
        self._controls = [control for control in self._controls
                          if control not in controls]

    def getControl(self, control_id):
        if control_id == 100:
            return self.video
        if control_id == 102:
            return self.video_small
        if control_id in (101, 103):
            raise RuntimeError("Unknown control type for python")
        return next(control for control in self._controls
                    if control.getId() == control_id)

    def setProperty(self, key, value):
        self.properties[key] = value

    def setFocus(self, control):
        assert control in self._controls and control.enabled
        self.focus_calls += 1
        self.focus_requests.append(control)

    def pump_focus(self):
        requests, self.focus_requests = self.focus_requests, []
        for control in requests:
            if control in self._controls and control.enabled:
                # Native setFocus queues a GUI message; Python callbacks can
                # arrive after the next requested focus has already landed.
                self.focused_control = control
                self.focus_messages.append(control.getId())
        messages, self.focus_messages = self.focus_messages, []
        for control_id in messages:
            self.onFocus(control_id)

    def getFocusId(self):
        if self.focused_control is None:
            raise RuntimeError("No control in this window has focus")
        return self.focused_control.getId()

    def close(self):
        self.was_closed = True
        self.onDeinit()


class Window:
    def __init__(self):
        self.properties = {}

    def getProperty(self, key):
        return self.properties.get(key, "")

    def setProperty(self, key, value):
        self.properties[key] = value


class Action:
    def __init__(self, action_id):
        self.action_id = action_id

    def getId(self):
        return self.action_id


def fake_xbmcgui(window, control_label=ControlLabel, notifications=None, context_choice=-1):
    return types.SimpleNamespace(
        Window=lambda window_id: window,
        WindowXMLDialog=WindowXMLDialog,
        getCurrentWindowDialogId=lambda: 13004,
        getCurrentWindowId=lambda: 10025,
        ControlImage=ControlImage,
        ControlLabel=control_label,
        ControlButton=ControlButton,
        ControlTextBox=ControlTextBox,
        Dialog=lambda: types.SimpleNamespace(
            notification=lambda *args, **kwargs:
                notifications.append(args[1]) if notifications is not None else None,
            contextmenu=lambda _: context_choice),
        ACTION_MOVE_LEFT=1,
        ACTION_MOVE_RIGHT=2,
        ACTION_MOVE_UP=3,
        ACTION_MOVE_DOWN=4,
        ACTION_PREVIOUS_MENU=10,
        ACTION_NAV_BACK=92,
    )


def fake_xbmc(language="en"):
    deadline = time.monotonic() + 5

    def sleep(milliseconds):
        dialog = WindowXMLDialog.last_instance
        if dialog.init_pending:
            dialog.init_pending = False
            dialog.onInit()
        elif WindowXMLDialog.modal_callback is not None:
            dialog.pump_focus()
            WindowXMLDialog.modal_callback(dialog)
        if time.monotonic() >= deadline:
            raise AssertionError("guide dialog did not finish")
        time.sleep(0.001)

    def is_visible(condition):
        raise AssertionError("guide lifecycle must not query GUI visibility: " + condition)

    return types.SimpleNamespace(
        Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                              waitForAbort=lambda s: sleep(s * 1000)),
        getCondVisibility=is_visible, sleep=sleep, ISO_639_1=0,
        getLanguage=lambda *_: language
    )


class GuideWindowConstructionTests(unittest.TestCase):
    def test_preview_setting_and_native_control_contract(self):
        root = ET.parse(os.path.join(ADDON_ROOT, "resources", "settings.xml")).getroot()
        setting = root.find(".//setting[@id='guide_mini_picture']")
        self.assertEqual((setting.get("type"), setting.get("default")), ("bool", "true"))
        xml = ET.parse(os.path.join(
            ADDON_ROOT, "resources", "skins", "Default", "1080i", "guide.xml"))
        group = xml.find(".//control[@type='group'][@id='100']")
        video = group.find("./control[@type='videowindow'][@id='101']")
        self.assertEqual(video.findtext("visible"),
                         "String.IsEqual(Window.Property(simplitv_t.guide.video),true)")
        self.assertEqual((video.findtext("width"), video.findtext("height")), ("312", "176"))
        self.assertEqual((group.findtext("width"), group.findtext("height")), ("312", "176"))
        group = xml.find(".//control[@type='group'][@id='102']")
        video = group.find("./control[@type='videowindow'][@id='103']")
        self.assertEqual((video.findtext("width"), video.findtext("height")), ("216", "121"))

    def test_preview_gates_current_stream_without_changing_grid_or_tuning(self):
        for owned in (True, False):
            with self.subTest(owned=owned):
                playing = types.SimpleNamespace(active=True, matches=True, setting=True)
                playback = {
                    "player": types.SimpleNamespace(isPlayingVideo=lambda: playing.active),
                    "matches": lambda: playing.matches,
                    "owned_window": owned,
                }
                media = fake_xbmc()
                gui = fake_xbmcgui(Window())
                starts = []

                def interact(dialog):
                    self.assertTrue(dialog.mini_active)
                    self.assertEqual(dialog.properties["simplitv_t.guide.video"], "true")
                    self.assertRaises(RuntimeError, dialog.getControl, 101)
                    rows = [(c.x, c.y, c.width, c.height)
                            for k, (_, c) in dialog.slots.items()
                            if isinstance(k, tuple) and k[0] == "row"]
                    self.assertGreaterEqual(dialog.video.x, dialog.detail_label.x + dialog.detail_label.width)
                    self.assertLessEqual(dialog.video.y + 121, dialog.watch_button.y)
                    dialog.onAction(Action(4))
                    self.assertEqual(starts, [])
                    playing.setting = False
                    dialog._render()
                    self.assertFalse(dialog.mini_active)
                    self.assertEqual(dialog.properties["simplitv_t.guide.video"], "")
                    self.assertEqual(rows, [(c.x, c.y, c.width, c.height)
                                            for k, (_, c) in dialog.slots.items()
                                            if isinstance(k, tuple) and k[0] == "row"])
                    playing.setting = True
                    playing.matches = False
                    dialog._render()
                    self.assertFalse(dialog.mini_active)
                    playing.matches = True
                    playing.active = False
                    dialog._render()
                    self.assertFalse(dialog.mini_active)
                    playing.active = True
                    dialog._render()
                    self.assertTrue(dialog.mini_active)
                    dialog._return_to_stream(activate=False)

                WindowXMLDialog.modal_callback = interact
                try:
                    with mock.patch.dict(sys.modules, {"xbmc": media, "xbmcgui": gui}):
                        result = open_guide(
                            ["one", "two"], lambda *_: [], lambda *_: [], str,
                            ADDON_ROOT, self.fail, "preview-test", datetime.timezone.utc,
                            start_playback=lambda *args: starts.append(args),
                            owned_playback=playback, mini_picture=lambda: playing.setting)
                finally:
                    WindowXMLDialog.modal_callback = None
                self.assertIs(result["player"], playback["player"])
                self.assertTrue(result["fullscreen"])
                self.assertEqual(starts, [])

    def test_preview_fits_details_area_without_changing_grid(self):
        for dimensions, expected in (((1920, 1080), (312, 176)),
                                     ((640, 480), (216, 121)),
                                     ((320, 360), None)):
            with self.subTest(dimensions=dimensions):
                WindowXMLDialog.dimensions = dimensions
                playback = {
                    "player": types.SimpleNamespace(isPlayingVideo=lambda: True),
                    "matches": lambda: True,
                }
                media = fake_xbmc()
                gui = fake_xbmcgui(Window())

                def interact(dialog):
                    self.assertEqual(dialog._video_size(), expected)
                    self.assertEqual(dialog.mini_active, expected is not None)
                    rows = [(c.x, c.y, c.width, c.height)
                            for k, (_, c) in dialog.slots.items()
                            if isinstance(k, tuple) and k[0] == "row"]
                    if expected:
                        self.assertEqual((dialog.video.width, dialog.video.height), expected)
                        self.assertLessEqual(dialog.video.y + expected[1] + 8, dialog.watch_button.y)
                        self.assertLessEqual(dialog.detail_label.x + dialog.detail_label.width,
                                             dialog.video.x)
                    dialog.close()
                    self.assertEqual(len(rows), dialog.visible_count)

                WindowXMLDialog.modal_callback = interact
                try:
                    with mock.patch.dict(sys.modules, {"xbmc": media, "xbmcgui": gui}):
                        open_guide(
                            ["one"] * 12, lambda *_: [], lambda *_: [], str,
                            ADDON_ROOT, self.fail, "small-preview", datetime.timezone.utc,
                            owned_playback=playback, mini_picture=lambda: True)
                finally:
                    WindowXMLDialog.modal_callback = None
                    WindowXMLDialog.dimensions = (1280, 720)

    def test_abort_during_guide_startup_skips_native_close_and_late_callbacks(self):
        state = types.SimpleNamespace(aborted=False)
        media = fake_xbmc()
        gui = fake_xbmcgui(Window())

        def wait(_):
            dialog = WindowXMLDialog.last_instance
            state.aborted = True
            dialog.onInit()
            dialog.onAction(Action(10))
            return True

        media.Monitor = lambda: types.SimpleNamespace(
            abortRequested=lambda: state.aborted, waitForAbort=wait)
        with mock.patch.dict(sys.modules, {"xbmc": media, "xbmcgui": gui}):
            result = guide.open_guide(
                ["one"], lambda *_: self.fail("loaded a page after abort"), None, str,
                ADDON_ROOT, self.fail, "abort-guide", datetime.timezone.utc)
        dialog = WindowXMLDialog.last_instance
        self.assertIsNone(result)
        self.assertTrue(dialog.cancel.is_set())
        self.assertFalse(dialog.initialized)
        self.assertFalse(dialog.was_closed)  # No native window message during shutdown.

    def test_remote_settings_remains_reachable_without_channel_data(self):
        for language in ("en", "de"):
            for status in ("loading", "", "error"):
                opened = []
                window = Window()
                saved = '{"channel":"two","view":0}'
                window.setProperty("simplitv_t.guide.selection.remote-account", saved)
                previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
                sys.modules.update(xbmc=fake_xbmc(language), xbmcgui=fake_xbmcgui(window))

                def interact(dialog):
                    labels = guide.GUIDE_TEXT[language == "de"]
                    self.assertNotIn("main-menu", dialog.slots)
                    self.assertEqual(dialog.settings_button.label, labels["settings"])
                    self.assertEqual(dialog.getFocusId(), dialog.settings_button.getId())
                    dialog.onAction(Action(2))
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), dialog.settings_button.getId())
                    dialog.onClick(dialog.getFocusId())
                    self.assertEqual(opened, ["settings"])
                    self.assertFalse(dialog.closed)
                    dialog._render()
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), dialog.settings_button.getId())
                    dialog.onAction(Action(1))
                    dialog.pump_focus()
                    dialog.onAction(Action(92))

                WindowXMLDialog.modal_callback = interact
                try:
                    result = open_guide(
                        [], lambda *_: self.fail("Unexpected data probe"), lambda *_: [],
                        str, ADDON_ROOT, lambda *_: None, "remote-account",
                        datetime.timezone.utc, access_status=status,
                        open_settings=lambda: opened.append("settings"))
                    self.assertIsNone(result)
                    self.assertEqual(window.getProperty(
                        "simplitv_t.guide.selection.remote-account"), saved)
                finally:
                    WindowXMLDialog.modal_callback = None
                    for name, module in previous.items():
                        if module is None:
                            sys.modules.pop(name, None)
                        else:
                            sys.modules[name] = module

    def test_initial_back_closes_without_playback_and_down_reaches_settings(self):
        for channels in ([], ["one"]):
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))

            def interact(dialog):
                if channels:
                    dialog.onAction(Action(4))
                    dialog.pump_focus()
                self.assertEqual(dialog.getFocusId(), dialog.settings_button.getId())
                dialog.onAction(Action(92))

            WindowXMLDialog.modal_callback = interact
            try:
                self.assertIsNone(open_guide(
                    channels, lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                    lambda *_: None, "back-account", datetime.timezone.utc,
                    start_playback=lambda *_: self.fail("Unexpected playback")))
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_startup_logo_resolves_only_existing_local_files(self):
        logo = "https://example.invalid/logo.png"
        with tempfile.TemporaryDirectory() as folder:
            local = os.path.join(folder, "local.png")
            with open(local, "wb"):
                pass
            paths = {"special://thumbnails/a/abc.png": local}
            old_vfs = sys.modules.get("xbmcvfs")
            sys.modules["xbmcvfs"] = types.SimpleNamespace(translatePath=lambda p: paths.get(p, p))
            try:
                def rpc(request):
                    query = json.loads(request)
                    self.assertEqual(query["method"], "Textures.GetTextures")
                    self.assertEqual(query["params"]["filter"]["value"], logo)
                    return json.dumps({"result": {"textures": [
                        {"cachedurl": "../invalid.png"}, {"cachedurl": "a/abc.png"}]}})

                xbmc = types.SimpleNamespace(executeJSONRPC=rpc)
                self.assertEqual(guide.local_startup_logo(xbmc, local), local)
                self.assertEqual(guide.local_startup_logo(xbmc, logo), "special://thumbnails/a/abc.png")
                paths.clear()
                self.assertIsNone(guide.local_startup_logo(xbmc, logo))
            finally:
                if old_vfs is None:
                    sys.modules.pop("xbmcvfs", None)
                else:
                    sys.modules["xbmcvfs"] = old_vfs

    def test_playable_only_waits_for_grants_and_restores_selection(self):
        window = Window()
        window.setProperty("simplitv_t.guide.selection.synthetic-account", '{"channel":"two"}')
        states = iter([([], "error"), (["one", "two"], "")])
        seen = []

        def interact(dialog):
            seen.append((list(dialog.channels), dialog.detail_label.label))
            if len(seen) == 1:
                self.assertFalse(dialog.watch_button.enabled)
            if len(seen) == 2:
                self.assertFalse(dialog.watch_button.enabled)
            if len(seen) == 3:
                self.assertEqual(dialog.channels[dialog.selected_channel], "two")
                self.assertTrue(dialog.watch_button.enabled)
                dialog.onAction(Action(92))
            dialog.check_channels_after = 0

        previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
        sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(window))
        WindowXMLDialog.modal_callback = interact
        try:
            open_guide(
                [], lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                lambda *_: None, "synthetic-account", datetime.timezone.utc,
                refresh_channels=lambda: next(states), access_status="loading")
            self.assertEqual(seen[0], ([], "Checking channel access…"))
            self.assertEqual(seen[1], ([], "Channel access could not be checked"))
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

    def test_header_clock_and_marker_advance_without_input(self):
        timezone = datetime.timezone(datetime.timedelta(hours=2))
        initial = datetime.datetime(2026, 6, 1, 10, 15, 5, tzinfo=datetime.timezone.utc)
        for language, date in (("de", "01.06.2026"), ("en", "01 Jun 2026")):
            now = initial.timestamp()
            clock = types.SimpleNamespace(time=lambda: now, monotonic=time.monotonic)
            ticks = []

            def interact(dialog):
                nonlocal now
                marker = dialog.slots["now-line", dialog.marker_layer][1]
                ticks.append((dialog.control_labels["status"], marker.x))
                if len(ticks) < 3:
                    now += 30
                else:
                    dialog.onAction(Action(92))

            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            original_clock = guide.time
            guide.time = clock
            sys.modules.update(xbmc=fake_xbmc(language), xbmcgui=fake_xbmcgui(Window()))
            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(
                    ["one"], lambda *_: [], lambda *_: self.fail("Unexpected data fetch"),
                    str, ADDON_ROOT, lambda *_: None, "synthetic-account", timezone)
                self.assertEqual([status for status, _ in ticks],
                                 [date + ", 12:15", date + ", 12:15", date + ", 12:16"])
                self.assertEqual(ticks[0][1], ticks[1][1])
                self.assertGreater(ticks[2][1], ticks[1][1])
            finally:
                guide.time = original_clock
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_now_line_is_clipped_to_timeline_and_actual_rows(self):
        from unittest.mock import patch

        now = datetime.datetime(2026, 6, 1, 10, tzinfo=datetime.timezone.utc).timestamp()
        clock = types.SimpleNamespace(time=lambda: now, monotonic=time.monotonic)

        def interact(dialog):
            grid_top = max(58, int(dialog.height * 0.085)) + 36 + 8
            grid_bottom = dialog.height - dialog._footer_height() - 18
            row_height = (grid_bottom - grid_top) // dialog.visible_count
            left = max(124, int(dialog.width * 0.15)) + 18
            right = dialog.width - max(18, int(dialog.width * 0.02))
            self.assertGreater(dialog.visible_count, 2)
            for elapsed, expected_x, expected_width in (
                    (0, left, 2),
                    (guide.TIMELINE_SECONDS // 2, (left + right) // 2 - 1, 2),
                    (guide.TIMELINE_SECONDS, right - 2, 2)):
                dialog.view_start = now - elapsed
                dialog._render()
                line = dialog.slots["now-line", dialog.marker_layer][1]
                self.assertEqual((line.x, line.y, line.width, line.height),
                                 (expected_x, grid_top, expected_width, row_height * 2))
                self.assertEqual(dialog.image_colors[("now-line", dialog.marker_layer)],
                                 "0x" + guide.TIMELINE_MARKER_COLOR)
                self.assertNotIn("now", dialog.slots)
            dialog.channels.clear()
            dialog._render()
            self.assertFalse(any(isinstance(key, tuple) and key[0] == "now-line"
                                 for key in dialog.slots))
            self.assertNotIn("now", dialog.slots)
            dialog.onAction(Action(92))

        WindowXMLDialog.modal_callback = interact
        try:
            with patch.object(guide, "time", clock), patch.dict(
                    sys.modules, {"xbmc": fake_xbmc(), "xbmcgui": fake_xbmcgui(Window())}):
                open_guide(["one", "two"], lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                           lambda *_: None, "synthetic-account", datetime.timezone.utc)
        finally:
            WindowXMLDialog.modal_callback = None

    def test_playback_handoff_keeps_guide_visible_and_accepts_only_one_click(self):
        for outcome in ("success", "failure", "cancel"):
            states = []
            notifications = []

            def start_playback(selection):
                dialog = WindowXMLDialog.last_instance
                self.assertIn("startup-static", dialog.slots)
                self.assertNotIn("startup-plate", dialog.slots)
                field, station, snow, status = (dialog.slots[key][1] for key in (
                    "startup-static", "startup-station", ("startup-interference", None),
                    "startup-status"))
                self.assertLess(field.getId(), station.getId())
                self.assertLess(station.getId(), snow.getId())
                self.assertEqual((snow.x, snow.width), (field.x, field.width))
                self.assertEqual((field.x, field.y, field.width, field.height),
                                 (0, 0, dialog.width, dialog.height))
                self.assertEqual(dialog.startup_frame, 0)
                self.assertTrue(field.visible)
                start = dialog.startup_clock
                frames = set()
                frame_controls = [dialog.slots[key][1] for key in
                                  ["startup-static"] + [("startup-static", index)
                                                       for index in range(1, len(frameset[0]))]]
                for step in range(18):
                    dialog.startup_clock = time.monotonic() - (step + 0.25) / 12
                    dialog._animate_startup()
                    frames.add(dialog.startup_frame)
                    self.assertEqual(sum(control.visible for control in frame_controls), 1)
                    self.assertTrue(frame_controls[dialog.startup_frame].visible)
                self.assertGreaterEqual(len(frames), 16)
                dialog.startup_clock = start
                self.assertTrue(all(os.path.isfile(control.filename) for control in frame_controls))
                self.assertTrue(os.path.isfile(snow.filename))
                self.assertTrue(status.shadowColor)
                self.assertEqual(dialog.control_labels["startup-station"], "one")
                self.assertTrue(os.path.isfile(dialog.slots["startup-static"][1].filename))
                return simulate_playback(selection)

            def simulate_playback(selection):
                try:
                    states.append(selection)
                    self.assertFalse(WindowXMLDialog.last_instance.was_closed)
                    yield
                    dialog = WindowXMLDialog.last_instance
                    logo = dialog.slots["startup-logo"][1]
                    snow = dialog.slots[("startup-interference", logo.filename)][1]
                    self.assertLess(logo.getId(), snow.getId())
                    self.assertEqual((logo.width, logo.height), (448, 208))
                    self.assertEqual(logo.aspectRatio, 2)
                    self.assertLessEqual(snow.y, logo.y)
                    self.assertGreaterEqual(snow.y + snow.height, logo.y + logo.height)
                    self.assertLessEqual(snow.y + snow.height, dialog.slots["startup-station"][1].y)
                    if outcome == "failure":
                        raise RuntimeError("synthetic playback failure")
                    states.append("ready")
                    return "owned-playback"
                finally:
                    states.append("closed")

            def interact(dialog):
                if dialog.handoff is None and not states:
                    button = dialog.watch_button.getId()
                    dialog.onClick(button)
                    dialog.onAction(Action(7))
                    dialog.onClick(button)
                    self.assertFalse(dialog.was_closed)
                    self.assertIn("Starting playback", dialog.control_labels["status"])
                elif outcome == "cancel" or notifications:
                    self.assertEqual("startup-static" in dialog.slots, outcome == "cancel")
                    self.assertFalse(dialog.was_closed)
                    dialog.onAction(Action(92))

            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(),
                               xbmcgui=fake_xbmcgui(Window(), notifications=notifications))
            original_lookup = guide.local_startup_logo
            guide.local_startup_logo = lambda *_: "special://thumbnails/a/demo.png"
            WindowXMLDialog.modal_callback = interact
            try:
                # The UI harness only needs existing files; cache and PNG output are tested separately.
                placeholder = os.path.join(ADDON_ROOT, "resources", "skins", "Default", "media", "guide-solid.png")
                frameset = ((placeholder,) * 36, (placeholder,) * 36)
                result = open_guide(
                    ["one"], lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                    lambda *_: None, "synthetic-account", datetime.timezone.utc,
                    channel_logo=lambda *_: "https://example.invalid/logo.png",
                    start_playback=start_playback, peek_crt=lambda: frameset)
                expected = [{"channel": "one", "metadata": {
                    "title": "one", "plot": "", "logo": "https://example.invalid/logo.png"}}]
                if outcome == "success":
                    expected.append("ready")
                self.assertEqual(states, expected + ["closed"])
                self.assertEqual(result, "owned-playback" if outcome == "success" else None)
                self.assertEqual(len(notifications), int(outcome == "failure"))
            finally:
                guide.local_startup_logo = original_lookup
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_cold_tune_stays_black_with_local_logo_after_noise_becomes_ready(self):
        from unittest.mock import patch

        seen = []
        art = "special://thumbnails/a/demo.png"

        def start_playback(_):
            dialog = WindowXMLDialog.last_instance
            black = dialog.slots["startup-black"][1]
            self.assertEqual((black.x, black.y, black.width, black.height),
                             (0, 0, dialog.width, dialog.height))
            self.assertEqual(black.colorDiffuse, "0xFF000000")
            self.assertNotIn("startup-logo", dialog.slots)
            seen.append("acquiring")
            yield
            logo = dialog.slots["startup-logo"][1]
            self.assertEqual(logo.filename, art)
            self.assertEqual((logo.width, logo.height, logo.aspectRatio), (448, 208, 2))
            self.assertGreater(logo.getId(), black.getId())
            keys = {key for key in dialog.slots if isinstance(key, str) and key.startswith("startup-")}
            self.assertEqual(keys, {"startup-black", "startup-logo"})
            seen.append("ready")
            return "owned-playback"

        def interact(dialog):
            if dialog.handoff is None and not seen:
                dialog.onClick(dialog.watch_button.getId())

        def peek_crt():
            return (("snow",), ("signal",)) if seen else None

        WindowXMLDialog.modal_callback = interact
        try:
            with patch.dict(sys.modules, {"xbmc": fake_xbmc(), "xbmcgui": fake_xbmcgui(Window())}), \
                    patch.object(guide, "local_startup_logo", return_value=art):
                result = open_guide(
                    ["one"], lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                    lambda *_: None, "synthetic-account", datetime.timezone.utc,
                    channel_logo=lambda *_: "https://example.invalid/logo.png",
                    start_playback=start_playback, peek_crt=peek_crt)
            self.assertEqual((result, seen), ("owned-playback", ["acquiring", "ready"]))
        finally:
            WindowXMLDialog.modal_callback = None

    def test_return_to_owned_paused_stream_and_stop_are_separate_from_back(self):
        for action in ("button", "owned-window", "empty-lineup", "tab", "native-fullscreen", "back", "stop", "replaced", "ended"):
            state = {"playing": True, "matches": True}
            stopped, commands = [], []
            current_window = [10025]
            player = types.SimpleNamespace(isPlayingVideo=lambda: state["playing"],
                                           paused=True, position=452.25)

            def stop():
                stopped.append(True)
                state["playing"] = False

            player.stop = stop
            owned = {"player": player, "matches": lambda: state["matches"], "fullscreen": True}
            if action == "owned-window":
                owned["owned_window"] = True

            def interact(dialog):
                self.assertIsNotNone(dialog.return_button)
                old_button = dialog.return_button.getId()
                if action == "empty-lineup":
                    dialog.onAction(Action(117))
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), old_button)
                    self.assertFalse(dialog.watch_button.enabled)
                    dialog.onClick(old_button)
                elif action in ("button", "owned-window"):
                    dialog.onAction(Action(117))
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), old_button)
                    dialog.onAction(Action(1))
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), dialog.watch_button.getId())
                    dialog.onAction(Action(2))
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), old_button)
                    dialog.onClick(old_button)
                elif action == "tab":
                    dialog.onAction(Action(18))
                elif action == "native-fullscreen":
                    current_window[0] = 12005
                elif action == "back":
                    dialog.onAction(Action(92))
                elif action == "stop":
                    dialog.onAction(Action(13))
                    self.assertIsNone(dialog.return_button)
                    self.assertFalse(dialog.closed)
                    dialog.onAction(Action(92))
                else:
                    state["matches" if action == "replaced" else "playing"] = False
                    dialog._apply_pending()
                    self.assertIsNone(dialog.return_button)
                    dialog.onClick(old_button)
                    dialog.onAction(Action(18))
                    self.assertFalse(dialog.closed)
                    dialog.onAction(Action(92))

            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            xbmc = fake_xbmc()
            xbmc.executebuiltin = commands.append
            gui = fake_xbmcgui(Window())
            gui.getCurrentWindowId = lambda: current_window[0]
            sys.modules.update(xbmc=xbmc, xbmcgui=gui)
            WindowXMLDialog.modal_callback = interact
            try:
                result = open_guide(
                    [] if action == "empty-lineup" else ["one"],
                    lambda *_: [], lambda *_: self.fail("unexpected fetch"),
                    str, ADDON_ROOT, lambda *_: None, "owned", datetime.timezone.utc,
                    start_playback=lambda *_: self.fail("return must not acquire or play"),
                    owned_playback=owned)
                if action in ("button", "owned-window", "empty-lineup", "tab", "native-fullscreen"):
                    self.assertIs(result["player"], player)
                    self.assertEqual(result["fullscreen"], action == "native-fullscreen")
                    self.assertEqual(commands, [] if action in ("native-fullscreen", "owned-window") else
                                     ["ActivateWindow(fullscreenvideo)"])
                else:
                    self.assertIsNone(result)
                    self.assertEqual(commands, [])
                self.assertEqual(stopped, [True] if action == "stop" else [])
                self.assertTrue(player.paused)
                self.assertEqual(player.position, 452.25)
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_short_rows_and_footer_fit_without_glyphs_markup_or_partial_lines(self):
        now = int(time.time())
        event = {
            "id": "layout", "title": "Programme title", "isCatchupEnabled": True, "isBlackouted": False,
            "description": "First<br />Second &amp; third<p>" + "Long description " * 120 + "</p>",
            "start": datetime.datetime.fromtimestamp(now - 300, datetime.timezone.utc).isoformat(),
            "stop": datetime.datetime.fromtimestamp(now + 1800, datetime.timezone.utc).isoformat(),
            "tileChannel": {"codename": "one"}}
        for dimensions in ((1280, 720), (1920, 1080), (960, 600)):
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc("de"), xbmcgui=fake_xbmcgui(Window()))
            WindowXMLDialog.dimensions = dimensions

            def interact(dialog):
                labels = [control for key, (_, control) in dialog.slots.items()
                          if isinstance(key, tuple) and key[0] == "synopsis"]
                self.assertTrue(labels)
                self.assertTrue(labels[0].label.startswith("First"))
                self.assertNotIn("<", "".join(label.label for label in labels))
                self.assertNotIn("&amp;", "".join(label.label for label in labels))
                self.assertTrue(labels[-1].label.endswith("…"))
                self.assertTrue(all(label.height == 28 and label.width > 0 for label in labels))
                self.assertLess(labels[-1].y + labels[-1].height, dialog.watch_button.y)
                for control in (dialog.watch_button, dialog.start_button, dialog.slots["help"][1]):
                    self.assertLessEqual(control.y + control.height, dialog.height)
                    self.assertLessEqual(control.x + control.width, dialog.width)
                badge = dialog.getControl(next(iter(dialog.restart_controls)))
                body = dialog.getControl(next(iter(dialog.event_controls)))
                self.assertEqual(badge.label, "")
                self.assertLessEqual(badge.x + badge.width, body.x)
                self.assertEqual(badge.y, body.y)
                self.assertGreaterEqual(body.height, badge.height)
                dialog.onAction(Action(92))

            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(["one"] + ["other{}".format(i) for i in range(15)],
                           lambda *_: [event], lambda *_: [], str, ADDON_ROOT, lambda *_: None,
                           "layout", datetime.timezone.utc,
                           rewind_observation=lambda _: {"seconds": 7200, "format": "DASH/Widevine"})
            finally:
                WindowXMLDialog.dimensions = (1280, 720)
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_mojibake_repairs_only_complete_valid_sequences_in_mixed_text(self):
        self.assertEqual(guide.repair_mojibake("KÃ¼che â€“ GrÃ¶ÃŸe"), "Küche – Größe")
        for text in ("Küche", "Ã la carte", "plain", "\u00e0\u0080\u0080", "â€"):
            with self.subTest(text=text):
                self.assertEqual(guide.repair_mojibake(text), text)
        for encoding in ("cp1252", "latin-1"):
            garbled = "„Ä 😀".encode("utf-8").decode(encoding)
            self.assertEqual(guide.repair_mojibake("schön " + garbled), "schön „Ä 😀")
        self.assertEqual(guide.description_text("Die KÃ¼che<br>Die Küche – Ã la carte"),
                         "Die Küche\nDie Küche – Ã la carte")
        metadata = guide.playback_metadata("PULS 4", None, {
            "title": "In der KÃ¼che", "description": "SchÃ¶n und gemütlich"})
        self.assertEqual((metadata["title"], metadata["plot"]),
                         ("PULS 4 — In der Küche", "Schön und gemütlich"))

    def test_playback_metadata_matches_live_or_selected_catchup_programme(self):
        now = int(time.time())

        def event(identifier, title, start, stop):
            return {
                "id": identifier, "codename": identifier, "title": title,
                "description": "First<br>Second &amp; third",
                "isBlackouted": False, "isCatchupEnabled": True,
                "start": datetime.datetime.fromtimestamp(now + start, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(now + stop, datetime.timezone.utc).isoformat(),
                "tileChannel": {"codename": "one", "title": "Station", "logoUrl": "station.png"},
            }

        past = event("past", "Past", -1800, -300)
        current = event("current", "Current", -300, 300)
        future = event("future", "Future", 300, 1800)
        for action, selected, title in (("watch_live", future, "Station — Current"),
                                        ("catchup", past, "Station — Past")):
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))
            received = []

            def start_playback(selection):
                received.append(selection)
                yield
                return "owned-playback"

            def interact(dialog):
                if dialog.handoff is None and not received:
                    dialog._select_event(selected)
                    dialog._activate(action)

            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(["one"], lambda *_: [past, current, future], lambda *_: [],
                           str, ADDON_ROOT, lambda *_: None, "metadata", datetime.timezone.utc,
                           start_playback=start_playback, catchup_eligible=lambda *_: True)
                self.assertEqual(len(received), 1)
                self.assertEqual(received[0]["metadata"], {
                    "title": title, "plot": "First\nSecond & third", "logo": "station.png"})
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_native_activation_starts_one_playable_programme(self):
        for offset, stop, restart, gesture in (
                (-120, 120, False, 7), (-1200, -600, True, 100), (120, 600, True, 7)):
            now = int(time.time())
            event = {
                "id": "test", "title": "Programme", "isCatchupEnabled": restart, "isBlackouted": False,
                "start": datetime.datetime.fromtimestamp(now + offset, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(now + stop, datetime.timezone.utc).isoformat(),
                "tileChannel": {"codename": "one"},
            }
            notifications = []

            def interact(dialog):
                button = next(iter(dialog.event_controls))
                # Kodi's native button emits onClick before the corresponding onAction.
                dialog.onClick(button)
                dialog.onAction(Action(gesture))
                if offset > 0:
                    self.assertTrue(not dialog.closed)
                    self.assertEqual(len(notifications), 1)
                    dialog.onAction(Action(92))
                else:
                    self.assertTrue(dialog.closed)
                    dialog.onClick(dialog.watch_button.getId())

            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(),
                               xbmcgui=fake_xbmcgui(Window(), notifications=notifications))
            WindowXMLDialog.modal_callback = interact
            try:
                result = open_guide(
                    ["one"], lambda *_: [event], lambda *_: [], str, ADDON_ROOT,
                    lambda *_: None, "synthetic-account", datetime.timezone.utc,
                    rewind_observation=lambda _: {"seconds": 7200, "format": "DASH/Widevine"})
                expected = None if offset > 0 else {"channel": "one"}
                if stop < 0:
                    expected["start"] = float(now + offset)
                    expected["stop"] = float(now + stop)
                self.assertEqual(result, expected)
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_catchup_badge_selects_provider_playback_not_rewind(self):
        now = int(time.time())
        event = {"id": "prg.1", "codename": "programme.1", "title": "Programme",
                 "isBlackouted": False, "isCatchupEnabled": True,
                 "start": datetime.datetime.fromtimestamp(now - 3000, datetime.timezone.utc).isoformat(),
                 "stop": datetime.datetime.fromtimestamp(now - 600, datetime.timezone.utc).isoformat(),
                 "tileChannel": {"codename": "one"}}
        previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
        sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))

        def interact(dialog):
            event_id = next(iter(dialog.event_controls))
            dialog.focused_control = dialog.getControl(event_id)
            dialog.onFocus(event_id)
            badge_id = next(iter(dialog.restart_controls))
            badge = dialog.getControl(badge_id)
            self.assertTrue(badge.noFocusTexture.endswith("guide-catchup.png"))
            self.assertEqual(dialog.start_button.label, "Watch Catch-up")
            dialog.onClick(badge_id)

        WindowXMLDialog.modal_callback = interact
        try:
            result = open_guide(
                ["one"], lambda *_: [event], lambda *_: [], str, ADDON_ROOT,
                lambda *_: None, "catchup-account", datetime.timezone.utc,
                rewind_observation=lambda _: {"seconds": 7200, "format": "DASH/Widevine"},
                catchup_eligible=lambda programme, _: programme is event)
            self.assertEqual(result["channel"], "one")
            self.assertIs(result["catchup"], event)
            self.assertNotIn("start", result)
            self.assertIn("request", result)
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

    def test_rewind_badge_uses_observation_or_default_and_respects_denials(self):
        now = int(time.time())
        event = {
            "id": "partial", "title": "Programme", "isCatchupEnabled": False,
            "isBlackouted": False,
            "start": datetime.datetime.fromtimestamp(now - 2400, datetime.timezone.utc).isoformat(),
            "stop": datetime.datetime.fromtimestamp(now - 400, datetime.timezone.utc).isoformat(),
            "tileChannel": {"codename": "one"}}
        for observation, denied, blacked_out, expected in (
                ({"seconds": 1200, "format": "DASH/Widevine"}, False, False, True),
                (None, False, False, True),
                ({"seconds": 300, "format": "DASH/Widevine"}, False, False, False),
                ({"seconds": 1200, "format": "DASH/Widevine"}, True, False, False),
                ({"seconds": 1200, "format": "DASH/Widevine"}, False, True, False)):
            event["isBlackouted"] = blacked_out
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))

            def interact(dialog):
                button = next(iter(dialog.event_controls))
                dialog.focused_control = dialog.getControl(button)
                dialog.onFocus(button)
                self.assertEqual(bool(dialog.restart_controls), expected)
                self.assertEqual(dialog.can_start, expected)
                if expected:
                    if observation is not None:
                        self.assertIn("from approximately", dialog.control_labels["rewind"])
                    else:
                        self.assertIn("estimated window", dialog.control_labels["rewind"])
                    badge = dialog.getControl(next(iter(dialog.restart_controls)))
                    self.assertTrue(badge.noFocusTexture.endswith("guide-rewind.png"))
                dialog.onAction(Action(92))

            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(["one"], lambda *_: [event], lambda *_: [], str, ADDON_ROOT,
                           lambda *_: None, "rewind-test", datetime.timezone.utc,
                           rewind_observation=lambda _: observation,
                           timeshift_denied=lambda _: denied)
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_inline_restart_and_short_tile_context_route_to_exact_programme(self):
        now = int(time.time())
        for action in ("primary", "restart", "short", "clipped", "stale"):
            short = action == "short"
            gutter = action in ("short", "clipped")
            start = now - (20 if short else 10800 if gutter else 1800)
            end = now + (20 if short else 1800)
            event = {
                "id": "test", "title": "Programme", "isCatchupEnabled": True, "isBlackouted": False,
                "start": datetime.datetime.fromtimestamp(start, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(end, datetime.timezone.utc).isoformat(),
                "tileChannel": {"codename": "two"},
            }
            notifications = []

            def interact(dialog):
                button = next(iter(dialog.event_controls))
                if gutter:
                    self.assertFalse(dialog.restart_controls)
                    dialog.focused_control = dialog.getControl(button)
                    dialog.onFocus(button)
                restart = next(iter(dialog.restart_controls))
                main_area, restart_area = map(dialog.getControl, (button, restart))
                self.assertEqual(restart_area.label, "")
                self.assertTrue(os.path.isfile(restart_area.noFocusTexture))
                self.assertNotEqual(restart_area.focusTexture, restart_area.noFocusTexture)
                self.assertTrue(os.path.isfile(restart_area.focusTexture))
                if gutter:
                    footer = dialog.control_labels["rewind"]
                    self.assertIn("Try rewind", footer)
                    self.assertNotIn("?", footer)
                    self.assertLessEqual(restart_area.x + restart_area.width, main_area.x)
                else:
                    self.assertLessEqual(restart_area.x + restart_area.width, main_area.x)
                    self.assertEqual(main_area.y, restart_area.y)
                dialog.onClick(button if action == "primary" else restart)
                dialog.onAction(Action(100))
                if action == "stale":
                    self.assertFalse(dialog.closed)
                    self.assertEqual(len(notifications), 1)
                    dialog.onAction(Action(92))

            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(
                Window(), notifications=notifications, context_choice=1))
            WindowXMLDialog.modal_callback = interact
            try:
                result = open_guide(
                    ["one", "two"], lambda *_: [event], lambda *_: [], str, ADDON_ROOT,
                    lambda *_: None, "synthetic-account", datetime.timezone.utc,
                    confirm_restart=lambda _, event: action != "stale",
                    rewind_observation=lambda _: {"seconds": 14400, "format": "DASH/Widevine"})
                expected = None if action == "stale" else {"channel": "two"}
                if action in ("restart", "short", "clipped"):
                    expected["start"] = float(start)
                    expected["stop"] = float(end)
                self.assertEqual(result, expected)
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_clipped_tile_shows_scheduled_start_without_changing_geometry_or_restart(self):
        timezone = datetime.timezone(datetime.timedelta(hours=1))
        viewport = datetime.datetime(2026, 11, 18, 14, 30, tzinfo=timezone).timestamp()
        start = datetime.datetime(2026, 11, 18, 13, 25, tzinfo=timezone).timestamp()
        stop = datetime.datetime(2026, 11, 18, 15, 13, tzinfo=timezone).timestamp()
        event = {
            "id": "clipped", "title": "WaPo Bodensee",
            "isCatchupEnabled": True, "isBlackouted": False,
            "start": datetime.datetime.fromtimestamp(
                start, datetime.timezone.utc).isoformat(),
            "stop": datetime.datetime.fromtimestamp(
                stop, datetime.timezone.utc).isoformat(),
            "tileChannel": {"codename": "one"},
        }
        window = Window()
        previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
        sys.modules.update(xbmc=fake_xbmc(),
                           xbmcgui=fake_xbmcgui(window))

        def interact(dialog):
            if getattr(dialog, "clipped_tile_verified", False):
                return
            dialog.view_start = dialog._snap(viewport)
            dialog.anchor = viewport + 60
            dialog._request_view(immediate=True)
            dialog._resolve_selection()
            dialog._render()

            key = guide.programme_key(event)
            button_id = next(
                control_id for control_id, value in dialog.event_controls.items()
                if value[0] == key
            )
            button = dialog.getControl(button_id)
            self.assertTrue(button.label.startswith("13:25  WaPo Bodensee"))
            self.assertTrue(dialog.detail_label.label.startswith("13:25–15:13"))

            pad = max(18, int(dialog.width * 0.02))
            left = max(124, int(dialog.width * 0.15))
            timeline_x = left + 18
            timeline_width = max(100, dialog.width - timeline_x - pad)
            scale = timeline_width / guide.TIMELINE_SECONDS
            x1 = max(timeline_x, int(timeline_x + (start - viewport) * scale))
            x2 = min(timeline_x + timeline_width,
                     int(timeline_x + (stop - viewport) * scale))
            self.assertEqual(button.x, x1 + 1)
            self.assertEqual(button.width, max(1, x2 - x1 - 2))

            restart_id = next(iter(dialog.restart_controls))
            dialog.onClick(restart_id)
            dialog.clipped_tile_verified = True

        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch("guide.time.time", return_value=viewport + 60):
                result = open_guide(
                    ["one"], lambda *_: [event], lambda *_: self.fail(
                        "the clipped tile should use the cached event"),
                    str, ADDON_ROOT, lambda _: None, "clipped-account", timezone,
                    rewind_observation=lambda _: {"seconds": 7200, "format": "DASH/Widevine"})
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

        self.assertEqual(result, {"channel": "one", "start": float(start), "stop": float(stop)})

    def test_page_actions_move_visible_pages_and_keep_time_focus(self):
        now = int(time.time())
        channels = ["channel-{}".format(index) for index in range(25)]

        def cached(_, visible):
            return [{"id": code, "title": code,
                     "start": datetime.datetime.fromtimestamp(
                         now - 900, datetime.timezone.utc).isoformat(),
                     "stop": datetime.datetime.fromtimestamp(
                         now + 900, datetime.timezone.utc).isoformat(),
                     "tileChannel": {"codename": code}} for code in visible]

        previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
        sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))

        def interact(dialog):
            size = dialog.visible_count
            self.assertGreater(size, 5)
            self.assertLess(size * 3, len(channels))
            for _ in range(5):
                dialog.onAction(Action(4))
            anchor = dialog.anchor

            def expect(index):
                self.assertEqual(dialog.selected_channel, index)
                self.assertEqual(dialog.first_channel, (index // size) * size)
                self.assertEqual(dialog.anchor, anchor)
                self.assertEqual(guide.programme_key(dialog.selected_programme)[0], channels[index])
                self.assertEqual(dialog.request[0][1],
                                 tuple(channels[dialog.first_channel:dialog.first_channel + size]))

            expect(5)
            dialog.onAction(Action(6))
            expect(5 + size)
            dialog.onAction(Action(6))
            expect(5 + 2 * size)
            dialog.onAction(Action(6))
            expect(len(channels) - 1)
            dialog.onAction(Action(6))
            expect(len(channels) - 1)
            dialog.onAction(Action(5))
            expect(len(channels) - 1 - size)
            dialog.onAction(Action(5))
            expect(len(channels) - 1 - 2 * size)
            dialog.onAction(Action(5))
            expect(len(channels) - 1 - 3 * size)
            dialog.onAction(Action(5))
            expect(len(channels) - 1 - 3 * size)
            dialog.onAction(Action(184))
            expect(len(channels) - 3 * size)
            dialog.onAction(Action(185))
            expect(len(channels) - 1 - 3 * size)
            dialog.onAction(Action(3))
            expect(len(channels) - 2 - 3 * size)
            dialog.onAction(Action(92))

        WindowXMLDialog.modal_callback = interact
        try:
            open_guide(channels, cached, lambda *_: self.fail("cached page should not load"),
                       str, ADDON_ROOT, lambda *_: None, "page-account", datetime.timezone.utc)
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

    def test_page_actions_on_short_or_empty_lineup(self):
        for channels in ([], ["one", "two"]):
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))

            def interact(dialog):
                if channels:
                    dialog.onAction(Action(4))
                    self.assertEqual(dialog.selected_channel, 1)
                before = dialog.selected_channel, dialog.anchor
                dialog.onAction(Action(5))
                dialog.onAction(Action(6))
                self.assertEqual((dialog.selected_channel, dialog.anchor), before)
                dialog.onAction(Action(92))

            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(channels, lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                           lambda *_: None, "short-page", datetime.timezone.utc)
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_latest_view_wins_while_empty_and_watch_remains_reachable(self):
        requests = []
        release_old = threading.Event()
        stale_cancelled = []
        channels = ["channel-{}".format(i) for i in range(35)]

        def make_event(start, channel, title):
            return {"id": title, "title": title, "start": start.isoformat(),
                    "stop": (start + datetime.timedelta(hours=1)).isoformat(),
                    "tileChannel": {"codename": channel}}

        def load(start, visible_channels, cancelled, publish):
            requests.append((start, visible_channels))
            if len(requests) == 1:
                assert release_old.wait(3)
                stale_cancelled.append(cancelled())
                return [make_event(start, visible_channels[0], "Stale programme")]
            return [make_event(start, visible_channels[0], "Active programme")]

        latest = []

        def interact(dialog):
            if not requests:
                return
            if not latest:
                self.assertEqual(dialog.getFocusId(), dialog.watch_button.getId())
                original_anchor = dialog.anchor
                dialog.onAction(Action(4))
                self.assertEqual(dialog.selected_channel, 1)
                self.assertEqual(dialog.anchor, original_anchor)
                dialog.onAction(Action(3))
                dialog.onAction(Action(2))
                self.assertGreater(dialog.view_start, requests[0][0].timestamp())
                for _ in range(2):
                    dialog.onAction(Action(6))
                anchor = dialog.anchor
                dialog.onAction(Action(185))
                dialog.onAction(Action(184))
                self.assertEqual(dialog.selected_channel, 2 * dialog.visible_count)
                self.assertEqual(dialog.anchor, anchor)
                latest.append(dialog.request[0])
                self.assertEqual(len(requests), 1)
                release_old.set()
            elif not dialog.loading:
                self.assertEqual(requests[1:], latest)
                self.assertEqual(stale_cancelled, [True])
                self.assertIn("Active programme", dialog.detail_label.label)
                self.assertEqual(dialog.getFocusId(), next(iter(dialog.event_controls)))
                dialog.onAction(Action(117))
                dialog.pump_focus()
                self.assertEqual(dialog.getFocusId(), dialog.watch_button.getId())
                dialog.onClick(dialog.getFocusId())

        previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
        sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))
        WindowXMLDialog.modal_callback = interact
        try:
            result = open_guide(
                channels, lambda *_: None, load, str, ADDON_ROOT,
                lambda message: None, "synthetic-account", datetime.timezone.utc)
            self.assertEqual(result, {"channel": latest[0][1][0]})
        finally:
            release_old.set()
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

    def test_open_guide_constructs_and_renders_channel_names_and_logos(self):
        window = Window()
        xbmc = fake_xbmc("de")
        xbmcgui = fake_xbmcgui(window)
        previous = {
            name: sys.modules.get(name)
            for name in ("xbmc", "xbmcgui")
        }
        sys.modules["xbmc"] = xbmc
        sys.modules["xbmcgui"] = xbmcgui
        try:
            now = time.time()
            programme = {
                "id": "event-1",
                "title": "Current programme",
                "description": "First synopsis line.\n" + "Long synopsis text. " * 22,
                "isCatchupEnabled": True, "isBlackouted": False,
                "start": datetime.datetime.fromtimestamp(
                    now - 600, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(
                    now + 1200, datetime.timezone.utc).isoformat(),
                "tileChannel": {
                    "codename": "channel-1",
                    "title": "Provider channel name",
                    "logoUrlOnDark": "special://provider/channel-one.png",
                },
            }
            programme_without_logo = {
                "id": "event-2",
                "title": "Upcoming programme",
                "start": datetime.datetime.fromtimestamp(
                    now + 1800, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(
                    now + 3600, datetime.timezone.utc).isoformat(),
                "tileChannel": {
                    "codename": "channel-3",
                    "title": "Provider fallback name",
                },
            }
            next_programme = {
                "id": "event-3",
                "title": "Next programme",
                "start": datetime.datetime.fromtimestamp(
                    now + 1200, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(
                    now + 2400, datetime.timezone.utc).isoformat(),
                "tileChannel": {
                    "codename": "channel-1",
                    "title": "Provider channel name",
                    "logoUrl": "special://provider/channel-one-fallback.png",
                },
            }
            static_names = {
                "channel-1": "Static one",
                "channel-2": "Static two",
                "channel-3": "Static three",
            }

            def interact(dialog):
                current_id = next(
                    control_id for control_id, value in dialog.event_controls.items()
                    if value[1]["title"] == "Current programme"
                )
                self.assertEqual(dialog.getFocusId(), current_id)
                self.assertIn("Current programme", dialog.detail_label.label)
                self.assertTrue("First synopsis" not in dialog.detail_label.label)
                lines = [control for key, (_, control) in dialog.slots.items()
                         if isinstance(key, tuple) and key[0] == "synopsis"]
                self.assertTrue(lines[0].label.startswith("First synopsis"))
                self.assertTrue(lines[-1].label.endswith("…"))
                self.assertEqual(dialog.start_button.label, "Zurückspulen versuchen")
                self.assertNotIn("now", dialog.slots)
                self.assertFalse(any(getattr(control, "label", "") in ("JETZT", "NOW")
                                     for _, control in dialog.slots.values()))
                rows = [control for key, (_, control) in dialog.slots.items()
                        if isinstance(key, tuple) and key[0] == "row"]
                name = dialog.slots[("channel", 0)][1]
                logo = dialog.slots[("logo", 0)][1]
                self.assertEqual((logo.x + logo.width // 2, logo.y + logo.height // 2),
                                 (name.x + name.width // 2, name.y + name.height // 2))
                self.assertEqual(logo.width, name.width)
                self.assertGreater(logo.height, 32)
                self.assertGreater(logo.y, rows[0].y)
                self.assertLess(logo.y + logo.height, rows[0].y + rows[0].height)
                self.assertLess(name.x + name.width, dialog.getControl(current_id).x)
                self.assertIn("start=100 end=0", logo.animations[0][1])
                self.assertIn("start=0 end=100", name.animations[0][1])
                self.assertNotIn(("channel", 1), dialog.slots)
                self.assertNotIn(("logo", 2), dialog.slots)
                self.assertTrue(dialog.slots[("channel", 2)][1].label)
                marker = next(control for key, (_, control) in dialog.slots.items()
                              if isinstance(key, tuple) and key[0] == "now-line")
                self.assertGreater(marker.y + marker.height, rows[-1].y)
                self.assertGreater(marker.getId(), current_id)
                title = dialog.getControl(current_id)
                self.assertEqual((title.alignment, title.textOffsetY), (4, 0))
                self.assertIn("Current programme", title.label)
                self.assertLess(lines[-1].y + lines[-1].height, dialog.watch_button.y)
                dialog.onAction(Action(2))
                self.assertEqual(logo.animation_updates, 1)
                self.assertEqual(
                    dialog.selected_programme["title"], "Next programme")
                self.assertIn("Next programme", dialog.detail_label.label)
                dialog.onAction(Action(1))
                self.assertEqual(
                    dialog.selected_programme["title"], "Current programme")
                dialog.onAction(Action(184))
                self.assertEqual(dialog.selected_channel, 1)
                self.assertEqual(logo.animations, [])
                self.assertNotIn(("channel", 0), dialog.slots)
                self.assertIn(("channel", 1), dialog.slots)
                self.assertIn(
                    "keine Programmdaten", dialog.detail_label.label)
                dialog.onAction(Action(185))
                self.assertEqual(dialog.selected_channel, 0)
                self.assertIn("Current programme", dialog.detail_label.label)
                dialog.onAction(Action(92))

            WindowXMLDialog.modal_callback = interact
            result = open_guide(
                ["channel-1", "channel-2", "channel-3"],
                lambda *_: [programme, next_programme, programme_without_logo],
                lambda *_: self.fail("cache hit must not start the worker"),
                lambda channel: static_names[channel],
                ADDON_ROOT,
                lambda message: None,
                "synthetic-account",
                datetime.timezone.utc,
                lambda channel, title: (os.path.join(ADDON_ROOT, "icon.png") if channel == "channel-3"
                                        else "special://mapped/{}.png".format(title.replace(" ", "-"))),
                rewind_observation=lambda _: {"seconds": 7200, "format": "DASH/Widevine"},
            )
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

        self.assertIsNone(result)
        self.assertEqual(
            WindowXMLDialog.constructor_args,
            ("guide.xml", ADDON_ROOT, "Default", "1080i")
        )
        controls = WindowXMLDialog.last_instance._controls
        labels = [control.label for control in controls
                  if isinstance(control, ControlLabel)]
        images = [control for control in controls if isinstance(control, ControlImage)]
        self.assertIn("simpliTVᵀ  |  Live TV", labels)
        self.assertIn("Provider channel name", labels)
        self.assertNotIn("Static two", labels)
        self.assertIn("Provider fallback name", labels)
        self.assertTrue(any(
            image.filename == "special://provider/channel-one.png"
            and image.aspectRatio == 2 for image in images
        ))
        self.assertTrue(any(
            image.filename == "special://mapped/Static-two.png"
            and image.aspectRatio == 2 for image in images
        ))
        self.assertFalse(any(image.filename == os.path.join(ADDON_ROOT, "icon.png") for image in images))
        skins = os.path.join(ADDON_ROOT, "resources", "skins", "Default")
        texture = ET.parse(os.path.join(skins, "1080i", "guide.xml")).findtext(".//texture")
        self.assertTrue(os.path.isfile(os.path.join(skins, "media", texture)))

    def test_render_failure_logs_and_closes_owned_dialog(self):
        window = Window()
        xbmc = fake_xbmc()

        def failing_label(*args, **kwargs):
            raise TypeError("synthetic render failure")

        xbmcgui = fake_xbmcgui(window, failing_label)
        previous = {
            name: sys.modules.get(name)
            for name in ("xbmc", "xbmcgui")
        }
        sys.modules["xbmc"] = xbmc
        sys.modules["xbmcgui"] = xbmcgui
        log_messages = []
        try:
            with self.assertRaises(RuntimeError):
                open_guide(
                    ["channel-1"], lambda *_: [], lambda *_: [],
                    lambda channel: "Channel one", ADDON_ROOT,
                    log_messages.append, "synthetic-account",
                    datetime.timezone.utc
                )
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

        dialog = WindowXMLDialog.last_instance
        self.assertTrue(dialog.was_closed)
        self.assertTrue(dialog.cancel.is_set())
        self.assertTrue(any("Guide render failed" in message for message in log_messages))
        self.assertTrue(any("Traceback" in message for message in log_messages))

    def test_background_completion_failure_and_late_results(self):
        for outcome in ("complete", "partial failure", "failure", "close"):
            release_worker = threading.Event()
            worker_done = threading.Event()
            saw_partial = []
            log_messages = []
            now = datetime.datetime.now(datetime.timezone.utc)
            programme = {
                "id": 1, "title": "Arrived in background",
                "start": (now - datetime.timedelta(minutes=5)).isoformat(),
                "stop": (now + datetime.timedelta(minutes=5)).isoformat(),
                "tileChannel": {"codename": "channel-1"},
            }

            def load(visible, channels, cancelled, publish):
                try:
                    if outcome == "failure":
                        raise LiveDataError("synthetic listing failure")
                    if outcome != "close":
                        publish((programme,))
                    if not release_worker.wait(4):
                        raise AssertionError("UI did not receive progress")
                    if outcome == "partial failure":
                        raise LiveDataError("synthetic second range failure")
                    if outcome == "close":
                        assert cancelled()
                        publish((programme,))
                    return [programme]
                finally:
                    worker_done.set()

            def interact(dialog):
                if outcome == "close":
                    if dialog.loading:
                        dialog.onAction(Action(92))
                    return
                if dialog.loading and dialog.programmes:
                    saw_partial.append(True)
                    self.assertIn("Arrived in background", dialog.detail_label.label)
                    if len(saw_partial) == 1:
                        focus_snapshot[:] = [dialog.getFocusId(), dialog.focus_calls,
                                             dialog.removals, dialog._next_id]
                    release_worker.set()
                if not dialog.loading:
                    if outcome != "failure":
                        self.assertEqual(
                            [dialog.getFocusId(), dialog.focus_calls, dialog.removals,
                             dialog._next_id], focus_snapshot)
                    dialog.onAction(Action(92))

            focus_snapshot = []
            window = Window()
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(window))
            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(
                    ["channel-1"], lambda *_: None, load, lambda _: "Channel one",
                    ADDON_ROOT, log_messages.append, "synthetic-account",
                    datetime.timezone.utc
                )
                dialog = WindowXMLDialog.last_instance
                release_worker.set()
                self.assertTrue(worker_done.wait(5))
                self.assertTrue(dialog.cancel.is_set())
                self.assertIsNone(dialog.pending)
                labels = [control.label for control in dialog._controls
                          if isinstance(control, ControlLabel)]
                if outcome == "close":
                    self.assertEqual(dialog.programmes, [])
                else:
                    self.assertEqual(dialog.loading, False)
                    self.assertEqual(bool(saw_partial), outcome != "failure")
                    if outcome == "failure":
                        self.assertIn("Programme data unavailable", labels)
                        self.assertEqual(dialog.programmes, [])
                    else:
                        self.assertEqual(list(dialog.programmes), [programme])
                    if outcome == "partial failure":
                        self.assertIn("Programme guide incomplete", labels)
                    if outcome.endswith("failure"):
                        self.assertTrue(bool(log_messages))
            finally:
                release_worker.set()
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module


if __name__ == "__main__":
    unittest.main()
