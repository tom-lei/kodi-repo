import datetime
import gc
import os
import sys
import types
import unittest
import weakref
import xml.etree.ElementTree as ET
from unittest.mock import Mock, patch

import crt_noise
import player_window


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class GoLiveTests(unittest.TestCase):
    def test_short_landing_gets_one_retry_then_warning(self):
        attempt = player_window.GoLiveAttempt(0)
        self.assertIsNone(attempt.review(999, 1000, 2, False))
        self.assertIsNone(attempt.review(976, 1000, 6, True))
        self.assertEqual(attempt.review(976, 1002, 6.5, False), "retry")
        self.assertIsNone(attempt.review(1001, 1002, 7, False))
        self.assertEqual(attempt.review(990, 1002, 12.5, False), "warn")

    def test_reached_edge_finishes_without_warning_on_either_attempt(self):
        first = player_window.GoLiveAttempt(0)
        self.assertEqual(first.review(994, 1000, 6, False), "reached")
        second = player_window.GoLiveAttempt(0)
        self.assertEqual(second.review(978, 1000, 6, False), "retry")
        self.assertEqual(second.review(997, 1005, 12, False), "reached")

    def test_unsettled_or_invalid_readback_cannot_cause_warning(self):
        first = player_window.GoLiveAttempt(0)
        self.assertEqual(first.review(978, 1000, 7, True), "cancel")
        second = player_window.GoLiveAttempt(0)
        self.assertEqual(second.review(978, 1000, 6, False), "retry")
        self.assertEqual(second.review(0, 0, 13, False), "cancel")


class SeekStatusTests(unittest.TestCase):
    def test_live_delay_follows_pending_marker_and_uses_live_threshold(self):
        status = player_window.seek_status
        wall = datetime.datetime(2025, 1, 15, 21, 50).timestamp()
        self.assertEqual(status(340, 600, 450, True, wall), "21:47 · −2:30")
        self.assertEqual(status(450, 600, 600, True, wall), "LIVE")
        self.assertEqual(status(588, 600, None, True, wall), "21:49 · −0:12")
        self.assertEqual(status(589, 600, None, True, wall), "LIVE")
        self.assertEqual(status(30, 600, 90, False, wall), "00:01:30 / 00:10:00")

    def test_frozen_duration_counts_paused_time_in_delay(self):
        clock = player_window.PauseClock()
        clock.update(600, True, 0)
        extra = clock.update(600, True, 20)
        wall = datetime.datetime(2025, 1, 15, 21, 50, 20).timestamp()
        self.assertEqual(player_window.seek_status(598, 600, None, True, wall, extra),
                         "21:49 · −0:22")
        self.assertEqual(player_window.seek_status(598, 600, 570, True, wall, extra),
                         "21:49 · −0:50")


class ZapTests(unittest.TestCase):
    def setUp(self):
        self.clock = 0.0
        self.allowed = ["one", "two", "three"]
        self.events = []

        def start(channel, dispatched):
            try:
                self.events.append(("acquire", channel))
                yield
                dispatched()
                self.events.append(("dispatch", channel))
                yield
                return {"channel": channel}
            finally:
                self.events.append(("closed", channel))

        self.controller = player_window.ZapController(
            {"channel": "one"}, lambda: list(self.allowed), start,
            lambda *args: self.events.append(("notify", args[0])), lambda: self.clock)

    def advance(self):
        self.clock += 0.3
        self.controller.tick()

    def test_rapid_zaps_discard_undispatched_work_and_keep_latest(self):
        self.controller.request(1)
        self.advance()
        self.assertIn(("acquire", "two"), self.events)
        self.controller.request(1)
        self.advance()
        self.assertIn(("closed", "two"), self.events)
        self.assertIn(("acquire", "three"), self.events)
        self.controller.tick()
        self.assertNotIn(("dispatch", "two"), self.events)
        self.assertIn(("dispatch", "three"), self.events)
        self.controller.tick()
        self.assertEqual(self.controller.playback["channel"], "three")

    def test_actions_during_dispatched_start_are_queued_until_owned(self):
        self.controller.request(1)
        self.advance()
        self.controller.tick()
        self.controller.request(1)
        self.assertTrue(self.controller.dispatched)
        self.assertTrue(self.controller.tick())
        self.assertEqual(self.controller.playback["channel"], "two")
        self.advance()
        self.controller.tick()
        self.assertIn(("dispatch", "three"), self.events)
        self.controller.tick()
        self.assertEqual(self.controller.playback["channel"], "three")

    def test_expired_rights_and_boundaries_do_not_start_a_tune(self):
        self.controller.request(-1)
        self.assertEqual(self.events, [])
        self.controller.request(1)
        self.allowed.remove("two")
        self.advance()
        self.assertEqual(self.events, [("notify", "unavailable")])
        self.assertEqual(self.controller.playback["channel"], "one")

    def test_cancellation_closes_worker_before_dispatch(self):
        self.controller.request(1)
        self.advance()
        self.controller.cancel()
        self.assertIn(("closed", "two"), self.events)
        self.assertNotIn(("dispatch", "two"), self.events)
        self.assertIsNone(self.controller.handoff)

    def test_returning_to_current_channel_cancels_undispatched_tune(self):
        self.controller.request(1)
        self.advance()
        self.controller.request(-1)
        self.advance()
        self.assertIn(("closed", "two"), self.events)
        self.assertNotIn(("acquire", "one"), self.events)
        self.assertIsNone(self.controller.desired)


class PlayerWindowTests(unittest.TestCase):
    def test_stop_and_stock_fullscreen_escape_do_not_stop_or_close_other_windows(self):
        for action in ("stop", "native-stop", "replaced", "fullscreen"):
            with self.subTest(action=action):
                state = {"active": 10025, "instance": None, "steps": 0, "calls": [],
                         "playing": True}

                class Control:
                    def __init__(self, *args, **kwargs):
                        pass
                    def setVisible(self, visible):
                        pass
                    def setLabel(self, value, **kwargs):
                        pass
                    def setWidth(self, value):
                        pass
                    def setAnimations(self, value):
                        pass

                class Window:
                    def __init__(self, *args):
                        state["instance"] = self
                    def show(self):
                        state["active"] = 13000
                    def close(self):
                        state["calls"].append("close")
                        state["active"] = 10025
                    def addControls(self, controls):
                        pass
                    def getWidth(self):
                        return 1920
                    def getHeight(self):
                        return 1080

                player = types.SimpleNamespace(
                    isPlayingVideo=lambda: state["playing"],
                    isPlaying=lambda: action == "replaced",
                    getTime=lambda: 120.0,
                    getTotalTime=lambda: 600.0,
                    stop=lambda: state["calls"].append("stop"))
                playback = {"channel": "one", "player": player, "matches": lambda: state["playing"],
                            "live": True, "metadata": {"title": "Station"}}

                def sleep(_):
                    state["steps"] += 1
                    if state["steps"] == 1:
                        state["instance"].onInit()
                    elif action == "stop":
                        state["instance"].onAction(types.SimpleNamespace(getId=lambda: 13))
                    elif action in ("native-stop", "replaced"):
                        # Playback ends before any queued Python onAction arrives.
                        state["playing"] = False
                    else:
                        state["active"] = 12005

                xbmc = types.SimpleNamespace(
                    Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                                          waitForAbort=lambda s: sleep(s * 1000)),
                    getLanguage=lambda *_: "en", ISO_639_1=0, sleep=sleep,
                    getCondVisibility=lambda _: False)
                xbmcgui = types.SimpleNamespace(
                    WindowXML=Window, ControlImage=Control, ControlLabel=Control,
                    getCurrentWindowId=lambda: state["active"],
                    Dialog=lambda: types.SimpleNamespace(notification=lambda *args: None))
                addon = types.SimpleNamespace(getAddonInfo=lambda _: ROOT, getSetting=lambda _: "true")
                with patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": xbmcgui}), \
                        patch.object(player_window, "skin_font", return_value="font13"):
                    reason, _ = player_window.open_player_window(
                        playback, lambda: ["one"], lambda *_: self.fail("unexpected tune"),
                        addon, lambda _: None)
                expected = {"stop": "stopped", "native-stop": "stopped",
                            "replaced": "closed", "fullscreen": "fullscreen"}[action]
                self.assertEqual(reason, expected)
                self.assertEqual(state["calls"], [] if action == "fullscreen" else ["close"])

    def test_zap_overlay_static_setting_and_external_replacement(self):
        for static, replace, back_during, fullscreen in (
                (True, False, False, False), (False, False, False, False),
                (True, True, False, False), (True, False, True, False),
                (True, False, False, True)):
            with self.subTest(static=static, replace=replace, back_during=back_during,
                              fullscreen=fullscreen):
                state = {"active": 10025, "instance": None, "clock": 0.0,
                         "steps": 0, "playing": True, "events": [], "frames": set()}

                class Control:
                    def __init__(self, *args, **kwargs):
                        self.content = args[4]
                        self.visible = True
                    def setVisible(self, visible):
                        self.visible = visible
                    def setLabel(self, value, **kwargs):
                        self.content = value
                    def setImage(self, value):
                        self.content = value
                    def setWidth(self, value):
                        pass
                    def setAnimations(self, value):
                        pass

                class Window:
                    def __init__(self, *args):
                        state["instance"] = self
                        self.added = []
                    def show(self):
                        state["active"] = 13000
                    def close(self):
                        state["active"] = 10025
                    def addControls(self, controls):
                        self.added.extend(controls)
                    def removeControls(self, controls):
                        for control in controls:
                            self.added.remove(control)
                    def getWidth(self):
                        return 1920
                    def getHeight(self):
                        return 1080

                player = types.SimpleNamespace(isPlayingVideo=lambda: state["playing"],
                                               isPlaying=lambda: replace,
                                               getTime=lambda: 120.0, getTotalTime=lambda: 600.0)
                playback = {"channel": "one", "player": player, "matches": lambda: state["playing"],
                            "live": True, "metadata": {"title": "One"}}

                def start(channel, dispatched):
                    try:
                        state["events"].append("acquire")
                        yield
                        dispatched()
                        state["events"].append("dispatch")
                        yield
                        return dict(playback, channel=channel, metadata={"title": "Two"})
                    finally:
                        state["events"].append("close")

                def sleep(_):
                    state["clock"] += 0.1
                    state["steps"] += 1
                    self.assertLess(state["steps"], 40)
                    window = state["instance"]
                    if state["steps"] == 1:
                        window.onInit()
                        self.assertFalse(hasattr(window, "seek_label"))
                        self.assertFalse(hasattr(window, "seek_background"))
                        window.onAction(types.SimpleNamespace(getId=lambda: 1))
                    elif state["steps"] == 2:
                        self.assertIsNotNone(window.gesture.target)
                        self.assertIsNotNone(window.strip)
                        window.onAction(types.SimpleNamespace(getId=lambda: 5))
                        self.assertIsNone(window.gesture.target)
                        self.assertIsNone(window.strip)
                        strip.close.assert_called_once()
                        self.assertEqual(window.startup_logo.content, "local-logo")
                        self.assertEqual(window.startup_frames is not None, static)
                        if not static:
                            self.assertIn("guide-solid.png", window.startup_controls[0].content)
                    if window.startup_frames is not None:
                        fields, signals = window.startup_frames
                        self.assertEqual(sum(f.visible for f in fields), 1)
                        self.assertEqual(sum(f.visible for f in signals), 1)
                        state["frames"].add(window.startup_frame)
                    if replace and "acquire" in state["events"]:
                        state["playing"] = False
                    elif back_during and "dispatch" in state["events"] and not window.back_pending:
                        window.onAction(types.SimpleNamespace(getId=lambda: 92))
                        self.assertTrue(window.back_pending)
                    elif window.controller.playback["channel"] == "two":
                        if fullscreen:
                            state["active"] = 12005
                        else:
                            window.onAction(types.SimpleNamespace(getId=lambda: 92))

                xbmc = types.SimpleNamespace(
                    Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                                          waitForAbort=lambda s: sleep(s * 1000)),
                    getLanguage=lambda *_: "en", ISO_639_1=0, sleep=sleep,
                    getCondVisibility=lambda condition: condition == "Player.SeekEnabled")
                xbmcgui = types.SimpleNamespace(
                    WindowXML=Window, ControlImage=Control, ControlLabel=Control,
                    getCurrentWindowId=lambda: state["active"],
                    Dialog=lambda: types.SimpleNamespace(notification=lambda *args: None))
                addon = types.SimpleNamespace(
                    getAddonInfo=lambda _: ROOT,
                    getSetting=lambda key: ("true" if static else "false") if key == "tv_static" else "true")
                original_controller = player_window.ZapController

                class TimedController(original_controller):
                    def __init__(self, *args):
                        super().__init__(*args, now=lambda: state["clock"])

                strip = Mock()
                with patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": xbmcgui}), \
                        patch.object(player_window, "skin_font", return_value="font13"), \
                        patch.object(player_window, "SeekStrip", new=lambda *_, **_kw: strip), \
                        patch.object(player_window, "local_startup_logo", return_value="local-logo"), \
                        patch.object(player_window, "ZapController", TimedController), \
                        patch.object(player_window.time, "monotonic", side_effect=lambda: state["clock"]), \
                        patch.object(crt_noise, "cached_textures",
                                     return_value=(("snow-0", "snow-1"), ("signal-0", "signal-1"))) as cached:
                    reason, result = player_window.open_player_window(
                        playback, lambda: ["one", "two"], start, addon, lambda _: None,
                        lambda _: {"title": "Two", "logo": "remote"},
                        lambda: crt_noise.startup_textures(addon, "profile"), lambda _: [])
                self.assertEqual(reason, "closed" if replace else "fullscreen" if fullscreen else "guide")
                self.assertEqual(result["channel"], "one" if replace else "two")
                self.assertEqual("dispatch" in state["events"], not replace)
                self.assertEqual(bool(cached.call_count), static)
                self.assertFalse(state["instance"].startup_controls)
                if static:
                    self.assertEqual(state["frames"], {0, 1})
                if fullscreen:
                    reference = weakref.ref(state["instance"])
                    gc_enabled = gc.isenabled()
                    gc.disable()
                    try:
                        state["instance"] = None
                        self.assertIsNone(reference())
                    finally:
                        if gc_enabled:
                            gc.enable()

    def test_video_surface_and_back_seek_do_not_touch_playlist_or_double_pause(self):
        xml = ET.parse(os.path.join(ROOT, "resources", "skins", "Default", "1080i",
                                    "simplitv-player.xml"))
        video = xml.find(".//control[@type='videowindow']")
        self.assertIsNotNone(video)
        self.assertEqual((video.findtext("width"), video.findtext("height")), ("1920", "1080"))
        state = {"active": 10025, "instance": None, "steps": 0, "time": 0.0}
        calls = []

        class Control:
            def __init__(self, *args, **kwargs):
                pass

            def setWidth(self, value):
                pass

            def setAnimations(self, value):
                pass

            def setVisibleCondition(self, value):
                pass

            def setVisible(self, visible):
                pass

            def setLabel(self, value, **kwargs):
                pass

        class Window:
            properties = {}

            def setProperty(self, key, value):
                self.properties[key] = value

            def getProperty(self, key):
                return self.properties.get(key)

            def clearProperty(self, key):
                self.properties.pop(key, None)

            def removeControls(self, controls):
                pass

            def __init__(self, *args):
                state["instance"] = self

            def show(self):
                state["active"] = 13000

            def close(self):
                state["active"] = 10025

            def addControls(self, controls):
                pass

            def getWidth(self):
                return 1920

            def getHeight(self):
                return 1080

        player = types.SimpleNamespace(
            isPlayingVideo=lambda: True, getTime=lambda: 120.0,
            getTotalTime=lambda: 600.0, seekTime=lambda pos: calls.append(("seek", pos)),
            pause=lambda: calls.append("pause"), stop=lambda: calls.append("stop"))
        playback = {"channel": "one", "player": player, "matches": lambda: True,
                    "live": True, "metadata": {"title": "Station"}}

        def sleep(_):
            window = state["instance"]
            state["steps"] += 1
            state["time"] += 0.1
            if state["steps"] == 1:
                window.onInit()
            elif state["steps"] == 2:
                window.onAction(types.SimpleNamespace(getId=lambda: 1))
                window.onAction(types.SimpleNamespace(getId=lambda: 12))  # Kodi handles pause.
            elif state["steps"] == 10:
                window.onAction(types.SimpleNamespace(getId=lambda: 92))

        xbmc = types.SimpleNamespace(
            Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                                  waitForAbort=lambda s: sleep(s * 1000)),
            getLanguage=lambda *_: "en", ISO_639_1=0, sleep=sleep,
            getCondVisibility=lambda condition: condition == "Player.SeekEnabled")
        xbmcgui = types.SimpleNamespace(
            WindowXML=Window, ControlImage=Control, ControlLabel=Control,
            getCurrentWindowId=lambda: state["active"],
            Dialog=lambda: types.SimpleNamespace(notification=lambda *args: calls.append("notification")))
        addon = types.SimpleNamespace(getAddonInfo=lambda _: ROOT, getSetting=lambda _: "true")
        with patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": xbmcgui}), \
                patch("timeshift_overlay.skin_font", return_value="font13"), \
                patch.object(player_window, "time", types.SimpleNamespace(
                    monotonic=lambda: state["time"], time=lambda: 10000)), \
                patch.object(player_window, "skin_font", return_value="font13"):
            result = player_window.open_player_window(
                playback, lambda: ["one"], lambda *_: self.fail("unexpected tune"), addon, lambda _: None)
        self.assertEqual(result, ("guide", playback))
        self.assertEqual(calls, [("seek", 90.0)])
        self.assertEqual(state["active"], 10025)


if __name__ == "__main__":
    unittest.main()
