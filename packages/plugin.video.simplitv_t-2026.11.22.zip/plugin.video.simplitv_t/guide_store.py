import hashlib
import json
import math
import os
import re
import time

from live_cache import MAX_GUIDE_PROGRAMMES, LiveDataError, broadcast_timestamp, claim_guide_session


VERSION = 1
MAX_FILE_BYTES = 256 * 1024
MAX_REWIND_SECONDS = 48 * 60 * 60
CODE = re.compile(r"[A-Za-z0-9_.-]{1,128}")
URL_TEXT = re.compile(r"\S*(?:://|www\.)\S+", re.IGNORECASE)


def compact_page(page):
    if not isinstance(page, list) or len(page) > MAX_GUIDE_PROGRAMMES:
        raise ValueError("Invalid guide page")
    items = []
    for event in page:
        channel = event["tileChannel"]
        code = channel["codename"]
        if not isinstance(code, str) or not CODE.fullmatch(code):
            raise ValueError("Invalid guide channel")
        start, stop = event["start"], event["stop"]
        if (broadcast_timestamp(start) >= broadcast_timestamp(stop)
                or len(start) > 40 or len(stop) > 40):
            raise ValueError("Invalid guide interval")
        item = {"start": start, "stop": stop, "tileChannel": {"codename": code},
                "isCatchupEnabled": event.get("isCatchupEnabled") is True}
        if type(event.get("isBlackouted")) is bool:
            item["isBlackouted"] = event["isBlackouted"]
        codename = event.get("codename")
        if isinstance(codename, str) and CODE.fullmatch(codename):
            item["codename"] = codename
        for name in ("catchupAvailableFrom", "catchupAvailableTo"):
            value = event.get(name)
            if value is not None:
                item[name] = value if isinstance(value, str) and len(value) <= 40 else ""
        tile_id = channel.get("tileId")
        if isinstance(tile_id, str) and CODE.fullmatch(tile_id):
            item["tileChannel"]["tileId"] = tile_id
        identity = event.get("id")
        if type(identity) is int or (isinstance(identity, str) and CODE.fullmatch(identity)):
            item["id"] = identity
        for source, output, key, limit in (
                (event, item, "title", 256), (event, item, "description", 1024),
                (channel, item["tileChannel"], "title", 128)):
            value = source.get(key)
            if isinstance(value, str):
                output[key] = URL_TEXT.sub("", value)[:limit]
        items.append(item)
    return items


def rewind_sample(data):
    seconds, stream_format = data["seconds"], data["format"]
    if stream_format == "HLS" and seconds is None:
        return {"seconds": None, "format": stream_format}
    if (type(seconds) not in (int, float) or not 1 <= seconds <= MAX_REWIND_SECONDS
            or stream_format not in ("DASH/Widevine", "DASH/PlayReady", "DASH/Clear", "HLS/Clear")):
        raise ValueError("Invalid rewind observation")
    return {"seconds": seconds, "format": stream_format}


class GuideStore:
    """Fixed slots bound disk use even across account changes; collisions are misses."""

    def __init__(self, profile, api_root, tenant, username, log, clock=time.time):
        self.root = os.path.join(profile, "guide-cache")
        self.scope = [api_root, tenant, username.strip()]
        self.clock = clock
        self.log = log

    def _address(self, kind, identity):
        slots = {"epg": 64, "rewind": 128}[kind]
        key = hashlib.sha256(json.dumps([self.scope, identity]).encode("utf-8")).hexdigest()
        return os.path.join(self.root, "{}-{:03}.json".format(kind, int(key[:8], 16) % slots)), key

    def _read(self, path, key, ttl, validate):
        try:
            with open(path, "rb") as handle:
                data = handle.read(MAX_FILE_BYTES + 1)
            if len(data) > MAX_FILE_BYTES:
                raise ValueError("Oversized cache entry")
            entry = json.loads(data)
            stamp = entry["created"]
            if (entry["version"] != VERSION or entry["key"] != key
                    or type(stamp) not in (int, float) or not math.isfinite(stamp) or stamp < 0
                    or (ttl is not None and not 0 <= self.clock() - stamp < ttl)):
                return None
            return stamp, validate(entry["data"])
        except FileNotFoundError:
            return None
        except (OSError, ValueError, TypeError, KeyError, AttributeError,
                OverflowError, RecursionError, LiveDataError):
            self.log("Ignoring unreadable guide disk cache entry")
            return None

    def _write(self, path, key, stamp, data):
        payload = json.dumps({"version": VERSION, "key": key, "created": stamp, "data": data},
                             ensure_ascii=True, separators=(",", ":"), allow_nan=False).encode("ascii")
        if len(payload) > MAX_FILE_BYTES:
            return
        # All writers hold the corresponding lock; readers only open the final path.
        temp = path + ".tmp"
        try:
            os.makedirs(self.root, exist_ok=True)
            with open(temp, "wb") as handle:
                handle.write(payload)
            os.replace(temp, path)
        finally:
            try:
                os.unlink(temp)
            except FileNotFoundError:
                pass

    def read_page(self, identity, ttl):
        return self._read(*self._address("epg", identity), ttl, compact_page)

    def write_page(self, identity, stamp, data):
        # Called under LiveCache's guide page lock.
        try:
            self._write(*self._address("epg", identity), stamp, compact_page(data))
        except (OSError, ValueError, TypeError, KeyError, AttributeError, LiveDataError):
            self.log("Could not save guide disk cache entry")

    def read_rewind(self, channel, drm_preference):
        entry = self._read(*self._address("rewind", [channel, drm_preference]),
                           None, rewind_sample)
        return dict(entry[1], observed_at=entry[0]) if entry else None

    def write_rewind(self, channel, drm_preference, stream_format, seconds):
        stamp = self.clock()
        path, key = self._address("rewind", [channel, drm_preference])
        try:
            if seconds is None:
                return  # An unsupported timeline is not a newer measurement.
            data = rewind_sample({"format": stream_format, "seconds": seconds})
            with claim_guide_session(os.path.join(self.root, "rewind.lock")) as claimed:
                if claimed:
                    old = self._read(path, key, None, rewind_sample)
                    if old is None or old[0] <= stamp:
                        self._write(path, key, stamp, data)
        except (OSError, ValueError, LiveDataError):
            self.log("Could not save rewind observation")
