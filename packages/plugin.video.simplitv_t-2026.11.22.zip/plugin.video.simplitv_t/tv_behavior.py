"""Shared, cache-only helpers for TV navigation and programme information."""

import datetime
import time

from seek_timeline import sane_timeline


LIVE_GAP = 12


class StationHistory:
    def __init__(self):
        self.current = self.previous = None

    def started(self, channel):
        if channel and channel != self.current:
            self.previous, self.current = self.current, channel

    def target(self, allowed):
        return self.previous if self.previous in allowed else None


def live_target(playback, xbmc):
    if not playback or not playback.get("live"):
        return None
    try:
        player = playback["player"]
        if (not player.isPlayingVideo() or not playback["matches"]()
                or not xbmc.getCondVisibility("Player.SeekEnabled")
                or xbmc.getCondVisibility("Player.Seeking")):
            return None
        position, duration = player.getTime(), player.getTotalTime()
        if sane_timeline(position, duration) and duration - position >= LIVE_GAP:
            return duration
    except RuntimeError:
        return None
    return None


def programme_banner(events, channel, station, now, german=False):
    from guide import repair_mojibake
    from live_cache import now_next_programmes

    current, following = next(now_next_programmes(events, [channel], now))[1]

    def title(entry):
        value = entry[2].get("title") if entry else None
        return repair_mojibake(value).strip() if isinstance(value, str) else ""

    heading = title(current)
    if not heading:
        return station, "", "", 0
    start, stop, _ = current
    ends = datetime.datetime.fromtimestamp(stop).strftime("%H:%M")
    upcoming = title(following)
    return (station, "{}  ·  {} {}".format(heading, "bis" if german else "until", ends),
            ("Danach: " if german else "Next: ") + upcoming if upcoming else "",
            100 * (now - start) / (stop - start))


class ProgrammeBanner:
    def __init__(self, window, addon, xbmcgui, font, fade, *, bottom=False, fonts=None):
        import os

        width, height = window.getWidth(), window.getHeight()
        left, top = int(width * .12), int(height * .16)
        wide = int(width * .76)
        row = max(24, int(height * .032))
        rows = (row, row, row)
        inset, gap = 16, 0
        if bottom:
            rows = (max(23, round(height * .030)), max(28, round(height * .040)),
                    max(22, round(height * .028)))
            gap = max(2, round(height * .004))
            left, wide = 0, width
            inset = min(20, max(4, width // 30))
        body = sum(rows) + 2 * gap
        if bottom:
            top = height - body - 16
        solid = os.path.join(addon.getAddonInfo("path"), "resources", "skins", "Default",
                             "media", "guide-solid.png")
        self.background = xbmcgui.ControlImage(
            left, top, wide, body + 16, solid, colorDiffuse="FF101722")
        self.progress_width = max(1, wide - 2 * inset)
        colors = ("FFE0E7F0", "FFFFFFFF", "FFB8C6D8") if bottom else ("FFFFFFFF",) * 3
        self.labels = [xbmcgui.ControlLabel(left + inset, top + sum(rows[:i]) + i * gap + 4,
                                           self.progress_width, size, "", font=face,
                                           textColor=color, alignment=4)
                       for i, (size, face, color) in enumerate(zip(rows, fonts or (font,) * 3, colors))]
        self.track = xbmcgui.ControlImage(left + inset, top + body + 6,
                                          self.progress_width, 4, solid, colorDiffuse="FF334155")
        self.progress = xbmcgui.ControlImage(left + inset, top + body + 6,
                                             1, 4, solid, colorDiffuse="FF80D6FF")
        self.controls = [self.background, *self.labels, self.track, self.progress]
        self.fade = fade
        self.bottom = bottom
        window.addControls(self.controls)
        for control in self.controls:
            control.setVisible(False)
            control.setAnimations(fade)
        self.until = 0
        self.model = ("", "", "", 0)
        self.visible = False

    def show(self, model):
        self.model = model
        for control, label in zip(self.labels, model[:3]):
            control.setLabel(label, shadowColor="FF000000")
        self.progress.setWidth(max(1, round(self.progress_width * model[3] / 100)))
        self.until = time.monotonic() + 4
        self.visible = None

    def update(self, unobstructed):
        visible = unobstructed and time.monotonic() < self.until
        if visible == self.visible:
            return
        self.visible = visible
        if self.bottom:
            for control in self.controls:
                # The seek bar owns this area; don't cross-fade two sets of text.
                control.setAnimations(self.fade if unobstructed else [])
        self.background.setVisible(visible)
        for control, text in zip(self.labels, self.model[:3]):
            control.setVisible(visible and bool(text))
        self.track.setVisible(visible and bool(self.model[1]))
        self.progress.setVisible(visible and self.model[3] > 0)

    def close(self, window):
        window.removeControls(self.controls)


TRACE_PROPERTY = "simplitv_t.dev.input_trace"


def input_trace(event, **fields):
    import xbmc
    import xbmcgui

    window = xbmcgui.Window(10000)
    if window.getProperty(TRACE_PROPERTY) == "1":
        import json

        xbmc.log("simpliTV input trace " + json.dumps(
            dict(fields, event=event, t=round(time.monotonic(), 3))), xbmc.LOGINFO)
