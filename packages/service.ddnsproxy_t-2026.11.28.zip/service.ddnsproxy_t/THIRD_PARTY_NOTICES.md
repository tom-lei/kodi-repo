# Third-party notices

## 3proxy

DDNS Proxyᵀ downloads the 3proxy 1.0.4 release binaries from https://github.com/3proxy/3proxy/releases at
runtime; they are not part of this repository. 3proxy is Copyright (c) 2000-2024 by Vladimir Dubrovin
(3APA3A) and is licensed under a BSD-style licence (alternatively Apache-2.0, GPL-2.0-or-later or
LGPL-2.1-or-later), see https://github.com/3proxy/3proxy/blob/master/copying. The Linux packages contain the
licence texts in `usr/share/doc/3proxy/copyright`, including notices for bundled BLAKE2 code (CC0 / OpenSSL /
Apache-2.0).

The 3proxy binaries link against OpenSSL (Apache-2.0), which is provided by the operating system.

## PCRE2 (Linux only)

The 3proxy Linux packages also need the PCRE2 8-bit library (`libpcre2-8.so.0`), which LibreELEC does not
ship. On Linux the add-on therefore downloads the Debian 12 package `libpcre2-8-0` 10.42-1 from
deb.debian.org (snapshot.debian.org as fallback), checks it against the SHA-256 pinned in
`resources/engine.json` and places only the library next to the 3proxy binary, together with its licence
file `PCRE2-COPYRIGHT.txt`. PCRE2 is Copyright (c) 1997-2022 University of Cambridge and licensed under the
BSD-3-Clause licence with the "binary library-like packages" exception; see
https://github.com/PCRE2Project/pcre2/blob/master/LICENCE.

## External services

Public-address discovery may contact api.ipify.org / IPv6 variants and similar IP echo services during
normal service operation and interactive actions. Opening Diagnostics automatically checks enabled,
locally listening ports from the internet, unless disabled under Tools. The separate port-check action
asks for confirmation. These checks may contact Globalping (api.globalping.io), Check-Host (check-host.net),
PortChecker.co and CanYouSeeMe.org, disclosing the public IP and external TCP port, never credentials.
An unavailable checker is reported as unavailable, not closed.

All HTTP requests follow Kodi's network proxy configuration. HTTP and SOCKS types are supported;
Kodi's HTTPS proxy type is currently rejected with an explicit error rather than bypassed.