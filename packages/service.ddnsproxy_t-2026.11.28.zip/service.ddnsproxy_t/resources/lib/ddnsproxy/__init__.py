# -*- coding: utf-8 -*-
"""Kodi-independent package for DDNS Proxyᵀ (service.ddnsproxy_t)."""

ADDON_ID = 'service.ddnsproxy_t'
ADDON_NAME = u'DDNS Proxy\u1d40'
