# -*- coding: utf-8 -*-
"""Translate add-on settings into typed configuration (no Kodi imports).

`settings` is any object offering get_bool(id), get_int(id) and get_string(id).
"""
import hashlib
import json

from . import ddns, netutil, threeproxy

ADDON_ID = 'service.ddnsproxy_t'
VERSION = '2026.11.28'
USER_AGENT = 'DDNSProxyT/%s' % VERSION
# No-IP requires a descriptive agent: "Company DeviceName-Model/Version maintainer-contact"
NOIP_USER_AGENT = 'tom-lei DDNSProxyT/%s tom-lei@users.noreply.github.com' % VERSION
DDNS_SLOTS = (1, 2)
PROVIDER_KEYS = ('noip', 'duckdns', 'dynu', 'desec', 'cloudflare', 'freedns', 'dyndns2')
TLS_AUTO = 0
TLS_CUSTOM = 1
PORTMAP_METHODS = ('auto', 'upnp', 'natpmp', 'pcp')


class Config(object):
    def __init__(self):
        self.proxy_enabled = True
        self.username = 'kodi'
        self.password = ''
        self.http_enabled = True
        self.http_port = 3128
        self.tls_enabled = False
        self.tls_port = 3129
        self.tls_mode = TLS_AUTO
        self.tls_cert_file = ''
        self.tls_key_file = ''
        self.socks_enabled = False
        self.socks_port = 1080
        self.single_port = False
        self.shared_port = 3128
        self.listen_ipv6 = False
        self.allow_list = []
        self.allow_list_invalid = []
        self.ddns_interval = 5
        self.ddns_router_ip = True
        self.ddns = {}
        self.portmap_enabled = False
        self.portmap_method = 'auto'
        self.portmap_lifetime = 3600
        self.engine_custom = False
        self.engine_path = ''
        self.debug = False
        self.diag_internet = True

    def ddns_entries(self, enabled_only=True):
        return [(slot, e) for slot, e in sorted(self.ddns.items()) if e.enabled or not enabled_only]

    def hostnames(self):
        names = []
        for _, entry in self.ddns_entries():
            fqdn = entry.fqdn()
            if fqdn and fqdn not in names:
                names.append(fqdn)
        return names

    def listener_ports(self):
        return list(dict.fromkeys(port for _, port in self.public_listeners()))

    def public_listeners(self):
        listeners = self.proxy_options().listeners()
        if self.single_port:
            return [(kind, self.shared_port) for kind, _ in listeners]
        return listeners

    def proxy_options(self, cert_file='', key_file='', log_file='', windows=False):
        return threeproxy.ProxyOptions(
            username=self.username, password=self.password, http_enabled=self.http_enabled,
            http_port=self.http_port, tls_enabled=self.tls_enabled, tls_port=self.tls_port,
            socks_enabled=self.socks_enabled, socks_port=self.socks_port, listen_ipv6=self.listen_ipv6,
            allow_list=self.allow_list, cert_file=cert_file, key_file=key_file, log_file=log_file,
            windows=windows)

    def proxy_problems(self):
        result = []
        if self.proxy_enabled:
            opts = self.proxy_options(cert_file='x', key_file='x')
            if self.single_port:
                # Private ports are allocated at startup; configured separate ports are unused.
                for index, (kind, _) in enumerate(opts.listeners()):
                    setattr(opts, kind + '_port', index + 1)
            result += threeproxy.validate(opts)
            if self.tls_enabled and self.tls_mode == TLS_CUSTOM and not (self.tls_cert_file and self.tls_key_file):
                result.append('Custom TLS certificate selected, but certificate or key file is missing.')
        return result

    def problems(self):
        """Human readable configuration problems (informational; saving is always allowed)."""
        result = self.proxy_problems()
        if self.allow_list_invalid:
            result.append('Ignored invalid allow-list entries: %s' % ', '.join(self.allow_list_invalid))
        for slot, entry in self.ddns_entries():
            for msg in ddns.make_provider(entry).check():
                result.append('DDNS %d: %s' % (slot, msg))
        return result

    def warnings(self):
        result = []
        if self.proxy_enabled and self.http_enabled and not self.tls_enabled:
            result.append('Only plain HTTP is enabled: the proxy password travels unencrypted. '
                          'Enable the TLS listener for use over the internet.')
        if self.proxy_enabled and self.socks_enabled:
            result.append('SOCKS5 sends the password unencrypted.')
        if self.proxy_enabled and self.single_port:
            result.append('Single-port mode supports SOCKS CONNECT only; UDP and BIND are disabled. '
                          '3proxy does not see the original client IP.')
        return result

    def fingerprint(self):
        data = {k: v for k, v in self.__dict__.items() if k != 'ddns'}
        data['ddns'] = {str(s): e.fingerprint() + str(e.enabled) for s, e in self.ddns.items()}
        return hashlib.sha256(json.dumps(data, sort_keys=True, default=str).encode('utf-8')).hexdigest()[:16]


def _clamp(value, low, high, default):
    try:
        value = int(value)
    except (TypeError, ValueError):
        return default
    return value if low <= value <= high else default


def load(settings):
    cfg = Config()
    cfg.proxy_enabled = settings.get_bool('proxy.enabled')
    cfg.username = settings.get_string('proxy.username').strip()
    cfg.password = settings.get_string('proxy.password')
    cfg.http_enabled = settings.get_bool('proxy.http_enabled')
    cfg.http_port = _clamp(settings.get_int('proxy.http_port'), 1, 65535, 3128)
    cfg.tls_enabled = settings.get_bool('proxy.tls_enabled')
    cfg.tls_port = _clamp(settings.get_int('proxy.tls_port'), 1, 65535, 3129)
    cfg.tls_mode = _clamp(settings.get_int('proxy.tls_mode'), 0, 1, TLS_AUTO)
    cfg.tls_cert_file = settings.get_string('proxy.tls_cert_file')
    cfg.tls_key_file = settings.get_string('proxy.tls_key_file')
    cfg.socks_enabled = settings.get_bool('proxy.socks_enabled')
    cfg.socks_port = _clamp(settings.get_int('proxy.socks_port'), 1, 65535, 1080)
    cfg.single_port = settings.get_bool('proxy.single_port')
    cfg.shared_port = _clamp(settings.get_int('proxy.shared_port'), 1, 65535, 3128)
    cfg.listen_ipv6 = settings.get_bool('proxy.ipv6')
    cfg.allow_list, cfg.allow_list_invalid = netutil.parse_allow_list(settings.get_string('proxy.allowlist'))
    cfg.ddns_interval = _clamp(settings.get_int('ddns.interval'), 1, 1440, 5)
    cfg.ddns_router_ip = settings.get_bool('ddns.router_ip')
    for slot in DDNS_SLOTS:
        prefix = 'ddns%d.' % slot
        provider = settings.get_string(prefix + 'provider') or 'noip'
        if provider not in PROVIDER_KEYS:
            provider = 'noip'
        cfg.ddns[slot] = ddns.Entry(
            provider=provider, hostname=settings.get_string(prefix + 'hostname'),
            username=settings.get_string(prefix + 'username'), secret=settings.get_string(prefix + 'secret'),
            server=settings.get_string(prefix + 'server'), ipv4=settings.get_bool(prefix + 'ipv4'),
            ipv6=settings.get_bool(prefix + 'ipv6'), enabled=settings.get_bool(prefix + 'enabled'))
    cfg.portmap_enabled = settings.get_bool('portmap.enabled')
    method = settings.get_string('portmap.method')
    cfg.portmap_method = method if method in PORTMAP_METHODS else 'auto'
    cfg.portmap_lifetime = _clamp(settings.get_int('portmap.lifetime'), 120, 86400, 3600)
    cfg.engine_custom = settings.get_int('engine.source') == 1
    cfg.engine_path = settings.get_string('engine.path')
    cfg.debug = settings.get_bool('debug')
    cfg.diag_internet = settings.get_bool('tools.internet_check')
    return cfg


def user_agent_for(provider_key):
    return NOIP_USER_AGENT if provider_key == 'noip' else USER_AGENT
