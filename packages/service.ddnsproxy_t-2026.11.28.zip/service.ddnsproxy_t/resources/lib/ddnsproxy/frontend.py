# -*- coding: utf-8 -*-
"""Bounded TCP protocol dispatcher for the shared external proxy port."""
import json
import os
import select
import socket
import ssl
import threading
import time

USAGE_CHECKPOINT_BYTES = 4 * 1024 * 1024


def check_backend(kind, target):
    """Verify the listener speaks the expected protocol without sending credentials."""
    unix = isinstance(target, str)
    sock = socket.socket(socket.AF_UNIX if unix else socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(0.5)
    try:
        sock.connect('\0' + target if unix else ('127.0.0.1', target))
        if kind == 'tls':
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            sock = context.wrap_socket(sock, server_hostname='localhost')
        if kind == 'socks':
            sock.sendall(b'\x05\x01\x02')
            data = b''
            while len(data) < 2:
                part = sock.recv(2 - len(data))
                if not part:
                    return False
                data += part
            return data == b'\x05\x02'
        sock.sendall(b'GET http://127.0.0.1/ HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n')
        data = b''
        while b'\n' not in data and len(data) < 1024:
            part = sock.recv(1024 - len(data))
            if not part:
                return False
            data += part
        return data.startswith(b'HTTP/') and b' 407 ' in data.split(b'\n', 1)[0]
    except (OSError, ValueError):
        return False
    finally:
        sock.close()


class Frontend(object):
    def __init__(self, port, ipv6, backends, limit=100, stats_file=None):
        self.port = port
        self.ipv6 = ipv6
        self.backends = backends
        self.stats_file = stats_file
        self.accounting_error = ''
        self.privacy_error = ''
        self.rotation_error = ''
        self.usage_day = time.strftime('%Y-%m-%d', time.gmtime())
        self.limit = threading.BoundedSemaphore(limit)
        self.stopped = threading.Event()
        self.lock = threading.Lock()
        self.sockets = set()
        self.listeners = []
        self.threads = []
        self.workers = set()
        if self.stats_file:
            self._prune_usage_files()

    def _prune_usage_files(self):
        directory = os.path.dirname(self.stats_file)
        prefix = os.path.basename(self.stats_file) + '.'
        try:
            names = sorted(name for name in os.listdir(directory) if name.startswith(prefix))
        except OSError:
            self.rotation_error = 'Relay usage files could not be listed for retention.'
            self.accounting_error = self.rotation_error
            return
        for name in names:
            if os.name != 'nt':
                try:
                    os.chmod(os.path.join(directory, name), 0o600)
                except OSError:
                    self.privacy_error = 'Relay usage file permissions could not be restricted.'
                    self.accounting_error = self.privacy_error
        for name in names[:-7]:
            try:
                os.remove(os.path.join(directory, name))
            except OSError:
                self.rotation_error = 'Old relay usage files could not be removed.'
                self.accounting_error = self.rotation_error

    def bind(self):
        try:
            addresses = [(socket.AF_INET, '0.0.0.0')]
            if self.ipv6:
                addresses.append((socket.AF_INET6, '::'))
            for family, address in addresses:
                sock = socket.socket(family, socket.SOCK_STREAM)
                self.listeners.append(sock)
                if family == socket.AF_INET6:
                    sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
                if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                else:
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind((address, self.port))
                sock.listen(128)
                sock.settimeout(0.5)
        except Exception:
            self.stop()
            raise

    def start(self):
        for sock in self.listeners:
            thread = threading.Thread(target=self._accept, args=(sock,), daemon=True)
            thread.start()
            self.threads.append(thread)

    def alive(self):
        return bool(self.threads) and all(thread.is_alive() for thread in self.threads)

    def _accept(self, listener):
        while not self.stopped.is_set():
            try:
                conn, peer = listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            if not self.limit.acquire(False):
                conn.close()
                continue
            with self.lock:
                if self.stopped.is_set():
                    conn.close()
                    self.limit.release()
                    break
                self.sockets.add(conn)
            thread = threading.Thread(target=self._client, args=(conn, peer[0]), daemon=True)
            try:
                with self.lock:
                    self.workers.add(thread)
                thread.start()
            except RuntimeError:
                with self.lock:
                    self.workers.discard(thread)
                    self.sockets.discard(conn)
                conn.close()
                self.limit.release()

    def _client(self, client, client_ip):
        backend = None
        try:
            client.settimeout(5)
            first = client.recv(1, socket.MSG_PEEK)
            if first == b'\x05':
                kind = 'socks'
            elif first == b'\x16':
                kind = 'tls'
            elif first and b'A' <= first <= b'Z':
                kind = 'http'
            else:
                return
            if kind not in self.backends:
                return
            target = self.backends[kind]
            unix = isinstance(target, str)
            family = socket.AF_UNIX if unix else socket.AF_INET
            backend = socket.socket(family, socket.SOCK_STREAM)
            with self.lock:
                if self.stopped.is_set():
                    return
                self.sockets.add(backend)
            backend.settimeout(5)
            backend.connect('\0' + target if unix else ('127.0.0.1', target))
            self._relay(client, backend, client_ip, kind)
        except (OSError, ValueError):
            pass
        finally:
            with self.lock:
                self.sockets.discard(client)
                if backend:
                    self.sockets.discard(backend)
                self.workers.discard(threading.current_thread())
            client.close()
            if backend:
                backend.close()
            self.limit.release()

    def _relay(self, client, backend, client_ip, transport):
        peers = {client: backend, backend: client}
        buffers = {client: bytearray(), backend: bytearray()}
        read_open = {client: True, backend: True}
        write_open = {client: True, backend: True}
        uploaded = downloaded = saved_upload = saved_download = 0
        for sock in peers:
            sock.setblocking(False)
        last = time.monotonic()
        last_checkpoint = last
        try:
            while not self.stopped.is_set():
                for sock in peers:
                    if not read_open[peers[sock]] and not buffers[sock] and write_open[sock]:
                        sock.shutdown(socket.SHUT_WR)
                        write_open[sock] = False
                if not any(read_open.values()) and not any(buffers.values()):
                    return
                readers = [s for s in peers if read_open[s] and len(buffers[peers[s]]) < 65536]
                writers = [s for s in peers if buffers[s]]
                ready, writable, _ = select.select(readers, writers, [], 1)
                if not ready and not writable:
                    now = time.monotonic()
                    if now - last > 1800:
                        return
                    if now - last_checkpoint >= 1:
                        if self._persist_usage(client_ip, transport, uploaded - saved_upload,
                                               downloaded - saved_download):
                            saved_upload, saved_download = uploaded, downloaded
                            last_checkpoint = now
                    continue
                last = time.monotonic()
                for sock in ready:
                    data = sock.recv(min(65536 - len(buffers[peers[sock]]), 65536))
                    if data:
                        buffers[peers[sock]].extend(data)
                    else:
                        read_open[sock] = False
                for sock in writable:
                    sent = sock.send(buffers[sock])
                    del buffers[sock][:sent]
                    if sock is backend:
                        uploaded += sent
                    else:
                        downloaded += sent
                now = time.monotonic()
                if (uploaded - saved_upload + downloaded - saved_download >= USAGE_CHECKPOINT_BYTES or
                        now - last_checkpoint >= 1):
                    if self._persist_usage(client_ip, transport, uploaded - saved_upload,
                                           downloaded - saved_download):
                        saved_upload, saved_download = uploaded, downloaded
                        last_checkpoint = now
        finally:
            self._persist_usage(client_ip, transport, uploaded - saved_upload, downloaded - saved_download)

    def _persist_usage(self, client_ip, transport, uploaded, downloaded):
        if not self.stats_file or not (uploaded or downloaded):
            return True
        now = time.gmtime()
        day = time.strftime('%Y-%m-%d', now)
        record = {
            'time': time.strftime('%Y-%m-%dT%H:%M:%SZ', now),
            'client': client_ip,
            'transport': transport,
            'uploaded': uploaded,
            'downloaded': downloaded,
        }
        committed = False
        try:
            data = (json.dumps(record, separators=(',', ':')) + '\n').encode('utf-8')
            with self.lock:
                flags = os.O_APPEND | os.O_CREAT | os.O_RDWR | getattr(os, 'O_BINARY', 0)
                path = self.stats_file + '.' + day
                new_file = not os.path.exists(path)
                fd = os.open(path, flags, 0o600)
                try:
                    size = os.lseek(fd, 0, os.SEEK_END)
                    if size:
                        os.lseek(fd, -1, os.SEEK_END)
                        if os.read(fd, 1) != b'\n':
                            os.write(fd, b'\n')
                    written = os.write(fd, data)
                    committed = written > 0
                    if written != len(data):
                        raise OSError('incomplete relay usage write')
                    os.fsync(fd)
                finally:
                    os.close(fd)
                if new_file or day != self.usage_day:
                    self._prune_usage_files()
                    self.usage_day = day
                self.accounting_error = self.accounting_error or self.privacy_error or self.rotation_error
            return True
        except (IOError, OSError, ValueError):
            with self.lock:
                self.accounting_error = 'Relay usage could not be persisted (file or storage error).'
            # Do not retry an uncertain append: the full record may already be present.
            return committed

    def stop(self):
        self.stopped.set()
        with self.lock:
            sockets = list(self.sockets) + self.listeners
            self.listeners = []
        for sock in sockets:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            sock.close()
        for thread in self.threads:
            thread.join(1)
        deadline = time.monotonic() + 2
        with self.lock:
            workers = list(self.workers)
        for thread in workers:
            thread.join(max(0, deadline - time.monotonic()))
