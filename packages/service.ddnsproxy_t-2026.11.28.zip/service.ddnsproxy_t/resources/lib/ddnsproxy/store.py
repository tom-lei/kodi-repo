# -*- coding: utf-8 -*-
"""Atomic JSON files shared between the service and the UI (no Kodi imports)."""
import json
import os


class Paths(object):
    """File locations below the add-on profile directory."""

    def __init__(self, profile):
        self.profile = profile
        self.run = os.path.join(profile, 'run')
        self.engine_root = os.path.join(profile, 'engine')
        self.tls = os.path.join(profile, 'tls')
        self.status = os.path.join(profile, 'status.json')
        self.ddns_state = os.path.join(profile, 'ddns_state.json')
        self.config = os.path.join(self.run, '3proxy.cfg')
        self.pid = os.path.join(self.run, '3proxy.pid')
        self.output_log = os.path.join(self.run, 'engine-output.log')
        self.proxy_log = os.path.join(self.run, 'proxy.log')
        self.frontend_traffic = os.path.join(self.run, 'frontend-traffic.jsonl')

    def create(self):
        for path in (self.profile, self.run, self.engine_root, self.tls):
            if not os.path.isdir(path):
                os.makedirs(path)
        return self

    def latest_proxy_log(self):
        logs = self.proxy_logs()
        return logs[-1] if logs else None

    def proxy_logs(self):
        """Return all currently retained proxy accounting logs in filename order."""
        base = os.path.basename(self.proxy_log)
        try:
            names = sorted(n for n in os.listdir(self.run) if n.startswith(base))
        except OSError:
            return [self.proxy_log]
        return [os.path.join(self.run, name) for name in names]

    def frontend_traffic_logs(self):
        """Return the retained daily shared-port relay ledgers."""
        base = os.path.basename(self.frontend_traffic) + '.'
        try:
            names = sorted(n for n in os.listdir(self.run) if n.startswith(base))
        except OSError:
            return [self.frontend_traffic]
        return [os.path.join(self.run, name) for name in names]


def read_json(path, default=None):
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except (IOError, OSError, ValueError):
        return {} if default is None else default


def write_json(path, data):
    tmp = '%s.%d.tmp' % (path, os.getpid())
    with open(tmp, 'w', encoding='utf-8') as handle:
        json.dump(data, handle, indent=1, sort_keys=True, default=str)
    os.replace(tmp, path)
