# -*- coding: utf-8 -*-
"""Router port forwarding via UPnP IGD, NAT-PMP (RFC 6886) and PCP (RFC 6887).

UPnP control uses HTTP, so it goes through the Kodi-proxy-aware HttpClient.
If Kodi uses a proxy, UPnP is skipped (LAN requests would otherwise be sent
to the proxy); NAT-PMP/PCP are plain UDP to the gateway and unaffected.
"""
import ipaddress
import os
import re
import socket
import struct
import subprocess
import time
import urllib.parse
import xml.etree.ElementTree as ET

from . import netutil
from .httpclient import HttpError

DESCRIPTION = 'DDNS Proxy_t'
NATPMP_PORT = 5351
SSDP_ADDR = ('239.255.255.250', 1900)
IGD_SERVICES = ('urn:schemas-upnp-org:service:WANIPConnection:2',
                'urn:schemas-upnp-org:service:WANIPConnection:1',
                'urn:schemas-upnp-org:service:WANPPPConnection:1')

NATPMP_RESULTS = {
    1: 'unsupported version',
    2: 'not authorized/refused',
    3: 'network failure',
    4: 'out of resources',
    5: 'unsupported opcode',
}

PCP_RESULTS = {
    1: 'unsupported version', 2: 'not authorized', 3: 'malformed request', 4: 'unsupported opcode',
    5: 'unsupported option', 6: 'malformed option', 7: 'network failure', 8: 'no resources',
    9: 'unsupported protocol', 10: 'user exceeded quota', 11: 'cannot provide external',
    12: 'address mismatch', 13: 'excessive remote peers',
}


class PortMapError(Exception):
    pass


class Mapping(object):
    def __init__(self, method, internal_port, external_port, lifetime, external_ip='', extra=None):
        self.method = method
        self.internal_port = internal_port
        self.external_port = external_port
        self.lifetime = lifetime
        self.external_ip = external_ip
        self.extra = extra or {}
        self.created = time.time()

    def to_dict(self):
        return {'method': self.method, 'internal_port': self.internal_port,
                'external_port': self.external_port, 'lifetime': self.lifetime,
                'external_ip': self.external_ip, 'created': int(self.created)}


# ------------------------------------------------------------ gateway

def parse_proc_route(text):
    for line in (text or '').splitlines()[1:]:
        fields = line.split()
        if len(fields) >= 3 and fields[1] == '00000000' and fields[2] != '00000000':
            return socket.inet_ntoa(struct.pack('<I', int(fields[2], 16)))
    return None


def parse_route_print(text):
    for line in (text or '').splitlines():
        fields = line.split()
        if len(fields) >= 3 and fields[0] == '0.0.0.0' and fields[1] == '0.0.0.0':
            if netutil.parse_ip(fields[2]) is not None:
                return fields[2]
    return None


def default_gateway():
    if os.path.exists('/proc/net/route'):
        try:
            with open('/proc/net/route', 'r') as handle:
                return parse_proc_route(handle.read())
        except (IOError, OSError):
            return None
    if os.name == 'nt':
        try:
            out = subprocess.check_output(['route', 'print', '-4', '0.0.0.0'], creationflags=0x08000000,
                                          timeout=10)
            return parse_route_print(out.decode('utf-8', 'replace'))
        except (OSError, subprocess.SubprocessError):
            return None
    return None


# ------------------------------------------------------------ NAT-PMP

def _udp_exchange(gateway, payload, expect_len, timeout=0.25, tries=4, port=NATPMP_PORT):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        for attempt in range(tries):
            sock.settimeout(timeout * (2 ** attempt))
            sock.sendto(payload, (gateway, port))
            try:
                while True:
                    data, addr = sock.recvfrom(1100)
                    if addr[0] == gateway and len(data) >= expect_len:
                        return data
            except socket.timeout:
                continue
    finally:
        sock.close()
    raise PortMapError('no answer from %s:%d' % (gateway, port))


def natpmp_external_ip(gateway):
    data = _udp_exchange(gateway, b'\x00\x00', 12)
    _, op, result = struct.unpack('!BBH', data[:4])
    if op != 128 or result != 0:
        raise PortMapError('NAT-PMP: %s' % NATPMP_RESULTS.get(result, 'error %d' % result))
    return socket.inet_ntoa(data[8:12])


def natpmp_request(internal_port, external_port, lifetime):
    return struct.pack('!BBHHHI', 0, 2, 0, internal_port, external_port, lifetime)


def parse_natpmp_response(data):
    ver, op, result, _epoch, internal, external, lifetime = struct.unpack('!BBHIHHI', data[:16])
    if ver != 0 or op != 130:
        raise PortMapError('NAT-PMP: unexpected response')
    if result != 0:
        raise PortMapError('NAT-PMP: %s' % NATPMP_RESULTS.get(result, 'error %d' % result))
    return internal, external, lifetime


def natpmp_map(gateway, internal_port, external_port, lifetime):
    data = _udp_exchange(gateway, natpmp_request(internal_port, external_port, lifetime), 16)
    internal, external, granted = parse_natpmp_response(data)
    ext_ip = ''
    try:
        ext_ip = natpmp_external_ip(gateway)
    except PortMapError:
        pass
    return Mapping('NAT-PMP', internal, external, granted, ext_ip, {'gateway': gateway})


def natpmp_unmap(gateway, mapping):
    data = _udp_exchange(gateway, natpmp_request(mapping.internal_port, 0, 0), 16)
    parse_natpmp_response(data)


# ------------------------------------------------------------ PCP

def _mapped(ip):
    addr = ipaddress.ip_address(ip)
    if addr.version == 4:
        return ipaddress.IPv6Address('::ffff:' + str(addr)).packed
    return addr.packed


def pcp_request(client_ip, internal_port, external_port, lifetime, nonce):
    header = struct.pack('!BBHI', 2, 1, 0, lifetime) + _mapped(client_ip)
    payload = nonce + struct.pack('!B3xHH', 6, internal_port, external_port) + _mapped('0.0.0.0')
    return header + payload


def parse_pcp_response(data, nonce):
    if len(data) < 60:
        raise PortMapError('PCP: short response')
    ver, opcode, _, result, lifetime, _epoch = struct.unpack('!BBBBII', data[:12])
    if ver != 2:
        raise PortMapError('PCP: unsupported version %d' % ver)
    if opcode != 0x81:
        raise PortMapError('PCP: unexpected opcode')
    if result != 0:
        raise PortMapError('PCP: %s' % PCP_RESULTS.get(result, 'error %d' % result))
    if data[24:36] != nonce:
        raise PortMapError('PCP: nonce mismatch')
    internal, external = struct.unpack('!HH', data[40:44])
    ext_ip = ipaddress.IPv6Address(data[44:60])
    ext_ip = str(ext_ip.ipv4_mapped or ext_ip)
    return internal, external, lifetime, ext_ip


def pcp_map(gateway, client_ip, internal_port, external_port, lifetime, nonce=None):
    nonce = nonce or os.urandom(12)
    data = _udp_exchange(gateway, pcp_request(client_ip, internal_port, external_port, lifetime, nonce), 60)
    internal, external, granted, ext_ip = parse_pcp_response(data, nonce)
    return Mapping('PCP', internal, external, granted, ext_ip, {'gateway': gateway, 'nonce': nonce.hex(),
                                                                  'client_ip': client_ip})


def pcp_unmap(gateway, mapping):
    nonce = bytes.fromhex(mapping.extra['nonce'])
    data = _udp_exchange(gateway, pcp_request(mapping.extra['client_ip'], mapping.internal_port, 0, 0,
                                              nonce), 60)
    parse_pcp_response(data, nonce)


# ------------------------------------------------------------ UPnP IGD

def ssdp_discover(timeout=3.0):
    """Return a list of (location URL, responder IP)."""
    found = []
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
    sock.settimeout(0.5)
    try:
        for st in ('urn:schemas-upnp-org:device:InternetGatewayDevice:2',
                   'urn:schemas-upnp-org:device:InternetGatewayDevice:1'):
            msg = ('M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: "ssdp:discover"\r\n'
                   'MX: 2\r\nST: %s\r\n\r\n' % st).encode('ascii')
            sock.sendto(msg, SSDP_ADDR)
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                data, addr = sock.recvfrom(4096)
            except socket.timeout:
                continue
            match = re.search(r'^location:\s*(\S+)', data.decode('utf-8', 'replace'), re.I | re.M)
            if match and match.group(1) not in [f[0] for f in found]:
                found.append((match.group(1), addr[0]))
    finally:
        sock.close()
    return found


def _local(tag):
    return tag.rsplit('}', 1)[-1]


def parse_igd_description(xml_text, location):
    """Return (serviceType, absolute controlURL) of the WAN connection service, or None."""
    root = ET.fromstring(xml_text)
    base = location
    services = []
    for elem in root.iter():
        name = _local(elem.tag)
        if name == 'URLBase' and (elem.text or '').strip():
            base = elem.text.strip()
        elif name == 'service':
            info = {_local(child.tag): (child.text or '').strip() for child in elem}
            services.append(info)
    for wanted in IGD_SERVICES:
        for info in services:
            if info.get('serviceType') == wanted and info.get('controlURL'):
                return wanted, urllib.parse.urljoin(base, info['controlURL'])
    return None


def soap_body(service_type, action, args):
    parts = ''.join('<%s>%s</%s>' % (k, _xml_escape(str(v)), k) for k, v in args)
    return ('<?xml version="1.0"?>\r\n'
            '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
            's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body>'
            '<u:%s xmlns:u="%s">%s</u:%s></s:Body></s:Envelope>' % (action, service_type, parts, action))


def _xml_escape(text):
    return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def parse_soap_response(xml_text):
    """Return (values dict, upnp error code or None, error description)."""
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return {}, -1, 'invalid SOAP response'
    values = {}
    code, desc = None, ''
    for elem in root.iter():
        name = _local(elem.tag)
        if name == 'errorCode':
            code = int((elem.text or '0').strip() or 0)
        elif name == 'errorDescription':
            desc = (elem.text or '').strip()
        elif len(elem) == 0 and name.startswith('New'):
            values[name] = (elem.text or '').strip()
    return values, code, desc


class UPnPClient(object):
    def __init__(self, client, control_url, service_type):
        self.client = client
        self.control_url = control_url
        self.service_type = service_type

    def call(self, action, args):
        resp = self.client.post(self.control_url, data=soap_body(self.service_type, action, args).encode('utf-8'),
                                headers={'Content-Type': 'text/xml; charset="utf-8"',
                                         'SOAPAction': '"%s#%s"' % (self.service_type, action)}, timeout=8)
        values, code, desc = parse_soap_response(resp.text())
        if resp.status != 200 or code:
            raise PortMapError('UPnP %s failed: %s %s' % (action, code or resp.status, desc))
        return values

    def external_ip(self):
        return self.call('GetExternalIPAddress', []).get('NewExternalIPAddress', '')

    def add(self, internal_client, internal_port, external_port, lifetime):
        args = [('NewRemoteHost', ''), ('NewExternalPort', external_port), ('NewProtocol', 'TCP'),
                ('NewInternalPort', internal_port), ('NewInternalClient', internal_client),
                ('NewEnabled', 1), ('NewPortMappingDescription', DESCRIPTION),
                ('NewLeaseDuration', lifetime)]
        try:
            self.call('AddPortMapping', args)
        except PortMapError as exc:
            if '725' not in str(exc):  # OnlyPermanentLeasesSupported
                raise
            args[-1] = ('NewLeaseDuration', 0)
            self.call('AddPortMapping', args)
            lifetime = 0
        return lifetime

    def delete(self, external_port):
        self.call('DeletePortMapping', [('NewRemoteHost', ''), ('NewExternalPort', external_port),
                                        ('NewProtocol', 'TCP')])


def upnp_find(client):
    for location, _ in ssdp_discover():
        if netutil.parse_ip(urllib.parse.urlparse(location).hostname or '') is None:
            continue
        try:
            resp = client.get(location, timeout=6)
            found = parse_igd_description(resp.text(), location) if resp.ok else None
        except (HttpError, ET.ParseError):
            continue
        if found:
            return UPnPClient(client, found[1], found[0])
    return None


def router_wan_ipv4(client, allow_upnp=True, gateway=None):
    """Ask the router for its WAN IPv4 address without creating any mapping.

    Tries NAT-PMP (UDP, read-only opcode 0), then UPnP IGD GetExternalIPAddress. UPnP is HTTP and the
    HttpClient follows Kodi's proxy, which cannot reach the LAN router, so it is skipped when
    allow_upnp is False. Returns (ip or '', method or error summary).
    """
    errors = []
    gateway = gateway if gateway is not None else default_gateway()
    if gateway:
        try:
            return natpmp_external_ip(gateway), 'NAT-PMP'
        except (PortMapError, OSError, struct.error) as exc:
            errors.append('NAT-PMP: %s' % exc)
    else:
        errors.append('NAT-PMP: default gateway unknown')
    if not allow_upnp:
        errors.append('UPnP: skipped because Kodi uses a proxy')
    else:
        try:
            igd = upnp_find(client)
            if igd is None:
                raise PortMapError('no UPnP internet gateway found')
            addr = netutil.parse_ip(igd.external_ip())
            if addr is None or addr.version != 4:
                raise PortMapError('router reported no IPv4 address')
            return str(addr), 'UPnP'
        except (PortMapError, HttpError, OSError) as exc:
            errors.append('UPnP: %s' % exc)
    return '', '; '.join(errors)


# ------------------------------------------------------------ manager

class PortMapper(object):
    """Keeps TCP port mappings alive using the first method that works."""

    def __init__(self, client, method='auto', lifetime=3600, log=lambda msg: None):
        self.client = client
        self.method = method
        self.lifetime = lifetime
        self.log = log
        self.mappings = {}
        self.errors = []
        self.external_ip = ''
        self.active_method = ''

    def _methods(self):
        if self.method == 'auto':
            return ['pcp', 'natpmp', 'upnp']
        return [self.method]

    def _map_one(self, port):
        errors = []
        gateway = default_gateway()
        local = netutil.local_ip(gateway or '192.0.2.1')
        for method in self._methods():
            try:
                if method in ('pcp', 'natpmp'):
                    if not gateway:
                        raise PortMapError('default gateway unknown')
                    if method == 'pcp':
                        return pcp_map(gateway, local, port, port, self.lifetime)
                    return natpmp_map(gateway, port, port, self.lifetime)
                if self.client.proxy() is not None:
                    raise PortMapError('skipped because Kodi uses a proxy')
                igd = upnp_find(self.client)
                if igd is None:
                    raise PortMapError('no UPnP internet gateway found')
                granted = igd.add(local, port, port, self.lifetime)
                ext_ip = ''
                try:
                    ext_ip = igd.external_ip()
                except PortMapError:
                    pass
                return Mapping('UPnP', port, port, granted, ext_ip,
                               {'control_url': igd.control_url, 'service_type': igd.service_type})
            except (PortMapError, HttpError, OSError) as exc:
                errors.append('%s: %s' % (method.upper(), exc))
        raise PortMapError('; '.join(errors))

    def ensure(self, ports, now=None):
        """Create/renew mappings for ports, remove obsolete ones. Returns status dict."""
        now = now or time.time()
        self.errors = []
        for port in list(self.mappings):
            if port not in ports:
                self._remove(port)
        for port in ports:
            mapping = self.mappings.get(port)
            if mapping and (mapping.lifetime == 0 or now < mapping.created + mapping.lifetime / 2.0):
                continue
            try:
                mapping = self._map_one(port)
            except PortMapError as exc:
                self.errors.append('port %d: %s' % (port, exc))
                self.mappings.pop(port, None)
                continue
            if mapping.external_port != port:
                self.errors.append('port %d: router assigned external port %d' % (port, mapping.external_port))
            self.mappings[port] = mapping
            self.active_method = mapping.method
            if mapping.external_ip:
                self.external_ip = mapping.external_ip
            self.log('%s mapping for port %d ok (lifetime %ds)' % (mapping.method, port, mapping.lifetime))
        return self.status()

    def _remove(self, port):
        mapping = self.mappings.pop(port, None)
        if mapping is None:
            return
        try:
            if mapping.method == 'NAT-PMP':
                natpmp_unmap(mapping.extra['gateway'], mapping)
            elif mapping.method == 'PCP':
                pcp_unmap(mapping.extra['gateway'], mapping)
            else:
                UPnPClient(self.client, mapping.extra['control_url'], mapping.extra['service_type']).delete(
                    mapping.external_port)
            self.log('removed %s mapping for port %d' % (mapping.method, port))
        except (PortMapError, HttpError, OSError) as exc:
            self.log('could not remove mapping for port %d: %s' % (port, exc))

    def remove_all(self):
        for port in list(self.mappings):
            self._remove(port)

    def status(self):
        return {
            'method': self.active_method,
            'external_ip': self.external_ip,
            'mappings': [m.to_dict() for m in self.mappings.values()],
            'errors': list(self.errors),
        }
