# -*- coding: utf-8 -*-
"""When to send DDNS updates (pure logic, no Kodi imports)."""
import time

from . import ddns

SETTLE_SECONDS = 1800          # DNS may lag behind a successful update (TTL, caches)
DNS_MISMATCH_RETRY = 6 * 3600  # don't hammer providers if DNS keeps disagreeing
MIN_RETRY = 300


def wanted_addresses(entry, ipv4, ipv6):
    return (ipv4 if entry.ipv4 else None), (ipv6 if entry.ipv6 else None)


def decide(state, entry, ipv4, ipv6, dns=None, now=None):
    """Return (update_needed, reason). state is the slot's persisted dict (may be empty)."""
    now = now or time.time()
    if not entry.enabled:
        return False, 'disabled'
    want4, want6 = wanted_addresses(entry, ipv4, ipv6)
    if not (want4 or want6):
        return False, 'public IP address unknown'
    if state.get('fingerprint') != entry.fingerprint():
        return True, 'configuration changed'
    if state.get('blocked'):
        return False, 'stopped after a permanent error - change the settings or use "Test"'
    if now < state.get('next_try', 0):
        return False, 'waiting before retry'
    if (want4 or None) != (state.get('ipv4') or None) or (want6 or None) != (state.get('ipv6') or None):
        return True, 'public IP address changed'
    if dns is not None and now - state.get('last_success', 0) > SETTLE_SECONDS \
            and now - state.get('last_dns_fix', 0) > DNS_MISMATCH_RETRY:
        if (want4 and want4 not in dns.get(4, [])) or (want6 and want6 not in dns.get(6, [])):
            return True, 'DNS does not match the public IP address'
    return False, 'up to date'


def apply_result(state, entry, result, ipv4, ipv6, reason='', now=None):
    """Return the new slot state after an update attempt."""
    now = now or time.time()
    want4, want6 = wanted_addresses(entry, ipv4, ipv6)
    new = dict(state) if state.get('fingerprint') == entry.fingerprint() else {}
    new.update({'fingerprint': entry.fingerprint(), 'result': result.to_dict(), 'last_attempt': now,
                'blocked': result.fatal})
    if reason.startswith('DNS'):
        new['last_dns_fix'] = now
    if result.success:
        new.update({'ipv4': want4, 'ipv6': want6, 'last_success': now, 'next_try': 0})
    elif not result.fatal:
        new['next_try'] = now + max(result.retry_after or 0, MIN_RETRY)
    return new


def summary(state):
    result = ddns.Result.from_dict(state.get('result')) if state.get('result') else None
    if result is None:
        return 'not updated yet'
    return '%s - %s' % (ddns.STATE_LABELS.get(result.state, result.state), result.message)
