# -*- coding: utf-8 -*-
"""Minimal OpenPGP detached-signature verification (RFC 4880, v4 RSA keys).

Kodi platforms (LibreELEC, Android) ship no gpg, so the signed SHA256SUMS of a
3proxy release are verified here in pure Python against a bundled public key
whose fingerprint is pinned in engine.json.
"""
import base64
import hashlib
import re
import struct

HASHES = {
    8: ('sha256', bytes.fromhex('3031300d060960864801650304020105000420')),
    9: ('sha384', bytes.fromhex('3041300d060960864801650304020205000430')),
    10: ('sha512', bytes.fromhex('3051300d060960864801650304020305000440')),
    11: ('sha224', bytes.fromhex('302d300d06096086480165030402040500041c')),
}
RSA_ALGOS = (1, 3)  # RSA (encrypt or sign), RSA sign-only
SIG_BINARY, SIG_TEXT = 0x00, 0x01
SUB_CREATED, SUB_EXPIRES, SUB_ISSUER, SUB_ISSUER_FPR = 2, 3, 16, 33


class SignatureError(Exception):
    pass


def _crc24(data):
    crc = 0xB704CE
    for byte in data:
        crc ^= byte << 16
        for _ in range(8):
            crc <<= 1
            if crc & 0x1000000:
                crc ^= 0x1864CFB
    return crc & 0xFFFFFF


def dearmor(text, kind):
    """Decode an ASCII-armored block ('PUBLIC KEY BLOCK' or 'SIGNATURE')."""
    if isinstance(text, bytes):
        text = text.decode('ascii', 'replace')
    match = re.search(r'-----BEGIN PGP %s-----\r?\n(.*?)-----END PGP %s-----' % (kind, kind), text, re.S)
    if not match:
        raise SignatureError('no armored PGP %s found' % kind.lower())
    lines = match.group(1).splitlines()
    # skip armor headers up to the first empty line, if any
    if '' in [l.strip() for l in lines]:
        first_blank = [l.strip() for l in lines].index('')
        if all(':' in l for l in lines[:first_blank]):
            lines = lines[first_blank + 1:]
    body, checksum = [], None
    for line in lines:
        line = line.strip()
        if line.startswith('=') and len(line) == 5:
            checksum = line[1:]
        elif line:
            body.append(line)
    try:
        data = base64.b64decode(''.join(body), validate=True)
    except (ValueError, TypeError):
        raise SignatureError('corrupt armored data')
    if checksum is not None:
        try:
            expected = struct.unpack('>I', b'\x00' + base64.b64decode(checksum))[0]
        except (ValueError, TypeError, struct.error):
            raise SignatureError('corrupt armor checksum')
        if _crc24(data) != expected:
            raise SignatureError('armor checksum mismatch')
    return data


def packets(data):
    """Yield (tag, body) for each OpenPGP packet."""
    pos = 0
    while pos < len(data):
        header = data[pos]
        pos += 1
        if not header & 0x80:
            raise SignatureError('invalid packet header')
        if header & 0x40:
            tag = header & 0x3F
            first = data[pos]
            if first < 192:
                length, pos = first, pos + 1
            elif first < 224:
                length, pos = ((first - 192) << 8) + data[pos + 1] + 192, pos + 2
            elif first == 255:
                length, pos = struct.unpack('>I', data[pos + 1:pos + 5])[0], pos + 5
            else:
                raise SignatureError('partial body lengths are not supported')
        else:
            tag = (header >> 2) & 0x0F
            ltype = header & 0x03
            if ltype == 3:
                raise SignatureError('indeterminate packet lengths are not supported')
            size = (1, 2, 4)[ltype]
            length = int.from_bytes(data[pos:pos + size], 'big')
            pos += size
        if pos + length > len(data):
            raise SignatureError('truncated packet')
        yield tag, data[pos:pos + length]
        pos += length


def _mpi(data, pos):
    bits = struct.unpack('>H', data[pos:pos + 2])[0]
    size = (bits + 7) // 8
    if pos + 2 + size > len(data):
        raise SignatureError('truncated MPI')
    return int.from_bytes(data[pos + 2:pos + 2 + size], 'big'), pos + 2 + size


class PublicKey(object):
    def __init__(self, body):
        if len(body) < 6 or body[0] != 4:
            raise SignatureError('only version 4 OpenPGP keys are supported')
        self.created = struct.unpack('>I', body[1:5])[0]
        self.algo = body[5]
        self.fingerprint = hashlib.sha1(b'\x99' + struct.pack('>H', len(body)) + body).hexdigest().upper()
        self.key_id = self.fingerprint[-16:]
        self.n = self.e = None
        if self.algo in RSA_ALGOS:
            self.n, pos = _mpi(body, 6)
            self.e, _ = _mpi(body, pos)


def load_keys(armored):
    """Return the primary key and subkeys of an armored public key block."""
    keys = [PublicKey(body) for tag, body in packets(dearmor(armored, 'PUBLIC KEY BLOCK')) if tag in (6, 14)]
    if not keys:
        raise SignatureError('no public key in key block')
    return keys


def normalize_fingerprint(value):
    return re.sub(r'[^0-9A-Fa-f]', '', value or '').upper()


def _subpackets(data):
    pos, result = 0, []
    while pos < len(data):
        first = data[pos]
        if first < 192:
            length, pos = first, pos + 1
        elif first < 255:
            length, pos = ((first - 192) << 8) + data[pos + 1] + 192, pos + 2
        else:
            length, pos = struct.unpack('>I', data[pos + 1:pos + 5])[0], pos + 5
        if length < 1 or pos + length > len(data):
            raise SignatureError('corrupt signature subpacket')
        result.append((data[pos] & 0x7F, bool(data[pos] & 0x80), data[pos + 1:pos + length]))
        pos += length
    return result


class Signature(object):
    def __init__(self, body):
        if len(body) < 10 or body[0] != 4:
            raise SignatureError('only version 4 OpenPGP signatures are supported')
        self.sig_type, self.algo, self.hash_algo = body[1], body[2], body[3]
        hashed_len = struct.unpack('>H', body[4:6])[0]
        self.hashed_part = body[:6 + hashed_len]
        self.hashed = _subpackets(body[6:6 + hashed_len])
        pos = 6 + hashed_len
        unhashed_len = struct.unpack('>H', body[pos:pos + 2])[0]
        self.unhashed = _subpackets(body[pos + 2:pos + 2 + unhashed_len])
        pos += 2 + unhashed_len
        self.left16 = body[pos:pos + 2]
        self.value, _ = _mpi(body, pos + 2)
        self.created = self.expires_after = None
        self.issuer_key_id = self.issuer_fpr = None
        for stype, critical, sdata in self.hashed:
            if stype == SUB_CREATED:
                self.created = struct.unpack('>I', sdata[:4])[0]
            elif stype == SUB_EXPIRES:
                self.expires_after = struct.unpack('>I', sdata[:4])[0]
            elif stype == SUB_ISSUER_FPR:
                self.issuer_fpr = sdata[1:].hex().upper()
            elif stype == SUB_ISSUER:
                self.issuer_key_id = sdata.hex().upper()
            elif critical:
                raise SignatureError('unsupported critical signature subpacket %d' % stype)
        for stype, _critical, sdata in self.unhashed:
            if stype == SUB_ISSUER and not self.issuer_key_id:
                self.issuer_key_id = sdata.hex().upper()
            elif stype == SUB_ISSUER_FPR and not self.issuer_fpr:
                self.issuer_fpr = sdata[1:].hex().upper()


def load_signature(armored):
    sigs = [Signature(body) for tag, body in packets(dearmor(armored, 'SIGNATURE')) if tag == 2]
    if len(sigs) != 1:
        raise SignatureError('expected exactly one signature, found %d' % len(sigs))
    return sigs[0]


def _canonical_text(data):
    return re.sub(rb'\r?\n', b'\r\n', data)


def verify_detached(data, armored_signature, armored_key, fingerprint, now=None):
    """Verify a detached signature over data made by the key with the pinned fingerprint.

    Returns the Signature on success, raises SignatureError otherwise.
    """
    pinned = normalize_fingerprint(fingerprint)
    if len(pinned) != 40:
        raise SignatureError('no valid signing key fingerprint configured')
    key = next((k for k in load_keys(armored_key) if k.fingerprint == pinned), None)
    if key is None:
        raise SignatureError('bundled key does not match the pinned fingerprint %s' % pinned)
    if key.algo not in RSA_ALGOS or key.n is None:
        raise SignatureError('unsupported key algorithm %d' % key.algo)
    sig = load_signature(armored_signature)
    if sig.issuer_fpr and sig.issuer_fpr != key.fingerprint:
        raise SignatureError('signed by unknown key %s' % sig.issuer_fpr)
    if sig.issuer_key_id and sig.issuer_key_id != key.key_id:
        raise SignatureError('signed by unknown key %s' % sig.issuer_key_id)
    if sig.sig_type not in (SIG_BINARY, SIG_TEXT):
        raise SignatureError('not a document signature (type 0x%02x)' % sig.sig_type)
    if sig.algo != key.algo and not (sig.algo in RSA_ALGOS and key.algo in RSA_ALGOS):
        raise SignatureError('signature algorithm does not match the key')
    if sig.hash_algo not in HASHES:
        raise SignatureError('unsupported or weak hash algorithm %d' % sig.hash_algo)
    if sig.created is None:
        raise SignatureError('signature has no creation time')
    if now is not None and sig.expires_after and now > sig.created + sig.expires_after:
        raise SignatureError('signature has expired')
    if isinstance(data, str):
        data = data.encode('utf-8')
    name, digest_info = HASHES[sig.hash_algo]
    hasher = hashlib.new(name)
    hasher.update(_canonical_text(data) if sig.sig_type == SIG_TEXT else data)
    hasher.update(sig.hashed_part)
    hasher.update(b'\x04\xff' + struct.pack('>I', len(sig.hashed_part)))
    digest = hasher.digest()
    if digest[:2] != sig.left16:
        raise SignatureError('BAD signature (digest mismatch)')
    size = (key.n.bit_length() + 7) // 8
    if sig.value >= key.n:
        raise SignatureError('BAD signature')
    encoded = pow(sig.value, key.e, key.n).to_bytes(size, 'big')
    suffix = digest_info + digest
    expected = b'\x00\x01' + b'\xff' * (size - len(suffix) - 3) + b'\x00' + suffix
    if encoded != expected:
        raise SignatureError('BAD signature')
    return sig
