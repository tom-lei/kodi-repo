# -*- coding: utf-8 -*-
"""Thin Kodi adapter: settings, paths, logging, JSON-RPC and Kodi's proxy."""
import json
import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .config import ADDON_ID
from .httpclient import ProxyConfig, ProxyUnsupportedError

ADDON_NAME = u'DDNS Proxy\u1d40'


def addon():
    # A fresh object is needed to see settings saved by another process.
    return xbmcaddon.Addon(ADDON_ID)


class Settings(object):
    def __init__(self):
        self._addon = addon()

    def get_bool(self, key):
        try:
            return self._addon.getSettingBool(key)
        except (RuntimeError, TypeError):
            return self._addon.getSetting(key).lower() == 'true'

    def get_int(self, key):
        try:
            return self._addon.getSettingInt(key)
        except (RuntimeError, TypeError):
            try:
                return int(self._addon.getSetting(key))
            except ValueError:
                return 0

    def get_string(self, key):
        return self._addon.getSetting(key)

    def set_string(self, key, value):
        self._addon.setSetting(key, value)


def localize(string_id):
    return addon().getLocalizedString(string_id)


def profile_dir():
    path = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def addon_dir():
    return xbmcvfs.translatePath(addon().getAddonInfo('path'))


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(message, error=False, ms=6000):
    icon = xbmcgui.NOTIFICATION_ERROR if error else os.path.join(addon_dir(), 'resources', 'icon.png')
    xbmcgui.Dialog().notification(ADDON_NAME, message, icon, ms)


def jsonrpc(method, **params):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if 'error' in response:
        raise RuntimeError('%s: %s' % (method, response['error'].get('message')))
    return response.get('result')


def _setting_value(name):
    return jsonrpc('Settings.GetSettingValue', setting=name)['value']


def kodi_proxy():
    """Kodi's configured network proxy (None = direct). Raises if it cannot be read (fail closed)."""
    try:
        if not _setting_value('network.usehttpproxy'):
            return None
        server = (_setting_value('network.httpproxyserver') or '').strip()
        port = int(_setting_value('network.httpproxyport') or 0)
        ptype = int(_setting_value('network.httpproxytype') or 0)
        username = _setting_value('network.httpproxyusername') or ''
        password = _setting_value('network.httpproxypassword') or ''
    except Exception as exc:
        raise ProxyUnsupportedError('Cannot read Kodi proxy settings (%s); request blocked' % exc)
    if not server or not port:
        # Kodi itself ignores an incomplete proxy configuration.
        return None
    for prefix in ('http://', 'https://', 'socks4://', 'socks4a://', 'socks5://', 'socks5h://'):
        if server.lower().startswith(prefix):
            server = server[len(prefix):]
    return ProxyConfig(ptype, server.rstrip('/'), port, username, password)


def open_settings():
    addon().openSettings()


def run_script(*args):
    xbmc.executebuiltin('RunScript(%s,%s)' % (ADDON_ID, ','.join(args)))


def notify_service(command):
    """Send a command to the running service (received in Monitor.onNotification)."""
    jsonrpc('JSONRPC.NotifyAll', sender=ADDON_ID, message='command', data={'command': command})
