# -*- coding: utf-8 -*-
"""Public IPv4/IPv6 detection through the (Kodi-proxy-aware) HttpClient."""
from . import netutil
from .httpclient import HttpError

V4_SOURCES = ('https://api.ipify.org', 'https://ipv4.icanhazip.com', 'https://v4.ident.me')
V6_SOURCES = ('https://api6.ipify.org', 'https://ipv6.icanhazip.com', 'https://v6.ident.me')


def parse_ip_response(text, version):
    addr = netutil.parse_ip((text or '').strip().splitlines()[0] if (text or '').strip() else '')
    if addr is None or addr.version != version or not netutil.is_external(addr):
        return None
    return str(addr)


def detect(client, version, sources=None):
    """Return (ip or None, source or error summary)."""
    errors = []
    for url in sources or (V4_SOURCES if version == 4 else V6_SOURCES):
        try:
            resp = client.get(url, timeout=8, headers={'Accept': 'text/plain'})
        except HttpError as exc:
            errors.append('%s: %s' % (url, exc))
            continue
        if not resp.ok:
            errors.append('%s: HTTP %d' % (url, resp.status))
            continue
        ip = parse_ip_response(resp.text(), version)
        if ip:
            return ip, url
        errors.append('%s: no public IPv%d in response' % (url, version))
    return None, '; '.join(errors)


def detect_all(client, want_v4=True, want_v6=True):
    result = {'ipv4': None, 'ipv6': None, 'ipv4_info': '', 'ipv6_info': ''}
    if want_v4:
        result['ipv4'], result['ipv4_info'] = detect(client, 4)
    if want_v6:
        result['ipv6'], result['ipv6_info'] = detect(client, 6)
    return result


def reconcile(detected, router_ip='', router_info='', via_proxy='', local_v6=None):
    """Decide which addresses may be published via DDNS.

    detected: result of detect_all (as seen by web services, i.e. through Kodi's proxy if any).
    router_ip/router_info: WAN IPv4 reported by the router (NAT-PMP/UPnP/PCP) or '' and why not.
    via_proxy: description of Kodi's proxy, '' if none. local_v6: global IPv6 of this device.
    Returns a status dict; 'ipv4'/'ipv6' are None unless trustworthy, 'paused' explains a pause.
    """
    result = dict(detected)
    notes = []
    router = netutil.parse_ip(router_ip) if router_ip else None
    router_public = router is not None and router.version == 4 and netutil.is_external(router)
    result.update({'router_ipv4': str(router) if router is not None else '', 'router_info': router_info,
                   'paused': '', 'notes': notes})
    if via_proxy:
        result['via_proxy'] = via_proxy
        result['proxy_ipv4'] = detected.get('ipv4')
        if router_public:
            result['ipv4'] = str(router)
            result['ipv4_info'] = 'router WAN address (%s)' % router_info
        else:
            result['ipv4'] = None
            if router is not None:
                why = 'the router WAN address %s is not public (carrier-grade NAT or a second router)' % router
            else:
                why = 'the router did not report its WAN address (%s)' % (router_info or 'not asked')
            result['ipv4_info'] = why
        v6 = netutil.parse_ip(local_v6) if local_v6 else None
        if v6 is not None and v6.version == 6 and netutil.is_external(v6):
            result['ipv6'] = str(v6)
            result['ipv6_info'] = 'address of this device'
        else:
            result['ipv6'] = None
            result['ipv6_info'] = 'no global IPv6 address on this device'
        if result['ipv4'] is None:
            result['paused'] = (
                'Kodi uses the proxy %s, so web services only see the proxy\'s address, and %s. '
                'IPv4 DDNS updates are paused so that no wrong address is published. Enable NAT-PMP '
                'on the router, or switch off Kodi\'s proxy (Settings > System > Internet access).'
                % (via_proxy, why))
        return result
    if router_public:
        if detected.get('ipv4') and detected['ipv4'] != str(router):
            notes.append('Web services see %s, but the router reports %s (VPN or proxy on this device?). '
                         'The router address is used for DDNS.' % (detected['ipv4'], router))
        if detected.get('ipv4') != str(router):
            result['ipv4'] = str(router)
            result['ipv4_info'] = 'router WAN address (%s)' % router_info
    elif router is not None:
        notes.append('The router WAN address %s is not public (carrier-grade NAT or a second router). '
                     'Connections from the internet will probably not reach this device.' % router)
    return result
