# -*- coding: utf-8 -*-
"""Pure-Python RSA key and X.509 certificate generation.

Kodi has no bundled crypto library on all platforms, so this module creates
a small local CA plus a server certificate signed by it (3proxy recommends
server certificates that are not self-signed and that carry a SAN).
"""
import base64
import datetime
import hashlib
import ipaddress
import os
import secrets

_SMALL_PRIMES = [p for p in range(3, 2000) if all(p % d for d in range(2, int(p ** 0.5) + 1))]

OID_RSA = '1.2.840.113549.1.1.1'
OID_SHA256_RSA = '1.2.840.113549.1.1.11'
OID_CN = '2.5.4.3'
OID_O = '2.5.4.10'
OID_SKI = '2.5.29.14'
OID_KEY_USAGE = '2.5.29.15'
OID_SAN = '2.5.29.17'
OID_BASIC_CONSTRAINTS = '2.5.29.19'
OID_AKI = '2.5.29.35'
OID_EXT_KEY_USAGE = '2.5.29.37'
OID_SERVER_AUTH = '1.3.6.1.5.5.7.3.1'
_SHA256_DIGEST_INFO = bytes.fromhex('3031300d060960864801650304020105000420')


# ---------------------------------------------------------------- RSA

class RSAKey(object):
    def __init__(self, n, e, d, p, q):
        self.n, self.e, self.d, self.p, self.q = n, e, d, p, q

    @property
    def size_bytes(self):
        return (self.n.bit_length() + 7) // 8

    def sign_sha256(self, data):
        """RSASSA-PKCS1-v1_5 with SHA-256."""
        t = _SHA256_DIGEST_INFO + hashlib.sha256(data).digest()
        k = self.size_bytes
        em = b'\x00\x01' + b'\xff' * (k - len(t) - 3) + b'\x00' + t
        m = int.from_bytes(em, 'big')
        # CRT
        dp, dq = self.d % (self.p - 1), self.d % (self.q - 1)
        qinv = pow(self.q, -1, self.p)
        m1, m2 = pow(m, dp, self.p), pow(m, dq, self.q)
        s = m2 + self.q * ((qinv * (m1 - m2)) % self.p)
        return s.to_bytes(k, 'big')

    def verify_sha256(self, data, signature):
        s = int.from_bytes(signature, 'big')
        em = pow(s, self.e, self.n).to_bytes(self.size_bytes, 'big')
        return em.endswith(_SHA256_DIGEST_INFO + hashlib.sha256(data).digest()) and em.startswith(b'\x00\x01\xff')

    def public_der(self):
        return der_seq(der_int(self.n), der_int(self.e))

    def private_der(self):
        return der_seq(der_int(0), der_int(self.n), der_int(self.e), der_int(self.d),
                       der_int(self.p), der_int(self.q), der_int(self.d % (self.p - 1)),
                       der_int(self.d % (self.q - 1)), der_int(pow(self.q, -1, self.p)))

    def private_pem(self):
        return pem('RSA PRIVATE KEY', self.private_der())


def _is_probable_prime(n, rounds=40):
    if n < 2:
        return False
    for p in _SMALL_PRIMES:
        if n % p == 0:
            return n == p
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for _ in range(rounds):
        a = secrets.randbelow(n - 3) + 2
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def _gen_prime(bits, e):
    while True:
        candidate = secrets.randbits(bits) | (3 << (bits - 2)) | 1
        if (candidate - 1) % e == 0:
            continue
        if _is_probable_prime(candidate):
            return candidate


def generate_rsa(bits=2048, e=65537):
    while True:
        p = _gen_prime(bits // 2, e)
        q = _gen_prime(bits - bits // 2, e)
        if p == q:
            continue
        n = p * q
        if n.bit_length() != bits:
            continue
        d = pow(e, -1, (p - 1) * (q - 1))
        if p < q:
            p, q = q, p
        return RSAKey(n, e, d, p, q)


# ---------------------------------------------------------------- DER

def _der_len(n):
    if n < 0x80:
        return bytes([n])
    raw = n.to_bytes((n.bit_length() + 7) // 8, 'big')
    return bytes([0x80 | len(raw)]) + raw


def der_tlv(tag, content):
    return bytes([tag]) + _der_len(len(content)) + content


def der_int(value):
    if value < 0:
        raise ValueError('negative integers are not supported')
    return der_tlv(0x02, value.to_bytes(value.bit_length() // 8 + 1, 'big'))


def der_seq(*items):
    return der_tlv(0x30, b''.join(items))


def der_set(*items):
    return der_tlv(0x31, b''.join(items))


def der_oid(dotted):
    parts = [int(x) for x in dotted.split('.')]
    body = bytes([40 * parts[0] + parts[1]])
    for part in parts[2:]:
        chunk = [part & 0x7F]
        part >>= 7
        while part:
            chunk.append(0x80 | (part & 0x7F))
            part >>= 7
        body += bytes(reversed(chunk))
    return der_tlv(0x06, body)


def der_null():
    return b'\x05\x00'


def der_bool(value):
    return der_tlv(0x01, b'\xff' if value else b'\x00')


def der_bitstring(payload, unused_bits=0):
    return der_tlv(0x03, bytes([unused_bits]) + payload)


def der_octets(payload):
    return der_tlv(0x04, payload)


def der_utf8(text):
    return der_tlv(0x0C, text.encode('utf-8'))


def der_time(when):
    if when.year < 2050:
        return der_tlv(0x17, when.strftime('%y%m%d%H%M%SZ').encode('ascii'))
    return der_tlv(0x18, when.strftime('%Y%m%d%H%M%SZ').encode('ascii'))


def der_explicit(number, content):
    return der_tlv(0xA0 | number, content)


def parse_der(data, pos=0):
    """Parse one TLV. Returns (tag, content, next_pos)."""
    tag = data[pos]
    length = data[pos + 1]
    pos += 2
    if length & 0x80:
        count = length & 0x7F
        length = int.from_bytes(data[pos:pos + count], 'big')
        pos += count
    return tag, data[pos:pos + length], pos + length


def pem(label, der):
    b64 = base64.b64encode(der).decode('ascii')
    lines = [b64[i:i + 64] for i in range(0, len(b64), 64)]
    return '-----BEGIN %s-----\n%s\n-----END %s-----\n' % (label, '\n'.join(lines), label)


def unpem(text, label):
    begin = '-----BEGIN %s-----' % label
    end = '-----END %s-----' % label
    start = text.index(begin) + len(begin)
    return base64.b64decode(''.join(text[start:text.index(end, start)].split()))


def load_private_key(pem_text):
    _, content, _ = parse_der(unpem(pem_text, 'RSA PRIVATE KEY'))
    values = []
    pos = 0
    while pos < len(content):
        tag, raw, pos = parse_der(content, pos)
        values.append(int.from_bytes(raw, 'big'))
    _, n, e, d, p, q = values[:6]
    return RSAKey(n, e, d, p, q)


# ---------------------------------------------------------------- X.509

def _name(common_name, organization=None):
    rdns = []
    if organization:
        rdns.append(der_set(der_seq(der_oid(OID_O), der_utf8(organization))))
    rdns.append(der_set(der_seq(der_oid(OID_CN), der_utf8(common_name))))
    return der_seq(*rdns)


def _extension(oid, value, critical=False):
    items = [der_oid(oid)]
    if critical:
        items.append(der_bool(True))
    items.append(der_octets(value))
    return der_seq(*items)


def _key_id(key):
    return hashlib.sha1(key.public_der()).digest()


def _san(names):
    entries = []
    for name in names:
        try:
            addr = ipaddress.ip_address(name)
        except ValueError:
            entries.append(der_tlv(0x82, name.encode('idna')))
        else:
            entries.append(der_tlv(0x87, addr.packed))
    return der_seq(*entries)


def build_certificate(subject_key, issuer_key, subject_cn, issuer_cn, not_before, not_after,
                      is_ca, san=(), organization=None):
    algorithm = der_seq(der_oid(OID_SHA256_RSA), der_null())
    spki = der_seq(der_seq(der_oid(OID_RSA), der_null()), der_bitstring(subject_key.public_der()))
    extensions = [_extension(OID_SKI, der_octets(_key_id(subject_key)))]
    if is_ca:
        extensions.append(_extension(OID_BASIC_CONSTRAINTS, der_seq(der_bool(True)), True))
        # keyCertSign (5) + cRLSign (6)
        extensions.append(_extension(OID_KEY_USAGE, der_bitstring(b'\x06', 1), True))
    else:
        extensions.append(_extension(OID_BASIC_CONSTRAINTS, der_seq(), True))
        # digitalSignature (0) + keyEncipherment (2)
        extensions.append(_extension(OID_KEY_USAGE, der_bitstring(b'\xa0', 5), True))
        extensions.append(_extension(OID_EXT_KEY_USAGE, der_seq(der_oid(OID_SERVER_AUTH))))
        extensions.append(_extension(OID_AKI, der_seq(der_tlv(0x80, _key_id(issuer_key)))))
        if san:
            extensions.append(_extension(OID_SAN, _san(san)))
    serial = int.from_bytes(os.urandom(16), 'big') >> 1 or 1
    tbs = der_seq(
        der_explicit(0, der_int(2)),
        der_int(serial),
        algorithm,
        _name(issuer_cn, organization),
        der_seq(der_time(not_before), der_time(not_after)),
        _name(subject_cn, organization),
        spki,
        der_explicit(3, der_seq(*extensions)),
    )
    signature = issuer_key.sign_sha256(tbs)
    return der_seq(tbs, algorithm, der_bitstring(signature))


def _now():
    return datetime.datetime.utcnow().replace(microsecond=0)


def create_ca(common_name, organization=None, years=10, bits=2048):
    key = generate_rsa(bits)
    start = _now() - datetime.timedelta(hours=1)
    cert = build_certificate(key, key, common_name, common_name, start,
                             start + datetime.timedelta(days=365 * years), True, organization=organization)
    return key, pem('CERTIFICATE', cert)


def create_server_cert(ca_key, ca_cn, names, key=None, days=397, organization=None, bits=2048):
    key = key or generate_rsa(bits)
    names = [n for n in names if n]
    start = _now() - datetime.timedelta(hours=1)
    cn = names[0] if names else 'localhost'
    cert = build_certificate(key, ca_key, cn, ca_cn, start, start + datetime.timedelta(days=days),
                             False, san=names or ['localhost'], organization=organization)
    return key, pem('CERTIFICATE', cert)


def certificate_validity(pem_text):
    """Return the validity interval (naive UTC datetimes) of a PEM certificate."""
    der = unpem(pem_text, 'CERTIFICATE')
    _, cert, _ = parse_der(der)
    _, tbs, _ = parse_der(cert)
    pos = 0
    fields = []
    while pos < len(tbs):
        tag, content, pos = parse_der(tbs, pos)
        fields.append((tag, content))
    if fields[0][0] == 0xA0:
        fields = fields[1:]
    validity = fields[3][1]
    def parse_time(tag, raw):
        if tag not in (0x17, 0x18):
            raise ValueError('Unsupported certificate time')
        text = raw.decode('ascii')
        year_width = 2 if tag == 0x17 else 4
        if len(text) != year_width + 11 or not text.endswith('Z') or not text[:-1].isdigit():
            raise ValueError('Unsupported certificate time')
        year = int(text[:year_width])
        if year_width == 2:
            year += 2000 if year < 50 else 1900
        parts = [int(text[i:i + 2]) for i in range(year_width, len(text) - 1, 2)]
        return datetime.datetime(year, *parts)
    tag, raw, next_pos = parse_der(validity)
    before = parse_time(tag, raw)
    tag, raw, _ = parse_der(validity, next_pos)
    return before, parse_time(tag, raw)


def certificate_not_after(pem_text):
    """Return notAfter (naive UTC datetime) of a PEM certificate."""
    return certificate_validity(pem_text)[1]
