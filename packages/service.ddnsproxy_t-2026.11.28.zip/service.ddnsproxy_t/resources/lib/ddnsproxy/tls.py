# -*- coding: utf-8 -*-
"""Automatic TLS certificate for the proxy listener (no Kodi imports).

A private CA is created once; clients may import ca.crt to trust the proxy.
The server certificate is reissued when its names change or it is about to
expire. Names include configured DDNS hostnames, the local IP and localhost.
"""
import datetime
import json
import os
import re
import ssl

from . import certgen, config

CA_CN = 'DDNS Proxy_t local CA'
ORGANIZATION = 'DDNS Proxy_t'
RENEW_DAYS = 30


def _write(path, text, private=False):
    tmp = path + '.tmp'
    with open(tmp, 'w', newline='\n') as handle:
        handle.write(text)
    if private and os.name != 'nt':
        os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def _read(path):
    try:
        with open(path, 'r') as handle:
            return handle.read()
    except (IOError, OSError):
        return None


def paths(directory):
    return {name: os.path.join(directory, name)
            for name in ('ca.key', 'ca.crt', 'server.key', 'server.crt', 'meta.json')}


def public_certificates(path):
    """Extract only PEM certificates, even when the source also contains private keys."""
    with open(path, 'r', encoding='ascii') as handle:
        text = handle.read()
    blocks = re.findall(r'-----BEGIN CERTIFICATE-----\s+.*?-----END CERTIFICATE-----', text, re.S)
    if not blocks:
        raise ValueError('No PEM certificates found')
    result = '\n'.join(blocks) + '\n'
    ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT).load_verify_locations(cadata=result)
    return result


def inspect_certificate(cert_file, key_file):
    """Check local PEM/key usability, not chain trust or hostname."""
    if not cert_file or not key_file:
        return 'Certificate or private key is not configured.'
    try:
        certs = public_certificates(cert_file)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(cert_file, key_file, password=lambda: '')
        not_before, expiry = certgen.certificate_validity(certs)
    except (OSError, ValueError, UnicodeError, IndexError, ssl.SSLError) as exc:
        return 'Certificate or private key is missing, invalid or unsupported: %s' % exc
    now = datetime.datetime.utcnow()
    if now < not_before:
        return 'The server certificate is not yet valid.'
    if expiry <= now:
        return 'The server certificate has expired.'
    return ''


def client_material(cfg, directory):
    """Return mode-specific guidance and safe public material to export."""
    if not cfg.tls_enabled:
        return [], ''
    p = paths(directory)
    custom = cfg.tls_mode == config.TLS_CUSTOM
    cert, key = (cfg.tls_cert_file, cfg.tls_key_file) if custom else (p['server.crt'], p['server.key'])
    lines = []
    issue = inspect_certificate(cert, key)
    if issue:
        lines.append('HTTPS certificate: ' + issue)
    lines.append('Client trust cannot be determined here. Each client must trust the issuer and connect '
                 'using a name or IP in the server certificate.')
    if custom:
        lines.append('Custom certificate: verify its chain and client trust; self-signed certificates '
                     'need explicit client trust where supported.')
        try:
            return lines, public_certificates(cert)
        except (OSError, ValueError, UnicodeError, ssl.SSLError) as exc:
            lines.append('Public certificate export unavailable: %s' % exc)
            return lines, ''
    lines.append('Automatic certificate: the private CA is not generally trusted; import it into each '
                 'client that supports HTTPS proxy trust.')
    try:
        ca = public_certificates(p['ca.crt'])
        chain = public_certificates(p['server.crt'])
        ca_der = {ssl.PEM_cert_to_DER_cert(block) for block in re.findall(
            r'-----BEGIN CERTIFICATE-----\s+.*?-----END CERTIFICATE-----', ca, re.S)}
        chain_der = {ssl.PEM_cert_to_DER_cert(block) for block in re.findall(
            r'-----BEGIN CERTIFICATE-----\s+.*?-----END CERTIFICATE-----', chain, re.S)}
        if not ca_der.issubset(chain_der):
            raise ValueError('CA does not match the stored server certificate chain')
        return lines, ca
    except (OSError, ValueError, UnicodeError, ssl.SSLError) as exc:
        lines.append('Automatic CA export unavailable: %s' % exc)
        return lines, ''


def normalize_names(names):
    result = []
    for name in names:
        name = (name or '').strip().lower()
        if name and name not in result:
            result.append(name)
    return result or ['localhost']


def needs_renewal(directory, names, now=None):
    now = now or datetime.datetime.utcnow()
    p = paths(directory)
    meta = _read(p['meta.json'])
    cert = _read(p['server.crt'])
    if not (meta and cert and os.path.isfile(p['server.key']) and os.path.isfile(p['ca.crt'])):
        return 'certificate missing'
    try:
        meta = json.loads(meta)
        not_after = certgen.certificate_not_after(cert)
    except (ValueError, IndexError, KeyError):
        return 'certificate unreadable'
    if sorted(meta.get('names', [])) != sorted(normalize_names(names)):
        return 'names changed'
    if not_after - now < datetime.timedelta(days=RENEW_DAYS):
        return 'expires soon'
    return None


def ensure(directory, names, force=False, log=lambda msg: None):
    """Make sure a valid certificate for names exists. Returns an info dict."""
    names = normalize_names(names)
    if not os.path.isdir(directory):
        os.makedirs(directory)
    p = paths(directory)
    reason = 'regeneration requested' if force else needs_renewal(directory, names)
    if reason:
        ca_pem = _read(p['ca.crt'])
        ca_key_pem = _read(p['ca.key'])
        ca_key = None
        if ca_pem and ca_key_pem:
            try:
                ca_key = certgen.load_private_key(ca_key_pem)
                if certgen.certificate_not_after(ca_pem) - datetime.datetime.utcnow() < datetime.timedelta(
                        days=400):
                    ca_key = None
            except (ValueError, IndexError):
                ca_key = None
        if ca_key is None:
            log('creating local certificate authority')
            ca_key, ca_pem = certgen.create_ca(CA_CN, organization=ORGANIZATION)
            _write(p['ca.key'], ca_key.private_pem(), True)
            _write(p['ca.crt'], ca_pem)
        log('issuing TLS certificate (%s) for %s' % (reason, ', '.join(names)))
        key, cert_pem = certgen.create_server_cert(ca_key, CA_CN, names, organization=ORGANIZATION)
        _write(p['server.key'], key.private_pem(), True)
        _write(p['server.crt'], cert_pem + ca_pem)
        _write(p['meta.json'], json.dumps({'names': names}))
    cert = _read(p['server.crt'])
    return {
        'cert_file': p['server.crt'],
        'key_file': p['server.key'],
        'ca_file': p['ca.crt'],
        'names': names,
        'not_after': certgen.certificate_not_after(cert).strftime('%Y-%m-%d'),
        'regenerated': bool(reason),
        'reason': reason or '',
    }
