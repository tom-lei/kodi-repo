# -*- coding: utf-8 -*-
"""On-demand external TCP port checks with several fallback services.

Order: Globalping API -> Check-Host API -> PortChecker.co -> CanYouSeeMe.org.
A checker that cannot give an answer reports UNAVAILABLE (never CLOSED), and
the next one is tried. No credentials are ever sent.
"""
import re
import threading
import time

from . import netutil
from .httpclient import HttpError

OPEN = 'open'
CLOSED = 'closed'
UNAVAILABLE = 'unavailable'
CANCELLED = 'cancelled'


class CheckResult(object):
    def __init__(self, state, service, detail=''):
        self.state = state
        self.service = service
        self.detail = detail

    @property
    def definitive(self):
        return self.state in (OPEN, CLOSED)

    def to_dict(self):
        return {'state': self.state, 'service': self.service, 'detail': self.detail}

    def __repr__(self):
        return 'CheckResult(%s, %s, %r)' % (self.state, self.service, self.detail)


# ------------------------------------------------------------ Globalping

def parse_globalping(data):
    """Interpret a finished/in-progress Globalping measurement. Returns (state, detail) or None if pending."""
    if data.get('status') == 'in-progress':
        return None
    results = data.get('results') or []
    received, answered, probes = 0, 0, 0
    for item in results:
        res = item.get('result') or {}
        probes += 1
        if res.get('status') != 'finished':
            continue
        stats = res.get('stats') or {}
        answered += 1
        received += int(stats.get('rcv') or 0)
    if received > 0:
        return OPEN, 'reachable from %d of %d probes' % (sum(
            1 for i in results if int(((i.get('result') or {}).get('stats') or {}).get('rcv') or 0) > 0), probes)
    if answered > 0:
        return CLOSED, 'no TCP connection from %d probes' % answered
    return UNAVAILABLE, 'no probe finished the measurement'


def check_globalping(client, host, port, wait=25, sleep=time.sleep):
    service = 'Globalping'
    body = {
        'type': 'ping',
        'target': host,
        'limit': 3,
        'measurementOptions': {'packets': 3, 'protocol': 'TCP', 'port': port},
    }
    if netutil.parse_ip(host) is None:
        body['measurementOptions']['ipVersion'] = 4
    try:
        resp = client.post('https://api.globalping.io/v1/measurements', json_body=body,
                           headers={'Accept': 'application/json'})
        if resp.status == 429:
            return CheckResult(UNAVAILABLE, service, 'rate limit reached')
        if resp.status not in (200, 202):
            return CheckResult(UNAVAILABLE, service, 'HTTP %d' % resp.status)
        mid = resp.json().get('id')
        if not mid:
            return CheckResult(UNAVAILABLE, service, 'no measurement id')
        deadline = time.time() + wait
        while True:
            sleep(1.0)
            resp = client.get('https://api.globalping.io/v1/measurements/%s' % mid,
                              headers={'Accept': 'application/json'})
            if resp.status != 200:
                return CheckResult(UNAVAILABLE, service, 'HTTP %d' % resp.status)
            parsed = parse_globalping(resp.json())
            if parsed is not None:
                return CheckResult(parsed[0], service, parsed[1])
            if time.time() > deadline:
                return CheckResult(UNAVAILABLE, service, 'timed out waiting for result')
    except (HttpError, ValueError, AttributeError) as exc:
        return CheckResult(UNAVAILABLE, service, str(exc))


# ------------------------------------------------------------ Check-Host

def parse_checkhost(data):
    """Returns (state, detail) or None while results are pending."""
    if not isinstance(data, dict) or not data:
        return None
    opened, failed, pending = 0, 0, 0
    errors = []
    for value in data.values():
        if value is None:
            pending += 1
            continue
        entries = value if isinstance(value, list) else [value]
        ok = False
        for entry in entries:
            if isinstance(entry, dict) and entry.get('time') is not None:
                ok = True
            elif isinstance(entry, dict) and entry.get('error'):
                errors.append(str(entry['error']))
        if ok:
            opened += 1
        else:
            failed += 1
    if opened:
        return OPEN, 'reachable from %d of %d nodes' % (opened, len(data))
    if pending:
        return None
    if failed:
        return CLOSED, 'not reachable from %d nodes (%s)' % (failed, ', '.join(sorted(set(errors)))[:120])
    return UNAVAILABLE, 'no node answered'


def check_checkhost(client, host, port, wait=25, sleep=time.sleep):
    service = 'Check-Host'
    headers = {'Accept': 'application/json'}
    try:
        resp = client.get('https://check-host.net/check-tcp',
                          params={'host': netutil.host_port(host, port), 'max_nodes': 3}, headers=headers)
        if resp.status != 200:
            return CheckResult(UNAVAILABLE, service, 'HTTP %d' % resp.status)
        data = resp.json()
        rid = data.get('request_id')
        if not data.get('ok') or not rid:
            return CheckResult(UNAVAILABLE, service, data.get('error') or 'request not accepted')
        deadline = time.time() + wait
        last = None
        while time.time() < deadline:
            sleep(2.0)
            resp = client.get('https://check-host.net/check-result/%s' % rid, headers=headers)
            if resp.status != 200:
                return CheckResult(UNAVAILABLE, service, 'HTTP %d' % resp.status)
            last = resp.json()
            parsed = parse_checkhost(last)
            if parsed is not None:
                return CheckResult(parsed[0], service, parsed[1])
        return CheckResult(UNAVAILABLE, service, 'timed out waiting for result')
    except (HttpError, ValueError, AttributeError) as exc:
        return CheckResult(UNAVAILABLE, service, str(exc))


# ------------------------------------------------------------ PortChecker.co

_CSRF_RE = re.compile(r'name=["\']_csrf["\'][^>]*value=["\']([^"\']+)["\']|'
                      r'value=["\']([^"\']+)["\'][^>]*name=["\']_csrf["\']', re.I)
_PORTCHECKER_RE = re.compile(r'\bis\s*(?:<[^>]*>\s*)*(open|closed)\b', re.I)


def parse_csrf(html):
    match = _CSRF_RE.search(html or '')
    if not match:
        return None
    return match.group(1) or match.group(2)


def parse_portchecker(html):
    match = _PORTCHECKER_RE.search(html or '')
    if not match:
        return UNAVAILABLE, 'result not recognised'
    return (OPEN, 'port is open') if match.group(1).lower() == 'open' else (CLOSED, 'port is closed')


def check_portchecker(client, host, port):
    service = 'PortChecker.co'
    if netutil.parse_ip(host) is None:
        resolved = netutil.resolve(host)
        host = next((ip for ip in resolved if ':' not in ip), host)
    try:
        page = client.get('https://portchecker.co/')
        token = parse_csrf(page.text()) if page.ok else None
        if not token:
            return CheckResult(UNAVAILABLE, service, 'form not available')
        resp = client.post('https://portchecker.co/check-v0',
                           data={'target_ip': host, 'port': str(port), '_csrf': token},
                           headers={'Referer': 'https://portchecker.co/', 'Origin': 'https://portchecker.co'})
        if not resp.ok:
            return CheckResult(UNAVAILABLE, service, 'HTTP %d' % resp.status)
        state, detail = parse_portchecker(resp.text())
        return CheckResult(state, service, detail)
    except HttpError as exc:
        return CheckResult(UNAVAILABLE, service, str(exc))


# ------------------------------------------------------------ CanYouSeeMe.org

_CYSM_IP_RE = re.compile(r'name=["\']IP["\'][^>]*value=["\']([0-9a-fA-F:.]+)["\']|'
                         r'value=["\']([0-9a-fA-F:.]+)["\'][^>]*name=["\']IP["\']', re.I)


def parse_canyouseeme_ip(html):
    match = _CYSM_IP_RE.search(html or '')
    if not match:
        return None
    return match.group(1) or match.group(2)


def parse_canyouseeme(html):
    text = re.sub(r'<[^>]+>', ' ', html or '')
    if re.search(r'Success:\s*I can see your service', text, re.I):
        return OPEN, 'service visible'
    if re.search(r'Error:\s*I could not see your service', text, re.I):
        return CLOSED, 'service not visible'
    return UNAVAILABLE, 'result not recognised'


def check_canyouseeme(client, host, port):
    service = 'CanYouSeeMe.org'
    target = host if netutil.parse_ip(host) else next(iter(netutil.resolve(host)), '')
    try:
        page = client.get('https://canyouseeme.org/')
        if not page.ok:
            return CheckResult(UNAVAILABLE, service, 'HTTP %d' % page.status)
        caller_ip = parse_canyouseeme_ip(page.text())
        if not caller_ip:
            return CheckResult(UNAVAILABLE, service, 'form not available')
        if not target or netutil.parse_ip(caller_ip) != netutil.parse_ip(target):
            return CheckResult(UNAVAILABLE, service,
                               'only checks the caller address %s, not %s' % (caller_ip, target or host))
        resp = client.post('https://canyouseeme.org/', data={'port': str(port), 'IP': caller_ip},
                           headers={'Referer': 'https://canyouseeme.org/'})
        if not resp.ok:
            return CheckResult(UNAVAILABLE, service, 'HTTP %d' % resp.status)
        state, detail = parse_canyouseeme(resp.text())
        return CheckResult(state, service, detail)
    except HttpError as exc:
        return CheckResult(UNAVAILABLE, service, str(exc))


CHECKERS = (check_globalping, check_checkhost, check_portchecker, check_canyouseeme)
CHECKER_NAMES = {'check_globalping': 'Globalping', 'check_checkhost': 'Check-Host',
                 'check_portchecker': 'PortChecker.co', 'check_canyouseeme': 'CanYouSeeMe.org'}
SERVICES = ', '.join(CHECKER_NAMES[c.__name__] for c in CHECKERS)


def check_port(client_factory, host, port, progress=None, checkers=CHECKERS):
    """Run checkers in order until one gives a definitive answer.

    client_factory() must return a fresh HttpClient (with cookies). Returns
    (final CheckResult, [all CheckResults]).
    """
    attempts = []
    for index, checker in enumerate(checkers):
        if progress and progress(index, len(checkers), checker):
            return CheckResult(CANCELLED, 'all', 'check cancelled'), attempts
        result = checker(client_factory(), host, port)
        attempts.append(result)
        if result.definitive:
            return result, attempts
    detail = '; '.join('%s: %s' % (a.service, a.detail) for a in attempts)
    return CheckResult(UNAVAILABLE, 'all', 'check unavailable (%s)' % detail), attempts


def check_ports(client_factory, host, ports, tick=None, checkers=CHECKERS, interval=0.5, grace=1.0):
    """Check several ports in parallel. Returns {port: (final CheckResult, attempts)}.

    tick(progress) is called in the caller's thread about every `interval`
    seconds with {port: current service or 'done'}; returning True cancels.
    After a cancel, ports still running are reported as CANCELLED without
    waiting for their HTTP requests to finish.
    """
    results = {}
    progress = dict((port, 'waiting') for port in ports)
    cancel = threading.Event()

    def worker(port):
        def step(index, total, checker):
            progress[port] = CHECKER_NAMES.get(checker.__name__, checker.__name__)
            return cancel.is_set()
        try:
            results[port] = check_port(client_factory, host, port, step, checkers)
        except Exception as exc:  # never let a checker bug hide the other results
            results[port] = (CheckResult(UNAVAILABLE, 'all', 'check failed: %s' % exc), [])
        progress[port] = 'done'

    threads = [threading.Thread(target=worker, args=(port,)) for port in ports]
    for thread in threads:
        thread.daemon = True
        thread.start()
    deadline = None
    while any(t.is_alive() for t in threads):
        if deadline is None and tick is not None and tick(dict(progress)):
            cancel.set()
            deadline = time.time() + grace
        if deadline is not None and time.time() > deadline:
            break
        time.sleep(interval)
    for port in ports:
        if port not in results:
            results[port] = (CheckResult(CANCELLED, 'all', 'check cancelled'), [])
    return results
