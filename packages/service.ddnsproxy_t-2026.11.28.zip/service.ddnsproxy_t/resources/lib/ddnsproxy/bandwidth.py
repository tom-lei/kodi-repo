# -*- coding: utf-8 -*-
"""Read privacy-limited 3proxy access logs for the bandwidth report."""
import ipaddress
import json
import os
import re
import time


_RECORD = re.compile(
    r'^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2}) ([DS]) '
    r'([A-Za-z0-9._-]{1,64}) (\S+) (\d+) (\d+)(?:\s|$)'
)
_TIMESTAMP = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?:\s|$)')
_TRANSPORTS = {'http', 'tls', 'socks'}


def parse_line(line):
    """Return one current-format 3proxy record; L is a timezone selector, not output."""
    match = _RECORD.match(line)
    if not match:
        return None
    date, clock, mode, username, client, uploaded, downloaded = match.groups()
    try:
        ipaddress.ip_address(client.strip('[]'))
        # Reject malformed dates instead of displaying arbitrary log text.
        time.strptime(date + ' ' + clock, '%Y-%m-%d %H:%M:%S')
        uploaded, downloaded = int(uploaded), int(downloaded)
    except (ValueError, OverflowError):
        return None
    return {
        'timestamp': date + ' ' + clock,
        'mode': mode,
        'username': username,
        'client': client.strip('[]'),
        'downloaded': downloaded,
        'uploaded': uploaded,
    }


def read_logs(paths):
    """Read direct-mode payload counts, excluding unmarked or shared records."""
    result = {
        'requests': 0, 'uploaded': 0, 'downloaded': 0, 'first': '', 'last': '',
        'clients': {}, 'errors': [], 'shared_excluded': 0, 'unclassified': 0,
    }
    for path in paths:
        try:
            handle = open(path, 'r', encoding='utf-8', errors='replace')
        except (IOError, OSError):
            result['errors'].append(os.path.basename(path))
            continue
        try:
            with handle:
                for line in handle:
                    record = parse_line(line)
                    if record is None:
                        if _TIMESTAMP.match(line):
                            result['unclassified'] += 1
                        continue
                    if record['mode'] == 'S':
                        result['shared_excluded'] += 1
                        continue
                    if record['username'] == '-':
                        continue
                    result['requests'] += 1
                    result['uploaded'] += record['uploaded']
                    result['downloaded'] += record['downloaded']
                    stamp = record['timestamp']
                    if not result['first'] or stamp < result['first']:
                        result['first'] = stamp
                    if stamp > result['last']:
                        result['last'] = stamp
                    client = result['clients'].setdefault(record['client'], {
                        'uploaded': 0, 'downloaded': 0, 'requests': 0, 'users': set(),
                    })
                    client['uploaded'] += record['uploaded']
                    client['downloaded'] += record['downloaded']
                    client['requests'] += 1
                    client['users'].add(record['username'])
        except (IOError, OSError):
            result['errors'].append(os.path.basename(path))
    return result


def read_frontend_ledger(paths):
    """Aggregate retained dispatcher relay deltas; no 3proxy logs are read here."""
    result = {
        'requests': 0, 'uploaded': 0, 'downloaded': 0, 'first': '', 'last': '',
        'clients': {}, 'errors': [], 'checkpoints': 0,
    }
    if isinstance(paths, str):
        paths = [paths]
    for path in paths:
        try:
            handle = open(path, 'r', encoding='utf-8', errors='replace')
        except (IOError, OSError):
            result['errors'].append(os.path.basename(path))
            continue
        try:
            with handle:
                for line in handle:
                    try:
                        record = json.loads(line)
                        client = record['client']
                        if not isinstance(client, str):
                            raise ValueError('invalid client address')
                        ipaddress.ip_address(client)
                        transport = record['transport']
                        stamp = record['time']
                        time.strptime(stamp, '%Y-%m-%dT%H:%M:%SZ')
                        uploaded = record['uploaded']
                        downloaded = record['downloaded']
                        if (transport not in _TRANSPORTS or isinstance(uploaded, bool) or
                                isinstance(downloaded, bool) or not isinstance(uploaded, int) or
                                not isinstance(downloaded, int) or uploaded < 0 or downloaded < 0 or
                                not (uploaded or downloaded)):
                            raise ValueError('invalid relay usage fields')
                    except (KeyError, TypeError, ValueError):
                        result['errors'].append('invalid or incomplete relay usage records')
                        continue
                    result['checkpoints'] += 1
                    result['uploaded'] += uploaded
                    result['downloaded'] += downloaded
                    if not result['first'] or stamp < result['first']:
                        result['first'] = stamp
                    if stamp > result['last']:
                        result['last'] = stamp
                    identity = (client, transport)
                    usage = result['clients'].setdefault(identity, {
                        'uploaded': 0, 'downloaded': 0, 'checkpoints': 0,
                    })
                    usage['uploaded'] += uploaded
                    usage['downloaded'] += downloaded
                    usage['checkpoints'] += 1
        except (IOError, OSError):
            result['errors'].append(os.path.basename(path))
    return result


def format_bytes(value):
    value = float(value)
    for unit in ('B', 'KiB', 'MiB', 'GiB', 'TiB'):
        if value < 1024 or unit == 'TiB':
            return '%d %s' % (value, unit) if unit == 'B' else '%.2f %s' % (value, unit)
        value /= 1024.0


def format_report(stats, shared_port=False):
    lines = [
        '[B]Bandwidth usage[/B]',
        'Measured by 3proxy from its retained access logs; network overhead is not included.',
        '',
    ]
    if not stats['requests']:
        lines.append('No complete usage records are available yet.')
        lines.append('Usage is unavailable until an authenticated proxy request completes.')
        _append_log_caveats(lines, stats)
        return '\n'.join(lines)

    lines.extend([
        'Recorded: %s to %s' % (stats['first'], stats['last']),
        'Completed requests: %d' % stats['requests'],
        '3proxy payload out / client upload (%%O): %s' % format_bytes(stats['uploaded']),
        '3proxy payload in / client download (%%I): %s' % format_bytes(stats['downloaded']),
    ])
    if shared_port:
        lines.extend([
            '',
            '[COLOR orange]Per-client usage is unavailable in shared-port mode. '
            '3proxy only sees the local dispatcher, and the dispatcher does not inspect credentials.[/COLOR]',
            'Totals above are measured by 3proxy; they are not attributed to the loopback address.',
        ])
        return '\n'.join(lines)

    lines.extend(['', '[B]Clients by source IP[/B]'])
    clients = sorted(
        stats['clients'].items(),
        key=lambda item: (item[1]['uploaded'] + item[1]['downloaded'], item[0]),
        reverse=True,
    )
    for address, usage in clients[:20]:
        users = ', '.join(sorted(usage['users']))
        lines.append('%s (%s) - up %s, down %s, %d requests' % (
            address, users, format_bytes(usage['uploaded']), format_bytes(usage['downloaded']),
            usage['requests']))
    if len(clients) > 20:
        lines.append('Showing 20 of %d source IPs.' % len(clients))
    lines.extend([
        '',
        'Source IPs may identify a router or shared network, not an individual device.',
        'Statistics cover only log files still retained by 3proxy.',
    ])
    _append_log_caveats(lines, stats)
    return '\n'.join(lines)


def _append_log_caveats(lines, stats):
    if stats.get('errors'):
        lines.extend([
            '',
            '[COLOR red]Incomplete: could not read %d retained log file(s): %s. '
            'Totals exclude unreadable data.[/COLOR]' % (
                len(stats['errors']), ', '.join(sorted(set(stats['errors'])))),
        ])
    if stats.get('unclassified'):
        lines.extend([
            '',
            '[COLOR orange]%d older/unmarked log record(s) were excluded because their '
            'separate/shared mode cannot be determined.[/COLOR]' % stats['unclassified'],
        ])
    if stats.get('shared_excluded'):
        lines.extend([
            '',
            '%d shared-mode 3proxy payload record(s) excluded; shared-port relay totals are '
            'stored separately and are shown only in shared-port mode.' % stats['shared_excluded'],
        ])


def format_frontend_report(stats, status_error=''):
    lines = [
        '[B]Shared-port client bandwidth[/B]',
        'TCP relay bytes successfully written between the dispatcher and sockets; includes proxy '
        'authentication/protocol bytes and TLS handshake/record overhead.',
        'Excludes TCP/IP headers and retransmissions; a local socket write does not prove remote delivery.',
        'These are distinct from 3proxy payload counters and are not added to them.',
        '',
    ]
    if not stats['checkpoints']:
        lines.append('No complete relay-usage checkpoints are available yet.')
    else:
        lines.extend([
            'Recorded: %s to %s' % (stats['first'], stats['last']),
            'Uploaded (client to proxy): %s' % format_bytes(stats['uploaded']),
            'Downloaded (proxy to client): %s' % format_bytes(stats['downloaded']),
            '',
            '[B]Clients by source IP and transport[/B]',
        ])
        clients = sorted(
            stats['clients'].items(),
            key=lambda item: (item[1]['uploaded'] + item[1]['downloaded'], item[0]),
            reverse=True,
        )
        transport_names = {'http': 'HTTP', 'tls': 'HTTPS/TLS', 'socks': 'SOCKS5'}
        for (address, transport), usage in clients[:20]:
            lines.append('%s (%s) - up %s, down %s' % (
                address, transport_names[transport], format_bytes(usage['uploaded']),
                format_bytes(usage['downloaded'])))
        if len(clients) > 20:
            lines.append('Showing 20 of %d client/transport pairs.' % len(clients))
        lines.extend([
            '',
            'Source IPs may identify a router/shared network, not an individual device. '
            'Counters include failed authentication attempts; credentials are never inspected.',
            'Relay deltas are appended during active connections and after close. A sudden process or '
            'device failure can lose bytes since the last checkpoint (normally about one second or 4 MiB '
            'per active connection; storage errors can lose more).',
            'Only the latest seven daily relay ledgers are retained; shared-port totals remain separate '
            'from direct 3proxy payload statistics.',
        ])
    if stats['errors']:
        lines.extend([
            '',
            '[COLOR red]Incomplete: could not read the relay-usage file: %s. '
            'Displayed totals exclude unreadable data.[/COLOR]' % ', '.join(sorted(set(stats['errors']))),
        ])
    if status_error:
        lines.extend(['', '[COLOR red]%s[/COLOR]' % status_error])
    return '\n'.join(lines)
