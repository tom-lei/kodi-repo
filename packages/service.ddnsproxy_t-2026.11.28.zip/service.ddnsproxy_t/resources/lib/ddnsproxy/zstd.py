# -*- coding: utf-8 -*-
"""Minimal pure-Python Zstandard decompressor (RFC 8878), no dictionaries.

Only used once at engine installation to unpack data.tar.zst from the
official 3proxy .deb packages, so clarity beats speed. Integrity is ensured
by the SHA-256 check of the downloaded package, so the optional xxhash
content checksum is not verified.
"""
import struct

MAGIC = 0xFD2FB528


class ZstdError(Exception):
    pass


# ------------------------------------------------------------ bit readers

class ForwardBits(object):
    def __init__(self, data, pos=0):
        self.data = data
        self.bitpos = pos * 8

    def read(self, n):
        if n == 0:
            return 0
        start = self.bitpos
        end = start + n
        b0, b1 = start >> 3, (end + 7) >> 3
        if b1 > len(self.data):
            raise ZstdError('truncated table description')
        value = int.from_bytes(self.data[b0:b1], 'little') >> (start - b0 * 8)
        self.bitpos = end
        return value & ((1 << n) - 1)

    def rewind(self, n):
        self.bitpos -= n

    def byte_pos(self):
        return (self.bitpos + 7) >> 3


class BackwardBits(object):
    """Reads a zstd backward bitstream; reading past the start yields zeros."""

    def __init__(self, data, start, end):
        if end <= start:
            raise ZstdError('empty bitstream')
        self.data = data
        self.base = start
        last = data[end - 1]
        if last == 0:
            raise ZstdError('bitstream without end marker')
        self.pos = (end - 1 - start) * 8 + last.bit_length() - 1

    def read(self, n):
        if n == 0:
            return 0
        self.pos -= n
        lo = self.pos
        hi = lo + n
        shift = 0
        if lo < 0:
            shift = -lo
            lo = 0
            if hi <= 0:
                return 0
        b0, b1 = lo >> 3, (hi + 7) >> 3
        chunk = int.from_bytes(self.data[self.base + b0:self.base + b1], 'little') >> (lo - b0 * 8)
        return (chunk & ((1 << (hi - lo)) - 1)) << shift

    def overflowed(self):
        return self.pos < 0

    def finished(self):
        return self.pos == 0


# ------------------------------------------------------------ FSE

class FSETable(object):
    def __init__(self, norm, accuracy_log):
        size = 1 << accuracy_log
        self.accuracy_log = accuracy_log
        symbols = [0] * size
        nxt = [0] * len(norm)
        high = size
        for s, count in enumerate(norm):
            if count == -1:
                high -= 1
                symbols[high] = s
                nxt[s] = 1
            else:
                nxt[s] = count
        pos = 0
        step = (size >> 1) + (size >> 3) + 3
        mask = size - 1
        for s, count in enumerate(norm):
            for _ in range(max(count, 0)):
                symbols[pos] = s
                pos = (pos + step) & mask
                while pos >= high:
                    pos = (pos + step) & mask
        if pos != 0:
            raise ZstdError('corrupt FSE distribution')
        self.symbols = symbols
        self.nbits = [0] * size
        self.base = [0] * size
        for i in range(size):
            s = symbols[i]
            desc = nxt[s]
            nxt[s] += 1
            nb = accuracy_log - (desc.bit_length() - 1)
            self.nbits[i] = nb
            self.base[i] = (desc << nb) - size

    @classmethod
    def rle(cls, symbol):
        table = cls.__new__(cls)
        table.accuracy_log = 0
        table.symbols = [symbol]
        table.nbits = [0]
        table.base = [0]
        return table


def read_fse_description(data, pos, max_log, max_symbols):
    bits = ForwardBits(data, pos)
    accuracy_log = 5 + bits.read(4)
    if accuracy_log > max_log:
        raise ZstdError('FSE accuracy log too large')
    remaining = 1 << accuracy_log
    norm = []
    while remaining > 0 and len(norm) < max_symbols:
        nb = (remaining + 1).bit_length()
        val = bits.read(nb)
        lower_mask = (1 << (nb - 1)) - 1
        threshold = (1 << nb) - 1 - (remaining + 1)
        if (val & lower_mask) < threshold:
            bits.rewind(1)
            val &= lower_mask
        elif val > lower_mask:
            val -= threshold
        proba = val - 1
        remaining -= -proba if proba < 0 else proba
        norm.append(proba)
        if proba == 0:
            repeat = bits.read(2)
            while True:
                for _ in range(repeat):
                    if len(norm) < max_symbols:
                        norm.append(0)
                if repeat != 3:
                    break
                repeat = bits.read(2)
    if remaining != 0:
        raise ZstdError('corrupt FSE description')
    return FSETable(norm, accuracy_log), bits.byte_pos()


# ------------------------------------------------------------ Huffman

class HuffmanTable(object):
    def __init__(self, weights):
        total = sum(1 << (w - 1) for w in weights if w)
        if total == 0:
            raise ZstdError('empty Huffman table')
        max_bits = total.bit_length()
        left = (1 << max_bits) - total
        if left & (left - 1):
            raise ZstdError('corrupt Huffman weights')
        weights = list(weights) + [left.bit_length()]
        bits = [(max_bits + 1 - w) if w else 0 for w in weights]
        size = 1 << max_bits
        rank_count = [0] * (max_bits + 1)
        for b in bits:
            if b:
                rank_count[b] += 1
        rank_idx = [0] * (max_bits + 1)
        for b in range(max_bits, 0, -1):
            rank_idx[b - 1] = rank_idx[b] + rank_count[b] * (1 << (max_bits - b))
        self.max_bits = max_bits
        self.symbols = [0] * size
        self.nbits = [0] * size
        for sym, b in enumerate(bits):
            if b:
                code = rank_idx[b]
                length = 1 << (max_bits - b)
                for i in range(code, code + length):
                    self.symbols[i] = sym
                    self.nbits[i] = b
                rank_idx[b] += length

    def decode_stream(self, data, start, end, count):
        bits = BackwardBits(data, start, end)
        mb = self.max_bits
        mask = (1 << mb) - 1
        symbols, nbits = self.symbols, self.nbits
        state = bits.read(mb)
        out = bytearray(count)
        for i in range(count):
            out[i] = symbols[state]
            nb = nbits[state]
            state = ((state << nb) + bits.read(nb)) & mask
        if bits.pos != -mb:
            raise ZstdError('Huffman stream not fully consumed')
        return out


def read_huffman_description(data, pos):
    header = data[pos]
    pos += 1
    if header >= 128:
        count = header - 127
        nbytes = (count + 1) // 2
        weights = []
        for i in range(count):
            byte = data[pos + i // 2]
            weights.append(byte >> 4 if i % 2 == 0 else byte & 15)
        return HuffmanTable(weights), pos + nbytes
    end = pos + header
    table, stream_start = read_fse_description(data, pos, 6, 256)
    bits = BackwardBits(data, stream_start, end)
    al = table.accuracy_log
    s1, s2 = bits.read(al), bits.read(al)
    weights = []
    while True:
        weights.append(table.symbols[s1])
        s1 = table.base[s1] + bits.read(table.nbits[s1])
        if bits.overflowed():
            weights.append(table.symbols[s2])
            break
        weights.append(table.symbols[s2])
        s2 = table.base[s2] + bits.read(table.nbits[s2])
        if bits.overflowed():
            weights.append(table.symbols[s1])
            break
        if len(weights) > 255:
            raise ZstdError('too many Huffman weights')
    return HuffmanTable(weights), end


# ------------------------------------------------------------ sequences

LL_BASE = list(range(16)) + [16, 18, 20, 22, 24, 28, 32, 40, 48, 64, 128, 256, 512, 1024, 2048, 4096,
                             8192, 16384, 32768, 65536]
LL_BITS = [0] * 16 + [1, 1, 1, 1, 2, 2, 3, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
ML_BASE = [i + 3 for i in range(32)] + [35, 37, 39, 41, 43, 47, 51, 59, 67, 83, 99, 131, 259, 515, 1027,
                                        2051, 4099, 8195, 16387, 32771, 65539]
ML_BITS = [0] * 32 + [1, 1, 1, 1, 2, 2, 3, 3, 4, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

LL_DEFAULT = FSETable([4, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 1, 1, 1,
                       1, 1, -1, -1, -1, -1], 6)
ML_DEFAULT = FSETable([1, 4, 3, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1], 6)
OF_DEFAULT = FSETable([1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1,
                       -1], 5)


class _FrameState(object):
    def __init__(self):
        self.huffman = None
        self.tables = {'ll': None, 'of': None, 'ml': None}
        self.rep = [1, 4, 8]


def _read_table(data, pos, mode, kind, state):
    default, max_log, max_sym = {'ll': (LL_DEFAULT, 9, 36), 'of': (OF_DEFAULT, 8, 32),
                                 'ml': (ML_DEFAULT, 9, 53)}[kind]
    if mode == 0:
        table = default
    elif mode == 1:
        table = FSETable.rle(data[pos])
        pos += 1
    elif mode == 2:
        table, pos = read_fse_description(data, pos, max_log, max_sym)
    else:
        table = state.tables[kind]
        if table is None:
            raise ZstdError('repeat mode without previous table')
    state.tables[kind] = table
    return table, pos


def _literals(data, pos, end, state):
    b0 = data[pos]
    ltype = b0 & 3
    sf = (b0 >> 2) & 3
    if ltype in (0, 1):
        if sf in (0, 2):
            size, pos = b0 >> 3, pos + 1
        elif sf == 1:
            size, pos = (b0 >> 4) + (data[pos + 1] << 4), pos + 2
        else:
            size, pos = (b0 >> 4) + (data[pos + 1] << 4) + (data[pos + 2] << 12), pos + 3
        if ltype == 0:
            return bytes(data[pos:pos + size]), pos + size
        return bytes([data[pos]]) * size, pos + 1
    hsize, nbits, streams = {0: (3, 10, 1), 1: (3, 10, 4), 2: (4, 14, 4), 3: (5, 18, 4)}[sf]
    header = int.from_bytes(data[pos:pos + hsize], 'little')
    mask = (1 << nbits) - 1
    regen = (header >> 4) & mask
    csize = (header >> (4 + nbits)) & mask
    pos += hsize
    lit_end = pos + csize
    if ltype == 2:
        state.huffman, pos = read_huffman_description(data, pos)
    elif state.huffman is None:
        raise ZstdError('treeless literals without previous table')
    table = state.huffman
    if streams == 1:
        return bytes(table.decode_stream(data, pos, lit_end, regen)), lit_end
    s1, s2, s3 = struct.unpack('<HHH', bytes(data[pos:pos + 6]))
    pos += 6
    each = (regen + 3) // 4
    out = bytearray()
    bounds = [pos, pos + s1, pos + s1 + s2, pos + s1 + s2 + s3, lit_end]
    for i in range(4):
        count = each if i < 3 else regen - 3 * each
        out += table.decode_stream(data, bounds[i], bounds[i + 1], count)
    return bytes(out), lit_end


def _block(data, pos, end, out, state):
    literals, pos = _literals(data, pos, end, state)
    b0 = data[pos]
    if b0 == 0:
        out += literals
        return
    if b0 < 128:
        nseq, pos = b0, pos + 1
    elif b0 < 255:
        nseq, pos = ((b0 - 128) << 8) + data[pos + 1], pos + 2
    else:
        nseq, pos = data[pos + 1] + (data[pos + 2] << 8) + 0x7F00, pos + 3
    modes = data[pos]
    pos += 1
    ll_t, pos = _read_table(data, pos, modes >> 6, 'll', state)
    of_t, pos = _read_table(data, pos, (modes >> 4) & 3, 'of', state)
    ml_t, pos = _read_table(data, pos, (modes >> 2) & 3, 'ml', state)
    bits = BackwardBits(data, pos, end)
    ll_s = bits.read(ll_t.accuracy_log)
    of_s = bits.read(of_t.accuracy_log)
    ml_s = bits.read(ml_t.accuracy_log)
    rep = state.rep
    lit_pos = 0
    for i in range(nseq):
        of_code = of_t.symbols[of_s]
        ll_code = ll_t.symbols[ll_s]
        ml_code = ml_t.symbols[ml_s]
        if ll_code > 35 or ml_code > 52 or of_code > 31:
            raise ZstdError('invalid sequence code')
        offset_value = (1 << of_code) + bits.read(of_code)
        match_len = ML_BASE[ml_code] + bits.read(ML_BITS[ml_code])
        lit_len = LL_BASE[ll_code] + bits.read(LL_BITS[ll_code])
        if offset_value > 3:
            offset = offset_value - 3
            rep[2], rep[1], rep[0] = rep[1], rep[0], offset
        else:
            idx = offset_value - 1 + (1 if lit_len == 0 else 0)
            if idx == 0:
                offset = rep[0]
            else:
                offset = rep[idx] if idx < 3 else rep[0] - 1
                if idx > 1:
                    rep[2] = rep[1]
                rep[1], rep[0] = rep[0], offset
        if i != nseq - 1:
            ll_s = ll_t.base[ll_s] + bits.read(ll_t.nbits[ll_s])
            ml_s = ml_t.base[ml_s] + bits.read(ml_t.nbits[ml_s])
            of_s = of_t.base[of_s] + bits.read(of_t.nbits[of_s])
        out += literals[lit_pos:lit_pos + lit_len]
        lit_pos += lit_len
        if offset <= 0 or offset > len(out):
            raise ZstdError('invalid match offset')
        start = len(out) - offset
        if offset >= match_len:
            out += out[start:start + match_len]
        else:
            chunk = out[start:]
            while match_len > 0:
                piece = chunk[:match_len]
                out += piece
                match_len -= len(piece)
                chunk = chunk + piece
    if not bits.finished():
        raise ZstdError('sequence bitstream not fully consumed')
    out += literals[lit_pos:]


def _frame(data, pos):
    desc = data[pos]
    pos += 1
    fcs_flag = desc >> 6
    single = (desc >> 5) & 1
    checksum = (desc >> 2) & 1
    dict_flag = desc & 3
    if desc & 8:
        raise ZstdError('reserved frame header bit set')
    if not single:
        pos += 1
    dict_size = (0, 1, 2, 4)[dict_flag]
    if dict_size and int.from_bytes(data[pos:pos + dict_size], 'little'):
        raise ZstdError('dictionaries are not supported')
    pos += dict_size
    pos += (1 if single else 0, 2, 4, 8)[fcs_flag]
    out = bytearray()
    state = _FrameState()
    while True:
        if pos + 3 > len(data):
            raise ZstdError('truncated block header')
        header = int.from_bytes(data[pos:pos + 3], 'little')
        pos += 3
        last, btype, size = header & 1, (header >> 1) & 3, header >> 3
        if btype == 0:
            out += data[pos:pos + size]
            pos += size
        elif btype == 1:
            out += bytes([data[pos]]) * size
            pos += 1
        elif btype == 2:
            if pos + size > len(data):
                raise ZstdError('truncated block')
            _block(data, pos, pos + size, out, state)
            pos += size
        else:
            raise ZstdError('reserved block type')
        if last:
            break
    if checksum:
        pos += 4
    return bytes(out), pos


def decompress(data):
    data = memoryview(bytes(data))
    pos = 0
    result = []
    while pos < len(data):
        magic = struct.unpack('<I', bytes(data[pos:pos + 4]))[0]
        pos += 4
        if 0x184D2A50 <= magic <= 0x184D2A5F:
            size = struct.unpack('<I', bytes(data[pos:pos + 4]))[0]
            pos += 4 + size
            continue
        if magic != MAGIC:
            raise ZstdError('not a zstd frame')
        chunk, pos = _frame(data, pos)
        result.append(chunk)
    return b''.join(result)
