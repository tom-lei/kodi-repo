# -*- coding: utf-8 -*-
"""Kodi service entry point: wires the Kodi-free Core to xbmc.Monitor."""
import json

import xbmc

from . import kodi, store
from .config import ADDON_ID
from .core import Core

TICK_SECONDS = 2


class KodiHost(object):
    def __init__(self):
        self.addon_dir = kodi.addon_dir()
        self.debug = False

    def settings(self):
        settings = kodi.Settings()
        self.debug = settings.get_bool('debug')
        return settings

    def set_setting(self, key, value):
        kodi.Settings().set_string(key, value)

    def proxy(self):
        return kodi.kodi_proxy()

    def notify(self, msg, error=False):
        kodi.notify(msg, error)

    def log(self, msg, debug=False):
        if debug and not self.debug:
            return
        kodi.log(msg, xbmc.LOGINFO if not debug else xbmc.LOGDEBUG)


class Monitor(xbmc.Monitor):
    def __init__(self, core):
        xbmc.Monitor.__init__(self)
        self.core = core
        self.reload = False
        self.commands = []

    def onSettingsChanged(self):
        self.reload = True

    def onNotification(self, sender, method, data):
        if sender != ADDON_ID or not method.endswith('command'):
            return
        try:
            command = json.loads(data).get('command')
        except (ValueError, AttributeError):
            return
        if command:
            self.commands.append(command)


def run():
    host = KodiHost()
    core = Core(host, store.Paths(kodi.profile_dir()))
    monitor = Monitor(core)
    kodi.log('service started (platform %s)' % core.platform)
    core.start()
    try:
        while not monitor.abortRequested():
            if monitor.reload:
                monitor.reload = False
                core.reload()
            while monitor.commands:
                core.command(monitor.commands.pop(0))
            core.tick()
            if monitor.waitForAbort(TICK_SECONDS):
                break
    finally:
        core.shutdown()
        kodi.log('service stopped')
