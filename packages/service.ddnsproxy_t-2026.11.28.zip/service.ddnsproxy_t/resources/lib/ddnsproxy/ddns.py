# -*- coding: utf-8 -*-
"""Dynamic DNS providers: local checks, read-only validation and updates.

No Kodi imports. All HTTP goes through the injected HttpClient.
"""
import hashlib
import json

from . import netutil
from .httpclient import HttpError

OK = 'ok'
NOCHG = 'nochg'
UNVERIFIED = 'unverified'
AUTH = 'auth_error'
HOST = 'host_error'
CONFIG = 'config_error'
ERROR = 'error'
DISABLED = 'disabled'

STATE_LABELS = {
    OK: 'OK',
    NOCHG: 'OK (unchanged)',
    UNVERIFIED: 'Not verified',
    AUTH: 'Authentication failed',
    HOST: 'Hostname problem',
    CONFIG: 'Configuration problem',
    ERROR: 'Error',
    DISABLED: 'Disabled',
}


class Result(object):
    def __init__(self, state, message, detail='', retry_after=0):
        self.state = state
        self.message = message
        self.detail = detail
        self.retry_after = retry_after

    @property
    def success(self):
        return self.state in (OK, NOCHG)

    @property
    def fatal(self):
        """Retrying makes no sense until the configuration changes."""
        return self.state in (AUTH, HOST, CONFIG)

    def to_dict(self):
        return {'state': self.state, 'message': self.message, 'detail': self.detail,
                'retry_after': self.retry_after}

    @classmethod
    def from_dict(cls, data):
        data = data or {}
        return cls(data.get('state', ERROR), data.get('message', ''), data.get('detail', ''),
                   data.get('retry_after', 0))

    def __repr__(self):
        return 'Result(%s, %r)' % (self.state, self.message)


class Entry(object):
    """One configured DDNS record."""

    def __init__(self, provider='noip', hostname='', username='', secret='', server='',
                 ipv4=True, ipv6=False, enabled=True):
        self.provider = provider
        self.hostname = (hostname or '').strip().lower().rstrip('.')
        self.username = (username or '').strip()
        self.secret = (secret or '').strip()
        self.server = (server or '').strip()
        self.ipv4 = bool(ipv4)
        self.ipv6 = bool(ipv6)
        self.enabled = bool(enabled)

    def fingerprint(self):
        raw = json.dumps([self.provider, self.hostname, self.username, self.secret, self.server,
                          self.ipv4, self.ipv6])
        return hashlib.sha256(raw.encode('utf-8')).hexdigest()[:16]

    def fqdn(self):
        return provider_class(self.provider).fqdn(self.hostname)


def _first_line(text):
    text = (text or '').strip()
    return text.splitlines()[0].strip() if text else ''


def parse_dyndns2(status, text):
    """Interpret a dyndns2 protocol response (No-IP, Dynu, deSEC, generic)."""
    line = _first_line(text)
    code = line.split(' ')[0].lower() if line else ''
    if status == 401 or code == 'badauth':
        return Result(AUTH, 'Username or password/token rejected (badauth).', line)
    if status == 403 and not code:
        return Result(AUTH, 'Access denied by the provider (HTTP 403).', line)
    if code == 'good':
        return Result(OK, 'Record updated.', line)
    if code == 'nochg':
        return Result(NOCHG, 'Record already up to date.', line)
    if code == 'nohost':
        return Result(HOST, 'The hostname does not exist in this account (nohost).', line)
    if code == 'notfqdn':
        return Result(HOST, 'The hostname is not a fully qualified domain name (notfqdn).', line)
    if code == 'numhost':
        return Result(HOST, 'Too many hosts in one request (numhost).', line)
    if code == 'abuse':
        return Result(HOST, 'The hostname is blocked for abuse (abuse).', line)
    if code == '!donator':
        return Result(CONFIG, 'This feature requires a paid account (!donator).', line)
    if code == 'badagent':
        return Result(ERROR, 'The provider rejected this client (badagent).', line, 86400)
    if code in ('911', 'dnserr'):
        return Result(ERROR, 'Temporary problem at the provider (%s). Retrying later.' % code, line, 1800)
    if status == 429:
        return Result(ERROR, 'Rate limited by the provider. Retrying later.', line, 1800)
    if status >= 500:
        return Result(ERROR, 'Provider error (HTTP %d). Retrying later.' % status, line, 600)
    return Result(ERROR, 'Unexpected response (HTTP %d): %s' % (status, line[:120] or '(empty)'), line, 900)


def parse_duckdns(status, text):
    line = _first_line(text)
    if status == 200 and line.upper() == 'OK':
        lines = (text or '').strip().splitlines()
        changed = len(lines) >= 4 and lines[3].strip().upper() == 'UPDATED'
        return Result(OK if changed else NOCHG, 'Record updated.' if changed else 'Record already up to date.',
                      line)
    if line.upper() == 'KO':
        return Result(AUTH, 'DuckDNS rejected the token or the subdomain (KO).', line)
    if status >= 500:
        return Result(ERROR, 'DuckDNS error (HTTP %d). Retrying later.' % status, line, 600)
    return Result(ERROR, 'Unexpected response (HTTP %d): %s' % (status, line[:120] or '(empty)'), line, 900)


def parse_freedns(status, text):
    line = _first_line(text)
    low = line.lower()
    if low.startswith('updated'):
        return Result(OK, 'Record updated.', line)
    if low.startswith('no ip change'):
        return Result(NOCHG, 'Record already up to date.', line)
    if 'unable to locate' in low or 'invalid' in low:
        return Result(AUTH, 'FreeDNS did not accept the update token.', line)
    if low.startswith('error'):
        return Result(ERROR, 'FreeDNS: %s' % line[:160], line, 900)
    if status >= 500:
        return Result(ERROR, 'FreeDNS error (HTTP %d). Retrying later.' % status, line, 600)
    return Result(ERROR, 'Unexpected response (HTTP %d): %s' % (status, line[:120] or '(empty)'), line, 900)


def _network_error(exc):
    return Result(ERROR, 'Network error: %s' % exc, '', 300)


class Provider(object):
    key = ''
    name = ''
    read_only_check = False
    needs_username = False
    needs_server = False
    domain_suffix = ''
    supports_ipv6 = True

    def __init__(self, entry, user_agent='DDNSProxyT'):
        self.entry = entry
        self.user_agent = user_agent

    @classmethod
    def fqdn(cls, hostname):
        hostname = (hostname or '').lower().rstrip('.')
        if cls.domain_suffix and hostname and '.' not in hostname:
            return hostname + cls.domain_suffix
        return hostname

    def check(self):
        """Local configuration checks. Returns a list of problems."""
        e = self.entry
        problems = []
        if not netutil.is_valid_hostname(self.fqdn(e.hostname)):
            problems.append('Hostname "%s" is not valid.' % (e.hostname or ''))
        if self.needs_username and not e.username:
            problems.append('%s needs a username.' % self.name)
        if not e.secret:
            problems.append('%s needs a password/token.' % self.name)
        if self.needs_server and not e.server.lower().startswith(('https://', 'http://')):
            problems.append('Enter the update URL of your dyndns2 service (https://...).')
        if not (e.ipv4 or e.ipv6):
            problems.append('Enable IPv4 and/or IPv6 updates.')
        if e.ipv6 and not self.supports_ipv6:
            problems.append('%s updates are IPv4 only here.' % self.name)
        return problems

    def validate(self, client):
        """Read-only credential check. Providers without one return UNVERIFIED."""
        return Result(UNVERIFIED, '%s offers no read-only check; verifying requires sending a real update.'
                      % self.name)

    def update(self, client, ipv4, ipv6):
        raise NotImplementedError


class Dyndns2Provider(Provider):
    url = ''
    v4_param = 'myip'
    v6_param = 'myipv6'
    v4_off = None
    v6_off = None

    def update_url(self):
        return self.url

    def credentials(self):
        return self.entry.username, self.entry.secret

    def params(self, ipv4, ipv6):
        params = {'hostname': self.fqdn(self.entry.hostname)}
        if ipv4:
            params[self.v4_param] = ipv4
        elif self.v4_off is not None:
            params[self.v4_param] = self.v4_off
        if ipv6:
            params[self.v6_param] = ipv6
        elif self.v6_off is not None:
            params[self.v6_param] = self.v6_off
        return params

    def update(self, client, ipv4, ipv6):
        try:
            resp = client.get(self.update_url(), params=self.params(ipv4, ipv6), auth=self.credentials(),
                              headers={'User-Agent': self.user_agent})
        except HttpError as exc:
            return _network_error(exc)
        return parse_dyndns2(resp.status, resp.text())


class NoIP(Dyndns2Provider):
    key = 'noip'
    name = 'No-IP'
    needs_username = True
    url = 'https://dynupdate.no-ip.com/nic/update'


class Dynu(Dyndns2Provider):
    key = 'dynu'
    name = 'Dynu'
    needs_username = True
    url = 'https://api.dynu.com/nic/update'
    v4_off = 'no'
    v6_off = 'no'


class DeSEC(Dyndns2Provider):
    key = 'desec'
    name = 'deSEC'
    url = 'https://update.dedyn.io/'
    v4_param = 'myipv4'
    v4_off = 'preserve'
    v6_off = 'preserve'
    domain_suffix = '.dedyn.io'

    def credentials(self):
        return self.fqdn(self.entry.hostname), self.entry.secret

    read_only_check = True

    def validate(self, client):
        host = self.fqdn(self.entry.hostname)
        try:
            resp = client.get('https://desec.io/api/v1/domains/', params={'owns_qname': host},
                              headers={'Authorization': 'Token %s' % self.entry.secret,
                                       'Accept': 'application/json'})
        except HttpError as exc:
            return _network_error(exc)
        return parse_desec_domains(resp.status, resp.text(), host)


def parse_desec_domains(status, text, host):
    if status == 401:
        return Result(AUTH, 'deSEC rejected the token.', text[:200])
    if status == 403:
        return Result(UNVERIFIED, 'Token accepted, but it may not list domains (restricted token).', text[:200])
    if status == 429:
        return Result(ERROR, 'deSEC rate limit reached, try again later.', text[:200], 600)
    if status != 200:
        return Result(ERROR, 'Unexpected deSEC response (HTTP %d).' % status, text[:200], 600)
    try:
        domains = json.loads(text)
    except ValueError:
        return Result(ERROR, 'Invalid deSEC response.', text[:200], 600)
    if not domains:
        return Result(HOST, 'The token is valid, but %s is not part of this deSEC account.' % host)
    return Result(OK, 'Token valid, domain %s found.' % domains[0].get('name', host))


class GenericDyndns2(Dyndns2Provider):
    key = 'dyndns2'
    name = 'dyndns2'
    needs_username = True
    needs_server = True

    def update_url(self):
        return self.entry.server


class DuckDNS(Provider):
    key = 'duckdns'
    name = 'DuckDNS'
    domain_suffix = '.duckdns.org'

    def subdomain(self):
        host = self.fqdn(self.entry.hostname)
        return host[:-len(self.domain_suffix)] if host.endswith(self.domain_suffix) else host

    def check(self):
        problems = Provider.check(self)
        if not self.fqdn(self.entry.hostname).endswith(self.domain_suffix):
            problems.append('DuckDNS hostnames end with .duckdns.org.')
        return problems

    def update(self, client, ipv4, ipv6):
        params = {'domains': self.subdomain(), 'token': self.entry.secret, 'verbose': 'true'}
        if ipv4:
            params['ip'] = ipv4
        if ipv6:
            params['ipv6'] = ipv6
        try:
            resp = client.get('https://www.duckdns.org/update', params=params)
        except HttpError as exc:
            return _network_error(exc)
        return parse_duckdns(resp.status, resp.text())


class FreeDNS(Provider):
    key = 'freedns'
    name = 'FreeDNS (afraid.org)'
    supports_ipv6 = True

    def update(self, client, ipv4, ipv6):
        results = []
        for host, address in (('sync.afraid.org', ipv4), ('v6.sync.afraid.org', ipv6)):
            if not address:
                continue
            try:
                resp = client.get('https://%s/u/%s/' % (host, self.entry.secret), params={'ip': address})
            except HttpError as exc:
                return _network_error(exc)
            results.append(parse_freedns(resp.status, resp.text()))
        if not results:
            return Result(ERROR, 'No address to update.')
        for result in results:
            if not result.success:
                return result
        return next((r for r in results if r.state == OK), results[0])


class Cloudflare(Provider):
    key = 'cloudflare'
    name = 'Cloudflare'
    read_only_check = True
    api = 'https://api.cloudflare.com/client/v4'

    def _call(self, client, method, path, params=None, body=None):
        headers = {'Authorization': 'Bearer %s' % self.entry.secret, 'Accept': 'application/json'}
        resp = client.request(method, self.api + path, params=params, json_body=body, headers=headers)
        try:
            data = resp.json()
        except ValueError:
            data = {'success': False, 'errors': [{'message': 'invalid response (HTTP %d)' % resp.status}]}
        return resp.status, data

    @staticmethod
    def _error(status, data):
        errors = data.get('errors') or []
        msg = '; '.join('%s (%s)' % (e.get('message', ''), e.get('code', '')) for e in errors) or \
            'HTTP %d' % status
        codes = set(e.get('code') for e in errors)
        if status in (401, 403) or codes & {9109, 10000, 6003, 6111, 1000, 1001}:
            return Result(AUTH, 'Cloudflare rejected the API token: %s' % msg)
        if status == 429:
            return Result(ERROR, 'Cloudflare rate limit reached.', msg, 900)
        return Result(ERROR, 'Cloudflare error: %s' % msg, '', 600)

    def _zone(self, client, host):
        labels = host.split('.')
        for i in range(len(labels) - 1):
            candidate = '.'.join(labels[i:])
            status, data = self._call(client, 'GET', '/zones', params={'name': candidate})
            if not data.get('success'):
                return None, self._error(status, data)
            if data.get('result'):
                return data['result'][0]['id'], None
        return None, Result(HOST, 'No Cloudflare zone for %s is accessible with this token.' % host)

    def _records(self, client, zone_id, host, rtype):
        status, data = self._call(client, 'GET', '/zones/%s/dns_records' % zone_id,
                                  params={'name': host, 'type': rtype})
        if not data.get('success'):
            return None, self._error(status, data)
        return data.get('result') or [], None

    def validate(self, client):
        host = self.fqdn(self.entry.hostname)
        try:
            zone_id, err = self._zone(client, host)
            if err:
                return err
            for rtype, enabled in (('A', self.entry.ipv4), ('AAAA', self.entry.ipv6)):
                if not enabled:
                    continue
                _, err = self._records(client, zone_id, host, rtype)
                if err:
                    return err
        except HttpError as exc:
            return _network_error(exc)
        return Result(OK, 'Token valid, zone for %s found.' % host)

    def update(self, client, ipv4, ipv6):
        host = self.fqdn(self.entry.hostname)
        changed = False
        try:
            zone_id, err = self._zone(client, host)
            if err:
                return err
            for rtype, address in (('A', ipv4), ('AAAA', ipv6)):
                if not address:
                    continue
                records, err = self._records(client, zone_id, host, rtype)
                if err:
                    return err
                if records and records[0].get('content') == address:
                    continue
                if records:
                    status, data = self._call(client, 'PATCH', '/zones/%s/dns_records/%s'
                                              % (zone_id, records[0]['id']), body={'content': address})
                else:
                    status, data = self._call(client, 'POST', '/zones/%s/dns_records' % zone_id,
                                              body={'type': rtype, 'name': host, 'content': address,
                                                    'ttl': 60, 'proxied': False})
                if not data.get('success'):
                    return self._error(status, data)
                changed = True
        except HttpError as exc:
            return _network_error(exc)
        return Result(OK, 'Record updated.') if changed else Result(NOCHG, 'Record already up to date.')


PROVIDERS = {cls.key: cls for cls in (NoIP, DuckDNS, Dynu, DeSEC, Cloudflare, FreeDNS, GenericDyndns2)}


def provider_class(key):
    return PROVIDERS.get(key, NoIP)


def make_provider(entry, user_agent='DDNSProxyT'):
    return provider_class(entry.provider)(entry, user_agent)
