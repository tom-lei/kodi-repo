# -*- coding: utf-8 -*-
"""Minimal SOCKS4/4a/5 client used to honour Kodi's SOCKS proxy settings."""
import ipaddress
import socket
import struct

SOCKS4 = 'socks4'
SOCKS4A = 'socks4a'
SOCKS5 = 'socks5'      # local DNS resolution
SOCKS5H = 'socks5h'    # remote DNS resolution


class SocksError(OSError):
    pass


_SOCKS5_ERRORS = {
    1: 'general SOCKS server failure',
    2: 'connection not allowed by ruleset',
    3: 'network unreachable',
    4: 'host unreachable',
    5: 'connection refused',
    6: 'TTL expired',
    7: 'command not supported',
    8: 'address type not supported',
}


def _recv_exact(sock, count):
    data = b''
    while len(data) < count:
        chunk = sock.recv(count - len(data))
        if not chunk:
            raise SocksError('SOCKS proxy closed the connection')
        data += chunk
    return data


def _resolve(host, port, family=0):
    try:
        infos = socket.getaddrinfo(host, port, family, socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise SocksError('cannot resolve %s: %s' % (host, exc))
    return ipaddress.ip_address(infos[0][4][0].split('%', 1)[0])


def _ip_or_none(host):
    try:
        return ipaddress.ip_address(host)
    except ValueError:
        return None


def socks5_handshake(sock, host, port, username='', password='', remote_dns=True):
    methods = b'\x00\x02' if username else b'\x00'
    sock.sendall(b'\x05' + bytes([len(methods)]) + methods)
    ver, method = _recv_exact(sock, 2)
    if ver != 5:
        raise SocksError('not a SOCKS5 proxy')
    if method == 0x02:
        user = username.encode('utf-8')
        pwd = (password or '').encode('utf-8')
        if len(user) > 255 or len(pwd) > 255:
            raise SocksError('SOCKS5 credentials too long')
        sock.sendall(b'\x01' + bytes([len(user)]) + user + bytes([len(pwd)]) + pwd)
        _, status = _recv_exact(sock, 2)
        if status != 0:
            raise SocksError('SOCKS5 authentication failed')
    elif method != 0x00:
        raise SocksError('SOCKS5 proxy requires an unsupported authentication method')

    addr = _ip_or_none(host)
    if addr is None and not remote_dns:
        addr = _resolve(host, port)
    if addr is None:
        name = host.encode('idna')
        dest = b'\x03' + bytes([len(name)]) + name
    elif addr.version == 4:
        dest = b'\x01' + addr.packed
    else:
        dest = b'\x04' + addr.packed
    sock.sendall(b'\x05\x01\x00' + dest + struct.pack('!H', port))
    ver, rep, _, atyp = _recv_exact(sock, 4)
    if ver != 5:
        raise SocksError('invalid SOCKS5 reply')
    if rep != 0:
        raise SocksError('SOCKS5 proxy: %s' % _SOCKS5_ERRORS.get(rep, 'error %d' % rep))
    if atyp == 1:
        _recv_exact(sock, 4)
    elif atyp == 4:
        _recv_exact(sock, 16)
    elif atyp == 3:
        _recv_exact(sock, _recv_exact(sock, 1)[0])
    else:
        raise SocksError('invalid SOCKS5 address type')
    _recv_exact(sock, 2)


def socks4_handshake(sock, host, port, username='', remote_dns=False):
    user = (username or '').encode('utf-8') + b'\x00'
    addr = _ip_or_none(host)
    if addr is not None and addr.version != 4:
        raise SocksError('SOCKS4 does not support IPv6')
    if addr is None and not remote_dns:
        addr = _resolve(host, port, socket.AF_INET)
    if addr is None:
        req = struct.pack('!BBH', 4, 1, port) + b'\x00\x00\x00\x01' + user + host.encode('idna') + b'\x00'
    else:
        req = struct.pack('!BBH', 4, 1, port) + addr.packed + user
    sock.sendall(req)
    reply = _recv_exact(sock, 8)
    if reply[1] != 0x5A:
        raise SocksError('SOCKS4 proxy rejected the request (code %d)' % reply[1])


def create_connection(proxy_type, proxy_host, proxy_port, host, port,
                      username='', password='', timeout=None):
    """Open a TCP connection to host:port through a SOCKS proxy."""
    if timeout is None or timeout is socket._GLOBAL_DEFAULT_TIMEOUT:
        sock = socket.create_connection((proxy_host, proxy_port))
    else:
        sock = socket.create_connection((proxy_host, proxy_port), timeout)
    try:
        if proxy_type in (SOCKS5, SOCKS5H):
            socks5_handshake(sock, host, port, username, password, proxy_type == SOCKS5H)
        elif proxy_type in (SOCKS4, SOCKS4A):
            socks4_handshake(sock, host, port, username, proxy_type == SOCKS4A)
        else:
            raise SocksError('unknown SOCKS type %r' % proxy_type)
    except Exception:
        sock.close()
        raise
    return sock
