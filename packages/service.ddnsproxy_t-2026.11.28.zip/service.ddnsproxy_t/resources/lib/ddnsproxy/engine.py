# -*- coding: utf-8 -*-
"""Download, verify and install the 3proxy engine; manage its process.

No Kodi imports: HTTP is done through an injected HttpClient so Kodi's proxy
settings are honoured.
"""
import hashlib
import io
import json
import os
import platform
import posixpath
import re
import shutil
import signal
import stat
import struct
import subprocess
import sys
import tarfile
import time
import urllib.parse
import zipfile

from . import openpgp, zstd

MAX_ASSET_BYTES = 64 * 1024 * 1024
LICENSE_NAMES = ('copying', 'copying.txt', 'license', 'license.txt', 'licence', 'copyright', 'readme',
                 'readme.txt', 'readme.md')


class EngineError(Exception):
    pass


class EngineInfo(object):
    def __init__(self, binary, version='', directory='', asset='', sha256='',
                 signed_by='', custom=False, libraries=None):
        self.binary = binary
        self.version = version
        self.directory = directory or os.path.dirname(binary)
        self.asset = asset
        self.sha256 = sha256
        self.signed_by = signed_by
        self.custom = custom
        # shared libraries bundled next to the binary (e.g. PCRE2 for LibreELEC)
        self.libraries = list(libraries or [])

    def to_dict(self):
        return dict(self.__dict__)


def load_manifest(path):
    with open(path, 'r') as handle:
        manifest = json.load(handle)
    manifest['_dir'] = os.path.dirname(os.path.abspath(path))
    return manifest


def read_signing_key(manifest):
    path = os.path.join(manifest.get('_dir', ''), manifest.get('signing_key') or '')
    if not manifest.get('signing_key') or not os.path.isfile(path):
        raise EngineError('The 3proxy release signing key is missing from the add-on')
    with open(path, 'r') as handle:
        return handle.read()


def is_android():
    return 'ANDROID_ROOT' in os.environ or 'ANDROID_STORAGE' in os.environ or \
        hasattr(sys, 'getandroidapilevel')


def detect_platform(sys_platform=None, machine=None, pointer_bits=None, android=None):
    """Return the engine platform id, e.g. 'windows-x64' or 'linux-armhf'."""
    sys_platform = sys_platform or sys.platform
    machine = (machine if machine is not None else platform.machine()).lower()
    bits = pointer_bits or struct.calcsize('P') * 8
    android = is_android() if android is None else android
    if machine in ('x86_64', 'amd64', 'x64'):
        arch = 'x86_64' if bits == 64 else 'i686'
    elif machine in ('aarch64', 'arm64', 'armv8l', 'armv8b'):
        # 64-bit kernels often run a 32-bit userland (e.g. LibreELEC on RPi)
        arch = 'aarch64' if bits == 64 else 'armhf'
    elif machine.startswith('arm'):
        arch = 'armhf'
    elif machine in ('i386', 'i486', 'i586', 'i686', 'x86'):
        arch = 'i686'
    else:
        arch = machine or 'unknown'
    if sys_platform.startswith('win'):
        return 'windows-x64' if arch == 'x86_64' else 'windows-' + arch
    if android:
        return 'android-' + arch
    if sys_platform.startswith('linux'):
        return 'linux-' + arch
    if sys_platform == 'darwin':
        return 'macos-' + arch
    return '%s-%s' % (sys_platform, arch)


def parse_sums(text):
    """Parse a SHA256SUMS file into {filename: hexdigest}."""
    result = {}
    for line in (text or '').splitlines():
        match = re.match(r'^([0-9a-fA-F]{64})\s+\*?(.+?)\s*$', line)
        if match:
            result[posixpath.basename(match.group(2).strip())] = match.group(1).lower()
    return result


def select_asset(names, spec):
    """Choose the release asset for a platform spec from candidate file names."""
    candidates = []
    for name in sorted(names):
        low = name.lower()
        if not any(low.endswith(ext) for ext in spec.get('extensions', [])):
            continue
        if not any(k in low for k in spec.get('keywords', [])):
            continue
        if any(x in low for x in spec.get('exclude', [])):
            continue
        candidates.append(name)
    if not candidates:
        return None
    preferred = [n for n in candidates if not any(a in n.lower() for a in spec.get('avoid', []))]
    return (preferred or candidates)[0]


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(65536), b''):
            digest.update(chunk)
    return digest.hexdigest()


def parse_ar(data):
    """Parse a Unix ar archive (.deb). Returns [(name, bytes)]."""
    if not data.startswith(b'!<arch>\n'):
        raise EngineError('not a .deb (ar) archive')
    pos = 8
    members = []
    while pos + 60 <= len(data):
        header = data[pos:pos + 60]
        if header[58:60] != b'`\n':
            raise EngineError('corrupt ar archive')
        name = header[0:16].decode('ascii', 'replace').strip()
        if name.endswith('/'):
            name = name[:-1]
        size = int(header[48:58].decode('ascii').strip())
        pos += 60
        members.append((name, data[pos:pos + size]))
        pos += size + (size % 2)
    return members


def _write_file(dest_dir, name, payload, executable=False):
    path = os.path.join(dest_dir, os.path.basename(name))
    with open(path, 'wb') as handle:
        handle.write(payload)
    if executable and os.name != 'nt':
        os.chmod(path, os.stat(path).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return path


def _extract_zip(data, spec, dest_dir):
    binary_name = spec['binary'].lower()
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = [n for n in archive.namelist() if not n.endswith('/')]
        binaries = [n for n in names if posixpath.basename(n).lower() == binary_name]
        if not binaries:
            raise EngineError('%s not found in archive' % spec['binary'])
        binaries.sort(key=lambda n: (('64' not in n), len(n)))
        bin_dir = posixpath.dirname(binaries[0])
        wanted_suffixes = tuple(s.lower() for s in spec.get('extra_suffixes', []))
        written = {}
        for name in names:
            base = posixpath.basename(name)
            low = base.lower()
            if posixpath.dirname(name) == bin_dir and (low == binary_name or low.endswith(wanted_suffixes)):
                written[low] = _write_file(dest_dir, base, archive.read(name), low == binary_name)
            elif low in LICENSE_NAMES and low not in written:
                written[low] = _write_file(dest_dir, base, archive.read(name))
    return written


def _tar_member_data(tar, member, depth=0):
    if member.isreg():
        return tar.extractfile(member).read()
    if member.issym() and depth < 5:
        target = posixpath.normpath(posixpath.join(posixpath.dirname(member.name), member.linkname))
        for other in tar.getmembers():
            if posixpath.normpath(other.name.lstrip('./')) == target.lstrip('./').lstrip('/'):
                return _tar_member_data(tar, other, depth + 1)
    return None


def _extract_deb(data, spec, dest_dir):
    members = dict(parse_ar(data))
    tar_name = next((n for n in members if n.startswith('data.tar')), None)
    if tar_name is None:
        raise EngineError('data.tar not found in .deb')
    payload = members[tar_name]
    if tar_name.endswith('.zst'):
        try:
            payload = zstd.decompress(payload)
        except zstd.ZstdError as exc:
            raise EngineError('cannot unpack %s: %s' % (tar_name, exc))
    binary_name = spec['binary']
    written = {}
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:*') as tar:
        for member in tar.getmembers():
            base = posixpath.basename(member.name)
            if not (member.isreg() or member.issym()):
                continue
            if base == binary_name and '/bin/' in '/' + member.name.lstrip('./'):
                payload = _tar_member_data(tar, member)
                if payload and 'binary' not in written:
                    written['binary'] = _write_file(dest_dir, base, payload, True)
            elif base.lower() in LICENSE_NAMES and 'doc' in member.name and base.lower() not in written:
                payload = _tar_member_data(tar, member)
                if payload:
                    written[base.lower()] = _write_file(dest_dir, base, payload)
    if 'binary' not in written:
        raise EngineError('%s not found in package' % binary_name)
    return written


def extract_deb_members(data, wanted):
    """Return {path: bytes} for the wanted data.tar member paths of a .deb."""
    members = dict(parse_ar(data))
    tar_name = next((n for n in members if n.startswith('data.tar')), None)
    if tar_name is None:
        raise EngineError('data.tar not found in .deb')
    payload = members[tar_name]
    if tar_name.endswith('.zst'):
        try:
            payload = zstd.decompress(payload)
        except zstd.ZstdError as exc:
            raise EngineError('cannot unpack %s: %s' % (tar_name, exc))
    wanted = set(posixpath.normpath(w.lstrip('/')) for w in wanted)
    found = {}
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:*') as tar:
        for member in tar.getmembers():
            name = posixpath.normpath(member.name.lstrip('./').lstrip('/'))
            if name in wanted and name not in found:
                content = _tar_member_data(tar, member)
                if content is not None:
                    found[name] = content
    return found


def install_library(client, lib, dest_dir, log=lambda msg: None):
    """Download a pinned library package, verify it and extract the library."""
    package = lib.get('package') or lib['name']
    expected = (lib.get('sha256') or '').lower()
    if len(expected) != 64:
        raise EngineError('No checksum pinned for %s' % package)
    errors = []
    data = None
    for url in lib.get('urls', []):
        log('downloading %s' % url)
        try:
            resp = client.get(url, timeout=120, max_bytes=MAX_ASSET_BYTES)
        except Exception as exc:  # network errors from the injected client
            errors.append('%s: %s' % (url, exc))
            continue
        if not resp.ok:
            errors.append('%s: HTTP %d' % (url, resp.status))
            continue
        if hashlib.sha256(resp.body).hexdigest() != expected:
            errors.append('%s: checksum mismatch - rejected' % url)
            continue
        data = resp.body
        break
    if data is None:
        raise EngineError('Cannot download %s (%s)' % (package, '; '.join(errors) or 'no URL'))
    member = lib['member']
    wanted = [member] + ([lib['license_member']] if lib.get('license_member') else [])
    found = extract_deb_members(data, wanted)
    content = found.get(posixpath.normpath(member.lstrip('/')))
    if not content:
        raise EngineError('%s not found in %s' % (member, package))
    path = _write_file(dest_dir, lib['name'], content)
    if lib.get('license_member'):
        text = found.get(posixpath.normpath(lib['license_member'].lstrip('/')))
        if text:
            _write_file(dest_dir, lib.get('license_file') or (lib['name'] + '.copyright'), text)
    return {'name': lib['name'], 'package': package, 'package_sha256': expected,
            'sha256': sha256_file(path)}


def extract(asset_name, data, spec, dest_dir):
    if asset_name.lower().endswith('.zip'):
        return _extract_zip(data, spec, dest_dir)
    if asset_name.lower().endswith('.deb'):
        return _extract_deb(data, spec, dest_dir)
    raise EngineError('unsupported archive type: %s' % asset_name)


def install_dir(root, manifest, platform_id):
    return os.path.join(root, '%s-%s-%s' % (manifest['engine'], manifest['version'], platform_id))


def load_installed(root, manifest, platform_id):
    """Return EngineInfo for a verified installed engine, or None."""
    directory = install_dir(root, manifest, platform_id)
    try:
        with open(os.path.join(directory, 'install.json'), 'r') as handle:
            info = json.load(handle)
    except (IOError, OSError, ValueError):
        return None
    binary = os.path.join(directory, info.get('binary', ''))
    if not os.path.isfile(binary) or sha256_file(binary) != info.get('binary_sha256'):
        return None
    signed_by = info.get('sums_signed_by', '')
    # installs made before signature checking was enforced are re-downloaded
    if signed_by != openpgp.normalize_fingerprint(manifest.get('signing_key_fingerprint')):
        return None
    spec = manifest.get('platforms', {}).get(platform_id) or {}
    recorded = dict((l.get('name'), l) for l in info.get('libraries', []))
    libraries = []
    for lib in spec.get('libraries', []):
        rec = recorded.get(lib['name'])
        # an install lacking a bundled library (or with an altered one) is redone
        if not rec or rec.get('package_sha256') != (lib.get('sha256') or '').lower():
            return None
        path = os.path.join(directory, lib['name'])
        if not os.path.isfile(path) or sha256_file(path) != rec.get('sha256'):
            return None
        libraries.append(lib['name'])
    return EngineInfo(binary, manifest['version'], directory, info.get('asset', ''),
                      info.get('asset_sha256', ''), signed_by, libraries=libraries)


def install(client, manifest, platform_id, root, log=lambda msg: None):
    """Download, verify and install the engine. Returns EngineInfo."""
    spec = manifest['platforms'].get(platform_id)
    if spec is None:
        raise EngineError('No bundled 3proxy build is available for %s. '
                          'Set a custom 3proxy binary in the settings.' % platform_id)
    base = manifest['release_url']
    sums_file = spec['sums_file']
    signing_key = read_signing_key(manifest)
    log('downloading %s' % sums_file)
    resp = client.get(base + sums_file, timeout=30)
    if not resp.ok:
        raise EngineError('Cannot download %s (HTTP %d)' % (sums_file, resp.status))
    sums_body = resp.body
    log('downloading %s.asc' % sums_file)
    resp = client.get(base + sums_file + '.asc', timeout=30)
    if not resp.ok:
        raise EngineError('Cannot download the signature %s.asc (HTTP %d)' % (sums_file, resp.status))
    try:
        sig = openpgp.verify_detached(sums_body, resp.body, signing_key, manifest.get('signing_key_fingerprint'),
                                      now=time.time())
    except openpgp.SignatureError as exc:
        raise EngineError('Signature check of %s failed (%s) - download rejected' % (sums_file, exc))
    signed_by = openpgp.normalize_fingerprint(manifest.get('signing_key_fingerprint'))
    log('%s: good signature from %s (made %s)' % (
        sums_file, signed_by, time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime(sig.created))))
    # defence in depth: the release's sums file is also pinned for this add-on version
    pinned = (spec.get('sums_sha256') or '').lower()
    if pinned and hashlib.sha256(sums_body).hexdigest() != pinned:
        raise EngineError('%s does not match the checksum shipped with the add-on' % sums_file)
    sums = parse_sums(sums_body.decode('utf-8', 'replace'))
    asset = select_asset(sums.keys(), spec)
    if asset is None:
        raise EngineError('No matching 3proxy package for %s in %s' % (platform_id, sums_file))
    log('downloading %s' % asset)
    resp = client.get(base + urllib.parse.quote(asset), timeout=180, max_bytes=MAX_ASSET_BYTES)
    if not resp.ok:
        raise EngineError('Cannot download %s (HTTP %d)' % (asset, resp.status))
    digest = hashlib.sha256(resp.body).hexdigest()
    if digest != sums[asset]:
        raise EngineError('Checksum mismatch for %s - download rejected' % asset)

    directory = install_dir(root, manifest, platform_id)
    tmp = directory + '.tmp'
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    written = extract(asset, resp.body, spec, tmp)
    binary = os.path.basename(written.get('binary') or written.get(spec['binary'].lower()) or '')
    if not binary:
        raise EngineError('engine binary missing after extraction')
    libraries = [install_library(client, lib, tmp, log) for lib in spec.get('libraries', [])]
    meta = {
        'engine': manifest['engine'],
        'version': manifest['version'],
        'platform': platform_id,
        'asset': asset,
        'asset_sha256': digest,
        'sums_file': sums_file,
        'sums_signed_by': signed_by,
        'sums_signed_at': sig.created,
        'binary': binary,
        'binary_sha256': sha256_file(os.path.join(tmp, binary)),
        'libraries': libraries,
        'installed': int(time.time()),
    }
    with open(os.path.join(tmp, 'install.json'), 'w') as handle:
        json.dump(meta, handle, indent=2)
    shutil.rmtree(directory, ignore_errors=True)
    os.rename(tmp, directory)
    info = load_installed(root, manifest, platform_id)
    if info is None:
        raise EngineError('installed engine failed verification')
    log('installed %s (%s)' % (asset, digest))
    return info


def custom_engine(binary):
    if not binary or not os.path.isfile(binary):
        raise EngineError('Custom 3proxy binary not found: %s' % binary)
    return EngineInfo(binary, 'custom', os.path.dirname(binary), custom=True)


def _pid_is_engine(pid, binary):
    try:
        if os.name == 'nt':
            out = subprocess.check_output(['tasklist', '/FI', 'PID eq %d' % pid, '/FO', 'CSV', '/NH'],
                                          creationflags=0x08000000).decode('utf-8', 'replace')
            return os.path.basename(binary).lower() in out.lower()
        return os.path.realpath('/proc/%d/exe' % pid) == os.path.realpath(binary)
    except (OSError, subprocess.SubprocessError):
        return False


def library_env(library_dir, base=None):
    """Environment for running the engine with its bundled shared libraries first."""
    env = dict(os.environ if base is None else base)
    current = env.get('LD_LIBRARY_PATH', '')
    env['LD_LIBRARY_PATH'] = library_dir + (os.pathsep + current if current else '')
    return env


class EngineProcess(object):
    """Runs one 3proxy process in the foreground of the Kodi service."""

    def __init__(self, binary, config_path, workdir, output_log, pid_file, library_dir=None):
        self.binary = binary
        self.config_path = config_path
        self.workdir = workdir
        self.output_log = output_log
        self.pid_file = pid_file
        self.library_dir = library_dir
        self.proc = None
        self.started = 0

    def kill_stale(self):
        """Terminate a 3proxy left over from a previous Kodi crash."""
        try:
            with open(self.pid_file, 'r') as handle:
                pid = int(handle.read().strip())
        except (IOError, OSError, ValueError):
            return False
        killed = False
        if pid > 0 and _pid_is_engine(pid, self.binary):
            try:
                os.kill(pid, signal.SIGTERM)
                killed = True
                time.sleep(1)
            except OSError:
                pass
        try:
            os.remove(self.pid_file)
        except OSError:
            pass
        return killed

    def start(self):
        self.kill_stale()
        kwargs = {}
        if os.name == 'nt':
            kwargs['creationflags'] = 0x08000000  # CREATE_NO_WINDOW
        else:
            kwargs['start_new_session'] = True
            if self.library_dir:
                kwargs['env'] = library_env(self.library_dir)
        out = open(self.output_log, 'ab')
        try:
            self.proc = subprocess.Popen([self.binary, self.config_path], cwd=self.workdir,
                                         stdin=subprocess.DEVNULL, stdout=out, stderr=subprocess.STDOUT,
                                         close_fds=True, **kwargs)
        finally:
            out.close()
        self.started = time.time()
        with open(self.pid_file, 'w') as handle:
            handle.write(str(self.proc.pid))
        return self.proc.pid

    @property
    def pid(self):
        return self.proc.pid if self.proc else None

    def poll(self):
        """None while running, otherwise the exit code."""
        if self.proc is None:
            return -1
        return self.proc.poll()

    def stop(self, timeout=5):
        if self.proc is None:
            return
        if self.proc.poll() is None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                try:
                    self.proc.wait(timeout)
                except subprocess.TimeoutExpired:
                    pass
            except OSError:
                pass
        self.proc = None
        try:
            os.remove(self.pid_file)
        except OSError:
            pass


def tail(path, max_bytes=4096):
    try:
        with open(path, 'rb') as handle:
            handle.seek(0, os.SEEK_END)
            size = handle.tell()
            handle.seek(max(0, size - max_bytes))
            return handle.read().decode('utf-8', 'replace')
    except (IOError, OSError):
        return ''
