# -*- coding: utf-8 -*-
"""HTTP client that always routes traffic exactly like Kodi's proxy settings.

The proxy configuration is obtained from a provider callable (Kodi's
network.httpproxy* settings in production). If the configured proxy type
cannot be honoured, requests fail instead of bypassing the proxy.
"""
import base64
import http.client
import http.cookiejar
import json
import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request

from . import socks

# Values of Kodi's network.httpproxytype setting
PROXY_HTTP = 0
PROXY_SOCKS4 = 1
PROXY_SOCKS4A = 2
PROXY_SOCKS5 = 3
PROXY_SOCKS5_REMOTE = 4
PROXY_HTTPS = 5

PROXY_NAMES = {
    PROXY_HTTP: 'HTTP',
    PROXY_SOCKS4: 'SOCKS4',
    PROXY_SOCKS4A: 'SOCKS4a',
    PROXY_SOCKS5: 'SOCKS5',
    PROXY_SOCKS5_REMOTE: 'SOCKS5 (remote DNS)',
    PROXY_HTTPS: 'HTTPS',
}

_SOCKS_TYPES = {
    PROXY_SOCKS4: socks.SOCKS4,
    PROXY_SOCKS4A: socks.SOCKS4A,
    PROXY_SOCKS5: socks.SOCKS5,
    PROXY_SOCKS5_REMOTE: socks.SOCKS5H,
}

DEFAULT_MAX_BYTES = 4 * 1024 * 1024


class HttpError(Exception):
    """Network-level failure (no HTTP response received)."""


class ProxyUnsupportedError(HttpError):
    """Kodi's proxy cannot be honoured; the request was not sent."""


class ProxyConfig(object):
    def __init__(self, ptype, host, port, username='', password=''):
        self.type = int(ptype)
        self.host = host
        self.port = int(port)
        self.username = username or ''
        self.password = password or ''

    def describe(self):
        return '%s proxy %s:%d' % (PROXY_NAMES.get(self.type, '?'), self.host, self.port)

    def url(self):
        auth = ''
        if self.username:
            auth = '%s:%s@' % (urllib.parse.quote(self.username, safe=''),
                               urllib.parse.quote(self.password, safe=''))
        host = self.host
        if ':' in host and not host.startswith('['):
            host = '[%s]' % host
        return 'http://%s%s:%d' % (auth, host, self.port)


class Response(object):
    def __init__(self, status, headers, body, url):
        self.status = status
        self.headers = headers
        self.body = body or b''
        self.url = url

    @property
    def ok(self):
        return 200 <= self.status < 300

    def header(self, name, default=None):
        if self.headers is None:
            return default
        return self.headers.get(name, default)

    def text(self):
        return self.body.decode('utf-8', 'replace')

    def json(self):
        return json.loads(self.text())


def _socks_connection_class(base, proxy):
    stype = _SOCKS_TYPES[proxy.type]

    def factory(host, **kwargs):
        conn = base(host, **kwargs)

        def create_connection(address, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, source_address=None):
            return socks.create_connection(stype, proxy.host, proxy.port, address[0], address[1],
                                           proxy.username, proxy.password, timeout)

        conn._create_connection = create_connection
        return conn
    return factory


class _SocksHTTPHandler(urllib.request.HTTPHandler):
    def __init__(self, proxy):
        urllib.request.HTTPHandler.__init__(self)
        self._proxy = proxy

    def http_open(self, req):
        return self.do_open(_socks_connection_class(http.client.HTTPConnection, self._proxy), req)


class _SocksHTTPSHandler(urllib.request.HTTPSHandler):
    def __init__(self, proxy, context):
        urllib.request.HTTPSHandler.__init__(self, context=context)
        self._proxy = proxy

    def https_open(self, req):
        return self.do_open(_socks_connection_class(http.client.HTTPSConnection, self._proxy), req,
                            context=self._context)


def build_opener(proxy, cookiejar=None, context=None):
    """Create a urllib opener honouring proxy (None = direct connection)."""
    context = context or ssl.create_default_context()
    handlers = []
    if proxy is None:
        handlers += [urllib.request.ProxyHandler({}), urllib.request.HTTPSHandler(context=context)]
    elif proxy.type == PROXY_HTTP:
        url = proxy.url()
        handlers += [urllib.request.ProxyHandler({'http': url, 'https': url}),
                     urllib.request.HTTPSHandler(context=context)]
    elif proxy.type in _SOCKS_TYPES:
        handlers += [urllib.request.ProxyHandler({}), _SocksHTTPHandler(proxy),
                     _SocksHTTPSHandler(proxy, context)]
    else:
        raise ProxyUnsupportedError(
            'Kodi is configured to use an %s, which this add-on cannot use. '
            'Requests are blocked instead of bypassing the proxy.' % proxy.describe())
    if cookiejar is not None:
        handlers.append(urllib.request.HTTPCookieProcessor(cookiejar))
    return urllib.request.build_opener(*handlers)


def _describe_error(exc):
    reason = getattr(exc, 'reason', None)
    if reason is not None:
        exc = reason
    if isinstance(exc, socket.timeout):
        return 'timed out'
    if isinstance(exc, ssl.SSLError):
        return 'TLS error: %s' % (exc.reason or exc)
    return str(exc) or exc.__class__.__name__


class HttpClient(object):
    def __init__(self, proxy_provider=None, user_agent='Mozilla/5.0', timeout=15, cookies=False):
        self._proxy_provider = proxy_provider or (lambda: None)
        self.user_agent = user_agent
        self.timeout = timeout
        self.cookiejar = http.cookiejar.CookieJar() if cookies else None

    def proxy(self):
        """Current Kodi proxy (None if direct). May raise HttpError."""
        try:
            return self._proxy_provider()
        except HttpError:
            raise
        except Exception as exc:
            raise ProxyUnsupportedError('Cannot read Kodi proxy settings (%s); request blocked' % exc)

    def request(self, method, url, params=None, data=None, json_body=None, headers=None,
                auth=None, timeout=None, max_bytes=DEFAULT_MAX_BYTES):
        if params:
            url += ('&' if '?' in url else '?') + urllib.parse.urlencode(params)
        hdrs = {'User-Agent': self.user_agent, 'Accept': '*/*'}
        body = None
        if json_body is not None:
            body = json.dumps(json_body).encode('utf-8')
            hdrs['Content-Type'] = 'application/json'
        elif isinstance(data, dict):
            body = urllib.parse.urlencode(data).encode('utf-8')
            hdrs['Content-Type'] = 'application/x-www-form-urlencoded'
        elif data is not None:
            body = data
        if auth:
            token = base64.b64encode(('%s:%s' % auth).encode('utf-8')).decode('ascii')
            hdrs['Authorization'] = 'Basic ' + token
        if headers:
            hdrs.update(headers)
        opener = build_opener(self.proxy(), self.cookiejar)
        req = urllib.request.Request(url, data=body, headers=hdrs, method=method)
        try:
            resp = opener.open(req, timeout=timeout or self.timeout)
            try:
                payload = resp.read(max_bytes + 1)
                if len(payload) > max_bytes:
                    raise HttpError('response too large')
                return Response(resp.status, resp.headers, payload, resp.geturl())
            finally:
                resp.close()
        except urllib.error.HTTPError as exc:
            try:
                payload = exc.read(max_bytes)
            except Exception:
                payload = b''
            return Response(exc.code, exc.headers, payload, url)
        except HttpError:
            raise
        except (urllib.error.URLError, OSError, http.client.HTTPException, ValueError) as exc:
            raise HttpError(_describe_error(exc))

    def get(self, url, **kwargs):
        return self.request('GET', url, **kwargs)

    def post(self, url, **kwargs):
        return self.request('POST', url, **kwargs)
