import hashlib
from contextlib import contextmanager
import json
import math
import os
import secrets
import sys
import threading
import time

import requests
from kodi_network import KodiProxyError, KodiSession
from playback_media import media_files
from provider_errors import ProviderError, provider_failure, provider_json, provider_message
from service_config import API_ROOT, PORTAL_ROOT, TENANT_CODENAME, service_scope


CACHE_PROPERTY = "simplitv_t.auth.session." + service_scope(API_ROOT, TENANT_CODENAME)
CHECK_PROPERTY = "simplitv_t.auth.check." + service_scope(API_ROOT, TENANT_CODENAME)
CACHE_SECONDS = 30 * 60
AUTH_TEXT = (
    {
        "not_configured": "simpliTV is not configured. Enter your email and password in Settings.",
        "verified": "Sign-in verified.",
        "rejected": "Sign-in was not accepted. Check your email and password in Settings.",
        "unavailable": "Could not verify sign-in. Check your connection or try again later.",
        "runtime": "simpliTV could not sign in or authorize playback. Check your connection and sign-in details.",
        "settings": "Open settings", "later": "Later",
        "signed_out": "Signed out. Enter another account in Settings.",
    },
    {
        "not_configured": "simpliTV ist nicht eingerichtet. Gib E-Mail und Passwort in den Einstellungen ein.",
        "verified": "Anmeldung bestätigt.",
        "rejected": "Anmeldung nicht akzeptiert. Prüfe E-Mail und Passwort in den Einstellungen.",
        "unavailable": "Anmeldung konnte nicht geprüft werden. Prüfe die Internetverbindung oder versuche es später erneut.",
        "runtime": "simpliTV konnte die Anmeldung oder Wiedergabe nicht bestätigen. Prüfe Verbindung und Anmeldedaten.",
        "settings": "Einstellungen öffnen", "later": "Später",
        "signed_out": "Abgemeldet. Gib ein anderes Konto in den Einstellungen ein.",
    },
)
API_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0",
    "Content-type": "application/json;charset=utf-8",
    "X-Api-Date-Format": "iso", "X-Api-Camel-Case": "true",
    "Referer": PORTAL_ROOT + "/",
    "X-Tenant-Codename": TENANT_CODENAME
}


class AuthError(ProviderError):
    pass


class CredentialRejected(AuthError):
    pass


class AuthSession:
    def __init__(self, username, password, headers, window, log, session=None, lock_path=None,
                 credentials_current=None):
        self.username = username
        self.password = password
        self.api_root = API_ROOT
        self.tenant = TENANT_CODENAME
        self.headers = dict(headers)
        self.headers["X-Tenant-Codename"] = self.tenant
        self.cache_property = "simplitv_t.auth.session." + service_scope(
            self.api_root, self.tenant)
        self.window = window
        self.log = log
        self.session = session if session is not None else KodiSession()
        self.lock_path = lock_path
        self.credentials_current = credentials_current
        self.local_lock = threading.RLock()
        self.lock_depth = 0
        self.account = hashlib.sha256(
            json.dumps([self.api_root, self.tenant, username, password]).encode("utf-8")
        ).hexdigest()

    @contextmanager
    def _locked(self):
        with self.local_lock:
            if self.lock_depth:
                yield
                return
            lock_file = None
            try:
                if self.lock_path:
                    os.makedirs(os.path.dirname(self.lock_path), exist_ok=True)
                    lock_file = open(self.lock_path, "a+b")
                    if os.path.getsize(self.lock_path) == 0:
                        lock_file.write(b"\0")
                        lock_file.flush()
                    deadline = time.monotonic() + 90
                    while True:
                        try:
                            if os.name == "nt":
                                import msvcrt
                                lock_file.seek(0)
                                msvcrt.locking(lock_file.fileno(), msvcrt.LK_NBLCK, 1)
                            else:
                                import fcntl
                                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                            break
                        except OSError:
                            if time.monotonic() >= deadline:
                                raise AuthError("Timed out waiting for authentication preparation")
                            time.sleep(0.05)
                self.lock_depth = 1
                try:
                    yield
                finally:
                    self.lock_depth = 0
            except OSError:
                raise AuthError("Cannot access authentication preparation lock") from None
            finally:
                if lock_file is not None:
                    lock_file.close()

    def _check_current(self):
        if self.credentials_current is not None and not self.credentials_current():
            raise AuthError("simpliTV sign-in details changed")

    def _cache(self):
        self._check_current()
        text = self.window.getProperty(self.cache_property)
        if not text:
            return {}
        try:
            cache = json.loads(text)
            valid = (
                isinstance(cache, dict)
                and cache.get("account") == self.account
                and isinstance(cache.get("expires"), (int, float))
                and math.isfinite(cache["expires"])
                and 0 < cache["expires"] - time.time() <= CACHE_SECONDS
                and isinstance(cache.get("token"), str)
                and bool(cache["token"])
                and isinstance(cache.get("device", ""), str)
            )
        except (ValueError, TypeError):
            valid = False
        if not valid:
            self.invalidate()
            return {}
        return cache

    def invalidate(self):
        self._check_current()
        self.window.clearProperty(self.cache_property)

    def _request(self, method, path, **kwargs):
        headers = dict(kwargs.pop("headers", self.headers))
        headers["X-Tenant-Codename"] = self.tenant
        try:
            response = self.session.request(
                method, self.api_root + path, timeout=15, allow_redirects=False,
                headers=headers, **kwargs
            )
        except KodiProxyError:
            raise AuthError("", provider=provider_failure(reason="proxy")) from None
        except requests.RequestException as error:
            # Request exceptions can contain URLs with tokens; never log their text.
            raise AuthError("", provider=provider_failure(
                getattr(error, "response", None), "connection")) from None
        return response

    @staticmethod
    def _json(response):
        return provider_json(response, AuthError)

    def token(self):
        with self._locked():
            return self._token()

    def _token(self):
        cache = self._cache()
        if cache:
            return cache["token"]
        response = self._request("POST", "/v1/OrsUser/Authenticate", data=json.dumps({
            "Login": self.username, "Password": self.password,
            "LongExpiration": "true", "platformCodename": "www"
        }))
        self._check_current()
        if response.status_code in (400, 401, 403):
            raise CredentialRejected("", provider=provider_failure(response))
        data = self._json(response)
        value = data.get("token")
        if not isinstance(value, str) or not value.strip():
            value = data.get("accessToken")
        if not isinstance(value, str) or not value.strip():
            raise CredentialRejected("", provider=provider_failure(response, "unexpected"))
        self.window.setProperty(self.cache_property, json.dumps({
            "account": self.account, "token": value,
            "expires": time.time() + CACHE_SECONDS, "device": ""
        }))
        return value

    def _devices(self, token):
        return self._request("GET", "/v1/Devices/GetDevices", params={
            "platformCodename": "www", "token": token
        })

    def devicekey(self):
        with self._locked():
            return self._devicekey()

    def _devicekey(self):
        token = self.token()
        cache = self._cache()
        if cache.get("device"):
            return cache["device"]
        response = self._devices(token)
        self._check_current()
        if response.status_code in (401, 403):
            self.log("Device lookup rejected authorization; refreshing once")
            self.invalidate()
            token = self.token()
            response = self._devices(token)
        devices = self._json(response).get("devices")
        if not isinstance(devices, list):
            raise AuthError("", provider=provider_failure(response, "unexpected"))
        if not devices:
            self._check_current()
            response = self._request("POST", "/v1/Devices/RegisterDevice", data=json.dumps({
                "deviceKey": secrets.token_hex(16), "deviceName": "Firefox",
                "generalDeviceType": "2", "operatingSystem": "Windows",
                "platformCodename": "www", "pushToken": "",
                "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0",
                "userToken": token, "versionOs": "10"
            }))
            self._json(response)
            devices = self._json(self._devices(token)).get("devices")
        if not isinstance(devices, list) or not devices or not isinstance(devices[0], dict):
            raise AuthError("simpliTV did not return a registered device")
        key = devices[0].get("key")
        if not isinstance(key, str) or not key:
            raise AuthError("simpliTV did not return a device key")
        cache = self._cache()
        if cache and cache["token"] == token:
            cache["device"] = key
            self.window.setProperty(self.cache_property, json.dumps(cache))
        return key

    def acquire(self, codename, headers, require_success=False):
        with self._locked():
            return self._acquire(codename, headers, require_success)

    def _acquire(self, codename, headers, require_success=False):
        used_cache = bool(self._cache().get("device"))
        for attempt in range(2):
            key = self.devicekey()
            response = self._request("GET", "/v1/Player/AcquireContent", headers=headers,
                                     params={"platformCodename": "www", "deviceKey": key,
                                             "token": self.token(), "codename": codename})
            self._check_current()
            rejected = response.status_code in (401, 403)
            data = None if rejected else self._json(response)
            if require_success and not rejected:
                status = data.get("result", data.get("Result"))
                if not isinstance(status, dict) or status.get("success", status.get("Success")) is not True:
                    raise AuthError("", provider=provider_failure(response))
            # The API can also return a failed acquisition as HTTP 200.
            if attempt == 0 and (rejected or (used_cache and not media_files(data))):
                self.log("Playback acquisition rejected cached session; refreshing once")
                self.invalidate()
                continue
            if rejected:
                self.invalidate()
                raise AuthError("", provider=provider_failure(response))
            if not media_files(data):
                raise AuthError("", provider=provider_failure(response, "unexpected"))
            return data


def credentials(addon):
    return addon.getSetting("username"), addon.getSetting("password")


def configured(values):
    return bool(values[0].strip() and values[1])


def kodi_session():
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs

    addon = xbmcaddon.Addon("plugin.video.simplitv_t")
    values = credentials(addon)
    return AuthSession(
        *values, API_HEADERS,
        xbmcgui.Window(10000),
        lambda message: xbmc.log("[simpliTVᵀ] " + message, xbmc.LOGWARNING),
        lock_path=os.path.join(xbmcvfs.translatePath(addon.getAddonInfo("profile")), "auth.lock"),
        credentials_current=lambda: credentials(addon) == values,
    )


def start_credential_check():
    import xbmc
    import xbmcaddon

    addon = xbmcaddon.Addon("plugin.video.simplitv_t")
    script = os.path.join(addon.getAddonInfo("path"), "auth_session.py")
    xbmc.executebuiltin('RunScript("{}",credential-check)'.format(script))


def open_settings(addon):
    before = credentials(addon)
    addon.openSettings()
    after = credentials(addon)
    if after != before and configured(after):
        start_credential_check()
    return after != before


def ensure_configured(addon):
    import xbmc
    import xbmcgui

    if configured(credentials(addon)):
        return True
    text = AUTH_TEXT[xbmc.getLanguage(xbmc.ISO_639_1) == "de"]
    xbmcgui.Dialog().ok(addon.getAddonInfo("name"), text["not_configured"])
    open_settings(addon)
    return configured(credentials(addon))


def show_auth_error(addon, error):
    import xbmc
    import xbmcgui

    text = AUTH_TEXT[xbmc.getLanguage(xbmc.ISO_639_1) == "de"]
    message = text["rejected"] if isinstance(error, CredentialRejected) else text["runtime"]
    detail = provider_message(error, xbmc.getLanguage(xbmc.ISO_639_1) == "de")
    if detail:
        message = detail + "\n\n" + message
    if xbmcgui.Dialog().yesno(addon.getAddonInfo("name"), message,
                             nolabel=text["later"], yeslabel=text["settings"]):
        open_settings(addon)
        return True
    return False


def check_credentials():
    import xbmc
    import xbmcaddon
    import xbmcgui

    addon = xbmcaddon.Addon("plugin.video.simplitv_t")
    session = kodi_session()
    values = (session.username, session.password)
    if not configured(values):
        session.session.close()
        return
    result = None
    failure = None
    try:
        with session._locked():
            try:
                previous = json.loads(session.window.getProperty(CHECK_PROPERTY) or "{}")
            except (TypeError, ValueError):
                previous = {}
            stamp = previous.get("time") if isinstance(previous, dict) else None
            if (isinstance(previous, dict) and previous.get("account") == session.account
                    and type(stamp) in (int, float) and math.isfinite(stamp)
                    and 0 <= time.time() - stamp < 5):
                return
            try:
                session.token()
            except CredentialRejected as error:
                failure = error
                result = "rejected"
            except AuthError as error:
                failure = error
                session.log("Credential check failed: {}".format(type(error).__name__))
                result = "unavailable"
            if result is None:
                result = "verified"
            if credentials(addon) != values:
                return
            session.window.setProperty(CHECK_PROPERTY, json.dumps({
                "account": session.account, "time": time.time()}))
    except AuthError as error:
        failure = error
        session.log("Credential check failed: {}".format(type(error).__name__))
        if credentials(addon) == values:
            result = "unavailable"
    finally:
        session.session.close()
    if result is not None and credentials(addon) == values:
        text = AUTH_TEXT[xbmc.getLanguage(xbmc.ISO_639_1) == "de"]
        detail = provider_message(failure, xbmc.getLanguage(xbmc.ISO_639_1) == "de")
        message = detail or text[result]
        xbmcgui.Dialog().notification(addon.getAddonInfo("name"), message,
                                      addon.getAddonInfo("icon"), 5000)


def logout():
    import xbmc
    import xbmcaddon
    import xbmcgui

    addon = xbmcaddon.Addon("plugin.video.simplitv_t")
    session = kodi_session()
    try:
        with session._locked():
            session.invalidate()
            session.window.clearProperty(CHECK_PROPERTY)
            # Kodi queues dialog updates; apply them before saving the cleared values.
            addon.setSetting("password", "")
            addon.setSetting("username", "")
            if xbmc.getCondVisibility("Window.IsVisible(addonsettings)"):
                xbmc.sleep(300)
            settings = addon.getSettings()
            settings.setString("password", "")
            settings.setString("username", "")
    finally:
        session.session.close()
    text = AUTH_TEXT[xbmc.getLanguage(xbmc.ISO_639_1) == "de"]
    xbmcgui.Dialog().notification(addon.getAddonInfo("name"), text["signed_out"],
                                  addon.getAddonInfo("icon"), 5000)


def start_preparation(live_access=False):
    import xbmc
    import xbmcaddon

    addon = xbmcaddon.Addon("plugin.video.simplitv_t")
    script = os.path.join(addon.getAddonInfo("path"), "auth_session.py")
    xbmc.executebuiltin('RunScript("{}"{})'.format(script, ",live-access" if live_access else ""))


def prepare(live_access=False):
    import xbmc

    session = kodi_session()
    try:
        if not configured((session.username, session.password)):
            return
        if live_access:
            from channel_access import prepare_channel_grants, prepare_channel_branding, prepare_catchup_policy
            from live_cache import CHANNEL_SECONDS, LiveCache, LiveDataError

            cache = LiveCache(session.window, session.account, session.log)
            access = None
            try:
                access = prepare_channel_grants(session, cache, AuthError, CHANNEL_SECONDS)
            except (AuthError, LiveDataError) as error:
                session.log("Live channel access unavailable: {}".format(error))
            try:
                prepare_channel_branding(session, cache, CHANNEL_SECONDS,
                                         (access or {}).get("branding", {}))
            except LiveDataError as error:
                session.log("Live channel branding unavailable: {}".format(error))
            try:
                prepare_catchup_policy(session, cache, CHANNEL_SECONDS)
            except (AuthError, LiveDataError) as error:
                session.log("Catch-up policy unavailable: {}".format(type(error).__name__))
            return
        session.devicekey()
    except AuthError as error:
        xbmc.log("[simpliTVᵀ] Background preparation: " + str(error), xbmc.LOGERROR)
    finally:
        session.session.close()


if __name__ == "__main__":
    if sys.argv[1:] == ["credential-check"]:
        check_credentials()
    else:
        prepare(live_access=sys.argv[1:] == ["live-access"])
