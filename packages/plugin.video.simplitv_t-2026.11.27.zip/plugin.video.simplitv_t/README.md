# simpliTVᵀ

A Kodi 21 (Omega) add-on for [simpliTV live TV](https://streaming.simpli.at/tv).
It opens directly into the programme guide. A simpliTV account is required;
available channels and replay depend on your entitlement.

## Setup

Install the `plugin.video.simplitv_t` folder in Kodi’s `addons` directory and
restart Kodi. Under **Settings → General** (**Einstellungen → Allgemein**),
enter your e-mail address and password. When credentials are missing, the add-on
opens Settings for you. Changed credentials are checked and the result is shown;
you can still save them if the check fails. Kodi needs InputStream Adaptive and
InputStream Helper. For Widevine-protected streams, the helper offers to install
Widevine if needed; follow its prompts and licence terms. Clear streams use
InputStream Adaptive without a Widevine check. PlayReady-only streams are not
supported.

## Watching TV

| Where | Controls |
| --- | --- |
| **Programme guide** | Left/Right moves between programmes; Up/Down moves between channels. In the action row, Up/Down returns to the selected programme. Page Up/Down (often P+/P−) pages through the lineup. OK opens live TV or an available replay action. Menu focuses the action row, including Settings. Enter `000` to open Settings directly. |
| **While tuning** | Back cancels the tune. You can turn off TV static to show a black screen with the station logo instead. |
| **During playback** | Back returns to the guide without stopping the stream. **Return to stream** reopens it without retuning. Stop ends playback and returns to the guide. |

For past programmes, a **teal** badge marks provider Catch-up. An **amber** badge
marks estimated rewind in the live buffer. A rewind attempt may not land on the
scheduled start, and unavailable programmes don’t show a replay action. Until a
channel's buffer has been measured, its window is estimated at three hours;
this assumption is not saved. A shorter actual buffer starts at its earliest
available point, which may be after the selected programme.
The badge starts at the programme's start, or at the earliest estimated rewind
point for a partial programme. If that point is outside the visible timeline,
no badge is drawn; very short programmes can have overlapping badges.

When a channel is already playing, the guide shows its picture in the programme
details area. Sound and playback continue as before; browsing does not switch
channels. Turn the picture off in **Live TV** settings if desired.
With the mini-picture off or unavailable, the current video appears full-screen
behind a translucent guide. Without a matching stream, the guide stays opaque.
Back from the add-on player restores the guide without stopping the stream.
When playback stops or ends, the guide selects the watched channel and, for
guide-started Catch-up or rewind, the played airing if it is still available.
A future-only view does not reopen hours ahead when returning to live.

### Seeking and channel changes

The programme guide opens the **simpliTVᵀ player** for live TV and replay:

- **P+/P−** switches channels. Further channel keys while a stream starts are
  kept, so you can select the next channel without waiting for video.
  **Up/Down** seeks ten minutes.
- Enter a channel number on the remote to select it in the guide or player.
  Numbers follow the full lineup, so hiding unplayable channels leaves gaps;
  entering a hidden or unassigned number does not switch channels.
- Enter `000`, then press OK or wait 1.5 seconds, to open Settings in the guide
  or add-on player. An active stream continues playing.
- **Left/Right** seeks 30 seconds per tap for the first four taps in the same
  direction, then two minutes per tap. A pause between presses or a reversal
  starts a new burst.
- **Hold Left/Right** to jump to a known programme start or end (or the live
  edge for a programme still airing). This requires Kodi to report a distinct
  long press for your input. If it doesn’t, use the programme jump commands in
  the **context menu**, which also has audio and subtitle settings.
- **OK** opens Kodi's video controls (rewind, pause, stop, …); Back closes them.
- **Display / Fullscreen** switches to Kodi’s native fullscreen player. The
  add-on player has its own seek display, Info banner, and audio/subtitle menu,
  not every native dialog (for example, Kodi's seek bar).

The guide shows station numbers and logos; the selected row gently alternates
between its logo and name. The full-width seek strip shows the station number
and logo and a local-time ruler from the oldest reported point to live. A thin red line marks the seek target while
seeking, then follows actual playback. Without a logo, the station name stays
visible. In the simpliTVᵀ player a badge above the marker shows local
broadcast time and live offset, e.g. `21:47 · −4:56`, or `LIVE` near the edge.
The bar stays visible while paused. Replays show
position and duration at the bottom instead. The tune and Info banner shares
that area and yields to the seek bar.
The guide fills in the rewind window in the background;
gaps mean no programme information is available for that interval. The clock
(`Broadcast time ~` / `Sendezeit ~`) in Kodi fullscreen is approximate. Normal fullscreen retains
Kodi’s native seek controls and displays the same portable overlay when enabled.

## Settings

| Tab | Settings |
| --- | --- |
| **General / Allgemein** | Account credentials; log out / switch account; portable timeshift overlay (on); TV static while tuning (on). |
| **Live TV** | Show only playable channels (on); show the current channel in the guide (on); remember last watched channel (on). |
| **About / Über** | Credits and licence. |

If the guide can’t open, the recovery directory offers **Programme Guide**
and **Live TV settings**. Existing direct playable links, such as favourites
that point straight to a channel, use Kodi's standard player. Their channel
numbers appear when a recent lineup is already cached.
When enabled, remembering the last channel selects it in the guide on the next
launch; it does not automatically start playback.

## Credits and licence

simpliTVᵀ is maintained by **Tom** and based on the original simpliTV Kodi
add-on by **Publish3r** and **sunsettrack4**. It is unofficial and licensed
under [GNU GPL v3 or later](LICENSE.txt); the full licence is in [COPYING](COPYING).

[Developer reference](docs/developer.md) — implementation details, compatibility,
caches, changes from the original add-on, and offline testing.

[Development history](docs/development-history.md) — published versions,
unreleased changes, and what was verified.

**TV options:** In the guide, **TV options** is available when you can return
to the last station or go live in the current stream. The add-on
player also offers these in its context menu. Stations enter the history
only once playback starts. **Go live** seeks in the current stream.
