import datetime
from contextlib import contextmanager
import hashlib
import json
import math
import os
import time
import uuid
from service_config import API_ROOT
from provider_errors import ProviderError


CHANNEL_SECONDS = 15 * 60
EPG_SECONDS = 5 * 60
EPG_HORIZON_SECONDS = 6 * 60 * 60
MAX_GUIDE_PROGRAMMES = 2000
GUIDE_SLICE = datetime.timedelta(hours=4)
GUIDE_MEMORY_SLOTS = 16


class LiveDataError(ProviderError):
    pass


class LiveDataCancelled(RuntimeError):
    pass


@contextmanager
def claim_guide_session(lock_path):
    """Keep repeated input on the underlying Live TV row from starting a second guide."""
    try:
        os.makedirs(os.path.dirname(lock_path), exist_ok=True)
        handle = open(lock_path, "a+b")
    except OSError:
        raise LiveDataError("Cannot access Live TV session lock") from None
    with handle:
        if os.name == "nt":
            import msvcrt
            handle.seek(0)
            acquire = lambda: msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            acquire = lambda: fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            acquire()
        except OSError:
            yield False
        else:
            yield True


def fetch_programme_listing(live_json, start, end):
    tiles = live_json(
        "POST", API_ROOT + "/v1/EpgTile/FilterProgramTiles",
        data=json.dumps({"platformCodename": "www", "from": start.isoformat(),
                         "to": end.isoformat()})
    ).get("programs")
    if not isinstance(tiles, dict) or any(not isinstance(items, list) for items in tiles.values()):
        raise LiveDataError("Invalid live programme list")
    return tiles


def fetch_programmes(live_json, horizon=EPG_HORIZON_SECONDS, start=None, end=None,
                     cancelled=None, channels=None, listing=None, publish=None):
    if (start is None) != (end is None):
        raise LiveDataError("Incomplete live programme range")
    if start is None:
        start = datetime.datetime.now(datetime.timezone.utc)
        end = start + datetime.timedelta(seconds=horizon)
    if (not isinstance(start, datetime.datetime) or not isinstance(end, datetime.datetime)
            or start.tzinfo is None or end.tzinfo is None or end <= start):
        raise LiveDataError("Invalid live programme range")

    def check_cancelled():
        if cancelled is not None and cancelled():
            raise LiveDataCancelled("Programme guide fetch cancelled")

    check_cancelled()
    tiles = fetch_programme_listing(live_json, start, end) if listing is None else listing()
    try:
        ids = {}
        for channel, group in tiles.items():
            if channels is not None and channel not in channels:
                continue
            for item in group[:1] if horizon == 60 else group:
                identity = item["id"]
                ids[identity] = None
                if len(ids) > MAX_GUIDE_PROGRAMMES:
                    raise LiveDataError("Programme guide range returned too many entries")
        ids = list(ids)
    except (KeyError, TypeError):
        raise LiveDataError("Invalid live programme identifiers") from None
    programmes = []
    for offset in range(0, len(ids), 100):
        check_cancelled()
        details = live_json(
            "POST", API_ROOT + "/v2/Tile/GetTiles",
            data=json.dumps({"platformCodename": "www",
                             "requestedTiles": [{"id": item} for item in ids[offset:offset + 100]]})
        ).get("tiles")
        if not isinstance(details, list):
            raise LiveDataError("Invalid live programme details")
        if channels is not None and len(details) != min(100, len(ids) - offset):
            raise LiveDataError("Incomplete live programme details")
        try:
            for item in details:
                if (not isinstance(item["tileChannel"]["codename"], str)
                        or broadcast_timestamp(item["stop"]) <= broadcast_timestamp(item["start"])):
                    raise LiveDataError("Invalid live programme interval")
        except (KeyError, TypeError):
            raise LiveDataError("Incomplete live programme details") from None
        programmes.extend(item for item in details if channels is None
                          or item["tileChannel"]["codename"] in channels)
        if publish is not None and offset + 100 < len(ids):
            check_cancelled()
            publish(tuple(programmes))
    check_cancelled()
    return programmes


def guide_cache_slot(kind, start, channels=()):
    digest = hashlib.sha256(json.dumps(
        [start.isoformat(), list(channels)], separators=(",", ":")
    ).encode("utf-8")).hexdigest()
    return "guide.{}.{}".format(kind, int(digest[:8], 16) % GUIDE_MEMORY_SLOTS), digest


def load_guide_page(cache, lock_path, live_json, start, channels, cancelled, publish=None):
    end = start + GUIDE_SLICE
    page_key, page_id = guide_cache_slot("page", start, channels)
    listing_key, listing_id = guide_cache_slot("listing", start)

    def listing():
        def compact_listing():
            groups = fetch_programme_listing(live_json, start, end)
            if sum(map(len, groups.values())) > 16000:
                raise LiveDataError("Programme guide listing is too large")
            try:
                return {channel: [{"id": item["id"]} for item in items]
                        for channel, items in groups.items()}
            except (KeyError, TypeError):
                raise LiveDataError("Invalid live programme identifiers") from None

        return cache.get(listing_key, compact_listing, EPG_SECONDS, listing_id)

    return cache.get_with_lock(
        page_key, lambda: fetch_programmes(
            live_json, start=start, end=end, cancelled=cancelled,
            channels=frozenset(channels), listing=listing, publish=publish
        ), EPG_SECONDS, lock_path, cancelled, identity=page_id
    )


def broadcast_timestamp(value):
    if not isinstance(value, str):
        raise LiveDataError("Invalid programme timestamp")
    try:
        value = datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise LiveDataError("Invalid programme timestamp") from None
    if value.tzinfo is None:
        value = value.replace(tzinfo=datetime.timezone.utc)
    return value.timestamp()


def current_programmes(programmes, now=None):
    now = time.time() if now is None else now
    current = {}
    for programme in programmes:
        start = broadcast_timestamp(programme["start"])
        stop = broadcast_timestamp(programme["stop"])
        if start <= now < stop:
            channel = programme["tileChannel"]["codename"]
            previous = current.get(channel)
            if previous is None or start > broadcast_timestamp(previous["start"]):
                current[channel] = programme
    return current


def now_next_programmes(programmes, channels, now):
    current, upcoming = {}, {}
    channels = set(channels)
    for event in programmes:
        try:
            code = event["tileChannel"]["codename"]
            if code not in channels:
                continue
            start = broadcast_timestamp(event["start"])
            stop = broadcast_timestamp(event["stop"])
        except (KeyError, TypeError, ValueError, OverflowError, OSError, LiveDataError):
            continue
        if stop <= max(now, start):
            continue
        if start <= now:
            if code not in current or start > current[code][0]:
                current[code] = (start, stop, event)
        else:
            upcoming.setdefault(code, []).append((start, stop, event))
    for code in channels:
        on_air = current.get(code)
        # Ignore duplicate copies and overlapping entries, not genuine schedule gaps.
        threshold = on_air[1] if on_air else now
        following = min((entry for entry in upcoming.get(code, ()) if entry[0] >= threshold),
                        key=lambda entry: entry[0], default=None)
        yield code, (on_air, following)


class LiveCache:
    def __init__(self, window, account, log, clock=time.time, guide_store=None):
        self.window = window
        self.account = account
        self.log = log
        self.clock = clock
        self.guide_store = guide_store

    def _key(self, name):
        return "simplitv_t.live.{}.{}".format(self.account, name)

    def invalidate(self, name):
        self.window.setProperty(self._key(name) + ".revision", uuid.uuid4().hex)
        self.window.clearProperty(self._key(name))

    def get(self, name, loader, seconds, identity=None):
        cached = self.peek(name, seconds, identity)
        if cached is not None:
            return cached
        key = self._key(name)
        revision = self.window.getProperty(key + ".revision")
        now = self.clock()
        data = loader()
        if self.window.getProperty(key + ".revision") == revision:
            self.window.setProperty(key, json.dumps({
                "created": now, "revision": revision, "data": data, "identity": identity
            }))
            if self.guide_store is not None and name.startswith("guide.page.") and identity:
                self.guide_store.write_page(identity, now, data)
        return data

    def get_with_lock(self, name, loader, seconds, lock_path, cancelled=None,
                      wait_seconds=90, identity=None):
        deadline = time.monotonic() + wait_seconds
        while True:
            if cancelled is not None and cancelled():
                raise LiveDataCancelled("Live data fetch cancelled")
            cached = self.peek(name, seconds, identity)
            if cached is not None:
                return cached
            try:
                os.makedirs(os.path.dirname(lock_path), exist_ok=True)
                lock_file = open(lock_path, "a+b")
            except OSError:
                raise LiveDataError("Cannot access programme guide lock") from None
            acquired = False
            try:
                if os.path.getsize(lock_path) == 0:
                    lock_file.write(b"\0")
                    lock_file.flush()
                try:
                    if os.name == "nt":
                        import msvcrt
                        lock_file.seek(0)
                        msvcrt.locking(lock_file.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    acquired = True
                except OSError:
                    if time.monotonic() >= deadline:
                        raise LiveDataError("Timed out waiting for programme guide data")
                if acquired:
                    cached = self.peek(name, seconds, identity)
                    if cached is not None:
                        return cached
                    return self.get(name, loader, seconds, identity)
            finally:
                if acquired:
                    if os.name == "nt":
                        import msvcrt
                        lock_file.seek(0)
                        msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
                lock_file.close()
            time.sleep(0.1)

    def _memory_entry(self, key, revision, now, seconds):
        text = self.window.getProperty(key)
        if text:
            try:
                cached = json.loads(text)
                if (isinstance(cached, dict)
                        and cached.get("revision") == revision
                        and isinstance(cached.get("created"), (float, int))
                        and math.isfinite(cached["created"])
                        and 0 <= now - cached["created"] < seconds
                        and "data" in cached):
                    return cached
            except (ValueError, TypeError):
                self.log("Ignoring invalid live-list cache entry")
        return None

    def peek(self, name, seconds, identity=None):
        key = self._key(name)
        revision = self.window.getProperty(key + ".revision")
        entry = self._memory_entry(key, revision, self.clock(), seconds)
        if entry is not None and entry.get("identity") == identity:
            return entry["data"]
        if (self.guide_store is not None and name.startswith("guide.page.")
                and identity and not revision):
            stored = self.guide_store.read_page(identity, seconds)
            if stored is not None:
                created, data = stored
                self.window.setProperty(key, json.dumps({
                    "created": created, "revision": revision, "identity": identity, "data": data
                }))
                return data
        return None

    def cached_schedules(self):
        for name, ttl in (("upcoming", EPG_SECONDS), ("current", 60)):
            events = self.peek(name, ttl)
            if isinstance(events, list):
                yield from events
        # The guide uses range/channel-specific page identities. Inspect the
        # bounded published memory slots; do not guess identities or load pages.
        now = self.clock()
        pages = []
        for slot in range(GUIDE_MEMORY_SLOTS):
            key = self._key("guide.page.{}".format(slot))
            entry = self._memory_entry(key, self.window.getProperty(key + ".revision"),
                                       now, EPG_SECONDS)
            if (entry is not None and isinstance(entry.get("identity"), str)
                    and isinstance(entry["data"], list)):
                pages.append(entry)
        for entry in sorted(pages, key=lambda page: page["created"], reverse=True):
            yield from entry["data"]

    def programmes(self, loader):
        upcoming = self.peek("upcoming", EPG_SECONDS)
        if upcoming is not None:
            return upcoming
        return self.get("current", loader, 60)


def start_upcoming_preparation(cache):
    import xbmc

    if cache.peek("upcoming", EPG_SECONDS) is None:
        xbmc.executebuiltin('RunScript("{}")'.format(os.path.abspath(__file__)))


def prepare_upcoming():
    import xbmc
    import xbmcaddon
    import xbmcgui
    from auth_session import kodi_session, AuthError, API_ROOT

    session = kodi_session()
    cache = LiveCache(session.window, session.account,
                      lambda message: xbmc.log("[simpliTVᵀ] " + message, xbmc.LOGWARNING))
    # Keep the long EPG fetch independent of the authentication lock.
    session.lock_path = os.path.join(os.path.dirname(session.lock_path), "epg.lock")

    def live_json(method, url, **kwargs):
        return session._json(session._request(method, url[len(API_ROOT):], **kwargs))

    try:
        with session._locked():
            cache.get("upcoming", lambda: fetch_programmes(live_json), EPG_SECONDS)
    except (AuthError, LiveDataError) as error:
        xbmc.log("[simpliTVᵀ] Background EPG: " + str(error), xbmc.LOGERROR)
        addon = xbmcaddon.Addon("plugin.video.simplitv_t")
        xbmcgui.Dialog().notification(
            "simpliTVᵀ", "Programm-Vorschau konnte nicht geladen werden",
            addon.getAddonInfo("icon"), 5000
        )
    finally:
        session.session.close()


if __name__ == "__main__":
    prepare_upcoming()
