import datetime
import json
import math
import os
import time
import uuid
import xml.etree.ElementTree as ET

from seek_timeline import clamp, sane_timeline, strip_cells
from seek_schedule import SeekSchedule, load_schedule, schedule_rows
from tv_behavior import ProgrammeBanner, number_text, numbered, programme_banner


REQUEST_PROPERTY = "simplitv_t.timeshift.request"
WORKER_PROPERTY = "simplitv_t.timeshift.worker"
STRIP_PROPERTY = "simplitv_t.seekstrip"
TILE_COLOR = "FF35465B"
TILE_LIVE_COLOR = "FF31566E"
TINY_COLOR = "FF282F38"
FILLER_COLOR = "FF303944"
GAP_COLOR = "FF141B27"
TILE_ACTIVE_COLOR = "FF3B7593"
FADE = [("Visible", "effect=fade start=0 end=100 time=200"),
        ("Hidden", "effect=fade start=100 end=0 time=200")]
SHOW_CONDITION = (
    "Window.IsActive(fullscreenvideo) + "
    "[Player.Seeking | Player.HasPerformedSeek(3) | Player.Paused | "
    "Player.Forwarding | Player.Rewinding]"
)


def parse_time(value):
    if not value:
        return None
    value = value.strip()
    sign = -1 if value.startswith("-") else 1
    parts = value.lstrip("+-").split(":")
    if len(parts) not in (2, 3) or not all(part.isdigit() for part in parts):
        raise ValueError("Invalid player time")
    numbers = [int(part) for part in parts]
    if any(number >= 60 for number in numbers[1:]):
        raise ValueError("Invalid player time component")
    return sign * sum(number * 60 ** index for index, number in enumerate(reversed(numbers)))


def format_duration(seconds):
    seconds = max(0, int(seconds))
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)
    return "{:02d}:{:02d}:{:02d}".format(hours, minutes, seconds)


class PauseClock:
    def __init__(self):
        self.last_time = None
        self.last_duration = None
        self.was_paused = False
        self.extra_delay = 0.0

    def update(self, duration, paused, monotonic_now):
        if not math.isfinite(duration) or duration <= 0:
            raise ValueError("Invalid timeshift duration")
        if self.last_time is not None:
            elapsed = max(0, monotonic_now - self.last_time)
            growth = max(0, duration - self.last_duration)
            if self.was_paused:
                # Some input streams freeze their live edge until playback resumes.
                self.extra_delay = max(0, self.extra_delay + elapsed - growth)
            else:
                self.extra_delay = max(0, self.extra_delay - max(0, growth - elapsed))
        self.last_time = monotonic_now
        self.last_duration = duration
        self.was_paused = paused
        return self.extra_delay


def overlay_label(position, duration, now, extra_delay=0.0, german=True):
    if not math.isfinite(position) or not math.isfinite(duration) or duration <= 0:
        raise ValueError("Invalid timeshift timeline")
    target = max(0, min(position, duration))
    delay = max(0, duration - target + extra_delay)
    behind = int(round(delay))
    broadcast = datetime.datetime.fromtimestamp(now - delay).strftime("%H:%M:%S")
    clock_label = "Sendezeit" if german else "Broadcast time"
    return "[B]-{}[/B]  [COLOR FF999999]/ {}[/COLOR]     {} ~ [B]{}[/B]".format(
        format_duration(behind), format_duration(duration), clock_label, broadcast)


def launch(url, channel=None, account=None, logo=None, station=None, banner=False, number=None,
           remember=False):
    import xbmc
    import xbmcaddon
    import xbmcgui

    addon = xbmcaddon.Addon()
    if addon.getSetting("timeshift_overlay") == "false" and not banner and not remember:
        return
    request = json.dumps({"url": url.split("|", 1)[0], "token": uuid.uuid4().hex,
                          "channel": channel, "account": account, "logo": logo, "station": station,
                          "banner": banner, "number": number, "remember": remember})
    xbmcgui.Window(10000).setProperty(REQUEST_PROPERTY, request)
    script = os.path.join(addon.getAddonInfo("path"), "timeshift_overlay.py")
    xbmc.executebuiltin('RunScript("{}")'.format(script))


def remember_started_channel(addon, channel, account):
    if (addon.getSetting("remember_last_channel") == "false"
            or not isinstance(channel, str) or not channel
            or not isinstance(account, str) or not account):
        return
    import xbmc
    from auth_session import kodi_session
    from guide_store import GuideStore
    from service_config import API_ROOT, TENANT_CODENAME

    session = kodi_session()
    try:
        if session.account == account:
            store = GuideStore(os.path.dirname(session.lock_path), API_ROOT, TENANT_CODENAME,
                               session.username,
                               lambda message: xbmc.log("[simpliTVᵀ] " + message, xbmc.LOGWARNING))
            store.write_last_channel(channel)
    finally:
        session.session.close()


def skin_font(preferred=("font13", "font12", "font20", "font10")):
    import xbmc
    import xbmcaddon

    root = xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo("path")
    for folder in ("xml", "1080i", "720p"):
        path = os.path.join(root, folder, "Font.xml")
        if not os.path.isfile(path):
            continue
        try:
            fonts = [node.text for node in ET.parse(path).findall(".//font/name")]
        except (OSError, ET.ParseError) as error:
            xbmc.log("[simpliTVᵀ] Cannot read skin fonts: {}".format(error), xbmc.LOGWARNING)
            break
        for candidate in preferred:
            if candidate in fonts:
                return candidate
        if fonts:
            return fonts[0]
    xbmc.log("[simpliTVᵀ] Using default overlay font for this skin", xbmc.LOGWARNING)
    return "font13"


def channel_schedule(cache, channel):
    return schedule_rows(cache.cached_schedules(), channel)


class NativeSeekTarget:
    ARRIVAL_TOLERANCE = 2
    PENDING_TIMEOUT = 0.8

    def __init__(self):
        self.target = None
        self.last_preview = None
        self.until = 0

    def update(self, seeking, read_target, position, duration, now):
        if seeking and position is not None:
            try:
                target = parse_time(read_target())
                # Kodi's seek preview falls back to actual time between native steps.
                if (target is not None and 0 <= target <= duration
                        and abs(target - position) > self.ARRIVAL_TOLERANCE
                        and target != self.last_preview):
                    self.last_preview = target
                    self.target = target
                    self.until = now + self.PENDING_TIMEOUT
            except ValueError:
                pass
        if self.target is not None and (now >= self.until
                or (position is not None and abs(position - self.target) <= self.ARRIVAL_TOLERANCE)):
            self.target = None
        if not seeking and self.target is None:
            self.last_preview = None
        return self.target


def ruler_ticks(duration, edge, width, spacing):
    oldest = edge - duration
    step = next((seconds for seconds in (60, 120, 300, 600, 900, 1800, 3600, 7200, 14400, 28800)
                 if seconds * width >= spacing * duration), 86400)
    first = math.ceil(oldest / step) * step
    return [(round((stamp - oldest) * width / duration),
             datetime.datetime.fromtimestamp(stamp).strftime("%H:%M"))
            for stamp in range(first, math.floor(edge) + 1, step)]


def cached_strip_logo(xbmc, logo, fallback):
    from kodi_logos import get_logo_cache

    if not logo or logo == fallback:
        return None
    try:
        return get_logo_cache().get(logo, framed=True)
    except (ImportError, OSError, RuntimeError, TypeError, ValueError, AttributeError) as error:
        xbmc.log("simpliTV: seek strip logo unavailable ({})".format(type(error).__name__),
                 xbmc.LOGWARNING)
        return None


class SeekStrip:
    """Non-focusable guide tiles with one marker for the current seek position."""

    def __init__(self, window, addon, condition="", logo=None, station="", *,
                 status=False, minimal=False, number=None):
        import xbmcgui
        from guide import (GUIDE_CELL_TRIM, GUIDE_NUMBER_COLUMN, TIMELINE_MARKER_COLOR,
                           TIMELINE_MARKER_WIDTH, guide_logo_texture, guide_tile_gaps)

        self.window = window
        width, height = window.getWidth(), window.getHeight()
        self.height = height
        self.active = None
        self.pad = max(18, int(width * 0.02))
        self.number_column = GUIDE_NUMBER_COLUMN if number_text(number) else 0
        self.gap = guide_tile_gaps(width, height)[0]
        self.left = (max(124, int(width * 0.12)) + self.number_column
                     - (GUIDE_CELL_TRIM if self.number_column else 0) + 18)
        # The guide's safe margins: content stays clear of overscanned edges, the
        # background still bleeds to the screen edge.
        self.right_margin = max(18, int(width * 0.02))
        self.bottom_margin = max(12, int(height * 0.02))
        self.width = max(1, width - self.left - self.right_margin)
        self.row = max(24, round(height * .036)) if status and not minimal else max(24, int(height * .0296))
        self.top = height - self.bottom_margin - self.row * 2
        self.tile_y = self.top + self.row
        self.layout = self.ticks = None
        self.marker_x = None
        self.marker_width = min(self.width, TIMELINE_MARKER_WIDTH)
        self.shown = False
        self.owner = uuid.uuid4().hex
        solid = os.path.join(addon.getAddonInfo("path"), "resources", "skins", "Default",
                             "media", "guide-solid.png")
        font = skin_font()
        tile_font = skin_font(("font27", "font12", "font13") if status and not minimal
                              else ("font10", "font12", "font13"))

        def image(x, y, w, h, color):
            return xbmcgui.ControlImage(x, y, w, h, solid, colorDiffuse=color)

        def label(x, y, w, title, alignment, color="FFFFFFFF", size=font):
            return xbmcgui.ControlLabel(x, y, w, self.row, title, font=size,
                                         textColor=color, alignment=alignment)

        status_y = height - self.bottom_margin - self.row if minimal else self.top - self.row
        self.status_y = status_y
        self.status = (label(12, status_y, max(1, width - 12 - self.right_margin), "", 6)
                       if status or minimal else None)
        self.status_badge = None
        self.status_text = None
        if minimal:
            self.controls = [image(0, status_y, width, height - status_y, "FF101722"), self.status]
            self._attach(condition)
            return
        background_top = status_y if status else self.top
        if status:
            self.status_badge = image(0, status_y + 3, 1, self.row - 6, "FF30485D")
            self.status_width = min(max(1, width - 12), max(180, round(width * .115)))
            self.status_bounds = None
        self.background = image(0, background_top, width, height - background_top, GAP_COLOR)
        branding = image(self.pad, self.top, self.left - self.gap - self.pad, self.row * 2, "FF202A37")
        cell_x = self.pad + 8 + self.number_column
        cell_width = max(1, self.left - 18 - self.pad - 16 - self.number_column
                         + (GUIDE_CELL_TRIM if self.number_column else 0))
        number_label = (label(self.pad - 4, self.top + self.row // 2, self.number_column + 12,
                              number_text(number), 6, "FFF1F5F9",
                              skin_font(("font10", "font12", "font13")))
                        if self.number_column else None)
        station_logo = None
        if logo:
            from logo_geometry import logo_box
            logo_width, logo_height = logo_box(cell_width, max(16, self.row * 2 - 14))
            # Same Lanczos prescale as the guide; full-size logos alias when drawn this small.
            station_logo = xbmcgui.ControlImage(cell_x + (cell_width - logo_width) // 2,
                                               self.top + self.row - logo_height // 2,
                                               logo_width, logo_height,
                                               guide_logo_texture(logo, logo_width, logo_height),
                                               aspectRatio=2)
        # The logo alone identifies the channel; the name stands in only without one.
        station_name = (None if station_logo is not None else
                        label(cell_x, self.top + self.row // 2, cell_width, station, 6))
        self.tiles = [(image(self.left, self.tile_y, 1, self.row, TILE_COLOR),
                       label(self.left, self.tile_y, 1, "", 4, size=tile_font)) for _ in range(32)]
        self.tile_colors = [TILE_COLOR] * len(self.tiles)
        self.tick_width = max(50, int(width * 0.055))
        self.ruler_y = self.top if status else self.top - 2
        self.ruler = [(image(self.left, self.tile_y - 5, 2, 5, "FF8B9AAF"),
                       label(self.left, self.ruler_y, self.tick_width, "", 6, "FFB8C6D8"))
                      for _ in range(min(32, self.width // self.tick_width + 1))]
        self.marker = image(self.left, self.top, self.marker_width, self.row * 2, TIMELINE_MARKER_COLOR)
        self.controls = [self.background, branding, station_logo or station_name]
        if number_label is not None:
            self.controls.append(number_label)
        if self.status is not None:
            self.controls += [self.status_badge, self.status]
        self.controls += [control for pair in self.tiles + self.ruler for control in pair]
        self.controls.append(self.marker)
        self._attach(condition)
        for tile in self.tiles + self.ruler:
            for control in tile:
                control.setVisible(False)

    def _attach(self, condition):
        self.window.addControls(self.controls)
        show = "String.IsEqual(Window.Property({}),{})".format(STRIP_PROPERTY, self.owner)
        for control in self.controls:
            control.setAnimations(FADE)
            control.setVisibleCondition("{} + [{}]".format(show, condition) if condition else show)

    def show(self, status=None):
        if self.status is not None and status != self.status_text:
            self.status.setLabel(status or "")
            self.status_text = status
        if not self.shown:
            self.window.setProperty(STRIP_PROPERTY, self.owner)
            self.shown = True

    def update(self, rows, position, duration, edge, pending, status=None):
        from guide import TINY_CELL_WIDTH, fit_event_label

        labelled = [(start, stop, (datetime.datetime.fromtimestamp(start).strftime("%H:%M"), title))
                    for start, stop, title in rows]
        cells, cursor = [], 0
        for x, cell_width, payload in sorted(strip_cells(labelled, duration, edge, self.width)):
            if x - cursor > self.gap:
                cells.append((cursor, x - cursor, None))
            cells.append((x, cell_width, payload))
            cursor = max(cursor, x + cell_width)
        if cells and self.width - cursor > self.gap:
            cells.append((cursor, self.width - cursor, None))
        if len(cells) > len(self.tiles):
            cells = sorted(sorted(cells, key=lambda cell: cell[1], reverse=True)[:len(self.tiles)])
        if cells != self.layout:
            previous = self.layout or ()
            for index, (tile, label) in enumerate(self.tiles):
                cell = cells[index] if index < len(cells) else None
                old = previous[index] if index < len(previous) else None
                if cell == old:
                    continue
                text = ""
                if cell is not None:
                    x, width, payload = cell
                    width = max(1, width - (self.gap if x + width < self.width else 0))
                    tile.setPosition(self.left + x, self.tile_y)
                    tile.setWidth(width)
                    color = (FILLER_COLOR if payload is None else
                             TINY_COLOR if width < TINY_CELL_WIDTH else
                             TILE_LIVE_COLOR if x + cell[1] >= self.width else TILE_COLOR)
                    self.tile_colors[index] = color
                    tile.setColorDiffuse(color)
                    # Like guide cells: whole "HH:MM  Title", the time alone, or nothing.
                    if payload is not None and width >= TINY_CELL_WIDTH:
                        text = fit_event_label(payload[0], payload[1], width, self.height)
                    if text:
                        label.setPosition(self.left + x + 8, self.tile_y)
                        label.setWidth(max(1, width - 16))
                        label.setLabel(text)
                if (old is None) != (cell is None):
                    tile.setVisible(cell is not None)
                label.setVisible(bool(text))
            self.layout = cells
            relaid = True
        else:
            relaid = False
        ticks = ruler_ticks(duration, edge, self.width, self.tick_width * 1.5)
        if ticks != self.ticks:
            for index, (tick, label) in enumerate(self.ruler):
                if index < len(ticks):
                    x, title = ticks[index]
                    tick.setPosition(self.left + min(self.width - 2, x), self.tile_y - 5)
                    label_x = max(0, min(self.width - self.tick_width, x - self.tick_width // 2))
                    label.setPosition(self.left + label_x, self.ruler_y)
                    label.setLabel(title)
                tick.setVisible(index < len(ticks))
                label.setVisible(index < len(ticks))
            self.ticks = ticks
        point = position if pending is None else pending
        x = self.left + min(self.width - self.marker_width,
                            round(clamp(point, duration) / duration * self.width))
        if x != self.marker_x:
            self.marker.setPosition(x, self.top)
            self.marker_x = x
        offset = x - self.left
        active = next((index for index, (left, width, payload) in enumerate(self.layout or ())
                       if payload is not None and left <= offset < left + width), None)
        if active != self.active or (relaid and active is not None):
            # The programme at the playhead uses the guide's selected-cell colour.
            # self.active is the tile painted active, even if it was hidden or reassigned.
            for index in {self.active, active} - {None}:
                self.tiles[index][0].setColorDiffuse(
                    TILE_ACTIVE_COLOR if index == active else self.tile_colors[index])
            self.active = active
        if self.status_badge is not None:
            width = min(78, self.status_width) if status == "LIVE" else self.status_width
            inset = min(6, (self.left + self.width - width) // 2)
            left = max(inset, min(self.left + self.width - width - inset,
                                  x + self.marker_width // 2 - width // 2))
            if (left, width) != self.status_bounds:
                self.status_badge.setPosition(left, self.status_y + 3)
                self.status_badge.setWidth(width)
                self.status.setPosition(left, self.status_y)
                self.status.setWidth(width)
                self.status_bounds = left, width
        self.show(status)

    def hide(self):
        if self.shown:
            if self.window.getProperty(STRIP_PROPERTY) == self.owner:
                self.window.clearProperty(STRIP_PROPERTY)
            self.shown = False

    def close(self):
        self.hide()
        self.window.removeControls(self.controls)


class Overlay:
    def __init__(self, addon):
        import xbmcgui

        self.window = xbmcgui.Window(12005)
        width, height = self.window.getWidth(), self.window.getHeight()
        box_width = int(width * 0.76)
        box_height = int(height * 0.065)
        left, top = int((width - box_width) / 2), int(height * 0.16)
        background = xbmcgui.ControlImage(
            left, top, box_width, box_height,
            os.path.join(addon.getAddonInfo("path"), "resources", "timeshift-background.png")
        )
        self.label = xbmcgui.ControlLabel(
            left + 12, top, box_width - 24, box_height, "",
            font=skin_font(), textColor="FFFFFFFF", alignment=6
        )
        self.controls = [background, self.label]
        self.window.addControls(self.controls)
        for control in self.controls:
            control.setAnimations(FADE)
            control.setVisibleCondition(SHOW_CONDITION)

    def update(self, label):
        self.label.setLabel(label, shadowColor="FF000000")

    def close(self):
        self.window.removeControls(self.controls)


def run():
    import xbmc
    import xbmcaddon
    import xbmcgui

    addon = xbmcaddon.Addon("plugin.video.simplitv_t")
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    home = xbmcgui.Window(10000)
    request_text = home.getProperty(REQUEST_PROPERTY)
    if not request_text:
        return
    try:
        request = json.loads(request_text)
        url, token = request["url"], request["token"]
    except (ValueError, KeyError, TypeError) as error:
        xbmc.log("[simpliTVᵀ] Invalid overlay request: {}".format(error), xbmc.LOGERROR)
        return
    if home.getProperty(WORKER_PROPERTY) == token:
        return
    home.setProperty(WORKER_PROPERTY, token)
    overlay = strip = schedule = banner = banner_window = None
    try:
        deadline = time.monotonic() + 45
        while not monitor.abortRequested():
            if home.getProperty(REQUEST_PROPERTY) != request_text:
                return
            if player.isPlayingVideo() and player.getPlayingFile().split("|", 1)[0] == url:
                break
            if time.monotonic() >= deadline:
                raise RuntimeError("Timed out waiting for simpliTV playback")
            monitor.waitForAbort(0.1)
        else:
            return

        channel, account = request.get("channel"), request.get("account")
        overlay_enabled = addon.getSetting("timeshift_overlay") != "false"
        if request.get("remember") is True:
            remember_started_channel(addon, channel, account)
        if not overlay_enabled and request.get("banner") is not True:
            return
        warned = False
        skin = xbmc.getSkinDir()
        german = xbmc.getLanguage(xbmc.ISO_639_1) == "de"
        pause_clock = PauseClock()
        cache = None
        if isinstance(channel, str) and channel and isinstance(account, str) and account:
            from live_cache import LiveCache
            cache = LiveCache(home, account, lambda message: xbmc.log(message, xbmc.LOGWARNING))
            if overlay_enabled:
                schedule = SeekSchedule(channel, lambda code: channel_schedule(cache, code),
                                        lambda message: xbmc.log(message, xbmc.LOGWARNING), load_schedule)
        banner_pending = request.get("banner") is True
        banner_deadline = time.monotonic() + 10
        native_target = NativeSeekTarget()
        last_position = None
        while not monitor.abortRequested():
            if home.getProperty(REQUEST_PROPERTY) != request_text:
                break
            if not player.isPlayingVideo() or player.getPlayingFile().split("|", 1)[0] != url:
                break
            if overlay_enabled and addon.getSetting("timeshift_overlay") == "false":
                break
            if skin != xbmc.getSkinDir():
                break
            try:
                duration = player.getTotalTime()
                tick, wall = time.monotonic(), time.time()
                if math.isfinite(duration) and duration > 0:
                    extra_delay = pause_clock.update(
                        duration, xbmc.getCondVisibility("Player.Paused"), tick
                    )
                    edge = wall - extra_delay
                    rows = schedule.update(edge, duration, tick) if schedule is not None else []
                seek_visible = xbmc.getCondVisibility(SHOW_CONDITION)
                if banner_pending and tick >= banner_deadline:
                    banner_pending = False
                if banner_pending or banner is not None:
                    fullscreen = xbmcgui.getCurrentWindowId() == 12005
                    if banner_pending and fullscreen:
                        banner_pending = False
                        banner_window = xbmcgui.Window(12005)
                        try:
                            banner = ProgrammeBanner(banner_window, addon, xbmcgui, skin_font(), FADE)
                            station = numbered(request.get("number"), request.get("station") or channel)
                            banner.show(programme_banner(cache.cached_schedules() if cache is not None else (),
                                                         channel, station, wall, german))
                        except (RuntimeError, ValueError, OSError) as error:
                            xbmc.log("Programme banner unavailable: {}".format(type(error).__name__),
                                     xbmc.LOGWARNING)
                    if banner is not None:
                        banner.update(fullscreen and not seek_visible and
                                      not xbmc.getCondVisibility("Window.IsVisible(videoosd) | Window.IsVisible(fullscreeninfo)"))
                if (not overlay_enabled and not banner_pending
                        and (banner is None or tick >= banner.until + .3)):
                    break
                if overlay_enabled and seek_visible:
                    position = player.getTime()
                    actual = clamp(position, duration) if sane_timeline(position, duration) else None
                    pending = native_target.update(xbmc.getCondVisibility("Player.Seeking"),
                                                   lambda: xbmc.getInfoLabel("Player.SeekTime(hh:mm:ss)"),
                                                   actual, duration, tick)
                    if actual is not None:
                        last_position = actual
                    if last_position is not None and math.isfinite(duration) and duration > 0:
                        position = clamp(last_position, duration)
                        label = overlay_label(position if pending is None else pending,
                                              duration, wall, extra_delay, german)
                        if overlay is None:
                            overlay = Overlay(addon)
                        overlay.update(label)
                        if schedule is not None:
                            if strip is None:
                                station = request.get("station") or channel
                                logo = cached_strip_logo(xbmc, request.get("logo"),
                                                         addon.getAddonInfo("icon"))
                                condition = SHOW_CONDITION + " + ![Window.IsVisible(videoosd) | Window.IsVisible(fullscreeninfo)]"
                                strip = SeekStrip(overlay.window, addon, condition, logo,
                                                  station,
                                                  number=request.get("number"))
                            strip.update(rows, position, duration, edge, pending)
                        warned = False
                    elif overlay is not None:
                        overlay.update("Zeitversatz nicht verfuegbar")
                        if not monitor.abortRequested() and banner is not None:
                            banner.close(banner_window)
                        if not monitor.abortRequested() and strip is not None:
                            strip.hide()
                elif strip is not None:
                    strip.hide()
            except (RuntimeError, ValueError) as error:
                if strip is not None:
                    strip.hide()
                if not monitor.abortRequested() and overlay is not None:
                    overlay.update("Zeitversatz nicht verfuegbar")
                if not warned:
                    xbmc.log("[simpliTVᵀ] Cannot read seek position: {}".format(error),
                             xbmc.LOGWARNING)
                    warned = True
            monitor.waitForAbort(0.1)
    except (RuntimeError, OSError) as error:
        xbmc.log("[simpliTVᵀ] Timeshift overlay failed: {}".format(error), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "simpliTVᵀ", "Zeitversatz-Anzeige konnte nicht gestartet werden",
            addon.getAddonInfo("icon"), 5000
        )
    finally:
        if schedule is not None:
            schedule.close()
        if strip is not None:
            strip.close()
        if overlay is not None:
            overlay.close()
        if not monitor.abortRequested() and home.getProperty(WORKER_PROPERTY) == token:
            home.clearProperty(WORKER_PROPERTY)
        if not monitor.abortRequested() and home.getProperty(REQUEST_PROPERTY) == request_text:
            home.clearProperty(REQUEST_PROPERTY)


if __name__ == "__main__":
    run()
