"""Kodi adapters for the shared, asynchronous channel artwork cache."""

import atexit
import os
import threading
import time
from urllib.parse import urlsplit

from logo_geometry import guide_frame
from logo_pixels import MAX_BYTES


_lock = threading.Lock()
_cache = None


def fetch_logo(url, headers):
    import kodi_network
    import requests

    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.hostname or parts.username or parts.password:
        raise ValueError("Invalid channel artwork address")
    try:
        with kodi_network.request("GET", url, headers=headers, timeout=(3, 3), stream=True) as response:
            if response.status_code == 304:
                return 304, response.headers, b""
            response.raise_for_status()
            body = bytearray()
            deadline = time.monotonic() + 10
            for block in response.iter_content(64 * 1024):
                if len(body) + len(block) > MAX_BYTES or time.monotonic() >= deadline:
                    raise ValueError("Channel artwork download limit")
                body.extend(block)
            return response.status_code, response.headers, bytes(body)
    except requests.RequestException:
        raise OSError("Channel artwork download failed") from None


def local_logo_path(source):
    import xbmcvfs

    path = xbmcvfs.translatePath(source)
    if not os.path.isabs(path) or path.startswith(("\\\\", "//")):
        return None
    return path


def get_logo_cache():
    import xbmc
    import xbmcvfs
    from channel_logos import LogoCache

    global _cache
    with _lock:
        if _cache is None:
            profile = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.simplitv_t")
            _cache = LogoCache(profile, fetch_logo,
                               lambda message: xbmc.log("simpliTV: " + message, xbmc.LOGWARNING),
                               local_path=local_logo_path, guide_frame=guide_frame)
        return _cache


def close_logo_cache():
    global _cache
    with _lock:
        cache, _cache = _cache, None
    if cache is not None:
        cache.close()


atexit.register(close_logo_cache)
