"""Offline regressions for the provider's standard DRM and HLS handoff."""

import ast
import math
import os
import tempfile
import types
import urllib.parse

from guide_store import GuideStore, MAX_REWIND_SECONDS
from playback_media import WIDEVINE, select_playback
from tv_behavior import numbered

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_default(namespace, *names):
    with open(os.path.join(ROOT, "default.py"), encoding="utf-8-sig") as source:
        tree = ast.parse(source.read())
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    exec(compile(ast.Module(body=nodes, type_ignores=[]), "default.py", "exec"), namespace)


def playback(drm, current_kodi=True, metadata=None, guide=False, clear_url=None,
             helper_ready=True, number=None, cached_number=None):
    class Item:
        def __init__(self, label, path):
            self.label = label
            self.path = path
            self.properties = {}
            self.info = {}

        def setContentLookup(self, enabled):
            self.content_lookup = enabled

        def setInfo(self, _, values):
            self.info = values

        def getVideoInfoTag(self):
            return types.SimpleNamespace(
                setTitle=lambda value: self.info.update(title=value),
                setPlot=lambda value: self.info.update(plot=value))

        def setArt(self, values):
            self.art = values

        def setMimeType(self, value):
            self.mime_type = value

        def setProperty(self, key, value):
            self.properties[key] = value

    calls = []
    helper_calls = []

    def helper(protocol, drm):
        helper_calls.append((protocol, drm))
        return types.SimpleNamespace(check_inputstream=lambda: helper_ready)

    def resolved(handle, succeeded, item):
        assert handle == 1 and succeeded is True
        calls.append(("resolved", item))

    def play(item, listitem):
        calls.append(("play", item, listitem))

    namespace = dict(
        xbmcgui=types.SimpleNamespace(ListItem=Item),
        xbmc=types.SimpleNamespace(
            getInfoLabel=lambda name: "synthetic-title" if not guide and name == "ListItem.Title" else "",
            Player=lambda: types.SimpleNamespace(play=play)),
        xbmcplugin=types.SimpleNamespace(setResolvedUrl=resolved),
        launch_timeshift_overlay=lambda *args, **kwargs: calls.append(("overlay", *args, kwargs)),
        auth=types.SimpleNamespace(account="test"),
        addon=types.SimpleNamespace(getAddonInfo=lambda _: "fanart.png", getSetting=lambda _: "true"),
        addon_icon="fallback.png",
        channelname=lambda channel: channel.upper(),
        static_channel_logo=lambda *_: "fallback.png",
        cached_lineup_numbers=lambda: {"synthetic-channel": cached_number},
        numbered=numbered,
        addon_handle=1,
        KODI_un21=not current_kodi, KODI_ov20=current_kodi,
        stream_headers="synthetic-agent", license_headers="synthetic-license-headers",
        WIDEVINE=WIDEVINE, urllib=urllib, GUIDE_PLAYBACK_PROPERTY="guide",
        inputstreamhelper=types.SimpleNamespace(Helper=helper)
    )
    _load_default(namespace, "play")
    player = types.SimpleNamespace(request_id="request", play=play) if guide else None
    try:
        namespace["play"](
            "https://media.invalid/dash/stream.mpd" if drm else (clear_url or
            "https://media.invalid/hls/stream.m3u8?redirect=/dash/leave.mpd"),
            "https://license.invalid" if drm else "false",
            "synthetic-challenge", "synthetic-channel", guide_player=player, metadata=metadata,
            number=number)
    except RuntimeError as error:
        assert drm and not helper_ready
        assert str(error) == "Widevine playback prerequisites are unavailable"
        assert helper_calls == [("mpd", "widevine")] and not calls
        return None, None
    assert helper_calls == ([("mpd", "widevine")] if drm else [])
    assert not drm or helper_ready
    if guide:
        assert [call[0] for call in calls] == ["play"]
        return calls[0][2], calls[0][1]
    assert [call[0] for call in calls] == ["resolved", "play", "overlay"]
    item = calls[0][1]
    assert calls[1][2] is item
    assert item.content_lookup is False
    assert item.properties["IsPlayable"] == "true"
    assert calls[2][1:] == (calls[1][1], "synthetic-channel", "test", "fallback.png",
                            "SYNTHETIC-CHANNEL", {"number": number if number is not None else cached_number,
                                                  "remember": True})
    return item, calls[1][1]


def test_guide_playback_uses_explicit_metadata_instead_of_manifest_path():
    metadata = {"title": "Station — Programme", "plot": "Description", "logo": "station.png"}
    for current in (False, True):
        item, url = playback(True, current_kodi=current, metadata=metadata, guide=True)
        assert url.endswith("stream.mpd")
        assert item.label == item.info["title"] == "Station — Programme"
        assert item.info["plot"] == "Description"
        assert item.art == {"fanart": "fanart.png", "thumb": "station.png", "icon": "station.png"}
        assert item.properties["guide"] == "request"


def test_numbered_playback_title_does_not_change_programme_metadata():
    metadata = {"title": "Station — Programme", "plot": "Description", "logo": "station.png"}
    for current in (False, True):
        item, _ = playback(True, current_kodi=current, metadata=metadata, guide=True,
                           number=7, cached_number=99)
        assert item.label == item.info["title"] == "007  Station — Programme"
        assert metadata["title"] == "Station — Programme"
        direct, _ = playback(False, current_kodi=current, cached_number=7)
        assert direct.label == direct.info["title"] == "007  synthetic-title"


def test_empty_guide_metadata_falls_back_to_channel_not_manifest():
    item, _ = playback(True, metadata={}, guide=True)
    assert item.label == item.info["title"] == "SYNTHETIC-CHANNEL"
    assert item.art["thumb"] == "fallback.png"


def test_drm_uses_standard_player_with_provider_license_and_headers():
    item, url = playback(True)
    assert url == "https://media.invalid/dash/stream.mpd"
    assert item.mime_type == "application/dash+xml"
    assert item.properties == {
        "inputstream": "inputstream.adaptive",
        "inputstream.adaptive.manifest_headers": "User-Agent=synthetic-agent",
        "inputstream.adaptive.license_key": (
            "https://license.invalid|User-Agent=synthetic-license-headers"
            "&drmchallengecustomdata=synthetic-challenge"
            "&Content-Type=application/octet-stream|R{SSM}|"),
        "inputstream.adaptive.license_type": "com.widevine.alpha",
        "IsPlayable": "true"
    }


def test_legacy_kodi_properties_remain_supported():
    item, _ = playback(True, current_kodi=False)
    assert item.properties["inputstream"] == "inputstream.adaptive"
    assert item.properties["inputstream.adaptive.manifest_type"] == "mpd"
    assert item.properties["inputstream.adaptive.stream_headers"] == "User-Agent=synthetic-agent"
    assert "inputstream.adaptive.manifest_headers" not in item.properties


def test_clear_manifests_use_adaptive_without_license_or_url_rewriting():
    for extension, mime, manifest in (
            ("m3u8", "application/vnd.apple.mpegurl", "hls"),
            ("mpd", "application/dash+xml", "mpd")):
        url = "https://media.invalid/live.{}?token=synthetic%2Fvalue".format(extension)
        for current in (False, True):
            item, played_url = playback(False, current_kodi=current, clear_url=url,
                                        helper_ready=False)
            assert played_url == item.path == url
            assert item.mime_type == mime
            expected = {"inputstream": "inputstream.adaptive", "IsPlayable": "true"}
            if current:
                expected["inputstream.adaptive.manifest_headers"] = "User-Agent=synthetic-agent"
            else:
                expected["inputstream.adaptive.manifest_type"] = manifest
                expected["inputstream.adaptive.stream_headers"] = "User-Agent=synthetic-agent"
            assert item.properties == expected


def test_unavailable_widevine_never_dispatches_playback():
    for guide in (False, True):
        assert playback(True, guide=guide, helper_ready=False) == (None, None)


def _drm(system, suffix):
    return {"drmSystem": system, "licenseServerUrl": "https://license.invalid/" + suffix,
            "drmChallengeCustomData": suffix}


def _format(path, **metadata):
    return dict(Url="https://media.invalid" + path, **metadata)


def test_selects_returned_dash_and_named_drm_independent_of_order():
    actual = _format("/provider/explicit.MPD?signature=/hls/keep.m3u8")
    response = {"mediaFiles": [{"formats": [_format("/hls/live.m3u8"), actual]}],
                "drmInfo": [_drm("PlayReady", "pr"), _drm("Widevine", "wv")]}
    for order in (response["drmInfo"], list(reversed(response["drmInfo"]))):
        assert select_playback(dict(response, drmInfo=order)) == (
            actual["Url"], "https://license.invalid/wv", "wv")


def test_drm_stays_on_selected_media_and_format():
    response = {"MediaFiles": [
        {"Formats": [_format("/a.mpd")], "DrmInfo": [_drm("PlayReady", "unrelated")]},
        {"Formats": [_format("/b.mpd", DrmInfo=[_drm("Widevine", "chosen")])]},
    ], "DrmInfo": [_drm("Widevine", "ambiguous")]}
    assert select_playback(response) == (
        "https://media.invalid/b.mpd", "https://license.invalid/chosen", "chosen")
    response["MediaFiles"][1]["Formats"][0].pop("DrmInfo")
    try:
        select_playback(response)
    except ValueError:
        pass
    else:
        raise AssertionError("an unscoped license was used for one of multiple media files")


def test_indicated_protection_does_not_fall_through_to_clear():
    for metadata in ({"DrmInfo": None}, {"DrmInfo": [{"LicenseServerUrl": "unnamed"}]},
                     {"DrmInfo": [_drm("PlayReady", "wrong-system")]},
                     {"IsDrmProtected": True, "DrmInfo": []}):
        response = dict(MediaFiles=[{"Formats": [_format("/hls/live.m3u8")]}], **metadata)
        try:
            select_playback(response)
        except ValueError:
            continue
        raise AssertionError("protected response was accepted as clear HLS")


def test_format_scoped_license_does_not_apply_to_a_sibling_manifest():
    formats = [_format("/first.m3u8"), _format("/second.mpd",
               DrmInfo=[_drm("Widevine", "second-only")])]
    response = {"MediaFiles": [{"Formats": formats}]}
    assert select_playback(response)[0] == formats[1]["Url"]
    formats[1]["DrmInfo"] = [_drm("PlayReady", "unsupported")]
    try:
        select_playback(response)
    except ValueError:
        pass
    else:
        raise AssertionError("an unlabeled sibling format was treated as clear")
    formats[0]["IsDrmProtected"] = False
    assert select_playback(response) == (formats[0]["Url"], "false", "false")


def test_rewind_reuses_existing_widevine_partition():
    with tempfile.TemporaryDirectory() as profile:
        store = GuideStore(profile, "api", "tenant", "user", lambda _: None)
        store.write_rewind("channel", False, "DASH/Widevine", 3600)
        store.write_rewind("channel", True, "DASH/PlayReady", 7200)
        namespace = dict(guide_store=store, math=math, urllib=urllib, MAX_REWIND_SECONDS=MAX_REWIND_SECONDS)
        _load_default(namespace, "rewind_observation", "remember_rewind")
        assert namespace["rewind_observation"]("channel")["seconds"] == 3600
        namespace["remember_rewind"]("channel", ("stream", "license", ""), 5400)
        assert store.read_rewind("channel", False)["seconds"] == 5400
        assert store.read_rewind("channel", True)["seconds"] == 7200
        for url, expected in (("https://media.invalid/live.mpd?token=x", "DASH/Clear"),
                              ("https://media.invalid/live.m3u8?token=x", "HLS/Clear")):
            namespace["remember_rewind"]("clear", (url, "false", "false"), 3600)
            assert store.read_rewind("clear", False)["format"] == expected
            namespace["remember_rewind"]("clear", (url, "false", "false"), float("nan"))
            assert store.read_rewind("clear", False)["seconds"] == 3600


def test_keeps_legacy_cdn_paths_only_when_needed():
    hls = _format("/hls4h/live.m3u8?token=/hls/unchanged.m3u8")
    dash = _format("/dash_nodrm/live.mpd?token=.mpd")
    assert select_playback({"MediaFiles": [{"Formats": [hls]}],
                            "DrmInfo": [_drm("Widevine", "wv")]})[0] == (
        "https://media.invalid/dash4h/live.mpd?token=/hls/unchanged.m3u8")
    assert select_playback({"MediaFiles": [{"Formats": [dash]}]}) == (dash["Url"], "false", "false")
    assert select_playback({"MediaFiles": [{"Formats": [dash, hls]}]})[0] == dash["Url"]
    assert select_playback({"MediaFiles": [{"Formats": [hls]}]})[0] == hls["Url"]


def load_tests(loader, tests, pattern):
    import unittest

    return unittest.TestSuite(
        unittest.FunctionTestCase(value)
        for name, value in sorted(globals().items()) if name.startswith("test_")
    )


if __name__ == "__main__":
    for name, test in sorted(list(globals().items())):
        if name.startswith("test_"):
            test()
            print("PASS:", name)
