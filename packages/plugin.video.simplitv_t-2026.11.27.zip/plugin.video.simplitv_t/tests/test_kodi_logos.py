import os
import sys
import types
import unittest
from unittest import mock

import requests

import kodi_logos


class KodiLogoAdapterTests(unittest.TestCase):
    def response(self, status=200, blocks=(b"png",)):
        response = mock.MagicMock()
        response.__enter__.return_value = response
        response.status_code = status
        response.headers = {"ETag": '"version"'}
        response.iter_content.return_value = iter(blocks)
        return response

    def test_logo_fetch_always_uses_kodi_transport_and_conditional_headers(self):
        response = self.response()
        with mock.patch("kodi_network.request", return_value=response) as request:
            result = kodi_logos.fetch_logo("https://images.invalid/logo.png", {"If-None-Match": '"old"'})
        self.assertEqual(result, (200, {"ETag": '"version"'}, b"png"))
        request.assert_called_once_with("GET", "https://images.invalid/logo.png",
                                       headers={"If-None-Match": '"old"'},
                                       timeout=(3, 3), stream=True)
        response.raise_for_status.assert_called_once()

    def test_unchanged_response_does_not_read_body(self):
        response = self.response(304)
        with mock.patch("kodi_network.request", return_value=response):
            self.assertEqual(kodi_logos.fetch_logo("https://images.invalid/logo.png", {})[::2],
                             (304, b""))
        response.iter_content.assert_not_called()

    def test_invalid_addresses_and_oversized_downloads_fail_explicitly(self):
        with mock.patch("kodi_network.request") as request:
            for url in ("file:///private", "ftp://server/image", "https://user:secret@images.invalid/a"):
                with self.subTest(url=url), self.assertRaises(ValueError):
                    kodi_logos.fetch_logo(url, {})
        request.assert_not_called()
        with mock.patch("kodi_network.request", return_value=self.response(blocks=(b"1234",))), \
                mock.patch.object(kodi_logos, "MAX_BYTES", 3):
            with self.assertRaisesRegex(ValueError, "download limit"):
                kodi_logos.fetch_logo("https://images.invalid/a", {})

    def test_transport_failure_has_no_url_credentials_or_direct_retry(self):
        from kodi_network import KodiProxyError

        for error in (KodiProxyError("secret proxy credentials"),
                      requests.ConnectionError("https://private.invalid/?token=secret")):
            with mock.patch("kodi_network.request", side_effect=error) as request:
                with self.assertRaises(OSError) as caught:
                    kodi_logos.fetch_logo("https://images.invalid/a", {})
                self.assertEqual(str(caught.exception), "Channel artwork download failed")
                request.assert_called_once()

    def test_local_adapter_rejects_remote_and_unc_paths(self):
        local = os.path.abspath("example.png")
        with mock.patch.dict(sys.modules, {"xbmcvfs": types.SimpleNamespace(translatePath=lambda p: p)}):
            self.assertEqual(kodi_logos.local_logo_path(local), local)
            self.assertIsNone(kodi_logos.local_logo_path(r"\\server\private.png"))
            self.assertIsNone(kodi_logos.local_logo_path("https://images.invalid/a"))
