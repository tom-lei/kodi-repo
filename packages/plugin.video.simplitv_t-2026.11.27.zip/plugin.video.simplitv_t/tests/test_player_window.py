import datetime
import gc
import os
import sys
import types
import unittest
import weakref
import xml.etree.ElementTree as ET
from unittest.mock import Mock, patch

import crt_noise
import player_window
from live_cache import LiveDataError
from provider_errors import ProviderFailure


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class GoLiveTests(unittest.TestCase):
    def test_short_landing_gets_one_retry_then_warning(self):
        attempt = player_window.GoLiveAttempt(0)
        self.assertIsNone(attempt.review(999, 1000, 2, False))
        self.assertIsNone(attempt.review(976, 1000, 6, True))
        self.assertEqual(attempt.review(976, 1002, 6.5, False), "retry")
        self.assertIsNone(attempt.review(1001, 1002, 7, False))
        self.assertEqual(attempt.review(990, 1002, 12.5, False), "warn")

    def test_reached_edge_finishes_without_warning_on_either_attempt(self):
        first = player_window.GoLiveAttempt(0)
        self.assertEqual(first.review(994, 1000, 6, False), "reached")
        second = player_window.GoLiveAttempt(0)
        self.assertEqual(second.review(978, 1000, 6, False), "retry")
        self.assertEqual(second.review(997, 1005, 12, False), "reached")

    def test_unsettled_or_invalid_readback_cannot_cause_warning(self):
        first = player_window.GoLiveAttempt(0)
        self.assertEqual(first.review(978, 1000, 7, True), "cancel")
        second = player_window.GoLiveAttempt(0)
        self.assertEqual(second.review(978, 1000, 6, False), "retry")
        self.assertEqual(second.review(0, 0, 13, False), "cancel")


class SeekStatusTests(unittest.TestCase):
    def test_live_delay_follows_pending_marker_and_uses_live_threshold(self):
        status = player_window.seek_status
        wall = datetime.datetime(2025, 1, 15, 21, 50).timestamp()
        self.assertEqual(status(340, 600, 450, True, wall), "21:47 · −2:30")
        self.assertEqual(status(450, 600, 600, True, wall), "LIVE")
        self.assertEqual(status(588, 600, None, True, wall), "21:49 · −0:12")
        self.assertEqual(status(589, 600, None, True, wall), "LIVE")
        self.assertEqual(status(30, 600, 90, False, wall), "00:01:30 / 00:10:00")

    def test_frozen_duration_counts_paused_time_in_delay(self):
        clock = player_window.PauseClock()
        clock.update(600, True, 0)
        extra = clock.update(600, True, 20)
        wall = datetime.datetime(2025, 1, 15, 21, 50, 20).timestamp()
        self.assertEqual(player_window.seek_status(598, 600, None, True, wall, extra),
                         "21:49 · −0:22")
        self.assertEqual(player_window.seek_status(598, 600, 570, True, wall, extra),
                         "21:49 · −0:50")


class ZapTests(unittest.TestCase):
    def setUp(self):
        self.allowed = ["one", "two", "three"]
        self.events = []

        def start(channel, dispatched):
            try:
                self.events.append(("acquire", channel))
                yield
                dispatched()
                self.events.append(("dispatch", channel))
                yield
                return {"channel": channel}
            finally:
                self.events.append(("closed", channel))

        self.controller = player_window.ZapController(
            {"channel": "one"}, lambda: list(self.allowed), start,
            lambda *args: self.events.append(("notify", args[0])))

    def test_zap_starts_on_next_update_and_can_supersede_undispatched_work(self):
        self.controller.request(1)
        self.controller.tick()
        self.assertEqual(self.events, [("acquire", "two")])
        self.controller.request(1)
        self.controller.tick()
        self.assertIn(("closed", "two"), self.events)
        self.assertIn(("acquire", "three"), self.events)
        self.controller.tick()
        self.assertNotIn(("dispatch", "two"), self.events)
        self.assertIn(("dispatch", "three"), self.events)
        self.controller.tick()
        self.assertEqual(self.controller.playback["channel"], "three")

    def test_actions_during_dispatched_start_are_queued_until_owned(self):
        self.controller.request(1)
        self.controller.tick()
        self.controller.tick()
        self.controller.request(1)
        self.assertTrue(self.controller.dispatched)
        self.assertTrue(self.controller.tick())
        self.assertEqual(self.controller.playback["channel"], "two")
        self.controller.tick()
        self.controller.tick()
        self.assertIn(("dispatch", "three"), self.events)
        self.controller.tick()
        self.assertEqual(self.controller.playback["channel"], "three")

    def test_input_while_acquisition_generator_is_executing_keeps_latest_intent(self):
        original_start = self.controller.start

        def start(channel, dispatched):
            if channel == "two":
                self.assertTrue(self.controller.request(1))
                yield
                self.fail("Superseded channel must not dispatch")
            return (yield from original_start(channel, dispatched))

        self.controller.start = start
        self.controller.request(1)
        self.controller.tick()
        self.controller.tick()
        self.controller.tick()
        self.controller.tick()
        self.assertEqual(self.controller.playback["channel"], "three")

    def test_expired_rights_and_boundaries_do_not_start_a_tune(self):
        self.controller.request(-1)
        self.assertEqual(self.events, [])
        self.controller.request(1)
        self.allowed.remove("two")
        self.controller.tick()
        self.assertEqual(self.events, [("notify", "unavailable")])
        self.assertEqual(self.controller.playback["channel"], "one")

    def test_cancellation_closes_worker_before_dispatch(self):
        self.controller.request(1)
        self.controller.tick()
        self.controller.cancel()
        self.assertIn(("closed", "two"), self.events)
        self.assertNotIn(("dispatch", "two"), self.events)
        self.assertIsNone(self.controller.handoff)

    def test_returning_to_current_channel_cancels_undispatched_tune(self):
        self.controller.request(1)
        self.controller.tick()
        self.controller.request(-1)
        self.controller.tick()
        self.assertIn(("closed", "two"), self.events)
        self.assertNotIn(("acquire", "one"), self.events)
        self.assertIsNone(self.controller.desired)


class PlayerWindowTests(unittest.TestCase):
    def test_stop_and_stock_fullscreen_escape_do_not_stop_or_close_other_windows(self):
        for action in ("stop", "native-stop", "replaced", "fullscreen", "provider-failure"):
            with self.subTest(action=action):
                state = {"active": 10025, "instance": None, "steps": 0, "calls": [],
                         "playing": True, "notifications": []}

                class Control:
                    def __init__(self, *args, **kwargs):
                        pass
                    def setVisible(self, visible):
                        pass
                    def setLabel(self, value, **kwargs):
                        pass
                    def setWidth(self, value):
                        pass
                    def setAnimations(self, value):
                        pass
                    def setVisibleCondition(self, value):
                        pass

                class Window:
                    def __init__(self, *args):
                        state["instance"] = self
                    def show(self):
                        state["active"] = 13000
                    def close(self):
                        state["calls"].append("close")
                        state["active"] = 10025
                    def addControls(self, controls):
                        pass
                    def getWidth(self):
                        return 1920
                    def getHeight(self):
                        return 1080

                player = types.SimpleNamespace(
                    isPlayingVideo=lambda: state["playing"],
                    isPlaying=lambda: action == "replaced",
                    getTime=lambda: 120.0,
                    getTotalTime=lambda: 600.0,
                    stop=lambda: state["calls"].append("stop"))
                playback = {"channel": "one", "player": player, "matches": lambda: state["playing"],
                            "live": True, "metadata": {"title": "Station"}}

                def sleep(_):
                    state["steps"] += 1
                    if state["steps"] == 1:
                        state["instance"].onInit()
                    elif action == "stop":
                        state["instance"].onAction(types.SimpleNamespace(getId=lambda: 13))
                    elif action in ("native-stop", "replaced"):
                        # Playback ends before any queued Python onAction arrives.
                        state["playing"] = False
                    elif action == "provider-failure":
                        state["instance"].notify(
                            "failed", LiveDataError("", provider=ProviderFailure(403, 9602)))
                        self.assertTrue(state["playing"])
                        state["playing"] = False
                    else:
                        state["active"] = 12005

                xbmc = types.SimpleNamespace(
                    Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                                          waitForAbort=lambda s: sleep(s * 1000)),
                    getLanguage=lambda *_: "de" if action == "provider-failure" else "en",
                    ISO_639_1=0, sleep=sleep,
                    getCondVisibility=lambda _: False)
                xbmcgui = types.SimpleNamespace(
                    WindowXML=Window, ControlImage=Control, ControlLabel=Control,
                    getCurrentWindowId=lambda: state["active"],
                    Dialog=lambda: types.SimpleNamespace(
                        notification=lambda *args: state["notifications"].append(args[1])))
                addon = types.SimpleNamespace(getAddonInfo=lambda _: ROOT, getSetting=lambda _: "true")
                with patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": xbmcgui}), \
                        patch.object(player_window, "skin_font", return_value="font13"):
                    reason, _ = player_window.open_player_window(
                        playback, lambda: ["one"], lambda *_: self.fail("unexpected tune"),
                        addon, lambda _: None)
                expected = {"stop": "stopped", "native-stop": "stopped",
                            "replaced": "closed", "fullscreen": "fullscreen",
                            "provider-failure": "stopped"}[action]
                self.assertEqual(reason, expected)
                self.assertEqual(state["calls"], [] if action == "fullscreen" else ["close"])
                if action == "provider-failure":
                    self.assertTrue(state["notifications"][0].startswith(
                        "simpliTV Fehler 9602 (HTTP 403)"))
                    self.assertIn("VPN", state["notifications"][0])

    def test_zap_overlay_static_setting_and_external_replacement(self):
        for static, replace, back_during, fullscreen in (
                (True, False, False, False), (False, False, False, False),
                (True, True, False, False), (True, False, True, False),
                (True, False, False, True)):
            with self.subTest(static=static, replace=replace, back_during=back_during,
                              fullscreen=fullscreen):
                state = {"active": 10025, "instance": None, "clock": 0.0,
                         "steps": 0, "playing": True, "events": [], "frames": set()}

                class Control:
                    def __init__(self, *args, **kwargs):
                        self.content = args[4]
                        self.visible = True
                    def setVisible(self, visible):
                        self.visible = visible
                    def setLabel(self, value, **kwargs):
                        self.content = value
                    def setImage(self, value):
                        self.content = value
                    def setWidth(self, value):
                        pass
                    def setAnimations(self, value):
                        pass
                    def setVisibleCondition(self, value):
                        pass

                class Window:
                    def __init__(self, *args):
                        state["instance"] = self
                        self.added = []
                    def show(self):
                        state["active"] = 13000
                    def close(self):
                        state["active"] = 10025
                    def addControls(self, controls):
                        self.added.extend(controls)
                    def removeControls(self, controls):
                        for control in controls:
                            self.added.remove(control)
                    def getWidth(self):
                        return 1920
                    def getHeight(self):
                        return 1080

                player = types.SimpleNamespace(isPlayingVideo=lambda: state["playing"],
                                               isPlaying=lambda: replace,
                                               getTime=lambda: 120.0, getTotalTime=lambda: 600.0)
                playback = {"channel": "one", "player": player, "matches": lambda: state["playing"],
                            "live": True, "metadata": {"title": "One"}}

                def start(channel, dispatched):
                    try:
                        state["events"].append("acquire")
                        yield
                        dispatched()
                        state["events"].append("dispatch")
                        yield
                        return dict(playback, channel=channel, metadata={"title": "Two"})
                    finally:
                        state["events"].append("close")

                def sleep(_):
                    state["clock"] += 0.06
                    state["steps"] += 1
                    self.assertLess(state["steps"], 40)
                    window = state["instance"]
                    if state["steps"] == 1:
                        window.onInit()
                        self.assertFalse(hasattr(window, "seek_label"))
                        self.assertFalse(hasattr(window, "seek_background"))
                        window.onAction(types.SimpleNamespace(getId=lambda: 1))
                    elif state["steps"] == 2:
                        self.assertIsNotNone(window.gesture.target)
                        self.assertIsNotNone(window.strip)
                        window.onAction(types.SimpleNamespace(getId=lambda: 5))
                        self.assertIsNone(window.gesture.target)
                        self.assertIsNone(window.strip)
                        strip.close.assert_called_once()
                        self.assertEqual(window.startup_logo.content,
                                         player_window.guide_logo_texture("local-logo", 448, 208))
                        self.assertEqual(window.startup_frames is not None, static)
                        if not static:
                            self.assertIn("guide-solid.png", window.startup_controls[0].content)
                    if window.startup_frames is not None:
                        fields, signals = window.startup_frames
                        self.assertEqual(sum(f.visible for f in fields), 1)
                        self.assertEqual(sum(f.visible for f in signals), 1)
                        state["frames"].add(window.startup_frame)
                    if replace and "acquire" in state["events"]:
                        state["playing"] = False
                    elif back_during and "dispatch" in state["events"] and not window.back_pending:
                        window.onAction(types.SimpleNamespace(getId=lambda: 92))
                        self.assertTrue(window.back_pending)
                    elif window.controller.playback["channel"] == "two":
                        if fullscreen:
                            state["active"] = 12005
                        else:
                            window.onAction(types.SimpleNamespace(getId=lambda: 92))

                xbmc = types.SimpleNamespace(
                    Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                                          waitForAbort=lambda s: sleep(s * 1000)),
                    getLanguage=lambda *_: "en", ISO_639_1=0, sleep=sleep,
                    getCondVisibility=lambda condition: condition == "Player.SeekEnabled")
                xbmcgui = types.SimpleNamespace(
                    WindowXML=Window, ControlImage=Control, ControlLabel=Control,
                    getCurrentWindowId=lambda: state["active"],
                    Dialog=lambda: types.SimpleNamespace(notification=lambda *args: None))
                addon = types.SimpleNamespace(
                    getAddonInfo=lambda _: ROOT,
                    getSetting=lambda key: ("true" if static else "false") if key == "tv_static" else "true")
                strip = Mock()
                with patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": xbmcgui}), \
                        patch.object(player_window, "skin_font", return_value="font13"), \
                        patch.object(player_window, "SeekStrip", new=lambda *_, **_kw: strip), \
                        patch.object(player_window, "local_startup_logo", return_value="local-logo"), \
                        patch.object(player_window.time, "monotonic", side_effect=lambda: state["clock"]), \
                        patch.object(crt_noise, "cached_textures",
                                     return_value=(("snow-0", "snow-1"), ("signal-0", "signal-1"))) as cached:
                    reason, result = player_window.open_player_window(
                        playback, lambda: ["one", "two"], start, addon, lambda _: None,
                        lambda _: {"title": "Two", "logo": "remote"},
                        lambda: crt_noise.startup_textures(addon, "profile"), lambda _: [])
                self.assertEqual(reason, "closed" if replace else "fullscreen" if fullscreen else "guide")
                self.assertEqual(result["channel"], "one" if replace else "two")
                self.assertEqual("dispatch" in state["events"], not replace)
                self.assertEqual(bool(cached.call_count), static)
                self.assertFalse(state["instance"].startup_controls)
                if static:
                    self.assertEqual(state["frames"], {0} if replace else {0, 1})
                if fullscreen:
                    reference = weakref.ref(state["instance"])
                    gc_enabled = gc.isenabled()
                    gc.disable()
                    try:
                        state["instance"] = None
                        self.assertIsNone(reference())
                    finally:
                        if gc_enabled:
                            gc.enable()

    def test_channel_keys_number_entry_and_step_keys_follow_pvr_conventions(self):
        state = {"active": 10025, "instance": None, "steps": 0, "time": 0.0}
        banners, tunes, seeks, refreshes, alerts = [], [], [], [], []

        def refresh_channels():
            refreshes.append(state["time"])
            return ([], "loading") if len(refreshes) == 1 else ([], "error")

        class Control:
            def __init__(self, *args, **kwargs):
                pass

            def __getattr__(self, name):
                return lambda *args, **kwargs: None

        class Window:
            def __init__(self, *args):
                state["instance"] = self

            def show(self):
                state["active"] = 13000

            def close(self):
                state["active"] = 10025

            def getWidth(self):
                return 1920

            def getHeight(self):
                return 1080

            def __getattr__(self, name):
                return lambda *args, **kwargs: None

        player = types.SimpleNamespace(
            isPlayingVideo=lambda: True, getTime=lambda: 120.0, getTotalTime=lambda: 600.0,
            seekTime=lambda pos: None, pause=lambda: None, stop=lambda: None)
        playback = {"channel": "one", "player": player, "matches": lambda: True,
                    "live": True, "metadata": {"title": "Station"}}

        def press(action):
            state["instance"].onAction(types.SimpleNamespace(getId=lambda: action,
                                                             getButtonCode=lambda: 0))

        def sleep(_):
            window = state["instance"]
            state["steps"] += 1
            state["time"] += 0.1
            if state["steps"] == 1:
                window.onInit()
                window.show_banner = lambda message=None: banners.append(message)
                window.show_startup = lambda: None
                window.reset_seek = lambda **_: None
                window.seek = lambda direction, long=False, seconds=None: seeks.append(
                    (direction, seconds))
                window.controller.request = lambda delta: tunes.append(delta) or False
                window.controller.request_channel = lambda ch: tunes.append(ch) or True
                for action in (184, 185, 20, 21, 22, 23):
                    press(action)
                press(58 + 5)
                press(7)  # OK confirms pending digits instead of opening the OSD.
                press(58 + 2)  # This number belongs to a hidden channel.
                press(7)
                press(58)  # Zero is consumed rather than opening the OSD.
                press(7)
                press(58 + 1)
                press(58 + 2)
            elif state["steps"] == 5:
                self.assertEqual(tunes, [1, -1, "three"])
            elif state["steps"] == 25:
                press(58 + 9)
            elif state["steps"] == 45:
                press(92)

        xbmc = types.SimpleNamespace(
            Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                                  waitForAbort=lambda s: sleep(s * 1000)),
            getLanguage=lambda *_: "en", ISO_639_1=0, sleep=sleep,
            executebuiltin=lambda command: self.fail(command),
            getCondVisibility=lambda condition: condition == "Player.SeekEnabled")
        xbmcgui = types.SimpleNamespace(
            WindowXML=Window, ControlImage=Control, ControlLabel=Control,
            getCurrentWindowId=lambda: state["active"],
            Dialog=lambda: types.SimpleNamespace(notification=lambda *args: alerts.append(args[1])))
        addon = types.SimpleNamespace(getAddonInfo=lambda _: ROOT, getSetting=lambda _: "true")

        with patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": xbmcgui}), \
                patch("timeshift_overlay.skin_font", return_value="font13"), \
                patch.object(player_window, "time", types.SimpleNamespace(
                    monotonic=lambda: state["time"], time=lambda: 10000)), \
                patch.object(player_window, "skin_font", return_value="font13"):
            player_window.open_player_window(
                playback, lambda: ["one", "two", "three"], lambda *_: self.fail("tune"), addon,
                lambda _: None, cached_events=lambda: [],
                channel_numbers={"one": 1, "hidden": 2, "two": 3, "three": 5},
                refresh_channels=refresh_channels)
        self.assertEqual(seeks, [(1, None), (-1, None), (0, 600), (0, -600)])
        self.assertEqual(len(refreshes), 2)
        self.assertEqual(alerts, [player_window.ACCESS_TEXT[0]["error"]])
        # "12" times out into channel 12, out of range: the banner explains nothing changed;
        # "9" is also out of range.
        self.assertEqual(tunes, [1, -1, "three"])
        self.assertEqual(banners, [
            "5_  →  005 three", "2_  →  002 hidden (hidden)", None,
            "0_  →  000 not assigned", None,
            "1_  →  001 one", "12_  →  012 not assigned", None,
            "9_  →  009 not assigned", None,
        ])

    def test_settings_shortcut_keeps_playback_for_ok_and_timeout(self):
        for confirm in (True, False):
            with self.subTest(confirm=confirm):
                state = {"active": 10025, "instance": None, "steps": 0, "time": 0.0}
                banners, calls = [], []

                class Window:
                    def __init__(self, *args):
                        state["instance"] = self
                    def show(self):
                        state["active"] = 13000
                    def close(self):
                        state["active"] = 10025
                    def getWidth(self):
                        return 1920
                    def getHeight(self):
                        return 1080
                    def __getattr__(self, _):
                        return lambda *args, **kwargs: None

                player = types.SimpleNamespace(
                    isPlayingVideo=lambda: True, isPlaying=lambda: True,
                    getTime=lambda: 120.0, getTotalTime=lambda: 600.0,
                    stop=lambda: calls.append("stop"))
                playback = {"channel": "one", "player": player, "matches": lambda: True,
                            "live": True, "metadata": {"title": "Station"}}

                def settings():
                    self.assertTrue(player.isPlayingVideo())
                    calls.append("settings")

                def sleep(_):
                    state["steps"] += 1
                    window = state["instance"]
                    if state["steps"] == 1:
                        window.onInit()
                        window.show_banner = lambda message=None: banners.append(message)
                        for _ in range(3):
                            window.onAction(types.SimpleNamespace(getId=lambda: 58))
                        if confirm:
                            window.onAction(types.SimpleNamespace(getId=lambda: 7))
                    else:
                        state["time"] += 2
                    self.assertLess(state["steps"], 5)

                class Control:
                    def __init__(self, *args, **kwargs):
                        pass
                    def __getattr__(self, _):
                        return lambda *args, **kwargs: None

                xbmc = types.SimpleNamespace(
                    Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                                          waitForAbort=sleep),
                    getLanguage=lambda *_: "en", ISO_639_1=0,
                    getCondVisibility=lambda _: False)
                gui = types.SimpleNamespace(WindowXML=Window, ControlImage=Control,
                                            ControlLabel=Control,
                                            getCurrentWindowId=lambda: state["active"])
                addon = types.SimpleNamespace(getAddonInfo=lambda _: ROOT, getSetting=lambda _: "true")
                with patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": gui}), \
                        patch.object(player_window, "time", types.SimpleNamespace(
                            monotonic=lambda: state["time"], time=lambda: 10000)), \
                        patch.object(player_window, "skin_font", return_value="font13"):
                    reason, current = player_window.open_player_window(
                        playback, lambda: ["one"], lambda *_: self.fail("unexpected tune"),
                        addon, lambda _: None, open_settings=settings)
                self.assertIn("000_  →  Settings", banners)
                self.assertEqual((reason, current, calls), ("settings_changed", playback, ["settings"]))

    def test_video_surface_and_back_seek_do_not_touch_playlist_or_double_pause(self):
        xml = ET.parse(os.path.join(ROOT, "resources", "skins", "Default", "1080i",
                                    "simplitv-player.xml"))
        video = xml.find(".//control[@type='videowindow']")
        self.assertIsNotNone(video)
        self.assertEqual((video.findtext("width"), video.findtext("height")), ("1920", "1080"))
        state = {"active": 10025, "instance": None, "steps": 0, "time": 0.0}
        calls = []

        class Control:
            def __init__(self, *args, **kwargs):
                pass

            def setWidth(self, value):
                pass

            def setAnimations(self, value):
                pass

            def setVisibleCondition(self, value):
                pass

            def setVisible(self, visible):
                pass

            def setLabel(self, value, **kwargs):
                pass

        class Window:
            properties = {}

            def setProperty(self, key, value):
                self.properties[key] = value

            def getProperty(self, key):
                return self.properties.get(key)

            def clearProperty(self, key):
                self.properties.pop(key, None)

            def removeControls(self, controls):
                pass

            def __init__(self, *args):
                state["instance"] = self

            def show(self):
                state["active"] = 13000

            def close(self):
                state["active"] = 10025

            def addControls(self, controls):
                pass

            def getWidth(self):
                return 1920

            def getHeight(self):
                return 1080

        player = types.SimpleNamespace(
            isPlayingVideo=lambda: True, getTime=lambda: 120.0,
            getTotalTime=lambda: 600.0, seekTime=lambda pos: calls.append(("seek", pos)),
            pause=lambda: calls.append("pause"), stop=lambda: calls.append("stop"))
        playback = {"channel": "one", "player": player, "matches": lambda: True,
                    "live": True, "metadata": {"title": "Station"}}

        def sleep(_):
            window = state["instance"]
            state["steps"] += 1
            state["time"] += 0.1
            if state["steps"] == 1:
                window.onInit()
            elif state["steps"] == 2:
                window.onAction(types.SimpleNamespace(getId=lambda: 1))
                window.onAction(types.SimpleNamespace(getId=lambda: 12))  # Kodi handles pause.
            elif state["steps"] == 10:
                window.onAction(types.SimpleNamespace(getId=lambda: 92))

        xbmc = types.SimpleNamespace(
            Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                                  waitForAbort=lambda s: sleep(s * 1000)),
            getLanguage=lambda *_: "en", ISO_639_1=0, sleep=sleep,
            getCondVisibility=lambda condition: condition == "Player.SeekEnabled")
        xbmcgui = types.SimpleNamespace(
            WindowXML=Window, ControlImage=Control, ControlLabel=Control,
            getCurrentWindowId=lambda: state["active"],
            Dialog=lambda: types.SimpleNamespace(notification=lambda *args: calls.append("notification")))
        addon = types.SimpleNamespace(getAddonInfo=lambda _: ROOT, getSetting=lambda _: "true")
        with patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": xbmcgui}), \
                patch("timeshift_overlay.skin_font", return_value="font13"), \
                patch.object(player_window, "time", types.SimpleNamespace(
                    monotonic=lambda: state["time"], time=lambda: 10000)), \
                patch.object(player_window, "skin_font", return_value="font13"):
            result = player_window.open_player_window(
                playback, lambda: ["one"], lambda *_: self.fail("unexpected tune"), addon, lambda _: None)
        self.assertEqual(result, ("guide", playback))
        self.assertEqual(calls, [("seek", 90.0)])
        self.assertEqual(state["active"], 10025)

    def test_ok_opens_video_controls_and_banner_describes_timeshifted_programme(self):
        state = {"active": 10025, "instance": None, "steps": 0, "time": 0.0}
        builtins, banners = [], []

        class Control:
            def __init__(self, *args, **kwargs):
                self.visible = False
                self.animations, self.condition = [], ""

            def setVisible(self, visible):
                self.visible = visible

            def setAnimations(self, animations):
                self.animations = animations

            def setVisibleCondition(self, condition):
                self.condition = condition

            def __getattr__(self, name):
                return lambda *args, **kwargs: None

        class Window:
            properties = {}

            def __init__(self, *args):
                state["instance"] = self

            def setProperty(self, key, value):
                self.properties[key] = value

            def getProperty(self, key):
                return self.properties.get(key)

            def clearProperty(self, key):
                self.properties.pop(key, None)

            def show(self):
                state["active"] = 13000

            def close(self):
                state["active"] = 10025

            def addControls(self, controls):
                pass

            def removeControls(self, controls):
                pass

            def getWidth(self):
                return 1920

            def getHeight(self):
                return 1080

        player = types.SimpleNamespace(
            isPlayingVideo=lambda: True, getTime=lambda: 120.0, getTotalTime=lambda: 600.0,
            seekTime=lambda pos: None, pause=lambda: None, stop=lambda: None)
        playback = {"channel": "one", "player": player, "matches": lambda: True,
                    "live": True, "metadata": {"title": "Station"}}

        def sleep(_):
            window = state["instance"]
            state["steps"] += 1
            state["time"] += 0.1
            if state["steps"] == 1:
                window.onInit()
            elif state["steps"] == 5:
                for action in (7, 24):  # Global and FullscreenVideo keymaps.
                    window.programme_info.update(True)  # Ends any previous OSD linger.
                    window.programme_info.until = 0
                    window.programme_info.update(True)
                    self.assertFalse(window.programme_info.background.visible)
                    window.onAction(types.SimpleNamespace(getId=lambda: action))
                window.onAction(types.SimpleNamespace(getId=lambda: 11))
            elif state["steps"] == 10:
                window.onAction(types.SimpleNamespace(getId=lambda: 92))

        def execute(command):
            controls = state["instance"].programme_info.controls
            builtins.append((command, [control.visible for control in controls], controls))

        xbmc = types.SimpleNamespace(
            Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                                  waitForAbort=lambda s: sleep(s * 1000)),
            getLanguage=lambda *_: "en", ISO_639_1=0, sleep=sleep,
            executebuiltin=execute,
            getCondVisibility=lambda condition: condition == "Player.SeekEnabled")
        xbmcgui = types.SimpleNamespace(
            WindowXML=Window, ControlImage=Control, ControlLabel=Control,
            getCurrentWindowId=lambda: state["active"],
            Dialog=lambda: types.SimpleNamespace(notification=lambda *args: None))
        addon = types.SimpleNamespace(getAddonInfo=lambda _: ROOT, getSetting=lambda _: "true")

        def banner(events, channel, station, watched, german):
            banners.append(watched)
            return (station, "", "", 0)

        with patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": xbmcgui}), \
                patch("timeshift_overlay.skin_font", return_value="font13"), \
                patch.object(player_window, "time", types.SimpleNamespace(
                    monotonic=lambda: state["time"], time=lambda: 10000)), \
                patch.object(player_window, "programme_banner", side_effect=banner), \
                patch.object(player_window, "skin_font", return_value="font13"):
            player_window.open_player_window(
                playback, lambda: ["one"], lambda *_: self.fail("unexpected tune"), addon,
                lambda _: None, cached_events=lambda: [])
        self.assertEqual(len(builtins), 2)
        for command, visible, controls in builtins:
            self.assertEqual(command, "ActivateWindow(videoosd)")
            # The banner opens with the stock controls, lifted clear of them by Kodi itself.
            self.assertTrue(visible[0] and visible[1], "Banner must accompany VideoOSD")
            for control in controls:
                self.assertNotIn("videoosd", control.condition)
                lift = dict(control.animations)["Conditional"]
                self.assertIn("condition=Window.IsVisible(videoosd)", lift)
                self.assertLessEqual(int(lift.split("end=0,")[1].split()[0]), -180)
        # 480 s behind the live edge: the banner looks up the programme on screen.
        self.assertTrue(banners and banners[-1] <= 10000 - 480, banners)

    def test_boundary_menu_actions_chain_across_pending_seek(self):
        cases = (
            (2, 8500, ("menu", "menu", "settle", "settle"), [8000, 6000]),
            (3, 8500, ("menu", "menu", "settle", "settle"), [10000, 12000]),
            (3, 9998, ("menu", "menu", "settle", "settle"), [10000, 12000]),
            (3, 8500, ("menu", "settle-early", "menu", "settle"), [10000, 12000]),
            (3, 10040, ("left", "tick", "left", "menu", "settle", "settle"), [10010, 10000]),
            (3, 10040, ("left", "tick", "left", "long-right", "settle", "settle"), [10010, 10000]),
        )
        for choice, initial, commands, expected in cases:
            with self.subTest(choice=choice, initial=initial, commands=commands):
                state = {"active": 10025, "window": None, "step": -1,
                         "time": 0.0, "position": initial, "seeks": []}
                edge, duration = 1700000000.0, 14400.0
                oldest = edge - duration
                rows = [(oldest + start, oldest + start + 2000, "programme")
                        for start in range(0, 14000, 2000)]

                class Window:
                    def __init__(self, *args):
                        state["window"] = self
                    def show(self):
                        state["active"] = 13000
                    def close(self):
                        state["active"] = 10025
                    def getWidth(self):
                        return 1920
                    def getHeight(self):
                        return 1080

                player = types.SimpleNamespace(
                    isPlayingVideo=lambda: True, isPlaying=lambda: True,
                    getTime=lambda: state["position"], getTotalTime=lambda: duration,
                    seekTime=lambda target: state["seeks"].append(target))
                playback = {"channel": "one", "player": player, "matches": lambda: True,
                            "live": True, "metadata": {"title": "Station"}}

                def wait(_):
                    state["step"] += 1
                    window = state["window"]
                    if state["step"] == 0:
                        window.onInit()
                    elif state["step"] <= len(commands):
                        state["time"] += 0.1
                        command = commands[state["step"] - 1]
                        if command == "menu":
                            window.onAction(types.SimpleNamespace(getId=lambda: 117,
                                                                  getButtonCode=lambda: 0))
                        elif command in ("left", "long-right"):
                            window.onAction(types.SimpleNamespace(
                                getId=lambda: 1 if command == "left" else 2,
                                getButtonCode=lambda: 0 if command == "left" else 0x01000000))
                        elif command == "tick":
                            state["time"] += 0.6
                        else:
                            state["position"] = state["seeks"][-1] - (2 if command == "settle-early" else 0)
                    else:
                        window.onAction(types.SimpleNamespace(getId=lambda: 92,
                                                              getButtonCode=lambda: 0))
                    return False

                xbmc = types.SimpleNamespace(
                    Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                                          waitForAbort=wait),
                    getLanguage=lambda *_: "en", ISO_639_1=0,
                    getCondVisibility=lambda condition: condition == "Player.SeekEnabled")
                xbmcgui = types.SimpleNamespace(
                    WindowXML=Window, getCurrentWindowId=lambda: state["active"],
                    Dialog=lambda: types.SimpleNamespace(contextmenu=lambda _: choice,
                                                         notification=lambda *args: self.fail(args)))
                addon = types.SimpleNamespace(getAddonInfo=lambda _: ROOT, getSetting=lambda _: "false")
                clock = types.SimpleNamespace(monotonic=lambda: state["time"], time=lambda: edge)
                with patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": xbmcgui}), \
                        patch.object(player_window, "time", clock), \
                        patch.object(player_window, "skin_font", return_value="font13"), \
                        patch.object(player_window, "ProgrammeBanner"), \
                        patch.object(player_window, "SeekStrip"):
                    player_window.open_player_window(
                        playback, lambda: ["one"], lambda *_: None, addon, self.fail,
                        peek_schedule=lambda _: rows)
                self.assertEqual(state["seeks"], expected)
                self.assertEqual(state["position"], expected[-1])


if __name__ == "__main__":
    unittest.main()
