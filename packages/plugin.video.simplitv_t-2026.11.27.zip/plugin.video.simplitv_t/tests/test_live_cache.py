import datetime
import json
import os
import sys
import tempfile
import threading
import unittest
from unittest.mock import Mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from live_cache import (
    LiveCache, LiveDataCancelled, LiveDataError, current_programmes,
    broadcast_timestamp, EPG_HORIZON_SECONDS, MAX_GUIDE_PROGRAMMES,
    guide_cache_slot, load_guide_page, fetch_programmes
)
from guide_store import GuideStore


class Window:
    def __init__(self):
        self.values = {}

    def getProperty(self, key):
        return self.values.get(key, "")

    def setProperty(self, key, value):
        self.values[key] = value

    def clearProperty(self, key):
        self.values.pop(key, None)


def programme(title, start, stop):
    return {"title": title, "start": start, "stop": stop,
            "tileChannel": {"codename": "channel"}}


class LiveCacheTests(unittest.TestCase):
    def setUp(self):
        self.window = Window()
        self.now = 1000
        self.cache = LiveCache(self.window, "account", Mock(), lambda: self.now)

    def test_reuse_and_exact_expiry(self):
        loader = Mock(return_value=["channel"])
        self.assertEqual(self.cache.get("channels", loader, 60), ["channel"])
        self.now += 59
        self.cache.get("channels", loader, 60)
        loader.assert_called_once()
        self.now += 1
        self.cache.get("channels", loader, 60)
        self.assertEqual(loader.call_count, 2)

    def test_account_isolation(self):
        loader = Mock(return_value=["channel"])
        self.cache.get("channels", loader, 60)
        other = LiveCache(self.window, "other-account", Mock(), lambda: self.now)
        other.get("channels", loader, 60)
        self.assertEqual(loader.call_count, 2)

    def test_cached_schedule_scan_uses_active_fresh_pages_without_loading(self):
        start = datetime.datetime(2026, 11, 19, tzinfo=datetime.timezone.utc)
        key, identity = guide_cache_slot("page", start, ("channel",))
        current = {"title": "cached current"}
        page = {"title": "cached guide page"}
        self.cache.get("current", lambda: [current], 60)
        self.cache.get(key, lambda: [page], 300, identity)
        store = Mock()
        self.cache.guide_store = store
        other = LiveCache(self.window, "other-account", Mock(), lambda: self.now)
        self.assertEqual(list(other.cached_schedules()), [])
        self.assertEqual(list(self.cache.cached_schedules()), [current, page])
        self.now += 60
        self.assertEqual(list(self.cache.cached_schedules()), [page])
        self.now += 240
        self.assertEqual(list(self.cache.cached_schedules()), [])
        store.read_page.assert_not_called()

    def test_clock_rollback_refreshes(self):
        loader = Mock(return_value={})
        self.cache.get("recordings", loader, 60)
        self.now -= 1
        self.cache.get("recordings", loader, 60)
        self.assertEqual(loader.call_count, 2)

    def test_recording_invalidation_does_not_discard_programmes(self):
        recordings = Mock(return_value={"programme": "recording-id"})
        programmes = Mock(return_value=[])
        self.cache.get("recordings", recordings, 60)
        self.cache.get("programmes", programmes, 300)
        self.cache.invalidate("recordings")
        self.cache.get("recordings", recordings, 60)
        self.cache.get("programmes", programmes, 300)
        self.assertEqual(recordings.call_count, 2)
        programmes.assert_called_once()

    def test_invalidation_during_fetch_prevents_stale_cache_write(self):
        def loader():
            self.cache.invalidate("recordings")
            return {"old": "recording"}
        self.cache.get("recordings", loader, 60)
        fresh = Mock(return_value={})
        self.assertEqual(self.cache.get("recordings", fresh, 60), {})
        fresh.assert_called_once()

    def test_locked_guide_fetch_reuses_cached_details(self):
        loader = Mock(return_value=[{"title": "current"}])
        duplicate = Mock(return_value=[{"title": "duplicate"}])
        with tempfile.TemporaryDirectory() as folder:
            lock_path = os.path.join(folder, "guide.lock")
            self.assertEqual(self.cache.get_with_lock(
                "guide", loader, 300, lock_path), [{"title": "current"}])
            self.assertEqual(self.cache.get_with_lock(
                "guide", duplicate, 300, lock_path), [{"title": "current"}])
        loader.assert_called_once()
        duplicate.assert_not_called()

    def test_errors_are_not_cached_as_empty_results(self):
        loader = Mock(side_effect=LiveDataError("failed"))
        for _ in range(2):
            with self.assertRaises(LiveDataError):
                self.cache.get("recordings", loader, 60)
        self.assertEqual(loader.call_count, 2)

    def test_persistent_page_reopens_sanitized_and_preserves_only_literal_rights(self):
        day = "2026-11-06T17:00:00Z", "2026-11-06T17:30:00Z"
        allowed = dict(programme("Current", *day), id="prg.1", codename="programme.1",
                       catchupAvailableFrom="2026-11-06T17:30:00Z",
                       catchupAvailableTo="2026-11-07T17:30:00Z",
                       isCatchupEnabled=True,
                       isBlackouted=False,
                       description="A show https://media.invalid/?token=synthetic-secret",
                       token="not-persisted")
        denied = dict(programme("Next", *day), id="prg.2", isCatchupEnabled="true",
                      catchupAvailableTo=123)
        with tempfile.TemporaryDirectory() as folder:
            store = GuideStore(folder, "service", "tenant", "user", Mock(), lambda: self.now)
            cache = LiveCache(Window(), "memory", Mock(), lambda: self.now, store)
            lock_path = os.path.join(folder, "guide.lock")
            cache.get_with_lock("guide.page.1", lambda: [allowed, denied], 300, lock_path,
                                identity="page")
            reopened = LiveCache(Window(), "memory", Mock(), lambda: self.now, store)
            self.now += 299
            page = reopened.peek("guide.page.1", 300, "page")
            self.assertEqual([event["isCatchupEnabled"] for event in page], [True, False])
            self.assertIs(page[0]["isBlackouted"], False)
            self.assertEqual(page[0]["codename"], "programme.1")
            self.assertEqual(page[0]["catchupAvailableTo"], "2026-11-07T17:30:00Z")
            self.assertNotIn("isBlackouted", page[1])
            self.assertEqual(page[1]["catchupAvailableTo"], "")
            self.assertEqual(page[0]["description"], "A show ")
            self.assertNotIn("token", page[0])
            other = GuideStore(folder, "other-service", "tenant", "user", Mock(), lambda: self.now)
            self.assertIsNone(other.read_page("page", 300))
            self.now += 1
            self.assertIsNone(reopened.peek("guide.page.1", 300, "page"))
            corrupt_path, _ = store._address("epg", "page")
            with open(corrupt_path, "w", encoding="utf-8") as handle:
                handle.write('{"version":')
            self.assertIsNone(store.read_page("page", 300))
            reopened.get_with_lock("guide.page.1", lambda: [allowed], 300, lock_path,
                                   identity="page")
            self.assertEqual(store.read_page("page", 300)[1][0]["title"], "Current")

    def test_rewind_persists_until_a_newer_valid_observation(self):
        with tempfile.TemporaryDirectory() as folder:
            def store(user="user"):
                return GuideStore(folder, "service", "tenant", user, Mock(), lambda: self.now)

            self.assertIsNone(store().read_rewind("one", False))
            store().write_rewind("one", False, "DASH/Widevine", 14400)
            original = self.now
            self.now += 45 * 24 * 60 * 60
            self.assertEqual(store().read_rewind("one", False),
                             {"format": "DASH/Widevine", "seconds": 14400, "observed_at": original})
            self.assertIsNone(store().read_rewind("one", True))
            self.assertIsNone(store("someone-else").read_rewind("one", False))
            store().write_rewind("one", False, "HLS", None)
            self.assertEqual(store().read_rewind("one", False)["seconds"], 14400)
            store().write_rewind("one", False, "DASH/Widevine", 7200)
            updated = self.now
            self.now = original - 1
            store().write_rewind("one", False, "DASH/Widevine", 3600)
            self.assertEqual(store().read_rewind("one", False),
                             {"format": "DASH/Widevine", "seconds": 7200, "observed_at": updated})

    def test_last_watched_channel_is_account_scoped_and_can_be_forgotten(self):
        with tempfile.TemporaryDirectory() as folder:
            def store(user):
                return GuideStore(folder, "service", "tenant", user, Mock(), lambda: self.now)

            first = store("one")
            first.write_last_channel("orf1-hd")
            self.assertEqual(store("one").read_last_channel(), "orf1-hd")
            self.assertIsNone(store("two").read_last_channel())
            first.write_last_channel("../invalid")
            self.assertEqual(first.read_last_channel(), "orf1-hd")
            first.forget_last_channel()
            self.assertIsNone(first.read_last_channel())

            # A bounded slot collision must not let one account erase another.
            path = first._address("last", None)[0]
            second = next(store("other-{}".format(index)) for index in range(1000)
                          if store("other-{}".format(index))._address("last", None)[0] == path)
            second.write_last_channel("atv")
            first.forget_last_channel()
            self.assertEqual(second.read_last_channel(), "atv")

    def test_concurrent_cold_guide_writers_share_first_complete_page(self):
        page = [programme("Current", "2026-11-06T17:00:00Z", "2026-11-06T17:30:00Z")]
        loader_started, release = threading.Event(), threading.Event()
        with tempfile.TemporaryDirectory() as folder:
            store = GuideStore(folder, "service", "tenant", "user", Mock(), lambda: self.now)
            lock_path = os.path.join(folder, "guide.lock")
            results = []

            def read(loader):
                cache = LiveCache(Window(), "memory", Mock(), lambda: self.now, store)
                results.append(cache.get_with_lock(
                    "guide.page.1", loader, 300, lock_path, wait_seconds=2, identity="page"))

            def first_loader():
                loader_started.set()
                if not release.wait(2):
                    raise AssertionError("Cache loader was not released")
                return page

            unused = Mock(return_value=[])
            first = threading.Thread(target=read, args=(first_loader,))
            second = threading.Thread(target=read, args=(unused,))
            first.start()
            started = loader_started.wait(2)
            second.start()
            release.set()
            first.join(3)
            second.join(3)
            self.assertTrue(started)
            self.assertEqual(len(results), 2)
            unused.assert_not_called()
            self.assertEqual(store.read_page("page", 300)[1][0]["title"], "Current")

    def test_programme_boundary_selects_next_without_network(self):
        programmes = [
            programme("Current", "2026-11-06T17:00:00Z", "2026-11-06T17:30:00Z"),
            programme("Next", "2026-11-06T17:30:00Z", "2026-11-06T18:00:00Z")
        ]
        loader = Mock(return_value=programmes)
        before = broadcast_timestamp("2026-11-06T17:29:59Z")
        at = broadcast_timestamp("2026-11-06T17:30:00Z")
        self.assertEqual(current_programmes(
            self.cache.get("programmes", loader, 300), before
        )["channel"]["title"], "Current")
        self.assertEqual(current_programmes(
            self.cache.get("programmes", loader, 300), at
        )["channel"]["title"], "Next")
        loader.assert_called_once()
        self.assertEqual(current_programmes(programmes, at + 1800), {})

    def test_timestamp_offsets_and_midnight(self):
        self.assertEqual(broadcast_timestamp("2026-11-06T18:00:00+01:00"),
                         broadcast_timestamp("2026-11-06T17:00:00Z"))
        night = programme("Night", "2026-11-06T23:30:00Z", "2026-11-07T00:30:00Z")
        self.assertEqual(current_programmes(
            [night], broadcast_timestamp("2026-11-07T00:00:00Z")
        )["channel"]["title"], "Night")

    def test_epg_loader_fetches_all_ids_in_bounded_batches(self):
        calls = []

        def live_json(method, url, **kwargs):
            payload = json.loads(kwargs["data"])
            calls.append((url, payload))
            if url.endswith("FilterProgramTiles"):
                return {"programs": {"channel": [{"id": index} for index in range(201)]}}
            return {"tiles": [programme(str(item["id"]), "2026-11-06T17:00:00Z",
                                       "2026-11-06T18:00:00Z")
                              for item in payload["requestedTiles"]]}

        self.assertEqual(len(fetch_programmes(live_json)), 201)
        self.assertEqual(len(calls), 4)
        self.assertEqual([len(payload["requestedTiles"]) for _, payload in calls[1:]],
                         [100, 100, 1])
        payload = calls[0][1]
        self.assertEqual(broadcast_timestamp(payload["to"]) -
                         broadcast_timestamp(payload["from"]), EPG_HORIZON_SECONDS)

    def test_foreground_fetch_only_requests_current_details(self):
        calls = []

        def live_json(method, url, **kwargs):
            payload = json.loads(kwargs["data"])
            calls.append(payload)
            if url.endswith("FilterProgramTiles"):
                return {"programs": {"channel": [{"id": 1}, {"id": 2}]}}
            return {"tiles": [programme("Current", "2026-11-06T17:00:00Z",
                                       "2026-11-06T18:00:00Z")]}

        fetch_programmes(live_json, horizon=60)
        self.assertEqual(calls[1]["requestedTiles"], [{"id": 1}])
        self.assertEqual(broadcast_timestamp(calls[0]["to"]) -
                         broadcast_timestamp(calls[0]["from"]), 60)

    def test_guide_fetch_uses_explicit_window_and_all_programmes(self):
        start = datetime.datetime(2026, 11, 6, 15, tzinfo=datetime.timezone.utc)
        end = start + datetime.timedelta(hours=24)
        calls = []

        def live_json(method, url, **kwargs):
            payload = json.loads(kwargs["data"])
            calls.append((url, payload))
            if url.endswith("FilterProgramTiles"):
                return {"programs": {"channel": [{"id": index} for index in range(3)]}}
            return {"tiles": [programme(
                str(item["id"]), "2026-11-06T17:00:00Z", "2026-11-06T18:00:00Z"
            ) for item in payload["requestedTiles"]]}

        result = fetch_programmes(live_json, start=start, end=end)
        self.assertEqual(len(result), 3)
        self.assertEqual(calls[0][1]["from"], start.isoformat())
        self.assertEqual(calls[0][1]["to"], end.isoformat())
        self.assertEqual(len(calls[1][1]["requestedTiles"]), 3)

    def test_cancelled_guide_fetch_stops_before_details(self):
        calls = []

        def live_json(method, url, **kwargs):
            calls.append(url)
            return {"programs": {"channel": [{"id": 1}]}}

        with self.assertRaises(LiveDataCancelled):
            fetch_programmes(live_json, cancelled=lambda: bool(calls))
        self.assertEqual(len(calls), 1)

    def test_large_listing_only_loads_visible_details_and_reuses_listing_on_page_move(self):
        start = datetime.datetime(2026, 11, 6, 15, tzinfo=datetime.timezone.utc)
        listings, requested, progress = [], [], []

        def live_json(method, url, **kwargs):
            payload = json.loads(kwargs["data"])
            if url.endswith("FilterProgramTiles"):
                lower = datetime.datetime.fromisoformat(payload["from"])
                upper = datetime.datetime.fromisoformat(payload["to"])
                self.assertEqual(lower, start)
                self.assertEqual(upper - lower, datetime.timedelta(hours=4))
                listings.append(lower)
                return {"programs": {
                    "channel": [{"id": i} for i in range(120)] + [{"id": 0}],
                    "other": [{"id": 120}],
                    "not-visible": [{"id": i} for i in range(121, 2800)],
                }}
            batch = [item["id"] for item in payload["requestedTiles"]]
            self.assertTrue(0 < len(batch) <= 100)
            requested.append(batch)
            details = [programme(str(identity), start.isoformat(),
                                 (start + datetime.timedelta(hours=1)).isoformat())
                       for identity in batch]
            for identity, detail in zip(batch, details):
                if identity == 120:
                    detail["tileChannel"]["codename"] = "other"
            return {"tiles": details}

        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "guide.lock")
            def load(channels):
                return load_guide_page(self.cache, path, live_json, start,
                                       channels, lambda: False,
                                       lambda partial: progress.append(len(partial)))
            result = load(["channel"])
            self.assertEqual(len(result), 120)
            self.assertEqual(load(["channel"]), result)
            self.assertEqual([item["title"] for item in load(["other"])], ["120"])
        self.assertEqual(listings, [start])
        self.assertEqual(progress, [100])
        self.assertEqual(requested, [list(range(100)), list(range(100, 120)), [120]])

    def test_guide_slot_collision_never_serves_a_different_page(self):
        start = datetime.datetime(2026, 11, 6, 15, tzinfo=datetime.timezone.utc)
        slots = {}
        for i in range(17):
            key, identity = guide_cache_slot("page", start, [str(i)])
            if key in slots:
                first = slots[key]
                self.cache.get(key, lambda: ["first"], 300, first)
                self.assertIsNone(self.cache.peek(key, 300, identity))
                self.assertEqual(self.cache.peek(key, 300, first), ["first"])
                self.cache.get(key, lambda: ["second"], 300, identity)
                self.assertIsNone(self.cache.peek(key, 300, first))
                break
            slots[key] = identity
        else:
            self.fail("expected a collision in bounded slots")

    def test_guide_fetch_rejects_invalid_or_unbounded_ranges(self):
        start = datetime.datetime(2026, 11, 6, 15, tzinfo=datetime.timezone.utc)
        with self.assertRaises(LiveDataError):
            fetch_programmes(lambda *args, **kwargs: {}, start=start)
        with self.assertRaises(LiveDataError):
            fetch_programmes(
                lambda *args, **kwargs: {}, start=start,
                end=start - datetime.timedelta(seconds=1))

        def oversized(method, url, **kwargs):
            return {"programs": {"channel": [{"id": i}
                                             for i in range(MAX_GUIDE_PROGRAMMES + 1)]}}

        with self.assertRaises(LiveDataError):
            fetch_programmes(
                oversized, start=start, end=start + datetime.timedelta(days=1))

    def test_upcoming_cache_avoids_foreground_request(self):
        loader = Mock(return_value=[])
        self.cache.get("upcoming", lambda: ["upcoming"], 300)
        self.assertEqual(self.cache.programmes(loader), ["upcoming"])
        loader.assert_not_called()
        self.now += 300
        self.assertEqual(self.cache.programmes(loader), [])
        loader.assert_called_once()

    def test_current_cache_works_without_waiting_for_background(self):
        loader = Mock(return_value=["current"])
        self.assertEqual(self.cache.programmes(loader), ["current"])
        self.assertEqual(self.cache.programmes(loader), ["current"])
        loader.assert_called_once()

if __name__ == "__main__":
    unittest.main()
