import json
import importlib.util
import os
import sys
import tempfile
import threading
import types
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    import requests
except ImportError:
    sys.modules["requests"] = types.SimpleNamespace(
        RequestException=type("RequestException", (Exception,), {})
    )
import auth_session


class Window:
    def __init__(self):
        self.values = {}

    def getProperty(self, name):
        return self.values.get(name, "")

    def setProperty(self, name, value):
        self.values[name] = value

    def clearProperty(self, name):
        self.values.pop(name, None)


def response(data, status=200):
    result = Mock(status_code=status, content=json.dumps(data).encode("utf-8"),
                  headers={"Content-Type": "application/json"})
    result.json.return_value = data
    return result


class AuthTests(unittest.TestCase):
    def test_background_preparation_and_playback_share_result(self):
        with tempfile.TemporaryDirectory() as folder:
            lock_path = os.path.join(folder, "auth.lock")
            started, release = threading.Event(), threading.Event()
            errors = []
            results = []

            def request(method, url, **kwargs):
                if url.endswith("Authenticate"):
                    started.set()
                    if not release.wait(5):
                        raise RuntimeError("Test preparation timed out")
                    return response({"token": "prepared-token"})
                if url.endswith("GetDevices"):
                    return response({"devices": [{"key": "prepared-device"}]})
                return response({"MediaFiles": [1]})

            self.session.request.side_effect = request
            background = auth_session.AuthSession(
                "test-user", "test-password", {}, self.window, self.log,
                self.session, lock_path=lock_path
            )
            foreground = auth_session.AuthSession(
                "test-user", "test-password", {}, self.window, self.log,
                self.session, lock_path=lock_path
            )

            def worker(operation):
                try:
                    results.append(operation())
                except Exception as error:
                    errors.append(error)

            preparing = threading.Thread(target=worker, args=(background.devicekey,))
            playing = threading.Thread(target=worker, args=(lambda: foreground.acquire("channel", {}),))
            preparing.start()
            try:
                self.assertTrue(started.wait(5))
                playing.start()
            finally:
                release.set()
                preparing.join(5)
                if playing.ident is not None:
                    playing.join(5)
            self.assertFalse(preparing.is_alive())
            self.assertFalse(playing.is_alive())
            self.assertEqual(errors, [])
            self.assertEqual(self.session.request.call_count, 3)
            self.assertIn("prepared-device", results)
            self.assertIn({"MediaFiles": [1]}, results)

    def test_failed_preparation_releases_lock_for_playback(self):
        with tempfile.TemporaryDirectory() as folder:
            lock_path = os.path.join(folder, "auth.lock")
            self.auth.lock_path = lock_path
            self.session.request.side_effect = [
                response({}, 500), response({"token": "test-token"}),
                response({"devices": [{"key": "test-device"}]})
            ]
            with self.assertRaises(auth_session.AuthError):
                self.auth.devicekey()
            foreground = self.client()
            foreground.lock_path = lock_path
            self.assertEqual(foreground.devicekey(), "test-device")

    def setUp(self):
        self.window = Window()
        self.session = Mock()
        self.log = Mock()
        self.auth = self.client()

    def client(self, password="test-password"):
        return auth_session.AuthSession(
            "test-user", password, {}, self.window, self.log, self.session
        )

    def prepare_cache(self):
        self.session.request.side_effect = [
            response({"token": "test-token"}),
            response({"devices": [{"key": "test-device"}]})
        ]
        self.assertEqual(self.auth.devicekey(), "test-device")
        self.session.reset_mock()
        self.session.request.side_effect = None

    def test_first_start_and_reuse_across_plugin_invocations(self):
        media = {"MediaFiles": [{"Formats": [{"Url": "test-stream"}]}]}
        self.session.request.side_effect = [
            response({"token": "test-token"}),
            response({"devices": [{"key": "test-device"}]}), response(media), response(media)
        ]
        self.assertEqual(self.auth.acquire("channel", {}), media)
        self.assertEqual(self.session.request.call_count, 3)
        self.assertEqual(self.client().acquire("next-channel", {}), media)
        self.assertEqual(self.session.request.call_count, 4)
        self.assertNotIn("test-password", self.window.getProperty(auth_session.CACHE_PROPERTY))

    def test_expiration_and_credentials_change(self):
        self.prepare_cache()
        cache = json.loads(self.window.getProperty(auth_session.CACHE_PROPERTY))
        with patch.object(auth_session.time, "time", return_value=cache["expires"] + 1):
            self.assertEqual(self.auth._cache(), {})
        self.prepare_cache()
        self.assertEqual(self.client("changed-password")._cache(), {})

    def test_access_token_is_only_a_nonblank_string_fallback(self):
        cases = [
            ({"token": "primary", "accessToken": "fallback"}, "primary"),
            ({"accessToken": "fallback"}, "fallback"),
            ({"token": [], "accessToken": "fallback"}, "fallback"),
            ({"token": " ", "accessToken": "fallback"}, "fallback"),
            ({"token": None, "accessToken": 123}, None),
            ({"accessToken": " "}, None),
        ]
        for data, expected in cases:
            with self.subTest(data=data):
                self.auth.invalidate()
                self.session.request.return_value = response(data)
                if expected is None:
                    with self.assertRaises(auth_session.AuthError):
                        self.auth.token()
                else:
                    self.assertEqual(self.auth.token(), expected)

    def test_lower_camel_media_does_not_refresh_or_change_scoped_headers(self):
        self.prepare_cache()
        media = {"MediaFiles": [], "mediaFiles": [{"formats": [{"url": "synthetic"}]}]}
        self.session.request.return_value = response(media)
        headers = {"Accept": "application/json", "X-Tenant-Codename": "unexpected"}
        self.assertEqual(self.auth.acquire("channel", headers), media)
        self.session.request.assert_called_once()
        self.assertEqual(self.session.request.call_args.kwargs["headers"],
                         {**headers, "X-Tenant-Codename": self.auth.tenant})
        self.assertEqual(headers["X-Tenant-Codename"], "unexpected")

    def test_rejection_refreshes_token_and_device_once(self):
        for status in (401, 403):
            with self.subTest(status=status):
                self.auth.invalidate()
                self.prepare_cache()
                media = {"MediaFiles": [1]}
                self.session.request.side_effect = [
                    response({}, status), response({"token": "new-token"}),
                    response({"devices": [{"key": "new-device"}]}), response(media)
                ]
                self.assertEqual(self.auth.acquire("channel", {}), media)
                self.assertEqual(self.session.request.call_count, 4)
                params = self.session.request.call_args.kwargs["params"]
                self.assertEqual(params["token"], "new-token")
                self.assertEqual(params["deviceKey"], "new-device")

    def test_catchup_requires_explicit_provider_success(self):
        self.prepare_cache()
        media = [{"Formats": [{"Url": "test-stream"}]}]
        for result in ({"Result": {"Success": True}, "MediaFiles": media},
                       {"result": {"success": True}, "mediaFiles": media}):
            self.session.request.reset_mock()
            self.session.request.return_value = response(result)
            self.assertEqual(self.auth.acquire("programme.1", {}, require_success=True), result)
            self.assertEqual(self.session.request.call_args.kwargs["params"]["codename"], "programme.1")
        for result in ({}, {"Result": {"Success": False}}, {"result": {"success": "true"}}):
            self.session.request.reset_mock()
            self.session.request.return_value = response(dict(result, MediaFiles=media))
            with self.assertRaises(auth_session.AuthError):
                self.auth.acquire("programme.1", {}, require_success=True)
            self.assertEqual(self.session.request.call_count, 1)

    def test_repeated_rejection_fails_and_clears_cache(self):
        self.prepare_cache()
        self.session.request.side_effect = [
            response({}, 401), response({"token": "new-token"}),
            response({"devices": [{"key": "new-device"}]}),
            response({"result": {"code": 9602, "message": "token=secret"}}, 403)
        ]
        with self.assertRaises(auth_session.AuthError) as raised:
            self.auth.acquire("channel", {})
        self.assertIn("9602 (HTTP 403)", str(raised.exception))
        self.assertNotIn("secret", str(raised.exception))
        self.assertEqual(self.session.request.call_count, 4)
        self.assertEqual(self.auth._cache(), {})

    def test_http_200_failed_cached_acquisition_refreshes_once(self):
        self.prepare_cache()
        self.session.request.side_effect = [
            response({"error": "rejected"}), response({"token": "new-token"}),
            response({"devices": [{"key": "new-device"}]}),
            response({"result": {"success": False, "code": 9500, "message": "token=secret"}})
        ]
        with self.assertRaises(auth_session.AuthError) as raised:
            self.auth.acquire("channel", {})
        self.assertIn("9500 (HTTP 200)", str(raised.exception))
        self.assertEqual(self.session.request.call_count, 4)

    def test_server_failure_does_not_register_or_retry(self):
        self.prepare_cache()
        self.session.request.return_value = response({}, 500)
        with self.assertRaises(auth_session.AuthError):
            self.auth.acquire("channel", {})
        self.assertEqual(self.session.request.call_count, 1)

    def test_device_registration_only_for_empty_device_list(self):
        self.session.request.side_effect = [
            response({"token": "test-token"}), response({"devices": []}),
            response({}, 201), response({"devices": [{"key": "registered-device"}]})
        ]
        self.assertEqual(self.auth.devicekey(), "registered-device")
        self.assertEqual(self.session.request.call_count, 4)
        self.assertTrue(self.session.request.call_args_list[2].args[1].endswith("RegisterDevice"))

    def test_device_lookup_server_failure_does_not_register(self):
        self.session.request.side_effect = [
            response({"token": "test-token"}), response({}, 500)
        ]
        with self.assertRaises(auth_session.AuthError):
            self.auth.devicekey()
        self.assertEqual(self.session.request.call_count, 2)

    def test_network_errors_do_not_expose_token_urls(self):
        self.prepare_cache()
        self.session.request.side_effect = auth_session.requests.RequestException(
            "secret-token-in-url"
        )
        with self.assertRaises(auth_session.AuthError) as error:
            self.auth.acquire("channel", {})
        self.assertNotIn("secret-token", str(error.exception))


class OnboardingTests(unittest.TestCase):
    def setUp(self):
        self.settings = {"username": "", "password": ""}
        self.addon = types.SimpleNamespace(
            getSetting=lambda key: self.settings[key],
            setSetting=lambda key, value: self.settings.update({key: value}),
            getSettings=lambda: types.SimpleNamespace(
                setString=lambda key, value: self.settings.update({key: value})),
            getAddonInfo=lambda key: {"name": "simpliTV", "icon": "icon"}[key],
            openSettings=Mock())
        self.dialog = types.SimpleNamespace(ok=Mock(), yesno=Mock(), notification=Mock())
        self.xbmc = types.SimpleNamespace(getLanguage=lambda *_: "en", ISO_639_1=0,
                                          getCondVisibility=lambda *_: True, sleep=Mock())
        self.modules = {"xbmc": self.xbmc,
                        "xbmcaddon": types.SimpleNamespace(Addon=lambda *_: self.addon),
                        "xbmcgui": types.SimpleNamespace(Dialog=lambda: self.dialog)}

    def test_missing_credentials_explain_and_open_settings_without_login_prompt(self):
        def enter():
            self.settings.update(username="user", password="wrong-password")

        self.addon.openSettings.side_effect = enter
        with patch.dict(sys.modules, self.modules), \
                patch.object(auth_session, "start_credential_check") as check:
            self.assertTrue(auth_session.ensure_configured(self.addon))
            self.dialog.ok.assert_called_once_with("simpliTV", auth_session.AUTH_TEXT[0]["not_configured"])
            self.addon.openSettings.assert_called_once_with()
            check.assert_called_once_with()
            self.assertEqual(self.settings["password"], "wrong-password")
            self.dialog.yesno.assert_not_called()
            self.assertTrue(auth_session.ensure_configured(self.addon))
            self.addon.openSettings.assert_called_once_with()

        self.settings.update(username="", password="")
        self.addon.openSettings.side_effect = None
        with patch.dict(sys.modules, self.modules), \
                patch.object(auth_session, "start_credential_check") as check:
            self.assertFalse(auth_session.ensure_configured(self.addon))
            check.assert_not_called()

    def test_runtime_auth_error_offers_settings_and_keeps_saved_values(self):
        self.settings.update(username="user", password="wrong-password")
        self.dialog.yesno.return_value = True
        with patch.dict(sys.modules, self.modules), \
                patch.object(auth_session, "start_credential_check") as check:
            self.assertTrue(auth_session.show_auth_error(
                self.addon, auth_session.CredentialRejected("rejected")))
            self.addon.openSettings.assert_called_once_with()
            self.assertIn(auth_session.AUTH_TEXT[0]["rejected"], self.dialog.yesno.call_args.args)
            check.assert_not_called()
            self.assertEqual(self.settings["password"], "wrong-password")
            self.dialog.yesno.return_value = False
            self.assertFalse(auth_session.show_auth_error(
                self.addon, auth_session.AuthError("network")))

    def test_changed_credentials_check_and_report_without_registering_a_device(self):
        for data, status, expected in (({"token": "token"}, 200, "verified"),
                                       ({}, 401, "rejected"), ({}, 500, "unavailable")):
            with self.subTest(status=status):
                self.settings.update(username="user", password="saved-password")
                window = Window()
                http = Mock()
                http.request.return_value = response(data, status)
                session = auth_session.AuthSession(
                    "user", "saved-password", {}, window, Mock(), http,
                    credentials_current=lambda: auth_session.credentials(self.addon)
                    == ("user", "saved-password"))
                self.dialog.notification.reset_mock()
                with patch.dict(sys.modules, self.modules), \
                        patch.object(auth_session, "kodi_session", return_value=session):
                    auth_session.check_credentials()
                    auth_session.check_credentials()  # Settings callback and service may both fire.
                self.assertEqual(http.request.call_count, 1)
                self.assertTrue(http.request.call_args.args[1].endswith("/Authenticate"))
                message = (auth_session.AUTH_TEXT[0][expected] if status == 200 else
                           "simpliTV error (HTTP {}): The provider request failed.".format(status))
                self.dialog.notification.assert_called_once_with("simpliTV", message, "icon", 5000)
                self.assertEqual(self.settings["password"], "saved-password")
                self.assertNotIn("saved-password", str(self.dialog.notification.call_args))

    def test_provider_details_reach_german_signin_dialog_and_credential_notification(self):
        self.settings.update(username="user", password="saved-password")
        self.xbmc.getLanguage = lambda *_: "de"
        http = Mock()
        http.request.return_value = response(
            {"result": {"code": 9602, "message": "https://secret.invalid/token"}}, 403)
        session = auth_session.AuthSession("user", "saved-password", {}, Window(), Mock(), http)
        with self.assertRaises(auth_session.CredentialRejected) as raised:
            session.token()
        self.dialog.yesno.return_value = False
        with patch.dict(sys.modules, self.modules), \
                patch.object(auth_session, "kodi_session", return_value=session):
            auth_session.show_auth_error(self.addon, raised.exception)
            auth_session.check_credentials()
        for message in (self.dialog.yesno.call_args.args[1],
                        self.dialog.notification.call_args.args[1]):
            self.assertTrue(message.startswith("simpliTV Fehler 9602 (HTTP 403)"))
            self.assertIn("VPN", message)
            self.assertNotIn("secret", message)
        self.assertEqual(self.settings["password"], "saved-password")

    def test_stale_session_cannot_cache_login_or_register_a_device(self):
        self.settings.update(username="user", password="old")
        window, http = Window(), Mock()
        session = auth_session.AuthSession(
            "user", "old", {}, window, Mock(), http,
            credentials_current=lambda: auth_session.credentials(self.addon) == ("user", "old"))

        def authenticate(*_args, **_kwargs):
            self.settings["password"] = "new"
            return response({"token": "old-token"})

        http.request.side_effect = authenticate
        with self.assertRaises(auth_session.AuthError):
            session.devicekey()
        self.assertEqual(http.request.call_count, 1)
        self.assertEqual(window.getProperty(session.cache_property), "")

    def test_logout_clears_credentials_and_cached_authentication(self):
        self.settings.update(username="user", password="password")
        dialog_settings = dict(self.settings)
        self.addon.setSetting = lambda key, value: dialog_settings.update({key: value})
        window, http = Window(), Mock()
        session = auth_session.AuthSession(
            "user", "password", {}, window, Mock(), http,
            credentials_current=lambda: auth_session.credentials(self.addon) == ("user", "password"))
        window.setProperty(session.cache_property, "cached-token")
        window.setProperty(auth_session.CHECK_PROPERTY, "cached-check")
        with patch.dict(sys.modules, self.modules), \
                patch.object(auth_session, "kodi_session", return_value=session):
            auth_session.logout()
        self.assertEqual(self.settings, {"username": "", "password": ""})
        self.assertEqual(dialog_settings, {"username": "", "password": ""})
        self.xbmc.sleep.assert_called_once_with(300)
        self.assertEqual(window.values, {})
        self.dialog.notification.assert_called_once_with(
            "simpliTV", auth_session.AUTH_TEXT[0]["signed_out"], "icon", 5000)
        with self.assertRaises(auth_session.AuthError):
            session.token()

    def test_logout_does_not_report_success_when_saving_fails(self):
        self.settings.update(username="user", password="password")
        window, http = Window(), Mock()
        session = auth_session.AuthSession("user", "password", {}, window, Mock(), http)
        self.addon.getSettings = lambda: types.SimpleNamespace(
            setString=Mock(side_effect=RuntimeError("settings could not be saved")))
        with patch.dict(sys.modules, self.modules), \
                patch.object(auth_session, "kodi_session", return_value=session), \
                self.assertRaises(RuntimeError):
            auth_session.logout()
        self.dialog.notification.assert_not_called()
        http.close.assert_called_once_with()

    def test_monitor_waits_for_closed_settings_and_debounces_changes(self):
        state = {"now": 0.0, "open": True, "steps": 0}
        calls = []

        class Monitor:
            def waitForAbort(self, _):
                state["steps"] += 1
                state["now"] += .7
                if state["steps"] == 2:
                    state["open"] = False
                return state["steps"] > 2

        xbmc = types.SimpleNamespace(Monitor=Monitor,
                                     getCondVisibility=lambda _: state["open"])
        spec = importlib.util.spec_from_file_location(
            "settings_service_test", os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "service.py"))
        module = importlib.util.module_from_spec(spec)
        with patch.dict(sys.modules, dict(self.modules, xbmc=xbmc)):
            spec.loader.exec_module(module)
            with patch.object(module.time, "monotonic", side_effect=lambda: state["now"]), \
                    patch.object(module, "start_credential_check", side_effect=lambda: calls.append("check")):
                monitor = module.SettingsMonitor()
                self.settings.update(username="user", password="password")
                monitor.onSettingsChanged()
                monitor.onSettingsChanged()
                monitor.run()
        self.assertEqual(calls, ["check"])


if __name__ == "__main__":
    unittest.main()
