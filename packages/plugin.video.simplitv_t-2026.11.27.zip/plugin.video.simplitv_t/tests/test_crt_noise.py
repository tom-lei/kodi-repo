import os
import struct
from pathlib import Path
import sys
import tempfile
import types
import unittest
import zlib
from unittest.mock import patch

import crt_noise


class CrtCacheTests(unittest.TestCase):
    def test_disabled_static_skips_cache_and_background_generation(self):
        addon = types.SimpleNamespace(getSetting=lambda _: "false")
        with patch.object(crt_noise, "cached_textures", return_value=(("warm",), ("signal",))) as cached:
            self.assertIsNone(crt_noise.startup_textures(addon, "profile"))
            crt_noise.start_preparation("profile", addon)
            cached.assert_not_called()
        addon.getSetting = lambda _: ""
        with patch.object(crt_noise, "cached_textures", return_value=(("warm",), ("signal",))):
            self.assertEqual(crt_noise.startup_textures(addon, "profile"), (("warm",), ("signal",)))

    def test_persistent_cache_reuses_complete_frames_and_repairs_incomplete_set(self):
        with tempfile.TemporaryDirectory() as profile:
            crt_noise.prepare_cache(profile, lambda: False)
            snow, signal = crt_noise.cached_textures(profile)
            self.assertEqual(len(snow), crt_noise.FRAMES)
            addon = types.SimpleNamespace(getSetting=lambda _: "false")
            self.assertIsNone(crt_noise.startup_textures(addon, profile))
            addon.getSetting = lambda _: "true"
            self.assertEqual(crt_noise.startup_textures(addon, profile), (snow, signal))
            for frames in (snow, signal):
                data = [Path(path).read_bytes() for path in frames]
                self.assertEqual(len(set(data)), crt_noise.FRAMES)
                self.assertTrue(all(frame.startswith(b"\x89PNG\r\n\x1a\n") for frame in data))
            self.check_snow(Path(snow[4]).read_bytes(), Path(signal[4]).read_bytes())
            for path in (*snow, *signal):
                os.utime(path, (1000000000, 1000000000))
            with patch.object(crt_noise, "generate", side_effect=AssertionError("warm cache regenerated")):
                crt_noise.prepare_cache(str(Path(profile)), lambda: False)
                self.assertEqual(crt_noise.cached_textures(profile), (snow, signal))
                Path(snow[0]).write_bytes(b"truncated")
                self.assertIsNone(crt_noise.cached_textures(profile))
            with patch.object(crt_noise, "CACHE_VERSION", crt_noise.CACHE_VERSION + 1):
                self.assertIsNone(crt_noise.cached_textures(profile))
            crt_noise.prepare_cache(profile, lambda: False)
            self.assertEqual(crt_noise.cached_textures(profile), (snow, signal))
            self.assertTrue(Path(snow[0]).read_bytes().startswith(b"\x89PNG\r\n\x1a\n"))

    def check_snow(self, snow, signal):
        def decode(data):
            width, height, depth = struct.unpack_from(">IIB", data, 16)
            self.assertEqual(depth, 8)
            chunks = {}
            index = 8
            while index < len(data):
                length, kind = struct.unpack_from(">I4s", data, index)
                chunks[kind] = data[index + 8:index + 8 + length]
                index += 12 + length
            self.assertEqual(chunks[b"PLTE"], bytes(i for i in range(256) for _ in range(3)))
            if b"tRNS" in chunks:
                alpha = chunks[b"tRNS"]
                self.assertGreaterEqual(min(alpha), 16)
                self.assertTrue(100 <= max(alpha) <= 128)
            pixels = zlib.decompress(chunks[b"IDAT"])
            return [pixels[y * (width + 1) + 1:(y + 1) * (width + 1)] for y in range(height)]

        rows = decode(snow)
        samples = b"".join(rows)
        self.assertGreater(len(set(samples)), 200)
        self.assertLessEqual(min(samples), 3)
        self.assertGreaterEqual(max(samples), 252)
        self.assertTrue(104 < sum(samples) / len(samples) < 140)
        along = sum(abs(a - b) for row in rows for a, b in zip(row, row[1:]))
        across = sum(abs(a - b) for row, next_row in zip(rows, rows[1:]) for a, b in zip(row, next_row))
        self.assertLess(along, across * 0.75)
        overlay = decode(signal)
        start = (len(rows) - len(overlay)) // 2
        self.assertEqual(overlay, rows[start:start + len(overlay)])

    def test_tuning_logo_fits_small_windows_with_label_space(self):
        width, height = crt_noise.tuning_logo_size(380, 240)
        self.assertLess(width, 380)
        self.assertLessEqual(height + 108, 240)
        self.assertAlmostEqual(width / height, 448 / 208, places=1)

    def test_interrupted_generation_is_not_published_and_next_launch_can_retry(self):
        with tempfile.TemporaryDirectory() as profile:
            attempts = []
            aborted = False

            def generate(staging, cancelled):
                attempts.append(staging)
                staging.mkdir()
                (staging / crt_noise.FRAME_NAMES[0]).write_bytes(b"frame")
                # Another invocation can't remove staging or begin its own render.
                crt_noise.prepare_cache(profile, lambda: False)
                self.assertIsNone(crt_noise.cached_textures(profile))
                if cancelled():
                    return False
                for name in crt_noise.FRAME_NAMES:
                    (staging / name).write_bytes(b"frame")
                return True

            def cancel_after_lock():
                nonlocal aborted
                result, aborted = aborted, True
                return result

            with patch.object(crt_noise, "generate", side_effect=generate):
                crt_noise.prepare_cache(profile, cancel_after_lock)
                self.assertIsNone(crt_noise.cached_textures(profile))
                self.assertFalse(attempts[0].exists())
                # Simulate leftovers from Kodi terminating before the cleanup block.
                attempts[0].mkdir()
                (attempts[0] / "leftover").write_bytes(b"partial")
                crt_noise.prepare_cache(profile, lambda: False)
            self.assertEqual(len(attempts), 2)
            self.assertIsNotNone(crt_noise.cached_textures(profile))
            self.assertFalse((Path(crt_noise.cached_textures(profile)[0][0]).parent / "leftover").exists())

    def test_disabling_static_cancels_running_generation(self):
        with tempfile.TemporaryDirectory() as profile:
            addon = types.SimpleNamespace(getSetting=lambda _: "true")
            def generate(staging, cancelled):
                staging.mkdir()
                (staging / crt_noise.FRAME_NAMES[0]).write_bytes(b"partial")
                addon.getSetting = lambda _: "false"
                return not cancelled()
            with patch.object(crt_noise, "generate", side_effect=generate):
                crt_noise.prepare_cache(profile, lambda: not crt_noise.enabled(addon))
            self.assertIsNone(crt_noise.cached_textures(profile))
            self.assertFalse(crt_noise._directory(profile).with_suffix(".pending").exists())

    def test_cold_launch_dispatches_async_script_without_generating_inline(self):
        with tempfile.TemporaryDirectory() as profile:
            commands = []
            xbmc = types.SimpleNamespace(executebuiltin=commands.append)
            with patch.dict(sys.modules, {"xbmc": xbmc}), patch.object(
                    crt_noise, "generate", side_effect=AssertionError("foreground generation")):
                crt_noise.start_preparation(profile)
                self.assertEqual(commands, ['RunScript("{}")'.format(crt_noise.__file__)])
                with patch.object(crt_noise, "cached_textures", return_value=((), ())):
                    crt_noise.start_preparation(profile)
                self.assertEqual(len(commands), 1)
