import os
import sqlite3
import tempfile
import threading
import time
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import Mock, patch

from channel_logos import LogoCache
from test_logo_pixels import decoded, png


class ArtworkTests(unittest.TestCase):
    def setUp(self):
        profile = tempfile.TemporaryDirectory()
        self.addCleanup(profile.cleanup)
        self.profile = profile.name
        self.url = "https://fixture.invalid/catalogue?private=do-not-store"
        self.fetch = Mock(return_value=(200, {"ETag": '"v1"'}, png(3, 1, bytes(4) + b"\xff"*4 + bytes(4))))
        self.log = Mock()

    def cache(self):
        artwork = LogoCache(self.profile, self.fetch, self.log, lambda path: path)
        self.addCleanup(artwork.close)
        return artwork

    def test_optional_frame_policy_isolated_from_original_crop_cache(self):
        callback = lambda _: ((10, 6), (8, 2))
        artwork = LogoCache(self.profile, self.fetch, self.log, lambda path: path,
                            guide_frame=callback)
        self.addCleanup(artwork.close)
        crop = self.until(lambda: artwork.get(self.url))
        frame = self.until(lambda: artwork.get(self.url, framed=True))
        self.assertNotEqual(crop, frame)
        self.assertEqual(artwork.get(self.url, framed=True), frame)
        self.assertTrue(artwork.root.name.endswith("-framed"))
        with closing(sqlite3.connect(artwork.root / "index.db")) as db:
            row = db.execute("SELECT file,frame FROM logos").fetchone()
        self.assertEqual((row[0], row[1]), (Path(crop).name, Path(frame).name))

    def until(self, getter):
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            result = getter()
            if result:
                return result
            time.sleep(.01)
        self.fail("Artwork worker did not publish")

    def test_cache_hit_offline_and_conditional_revalidation_preserves_visible_image(self):
        first = self.cache()
        path = self.until(lambda: first.get(self.url))
        frame = first.get(self.url)
        self.assertEqual(frame, path)
        self.assertEqual(decoded(Path(path).read_bytes()), (1, 1, b"\xff"*4))
        first.close()
        warm = self.cache()
        self.assertEqual(self.until(lambda: warm.get(self.url)), path)
        self.assertEqual(warm.get(self.url), frame)
        self.fetch.assert_called_once_with(self.url, {})
        warm.close()
        index = first.root / "index.db"
        self.assertNotIn(b"do-not-store", index.read_bytes())
        with closing(sqlite3.connect(index)) as db, db:
            db.execute("UPDATE logos SET checked=0")
        entered, release = threading.Event(), threading.Event()
        def refresh(url, headers):
            self.assertEqual(headers, {"If-None-Match": '"v1"'})
            entered.set()
            release.wait(3)
            return 304, {}, b""
        self.fetch.side_effect = refresh
        last = self.cache()
        try:
            self.assertIsNone(last.get(self.url))
            self.assertTrue(entered.wait(3))
            self.assertEqual(last.get(self.url), path)
            self.assertEqual(last.revision, 1)
        finally:
            release.set()
            last.close()
        self.assertEqual(len(list(first.root.glob("*.png"))), 1)

    def test_local_art_replaced_without_colliding_with_kodi_texture_cache(self):
        path = Path(self.profile) / "source.png"
        first = self.cache()
        path.write_bytes(png(3, 1, bytes(4) + b"\xff"*4 + bytes(4)))
        old = self.until(lambda: first.get(str(path)))
        old_frame = first.get(str(path))
        first.close()
        # Explicit timestamp change even on coarser filesystems.
        path.write_bytes(png(2, 1, b"\x80"*8))
        os.utime(path, (1000000000, 1000000000))
        last = self.cache()
        def updated():
            new = last.get(str(path))
            return new if new and new != old else None
        new = self.until(updated)
        self.assertEqual(decoded(Path(new).read_bytes()), (2, 1, b"\x80"*8))
        self.assertFalse(Path(old).exists())
        self.assertEqual(old_frame, old)
        self.fetch.assert_not_called()

    def test_current_fit_fallback_and_bounded_cache(self):
        cache = self.cache()
        self.fetch.return_value = (200, {}, b"GIF89a" + bytes(15))
        with patch("channel_logos.MAX_ENTRIES", 2):
            for number in range(3):
                result = self.until(lambda: cache.get(self.url + str(number)))
                self.assertEqual(Path(result).read_bytes(), self.fetch.return_value[-1])
            self.assertEqual(len(list(cache.root.glob("*.gif"))), 2)
        self.fetch.side_effect = OSError(self.url)
        self.assertIsNone(cache.get(self.url))
        self.until(lambda: self.log.called)
        self.assertNotIn("do-not-store", repr(self.log.call_args_list))

    def test_cache_filename_is_safe_for_long_windows_portable_profiles(self):
        cache = self.cache()
        path = self.until(lambda: cache.get(self.url))
        self.assertEqual(len(Path(path).name), 68)
        with self.assertRaises(ValueError):
            cache._file("../outside.png")
