import ast
import json
import os
import sys
import types
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    import requests
except ImportError:
    requests = types.SimpleNamespace(
        RequestException=type("RequestException", (Exception,), {}))
    sys.modules["requests"] = requests

from auth_session import AuthError, AuthSession
from channel_access import load_channel_grants
from live_cache import LiveDataError
from provider_errors import (MAX_ERROR_BYTES, ProviderFailure, cached_provider_message,
                             provider_failure, provider_json, provider_message)
from seek_schedule import SeekSchedule, load_schedule
import kodi_network


def response(data=None, status=403, body=None, content_type="application/json"):
    headers = {} if content_type is None else {"Content-Type": content_type}
    return Mock(status_code=status, content=json.dumps(data).encode("utf-8") if body is None else body,
                headers=headers, json=Mock(return_value=data))


class ProviderErrorTests(unittest.TestCase):
    def test_verified_simplitv_codes_are_localized(self):
        for code, english, german in (
                (5, "temporarily unavailable", "vorübergehend"),
                (9003, "session", "Sitzung"),
                (9500, "content", "Inhalt"),
                (9602, "region", "regional")):
            for value in (code, str(code)):
                with self.subTest(code=value):
                    failure = provider_failure(response({"Result": {"Code": value}}))
                    self.assertIn(english, failure.message())
                    self.assertIn(german, failure.message(True))
                    self.assertIn("simpliTV Fehler {} (HTTP 403)".format(code), failure.message(True))

    def test_unknown_code_keeps_only_approved_stock_message(self):
        failure = provider_failure(response({"result": {
            "code": 2838, "message": "Access denied."}}))
        self.assertEqual(failure.message(), "simpliTV error 2838 (HTTP 403): Access denied.")
        self.assertEqual(failure.message(True), "simpliTV Fehler 2838 (HTTP 403): Zugriff verweigert.")
        self.assertNotIn("VPN", failure.message(True))
        failure = provider_failure(response({"code": 777, "error": {"messageCodename": "general_error"}}))
        self.assertIn("777 (HTTP 403)", failure.message())

    def test_unsafe_provider_text_never_enters_error_or_cache(self):
        for text in ("https://provider.invalid/?token=secret", "token=secret",
                     "Bearer secret", "alice@example.invalid", "deviceId=12345678",
                     "Access denied for user alice", "[B]Access denied[/B]", "Access denied.\nsecret"):
            with self.subTest(text=text):
                failure = provider_failure(response({"code": 1234, "message": text,
                                                      "logId": "sensitive-identifier"}))
                self.assertEqual(failure.message(),
                                 "simpliTV error 1234 (HTTP 403): The provider request failed.")
                error = LiveDataError("unsafe fallback", provider=failure)
                self.assertNotIn(text, str(error))
                self.assertNotIn("sensitive-identifier", repr(failure.to_dict()))
                self.assertEqual(cached_provider_message(failure.to_dict(), True),
                                 provider_message(error, True))
        self.assertEqual(cached_provider_message(
            {"code": "token=secret", "status": "url", "message_key": "secret", "reason": []}),
            "simpliTV error: The provider request failed.")

    def test_invalid_or_missing_codes_and_statuses_are_not_echoed(self):
        for code in (None, True, False, 0, -1, 9602.0, {}, [], "９６０２", "9602\n",
                     "token-secret", "1234567", 1234567):
            with self.subTest(code=code):
                failure = provider_failure(response({"errorCode": code}, status=502))
                self.assertEqual(failure.message(),
                                 "simpliTV error (HTTP 502): The provider request failed.")
        self.assertEqual(provider_failure(response({}, status="401 secret")).message(),
                         "simpliTV error: The provider request failed.")
        self.assertEqual(provider_failure(response({"message": "Access denied"}, status=401)).message(),
                         "simpliTV error (HTTP 401): Access denied.")

    def test_non_json_oversized_and_deep_bodies_keep_http_fallback(self):
        for body in (b"<html>token=secret</html>", b"{", b"[]", b"", b"\xff",
                     b"[" * 1500 + b"]" * 1500,
                     b'{"code":9602}' + b" " * MAX_ERROR_BYTES):
            with self.subTest(size=len(body)):
                reply = response(status=503, body=body)
                with self.assertRaises(AuthError) as raised:
                    provider_json(reply, AuthError)
                self.assertEqual(str(raised.exception),
                                 "simpliTV error (HTTP 503): The provider request failed.")
                reply.json.assert_not_called()
        bounded = response(body=b'{"code":9602}' + b" " * (MAX_ERROR_BYTES - 13))
        self.assertEqual(len(bounded.content), MAX_ERROR_BYTES)
        self.assertEqual(provider_failure(bounded).code, 9602)

    def test_error_body_is_parsed_only_for_json_media_types(self):
        for content_type, code in (
                ("text/html", None), (None, None), ("text/plain; charset=utf-8", None),
                ("application/jsonp", None), ("application/+json", None), ("json", None),
                ("application/json", 9602), ("Application/JSON; Charset=UTF-8", 9602),
                (" application/problem+json ; charset=utf-8", 9602)):
            with self.subTest(content_type=content_type):
                failure = provider_failure(response({"result": {"code": 9602}},
                                                    status=403, content_type=content_type))
                self.assertEqual(failure.code, code)
                self.assertEqual(failure.status, 403)
                if code is None:
                    self.assertEqual(failure.message(),
                                     "simpliTV error (HTTP 403): The provider request failed.")
        reply = response({"result": {"code": 9602}}, content_type=None)
        reply.headers = {"content-type": "application/json"}
        self.assertEqual(provider_failure(reply).code, 9602)
        reply.headers = None
        self.assertIsNone(provider_failure(reply).code)

    def test_success_and_malformed_success_keep_status(self):
        reply = response({"value": 1}, status=200)
        self.assertEqual(provider_json(reply, LiveDataError), {"value": 1})
        reply.json.side_effect = ValueError("https://secret.invalid/?token=secret")
        with self.assertRaises(LiveDataError) as raised:
            provider_json(reply, LiveDataError)
        self.assertEqual(str(raised.exception),
                         "simpliTV error (HTTP 200): The provider returned invalid JSON.")
        with self.assertRaises(LiveDataError) as raised:
            provider_json(response([], status=200), LiveDataError)
        self.assertIn("HTTP 200", str(raised.exception))

    def test_auth_live_and_schedule_transports_preserve_failure(self):
        path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "default.py")
        with open(path, encoding="utf-8") as source:
            tree = ast.parse(source.read())
        node = next(node for node in tree.body
                    if isinstance(node, ast.FunctionDef) and node.name == "live_json")
        namespace = dict(requests=requests, kodi_network=kodi_network, api_headers={}, LiveDataError=LiveDataError,
                         provider_failure=provider_failure, provider_json=provider_json)
        exec(compile(ast.Module(body=[node], type_ignores=[]), path, "exec"), namespace)
        for status in (200, 403):
            reply = response({"result": {"success": False, "code": 9602}}, status=status)
            for operation, error_type in (
                    (lambda: namespace["live_json"]("GET", "https://example.invalid"), LiveDataError),
                    (lambda: load_schedule("one", 100, 200, lambda: False), LiveDataError),
                    (lambda: AuthSession._json(reply), AuthError)):
                if status == 200 and error_type is AuthError:
                    continue  # Acquisition must decide when to retry failed HTTP 200 results.
                with self.subTest(status=status, operation=operation), \
                        patch.object(kodi_network, "request", return_value=reply), \
                        self.assertRaises(error_type) as raised:
                    operation()
                self.assertIn("9602 (HTTP {})".format(status), str(raised.exception))
            network_error = requests.RequestException("https://secret.invalid/?token=secret")
            network_error.response = reply
            with patch.object(kodi_network, "request", side_effect=network_error), \
                    self.assertRaises(LiveDataError) as raised:
                namespace["live_json"]("GET", "https://example.invalid")
            self.assertIn("9602 (HTTP {})".format(status), str(raised.exception))
            self.assertNotIn("secret", str(raised.exception))

    def test_schedule_background_failure_keeps_safe_diagnostic_and_retry_delay(self):
        error = LiveDataError("", provider=ProviderFailure(503, 5))
        log = Mock()
        load = Mock(side_effect=error)
        schedule = SeekSchedule("one", lambda _: [], log, load)
        try:
            schedule.refresh(100, 200)
            self.assertTrue(schedule.result[2])
            schedule.worker = Mock(is_alive=lambda: False)
            schedule.update(200, 100, 2)
            log.assert_called_once_with(provider_message(error))
            self.assertEqual(schedule.next_fetch, 32)
        finally:
            schedule.close()

    def test_partial_channel_access_keeps_grants_and_safe_failure_for_notification(self):
        session = Mock()
        session._json = AuthSession._json
        session._request.side_effect = [
            response({"availableChannels": [{"id": 1, "canPlay": True}]}, status=200),
            response({"result": {"code": 5, "message": "token=secret"}}, status=503)]
        access = load_channel_grants(session, "private-token", [("one", 1), ("two", 2)])
        self.assertEqual(access["status"], "partial")
        self.assertEqual(access["profile"], [1])
        self.assertEqual(access["free"], [])
        self.assertIn("simpliTV Fehler 5 (HTTP 503)",
                      cached_provider_message(access["provider_error"], True))
        self.assertNotIn("secret", repr(access) + repr(session.log.call_args_list))


if __name__ == "__main__":
    unittest.main()
