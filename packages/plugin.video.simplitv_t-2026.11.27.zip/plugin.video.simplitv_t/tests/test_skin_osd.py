import os
import tempfile
import unittest

from skin_osd import banner_lift, read_layout


def write(folder, name, text):
    with open(os.path.join(folder, name), "w", encoding="utf-8") as handle:
        handle.write(text)


class SkinOsdTest(unittest.TestCase):
    def skin(self, osd, includes="<includes/>", res='folder="720p" width="1280" height="720"'):
        root = tempfile.TemporaryDirectory()
        self.addCleanup(root.cleanup)
        folder = os.path.join(root.name, "720p")
        os.mkdir(folder)
        write(root.name, "addon.xml", '<addon><extension point="xbmc.gui.skin">'
              '<res folder="xml" width="1920" height="1080"/>'
              '<res {} default="true"/></extension></addon>'.format(res))
        write(folder, "includes.xml", includes)
        write(folder, "videoosd.xml", "<window><controls>{}</controls></window>".format(osd))
        return root.name

    def test_bottom_controls_through_includes_params_and_constants(self):
        includes = """<includes>
            <include file="More.xml"/>
            <constant name="BarHeight">120</constant>
            <include name="Touch"><control type="button"><top>0</top><height>40</height></control></include>
        </includes>"""
        more = """<includes>
            <include name="Bar"><param name="gap" default="10"/><definition>
                <control type="slider"><top>$PARAM[gap]</top><height>20</height>
                    <info>Player.Progress</info></control>
                <control type="button"><bottom>0</bottom><height>50</height></control>
            </definition></include>
        </includes>"""
        osd = """
            <control type="button"><top>0</top><bottom>200</bottom></control>
            <control type="button"><left>-3000</left><top>-3000</top><height>1</height></control>
            <control type="label"><top>600</top><height>30</height><visible>false</visible></control>
            <include condition="Skin.HasSetting(touchmode)">Touch</include>
            <control type="group"><bottom>0</bottom><height>BarHeight</height>
                <include content="Bar"><param name="gap" value="30"/></include>
            </control>"""
        path = self.skin(osd, includes)
        write(os.path.join(path, "720p"), "More.xml", more)
        layout = read_layout(path)
        self.assertAlmostEqual(layout["top"], 630 / 720)
        self.assertEqual([round(value, 3) for value in layout["slider"]],
                         [0, round(630 / 720, 3), 1, round(20 / 720, 3)])
        self.assertAlmostEqual(banner_lift(layout), 630 / 720)
        # A satisfied include condition adds controls; the top half is ignored anyway.
        self.assertAlmostEqual(read_layout(path, lambda _: True)["top"], 630 / 720)

    def test_banner_lift_uses_seekbar_edge_and_falls_back_to_controls(self):
        layout = {"top": 0.83, "slider": [0, 0.884, 1, 0.02]}
        self.assertEqual(banner_lift(layout), 0.884)
        self.assertEqual(banner_lift({"top": 0.83, "slider": None}), 0.83)
        self.assertIs(banner_lift(None), True)

    def test_skin_without_bottom_controls_and_unreadable_skins(self):
        layout = read_layout(self.skin('<control type="group"><top>0</top><height>100</height>'
                                       '<control type="button"><height>80</height></control>'
                                       '</control>'))
        self.assertEqual(layout, {"top": 1.0, "slider": None})
        with self.assertRaises(Exception):
            read_layout(self.skin("<control", res='folder="720p" width="1280" height="720"'))
        with self.assertRaises(Exception):
            read_layout(tempfile.gettempdir() + os.sep + "missing-skin")


if __name__ == "__main__":
    unittest.main()
