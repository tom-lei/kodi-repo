import json
import os
import sys
import threading
import types
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import Mock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import kodi_network
from auth_session import AuthError, AuthSession
from provider_errors import provider_message


class ProxyTests(unittest.TestCase):
    def setUp(self):
        self.settings = dict(usehttpproxy=True, httpproxytype=0, httpproxyserver="127.0.0.1",
                             httpproxyport=3128, httpproxyusername="", httpproxypassword="")
        self.queries = []

        def rpc(text):
            key = json.loads(text)["params"]["setting"].split(".", 1)[1]
            self.queries.append(key)
            return json.dumps({"result": {"value": self.settings[key]}})

        self.modules = patch.dict(sys.modules, {"xbmc": types.SimpleNamespace(executeJSONRPC=rpc)})
        self.modules.start()
        self.addCleanup(self.modules.stop)

    def test_off_preserves_requests_environment_behavior(self):
        self.settings["usehttpproxy"] = False
        with kodi_network.KodiSession() as session, \
                patch.object(kodi_network.requests.Session, "request", return_value="ok") as send:
            self.assertEqual(session.request("GET", "http://example.invalid"), "ok")
            self.assertTrue(session.trust_env)
            self.assertNotIn("proxies", send.call_args.kwargs)
        self.assertEqual(self.queries, ["usehttpproxy"])

    def test_proxy_types_credentials_and_ipv6(self):
        self.settings.update(httpproxyserver="::1", httpproxyusername="a@b:/",
                             httpproxypassword="secret #")
        socks = types.SimpleNamespace(create_connection=Mock())
        with patch.dict(sys.modules, {"socks": socks}):
            for kind, scheme in kodi_network.PROXY_SCHEMES.items():
                self.settings["httpproxytype"] = kind
                proxies = kodi_network.proxy_settings()
                self.assertEqual(proxies["http"],
                                 scheme + "://a%40b%3A%2F:secret%20%23@[::1]:3128")
                self.assertEqual(proxies["https"], proxies["http"])
                self.assertEqual(proxies["all"], proxies["http"])

    def test_invalid_or_unreadable_settings_fail_before_sending(self):
        for key, value in (("usehttpproxy", "true"), ("httpproxyserver", ""),
                           ("httpproxyserver", "user@secret"), ("httpproxyserver", "[broken]"),
                           ("httpproxytype", 99), ("httpproxyport", 0),
                           ("httpproxyport", "secret"), ("httpproxyusername", None)):
            with self.subTest(key=key, value=value), \
                    patch.dict(self.settings, {key: value}), \
                    patch.object(kodi_network.requests.Session, "request") as send, \
                    kodi_network.KodiSession() as session:
                with self.assertRaises(kodi_network.KodiProxyError) as raised:
                    session.request("GET", "http://example.invalid")
                self.assertNotIn("secret", str(raised.exception))
                send.assert_not_called()
        with patch.object(sys.modules["xbmc"], "executeJSONRPC", return_value='{"error":{}}'):
            with self.assertRaises(kodi_network.KodiProxyError):
                kodi_network.proxy_settings()

    def test_missing_socks_is_closed_and_explicit(self):
        self.settings["httpproxytype"] = 4
        with patch.dict(sys.modules, {"socks": None}), \
                patch.object(kodi_network.requests.Session, "request") as send:
            with self.assertRaisesRegex(kodi_network.KodiProxyError, "PySocks"):
                kodi_network.request("GET", "https://example.invalid")
            send.assert_not_called()

    def test_old_https_proxy_transport_is_closed(self):
        self.settings["httpproxytype"] = 5
        from requests.packages import urllib3
        with patch.object(urllib3, "__version__", "1.25.11"), \
                patch.object(kodi_network.requests.Session, "request") as send:
            with self.assertRaisesRegex(kodi_network.KodiProxyError, "urllib3"):
                kodi_network.request("GET", "https://example.invalid")
            send.assert_not_called()

    def test_session_reloads_settings_without_retaining_proxy_when_disabled(self):
        with kodi_network.KodiSession() as session:
            states = []

            def send(*args, **kwargs):
                states.append((session.trust_env, kwargs.get("proxies")))

            with patch.object(kodi_network.requests.Session, "request", side_effect=send):
                session.request("GET", "http://example.invalid")
                self.settings["httpproxyport"] = 4444
                session.request("GET", "http://example.invalid")
                self.settings["usehttpproxy"] = False
                session.request("GET", "http://example.invalid")
            self.assertEqual(states[0], (False, dict.fromkeys(
                ("http", "https", "all"), "http://127.0.0.1:3128")))
            self.assertEqual(states[1][1]["http"], "http://127.0.0.1:4444")
            self.assertEqual(states[2], (True, None))

    def test_failed_proxy_keeps_credentials_out_of_auth_error(self):
        with kodi_network.KodiSession() as transport:
            client = AuthSession("user", "password", {}, Mock(), Mock(), transport)
            with patch.object(kodi_network.requests.Session, "request",
                              side_effect=kodi_network.requests.RequestException("user:secret@proxy")):
                with self.assertRaises(AuthError) as raised:
                    client._request("GET", "/test")
            self.assertIn("Kodi", provider_message(raised.exception))
            self.assertIn("Proxy", provider_message(raised.exception, True))
            self.assertNotIn("secret", str(raised.exception))
            self.assertTrue(transport.trust_env)

    def test_real_http_redirect_and_https_connect_use_proxy_despite_no_proxy(self):
        hits = []

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                hits.append(self.path)
                if self.path.endswith("/redirect"):
                    self.send_response(302)
                    self.send_header("Location", "http://redirect.invalid/final")
                    self.end_headers()
                else:
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b"proxied")

            def do_CONNECT(self):
                hits.append("CONNECT " + self.path)
                self.send_error(502)

            def log_message(self, *args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        try:
            self.settings["httpproxyport"] = server.server_port
            with patch.dict(os.environ, {"NO_PROXY": "*", "no_proxy": "*",
                                         "HTTP_PROXY": "http://127.0.0.1:1",
                                         "HTTPS_PROXY": "http://127.0.0.1:1"}):
                reply = kodi_network.request("GET", "http://origin.invalid/redirect", timeout=3,
                                             proxies={"http": None, "https": None})
                self.assertEqual(reply.content, b"proxied")
                with self.assertRaises(kodi_network.KodiProxyError):
                    kodi_network.request("GET", "https://secure.invalid/test", timeout=3)
            self.assertEqual(hits, ["http://origin.invalid/redirect",
                                    "http://redirect.invalid/final", "CONNECT secure.invalid:443"])
        finally:
            server.shutdown()
            server.server_close()
            worker.join(3)


if __name__ == "__main__":
    unittest.main()
