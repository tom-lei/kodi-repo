import datetime
import json
import os
import sys
import tempfile
import threading
import time
import types
import unittest
import xml.etree.ElementTree as ET
from unittest import mock

ADDON_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ADDON_ROOT)

import guide
from guide import open_guide
from live_cache import LiveDataError
from provider_errors import ProviderFailure


class Control:
    def __init__(self, x, y, width, height):
        if any(type(value) is not int for value in (x, y, width, height)):
            raise TypeError("integer argument expected for control geometry")
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self._id = None

    def getId(self):
        return self._id

    def setColorDiffuse(self, color):
        self.color = color

    def setVisible(self, visible):
        self.visible = visible

    def setAnimations(self, animations):
        self.animations = animations
        self.animation_updates = getattr(self, "animation_updates", 0) + 1

    def setPosition(self, x, y):
        self.x, self.y = x, y

    def setWidth(self, width):
        self.width = width

    def setHeight(self, height):
        self.height = height


class ControlImage(Control):
    def __init__(self, x, y, width, height, filename,
                 aspectRatio=0, colorDiffuse=None):
        super().__init__(x, y, width, height)
        self.filename = filename
        self.aspectRatio = aspectRatio
        self.colorDiffuse = colorDiffuse


class ControlLabel(Control):
    def __init__(self, x, y, width, height, label, font=None, textColor=None,
                 disabledColor=None, alignment=0, hasPath=False, angle=0):
        super().__init__(x, y, width, height)
        self.label = label
        self.font = font
        self.textColor = textColor
        self.disabledColor = disabledColor
        self.alignment = alignment

    def setLabel(self, label, shadowColor=""):
        self.label = label
        self.shadowColor = shadowColor


class ControlButton(Control):
    def __init__(self, x, y, width, height, label, focusTexture=None,
                 noFocusTexture=None, textOffsetX=10, textOffsetY=2,
                 alignment=0, font=None, textColor=None, disabledColor=None,
                 angle=0, shadowColor=None, focusedColor=None):
        super().__init__(x, y, width, height)
        self.label = label
        self.focusTexture = focusTexture
        self.noFocusTexture = noFocusTexture
        self.alignment = alignment
        self.textOffsetY = textOffsetY
        self.font = font
        self.textColor = textColor
        self.disabledColor = disabledColor
        self.focusedColor = focusedColor
        self.enabled = True

    def setEnabled(self, enabled):
        self.enabled = enabled

    def setLabel(self, label):
        self.label = label


class ControlTextBox(Control):
    def __init__(self, x, y, width, height, font=None, textColor=None):
        super().__init__(x, y, width, height)
        self.text = ""

    def setText(self, text):
        assert self.getId() is not None
        self.text = text


class ListItem:
    def __init__(self, label="", label2="", path="", offscreen=False):
        self.label = label
        self.art = {}

    def getLabel(self):
        return self.label

    def setLabel(self, label):
        self.label = label

    def getArt(self, key):
        return self.art.get(key, "")

    def setArt(self, art):
        self.art.update(art)


class ControlList(Control):
    def __init__(self, x, y, width, height):
        super().__init__(x, y, width, height)
        self.items = []
        self.selected = None

    def addItems(self, items):
        self.items.extend(items)

    def selectItem(self, index):
        self.selected = index

    def getSelectedPosition(self):
        return self.selected


def xml_branding_controls():
    return {110: Control(-4000, 0, 242, 50), 111: Control(0, 0, 242, 50),
            112: ControlList(8, 2, 234, 45)}


class WindowXMLDialog:
    constructor_args = None
    last_instance = None
    modal_callback = None
    dimensions = (1280, 720)
    xml_branding = False

    def __new__(cls, xmlFilename, scriptPath, defaultSkin="Default",
                defaultRes="720p"):
        instance = object.__new__(cls)
        WindowXMLDialog.constructor_args = (
            xmlFilename, scriptPath, defaultSkin, defaultRes)
        WindowXMLDialog.last_instance = instance
        return instance

    def __init__(self, xmlFilename, scriptPath, defaultSkin="Default",
                 defaultRes="720p"):
        self.xmlFilename = xmlFilename
        self.scriptPath = scriptPath
        self.defaultSkin = defaultSkin
        self.defaultRes = defaultRes
        self._controls = []
        self._next_id = 3000
        self.focused_control = None
        self.focus_calls = 0
        self.removals = 0
        self.focus_messages = []
        self.focus_requests = []
        self.was_closed = False
        self.video = Control(0, 0, 312, 176)
        self.video_small = Control(0, 0, 216, 121)
        self.xml_controls = xml_branding_controls() if self.xml_branding else {}
        self.properties = {}

    def show(self):
        self.init_pending = True

    def getWidth(self):
        return self.dimensions[0]

    def getHeight(self):
        return self.dimensions[1]

    def addControl(self, control):
        control._id = self._next_id
        self._next_id += 1
        self._controls.append(control)

    def addControls(self, controls):
        for control in controls:
            self.addControl(control)

    def removeControls(self, controls):
        self.removals += len(controls)
        if self.focused_control in controls:
            self.focused_control = None
        self._controls = [control for control in self._controls
                          if control not in controls]

    def getControl(self, control_id):
        if control_id == 100:
            return self.video
        if control_id == 102:
            return self.video_small
        if control_id in (101, 103):
            raise RuntimeError("Unknown control type for python")
        if control_id in self.xml_controls:
            return self.xml_controls[control_id]
        control = next((control for control in self._controls
                        if control.getId() == control_id), None)
        if control is None:
            raise RuntimeError("Non-Existent Control %d" % control_id)
        return control

    def setProperty(self, key, value):
        self.properties[key] = value

    def setFocus(self, control):
        assert control in self._controls and control.enabled
        self.focus_calls += 1
        self.focus_requests.append(control)

    def pump_focus(self):
        requests, self.focus_requests = self.focus_requests, []
        for control in requests:
            if control in self._controls and control.enabled:
                # Native setFocus queues a GUI message; Python callbacks can
                # arrive after the next requested focus has already landed.
                self.focused_control = control
                self.focus_messages.append(control.getId())
        messages, self.focus_messages = self.focus_messages, []
        for control_id in messages:
            self.onFocus(control_id)

    def getFocusId(self):
        if self.focused_control is None:
            raise RuntimeError("No control in this window has focus")
        return self.focused_control.getId()

    def close(self):
        self.was_closed = True
        self.onDeinit()


class Window:
    def __init__(self):
        self.properties = {}

    def getProperty(self, key):
        return self.properties.get(key, "")

    def setProperty(self, key, value):
        self.properties[key] = value


class Action:
    def __init__(self, action_id):
        self.action_id = action_id

    def getId(self):
        return self.action_id


def fake_xbmcgui(window, control_label=ControlLabel, notifications=None, context_choice=-1):
    return types.SimpleNamespace(
        Window=lambda window_id: window,
        WindowXMLDialog=WindowXMLDialog,
        getCurrentWindowDialogId=lambda: 13004,
        getCurrentWindowId=lambda: 10025,
        ControlImage=ControlImage,
        ControlLabel=control_label,
        ControlButton=ControlButton,
        ControlTextBox=ControlTextBox,
        ListItem=ListItem,
        Dialog=lambda: types.SimpleNamespace(
            notification=lambda *args, **kwargs:
                notifications.append(args[1]) if notifications is not None else None,
            contextmenu=lambda _: context_choice),
        ACTION_MOVE_LEFT=1,
        ACTION_MOVE_RIGHT=2,
        ACTION_MOVE_UP=3,
        ACTION_MOVE_DOWN=4,
        ACTION_PREVIOUS_MENU=10,
        ACTION_NAV_BACK=92,
    )


def fake_xbmc(language="en"):
    deadline = time.monotonic() + 5

    def sleep(milliseconds):
        dialog = WindowXMLDialog.last_instance
        if dialog.init_pending:
            dialog.init_pending = False
            dialog.onInit()
        elif WindowXMLDialog.modal_callback is not None:
            dialog.pump_focus()
            WindowXMLDialog.modal_callback(dialog)
        if time.monotonic() >= deadline:
            raise AssertionError("guide dialog did not finish")
        time.sleep(0.001)

    def is_visible(condition):
        raise AssertionError("guide lifecycle must not query GUI visibility: " + condition)

    monitors = []

    class Monitor:
        def __init__(self):
            monitors.append(self)

        def abortRequested(self):
            return False

        def waitForAbort(self, seconds):
            sleep(seconds * 1000)
            return False

        def onNotification(self, sender, method, data):
            pass

    def notify_all(sender, data):
        # Kodi's NotifyAll reaches every Python Monitor as "Other.<data>".
        for monitor in list(monitors):
            monitor.onNotification(sender, "Other." + data, "null")

    return types.SimpleNamespace(
        Monitor=Monitor, notify_all=notify_all,
        getCondVisibility=is_visible, sleep=sleep, ISO_639_1=0,
        getLanguage=lambda *_: language
    )


class GuideWindowConstructionTests(unittest.TestCase):
    def setUp(self):
        self.logo_cache = types.SimpleNamespace(get=lambda source, *_args, **_kwargs: source,
                                                revision=0)
        patcher = mock.patch.object(guide, "get_logo_cache", return_value=self.logo_cache)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_normalized_logo_readiness_repaints_without_moving_selection(self):
        source = "https://images.invalid/channel.png"
        self.logo_cache.get = mock.Mock(return_value=None)

        def interact(dialog):
            self.assertNotIn(("logo", 0), dialog.slots)
            self.assertEqual(dialog.slots[("channel", 0)][1].label, "Station")
            self.logo_cache.get.return_value = os.path.join(ADDON_ROOT, "normalized.png")
            self.logo_cache.revision = 1
            dialog._apply_pending()
            logo = dialog.slots[("logo", 0)][1]
            self.assertIn("normalized.png", logo.filename)
            self.assertIn("scaling_algorithm=lanczos", logo.filename)
            self.logo_cache.get.assert_called_with(source, framed=True)
            self.assertEqual(dialog.selected_channel, 0)
            self.assertNotIn(("logo-original", 0), dialog.slots)
            dialog.close()

        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(),
                                               "xbmcgui": fake_xbmcgui(Window())}):
                open_guide(["one"], lambda *_: [], lambda *_: [], lambda _: "Station",
                           ADDON_ROOT, self.fail, "logo-ready", datetime.timezone.utc,
                           channel_logo=lambda *_: source)
        finally:
            WindowXMLDialog.modal_callback = None

    def test_selected_logo_arriving_after_init_starts_on_name_without_reselecting(self):
        sources = {"one": "https://images.invalid/one.png",
                   "two": "https://images.invalid/two.png"}
        cached = {}
        self.logo_cache.get = lambda source, *_args, **_kwargs: cached.get(source)

        def interact(dialog):
            carousel = dialog.xml_controls[guide.BRANDING_SLIDE_IDS[2]]
            fallback = dialog.slots[("channel", 0)][1]
            self.assertEqual(fallback.label, "One")
            self.assertFalse(carousel.items)
            with mock.patch.object(carousel, "selectItem", wraps=carousel.selectItem) as select:
                cached[sources["one"]] = os.path.join(ADDON_ROOT, "one-normalized.png")
                self.logo_cache.revision += 1
                dialog._apply_pending()
                self.assertEqual([item.getLabel() for item in carousel.items], ["One", ""])
                self.assertIn("one-normalized.png", carousel.items[1].getArt("thumb"))
                self.assertIs(dialog.slots[("channel", 0)][1], fallback)
                self.assertEqual(carousel.selected, 0)
                self.assertEqual(dialog.properties[guide.BRANDING_SLIDE_PROPERTY], "true")

                cached[sources["two"]] = os.path.join(ADDON_ROOT, "two-normalized.png")
                self.logo_cache.revision += 1
                dialog._apply_pending()
                self.assertIn("two-normalized.png", dialog.slots[("logo", 1)][1].filename)
                self.assertIs(dialog.slots[("channel", 0)][1], fallback)

                with mock.patch.object(guide, "time", wraps=time) as clock:
                    clock.monotonic.return_value = time.monotonic()
                    carousel.selected = 1  # Kodi advances the native list.
                    dialog._apply_pending()
                    self.assertIs(dialog.slots[("channel", 0)][1], fallback)
                    clock.monotonic.return_value += 1
                    dialog._apply_pending()
                self.assertNotIn(("channel", 0), dialog.slots)
                select.assert_called_once_with(0)
            dialog.close()

        WindowXMLDialog.modal_callback = interact
        WindowXMLDialog.dimensions = (1920, 1080)
        WindowXMLDialog.xml_branding = True
        try:
            with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(),
                                              "xbmcgui": fake_xbmcgui(Window())}):
                open_guide(["one", "two"], lambda *_: [], lambda *_: [], str,
                           ADDON_ROOT, self.fail, "cold-branding", datetime.timezone.utc,
                           peek_branding=lambda: {"one": ("One", sources["one"]),
                                                  "two": ("Two", sources["two"])})
        finally:
            WindowXMLDialog.modal_callback = None
            WindowXMLDialog.dimensions = (1280, 720)
            WindowXMLDialog.xml_branding = False

    def test_grid_tiles_share_single_gap_lines_and_remain_opaque_over_video(self):
        now = datetime.datetime.now(datetime.timezone.utc)
        events = [{
            "id": str(index), "title": "Programme {}".format(index),
            "start": (now + datetime.timedelta(minutes=30 * index - 30)).isoformat(),
            "stop": (now + datetime.timedelta(minutes=30 * index)).isoformat(),
            "tileChannel": {"codename": channel},
        } for channel in ("one", "two") for index in (0, 1, 2)]
        for dimensions in ((1920, 1080), (640, 360)):
            for playing in (False, True):
                with self.subTest(dimensions=dimensions, playing=playing):
                    WindowXMLDialog.dimensions = dimensions
                    playback = {
                        "player": types.SimpleNamespace(isPlayingVideo=lambda: playing),
                        "matches": lambda: True,
                    }

                    def interact(dialog):
                        dialog._set_programmes(events)
                        dialog._resolve_selection()
                        dialog._render()
                        gap_x, gap_y = guide.guide_tile_gaps(dialog.width, dialog.height)
                        self.assertIn(gap_x, (1, 2))
                        self.assertIn(gap_y, (1, 2))
                        # No separator images: tiles are parted by background alone.
                        self.assertFalse([key for key in dialog.slots if "separator" in str(key)])
                        row_count = min(2, dialog.visible_count)
                        rows = [dialog.slots[("row", row)][1] for row in range(row_count)]
                        if row_count == 2:
                            self.assertEqual(rows[1].y - (rows[0].y + rows[0].height), gap_y)
                        for row, channel in enumerate(("one", "two")[:row_count]):
                            fills = sorted(
                                (control for key, (_, control) in dialog.slots.items()
                                 if isinstance(key, tuple) and (
                                     key[0] == "event-fill" and key[1][0] == channel
                                     or key[0] == "gap-fill" and key[1] == channel)),
                                key=lambda control: control.x)
                            # Channel cell, then every tile, one gap apart and edge to edge.
                            self.assertEqual(fills[0].x - (rows[row].x + rows[row].width), gap_x)
                            for left, right in zip(fills, fills[1:]):
                                self.assertEqual(right.x - (left.x + left.width), gap_x)
                            self.assertEqual(fills[-1].x + fills[-1].width,
                                             dialog.width - max(18, int(dialog.width * 0.02)))
                            for control in fills:
                                self.assertEqual((control.y, control.height),
                                                 (rows[row].y, rows[row].height))
                        self.assertEqual(dialog.fullscreen_video, playing)
                        for key, (_, control) in dialog.slots.items():
                            if isinstance(key, tuple) and key[0] in (
                                    "event", "event-fill", "event-lower", "event-restart"):
                                channel = key[1][0]
                                row = rows[dialog.channels.index(channel) - dialog.first_channel]
                                self.assertGreaterEqual(control.y, row.y)
                                self.assertLessEqual(control.y + control.height, row.y + row.height)
                        self.assertTrue(dialog.event_controls)
                        dialog.close()

                    WindowXMLDialog.modal_callback = interact
                    try:
                        with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(),
                                                          "xbmcgui": fake_xbmcgui(Window())}):
                            open_guide(["one", "two"], lambda *_: events, lambda *_: events,
                                       str, ADDON_ROOT, self.fail, "separator-test",
                                       datetime.timezone.utc, owned_playback=playback,
                                       mini_picture=lambda: False)
                    finally:
                        WindowXMLDialog.modal_callback = None
                        WindowXMLDialog.dimensions = (1280, 720)

    def test_details_panel_follows_a_full_grid_without_an_empty_band(self):
        channels = ["c{}".format(index) for index in range(20)]

        def interact(dialog):
            last = dialog.slots[("row", dialog.visible_count - 1)][1]
            footer = dialog.slots.get("footer", dialog.slots.get("footer-top"))[1]
            self.assertEqual(dialog.visible_count, 12)
            # One background gap line, the same as between rows; no band, no extra line.
            self.assertEqual(footer.y - (last.y + last.height),
                             guide.guide_tile_gaps(dialog.width, dialog.height)[1])
            self.assertNotIn("footer-separator", dialog.slots)
            detail = dialog.slots["detail"][1]
            rewind = dialog.slots["rewind"][1]
            self.assertGreaterEqual(rewind.y, detail.y + detail.height)
            # Key help lives in the header, so the details panel keeps that line.
            help_label = dialog.slots["help"][1]
            self.assertLessEqual(help_label.y + help_label.height, dialog._header_height())
            title = dialog.slots["title"][1]
            self.assertGreaterEqual(help_label.x, title.x + title.width)
            # Hour labels clear the header and the half-raised badges of the first row.
            first_row = dialog.slots[("row", 0)][1]
            ticks = [slot[1] for key, slot in dialog.slots.items()
                     if isinstance(key, tuple) and key[0] == "tick"]
            self.assertTrue(ticks)
            for tick in ticks:
                self.assertGreaterEqual(tick.y, dialog._header_height() + 2)
                self.assertLessEqual(tick.y + tick.height, first_row.y)
                above = tick.y - dialog._header_height()
                below = first_row.y - (tick.y + tick.height)
                self.assertLessEqual(abs(above - below), 1)
            # Help and status never overlap, with the clock or a longer status message.
            for loading in (False, True):
                dialog.loading = loading
                dialog._render()
                help_label = dialog.slots["help"][1]
                status = dialog.slots["status"][1]
                self.assertLessEqual(help_label.x + help_label.width, status.x)
                self.assertLessEqual(status.x + status.width, dialog.width)
            dialog.close()

        WindowXMLDialog.dimensions = (1920, 1080)
        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(),
                                              "xbmcgui": fake_xbmcgui(Window())}):
                open_guide(channels, lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                           self.fail, "footer-gap-test", datetime.timezone.utc)
        finally:
            WindowXMLDialog.modal_callback = None
            WindowXMLDialog.dimensions = (1280, 720)

    def test_number_keys_info_and_tiny_cells_follow_pvr_guide_conventions(self):
        channels = ["c{}".format(index) for index in range(20)]
        now = datetime.datetime.now(datetime.timezone.utc).replace(second=0, microsecond=0)

        def event(number, start, minutes, title):
            begin = now + datetime.timedelta(minutes=start)
            return {"id": str(number), "title": title, "description": title + " synopsis",
                    "isCatchupEnabled": True, "isBlackouted": False,
                    "start": begin.isoformat(),
                    "stop": (begin + datetime.timedelta(minutes=minutes)).isoformat(),
                    "tileChannel": {"codename": "c0"}}

        events = [event(1, -30, 40, "Current"), event(2, 10, 2, "Tiny"), event(3, 12, 60, "Next")]
        viewed = []

        def interact(dialog):
            status = lambda: dialog.slots["status"][1].label
            for digit in (1, 2):
                dialog.onAction(Action(58 + digit))
            self.assertEqual(status(), "12_  →  012 c11")
            dialog._apply_pending()
            self.assertEqual(dialog.selected_channel, 0)
            dialog.onClick(-1)
            self.assertEqual(dialog.selected_channel, 11)
            self.assertNotIn("…", status())
            # Out of range numbers are dropped; the selection stays put.
            for digit in (9, 9):
                dialog.onAction(Action(58 + digit))
            dialog.onClick(-1)
            self.assertEqual(dialog.selected_channel, 11)
            # Without OK the number tunes after the entry timeout.
            dialog.onAction(Action(58 + 1))
            dialog.channel_number.until = 0
            dialog._apply_pending()
            self.assertEqual(dialog.selected_channel, 0)
            self.assertNotIn("…", status())
            tiny = next(control_id for control_id, value in dialog.event_controls.items()
                        if value[1]["title"] == "Tiny")
            control = dialog.getControl(tiny)
            self.assertEqual(control.label, "")
            self.assertFalse(any(value[1]["title"] == "Tiny"
                                 for value in dialog.restart_controls.values()))
            dialog.focused_control = control
            dialog.onFocus(tiny)
            self.assertEqual(dialog.selected_programme["title"], "Tiny")
            dialog.onAction(Action(11))
            self.assertEqual(len(viewed), 1)
            self.assertIn("Tiny", viewed[0][0])
            self.assertEqual(viewed[0][1], "Tiny synopsis")
            dialog.close()

        gui = fake_xbmcgui(Window())
        gui.Dialog = lambda: types.SimpleNamespace(
            textviewer=lambda heading, body: viewed.append((heading, body)))
        WindowXMLDialog.dimensions = (1920, 1080)
        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(), "xbmcgui": gui}):
                open_guide(channels, lambda *_: events, lambda *_: events, str, ADDON_ROOT,
                           self.fail, "number-test", datetime.timezone.utc)
        finally:
            WindowXMLDialog.modal_callback = None
            WindowXMLDialog.dimensions = (1280, 720)

    def test_number_entry_keeps_filtered_lineup_gaps(self):
        numbers = {"one": 1, "hidden": 2, "three": 3}

        def interact(dialog):
            self.assertEqual(dialog.slots[("number", 0)][1].label, "001")
            self.assertEqual(dialog.slots[("number", 1)][1].label, "003")
            number = dialog.slots[("number", 0)][1]
            name = dialog.slots[("channel", 0)][1]
            self.assertLessEqual(number.x + number.width, name.x)
            dialog.onAction(Action(60))
            self.assertIn("002 HIDDEN (hidden)", dialog.control_labels["status"])
            dialog.onClick(-1)
            self.assertEqual(dialog.selected_channel, 0)
            self.assertFalse(dialog.closed)
            dialog.onAction(Action(58))
            dialog.onClick(-1)
            self.assertFalse(dialog.closed)
            self.assertEqual(dialog.selected_channel, 0)
            dialog.onAction(Action(61))
            dialog.channel_number.until = 0
            dialog._apply_pending()
            self.assertEqual(dialog.channels[dialog.selected_channel], "three")
            dialog.close()

        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(), "xbmcgui": fake_xbmcgui(Window())}):
                open_guide(["one", "three"], lambda *_: [], lambda *_: [], str.upper,
                           ADDON_ROOT, self.fail, "filtered-numbers", datetime.timezone.utc,
                           channel_numbers=numbers)
        finally:
            WindowXMLDialog.modal_callback = None

    def test_settings_shortcut_confirms_or_times_out_without_losing_selection(self):
        for digits, confirm, expected in (("0", True, False), ("00", False, False),
                                          ("0001", True, False), ("005", True, False),
                                          ("0000", False, False), ("000", True, True),
                                          ("000", False, True)):
            with self.subTest(digits=digits, confirm=confirm):
                window = Window()
                opened = []

                def interact(dialog):
                    dialog._move_channel(1)
                    for digit in digits:
                        dialog.onAction(Action(58 + int(digit)))
                    if digits == "000":
                        self.assertEqual(dialog.control_labels["status"], "000_  →  Settings")
                    if confirm:
                        dialog.onClick(-1)
                    else:
                        dialog.channel_number.until = 0
                        dialog._apply_pending()
                    self.assertEqual(bool(opened), expected)
                    if expected:
                        self.assertEqual(json.loads(window.getProperty(
                            "simplitv_t.guide.selection.settings-test"))["channel"], "two")
                    else:
                        self.assertFalse(dialog.closed)
                        dialog.close()

                WindowXMLDialog.modal_callback = interact
                try:
                    with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(),
                                                      "xbmcgui": fake_xbmcgui(window)}):
                        result = open_guide(
                            ["one", "two"], lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                            self.fail, "settings-test", datetime.timezone.utc,
                            open_settings=lambda: opened.append("settings") or True)
                    self.assertEqual(result, "settings_changed" if expected else None)
                finally:
                    WindowXMLDialog.modal_callback = None

    def test_selection_follows_channel_identity_after_lineup_reordering(self):
        window = Window()
        window.setProperty("simplitv_t.guide.selection.reordered", json.dumps({"channel": "two"}))

        def interact(dialog):
            self.assertEqual(dialog.channels[dialog.selected_channel], "two")
            self.assertEqual(dialog.selected_channel, 0)
            self.assertEqual(dialog.slots[("number", 0)][1].label, "001")
            dialog.close()

        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(),
                                              "xbmcgui": fake_xbmcgui(window)}):
                open_guide(["two", "one"], lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                           self.fail, "reordered", datetime.timezone.utc,
                           channel_numbers={"two": 1, "one": 2})
        finally:
            WindowXMLDialog.modal_callback = None

    def test_badges_keep_exact_visible_anchors_and_stay_above_new_rows(self):
        now = 1_800_000_000
        view_start = now - 7200

        def event(channel, name, start, stop, blackout=False):
            return {"id": name, "title": name, "isBlackouted": blackout,
                    "start": datetime.datetime.fromtimestamp(start, datetime.timezone.utc).isoformat(),
                    "stop": datetime.datetime.fromtimestamp(stop, datetime.timezone.utc).isoformat(),
                    "tileChannel": {"codename": channel}}

        events = [
            event("edge", "offscreen", view_start - 600, view_start + 1200),
            event("partial", "partial", view_start - 600, now - 3500),
            event("partial", "short", now - 3500, now - 3470),
            event("partial", "next", now - 3470, now + 1200),
            event("blackout", "blackout", now - 3000, now + 1200, True),
        ]

        def interact(dialog):
            dialog.view_start = view_start
            dialog.selected_channel = 1
            dialog.anchor = now - 3550
            dialog._set_programmes(events)
            dialog._resolve_selection()
            dialog._render()

            def badges():
                return {event["id"]: dialog.getControl(control_id)
                        for control_id, (_, event) in dialog.restart_controls.items()}

            shown = badges()
            self.assertEqual(set(shown), {"partial", "short", "next"})
            left = (max(124, int(dialog.width * .12)) + guide.GUIDE_NUMBER_COLUMN
                    - guide.GUIDE_CELL_TRIM + 18)
            right = dialog.width - max(18, int(dialog.width * .02))
            scale = (right - left) / guide.TIMELINE_SECONDS
            self.assertEqual(shown["partial"].x + 2, int(left + (now - 3600 - view_start) * scale))
            self.assertEqual(shown["short"].x + 2, int(left + (now - 3500 - view_start) * scale))
            self.assertLess(shown["short"].x, shown["partial"].x + shown["partial"].width)
            short_button = next(dialog.getControl(control_id)
                                for control_id, (_, event) in dialog.event_controls.items()
                                if event["id"] == "short")
            self.assertLess(short_button.width, guide.TINY_CELL_WIDTH)
            self.assertEqual(shown["short"].y + 14, short_button.y)

            dialog.focused_control = shown["partial"]
            dialog.focus_requested = None
            dialog.onFocus(shown["partial"].getId())
            late = event("edge", "late", now - 3000, now + 1200)
            dialog._set_programmes(events + [late])
            dialog._render()
            shown = badges()
            self.assertGreater(min(control.getId() for control in shown.values()),
                               max(dialog.event_controls))
            dialog.pump_focus()
            self.assertEqual(dialog.getFocusId(), shown["partial"].getId())
            dialog.close()

        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(), "xbmcgui": fake_xbmcgui(Window())}), \
                    mock.patch.object(guide.time, "time", return_value=now):
                open_guide(["edge", "partial", "blackout"], lambda *_: events, lambda *_: events,
                           str, ADDON_ROOT, self.fail, "badge-anchors", datetime.timezone.utc,
                           rewind_observation=lambda channel: {"seconds": 14400 if channel == "edge" else 3600})
        finally:
            WindowXMLDialog.modal_callback = None

    def test_glitch_cells_and_logo_prescaling(self):
        now = datetime.datetime.now(datetime.timezone.utc).replace(second=0, microsecond=0)

        def event(number, start, minutes, title):
            begin = now + datetime.timedelta(minutes=start)
            return {"id": str(number), "title": title, "start": begin.isoformat(),
                    "stop": (begin + datetime.timedelta(minutes=minutes)).isoformat(),
                    "tileChannel": {"codename": "one"}}

        logo = "https://logos.example/one.png"
        events = [event(1, -30, 40, "Current"), event(2, 10, 1, "Filler"),
                  event(3, 11, 49, "After filler"), event(4, 70, 30, "After gap")]

        def interact(dialog):
            dialog._set_programmes(events)
            dialog._resolve_selection()
            dialog._render()
            labels = {key[1][1]: control.label for key, (_, control) in dialog.slots.items()
                      if isinstance(key, tuple) and key[0] == "event"}
            self.assertEqual(labels["2"], "")
            self.assertTrue(labels["3"].endswith("  After filler"))
            self.assertIn("Current", labels["1"])
            fills = [key for key in dialog.slots if isinstance(key, tuple) and key[0] == "gap-fill"]
            after = dialog.slots[next(key for key in dialog.slots if isinstance(key, tuple)
                                      and key[0] == "event-fill" and key[1][1] == "4")][1]
            before = dialog.slots[next(key for key in dialog.slots if isinstance(key, tuple)
                                       and key[0] == "event-fill" and key[1][1] == "3")][1]
            # The data hole between 3 and 4 is one quiet tile, a gap line on each side.
            gap = next(dialog.slots[key][1] for key in fills
                       if before.x < dialog.slots[key][1].x < after.x)
            gap_x = guide.guide_tile_gaps(dialog.width, dialog.height)[0]
            self.assertEqual(gap.x - (before.x + before.width), gap_x)
            self.assertEqual(after.x - (gap.x + gap.width), gap_x)
            shown = dialog.slots[("logo", 0)][1]
            self.assertTrue(shown.filename.startswith(
                "image://https%3A%2F%2Flogos.example%2Fone.png/transform?width="))
            self.assertNotIn(("logo-original", 0), dialog.slots)
            self.assertEqual((shown.width, shown.height), (176, 45))
            buttons = [dialog.slots[key][0] for key in ("watch", "restart", "settings")]
            self.assertEqual({(signature[0][1], signature[0][3], signature[1])
                              for signature in buttons}, {(buttons[0][0][1], 40, "font12")})
            # Buttons sit on the details panel's last line, clear of its bottom edge.
            self.assertLessEqual(buttons[0][0][1] + 40, dialog.height - 10)
            for index, title in ((1, "Filler"), (2, "After filler")):
                # The selected cell keeps its full label for Kodi's focus scrolling.
                dialog.selected_programme = events[index]
                dialog._render()
                selected = next(control for key, (_, control) in dialog.slots.items()
                                if isinstance(key, tuple) and key[0] == "event"
                                and key[1][1] == events[index]["id"])
                self.assertEqual(selected.label[2], ":")
                self.assertEqual(selected.label[5:], "  " + title)
            dialog.close()

        WindowXMLDialog.modal_callback = interact
        WindowXMLDialog.dimensions = (1920, 1200)
        try:
            with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(),
                                              "xbmcgui": fake_xbmcgui(Window())}):
                open_guide(["one"], lambda *_: events, lambda *_: events, str, ADDON_ROOT,
                           self.fail, "glitch-test", datetime.timezone.utc,
                           peek_branding=lambda: {"one": ("One", logo)})
        finally:
            WindowXMLDialog.modal_callback = None
            WindowXMLDialog.dimensions = (1280, 720)

    def test_selected_logo_and_name_slide_in_clipped_xml_carousel(self):
        xml = ET.parse(os.path.join(
            ADDON_ROOT, "resources", "skins", "Default", "1080i", "guide.xml"))
        group_id, background_id, list_id = guide.BRANDING_SLIDE_IDS
        group = xml.find(".//control[@type='group'][@id='{}']".format(group_id))
        background = group.find("./control[@type='image'][@id='{}']".format(background_id))
        carousel = group.find("./control[@type='list'][@id='{}']".format(list_id))
        size = lambda node: tuple(int(node.findtext(key)) for key in ("width", "height"))
        offset = tuple(int(carousel.findtext(key)) for key in ("left", "top"))
        self.assertEqual(size(background), size(group))
        self.assertEqual(carousel.findtext("orientation"), "horizontal")
        # A list container clips its items, so the slide never spills into the grid.
        for layout in ("itemlayout", "focusedlayout"):
            node = carousel.find(layout)
            self.assertEqual((int(node.get("width")), int(node.get("height"))), size(carousel))
            self.assertEqual(size(node.find("./control[@type='image']")), guide.logo_box(176, 45))
        self.assertTrue(200 <= int(carousel.findtext("scrolltime")) <= 250)
        self.assertEqual(int(carousel.findtext("scrolltime")) / 1000,
                         guide.BRANDING_SLIDE_SCROLL_SECONDS)
        autoscroll = carousel.find("autoscroll")
        # Half the old fade's rate: one switch per 3.15 s instead of per 1.575 s.
        self.assertEqual(int(autoscroll.get("time")), 3150)
        # Kodi reverses on the attribute's mere presence; forward keeps name→logo order.
        self.assertIsNone(autoscroll.get("reverse"))
        condition = "String.IsEqual(Window.Property({}),true)".format(
            guide.BRANDING_SLIDE_PROPERTY)
        self.assertEqual((autoscroll.text, carousel.findtext("visible")), (condition, condition))
        self.assertEqual(carousel.findtext("enable"), "false")

        logos = {"one": "https://logos.example/one.png", "three": "https://logos.example/three.png"}

        def interact(dialog):
            native = dialog.xml_controls
            items = native[list_id].items
            cell = dialog.slots[("row-column", 1)][0][0]
            self.assertEqual((cell[0], cell[2:]), (native[group_id].x, size(group)))
            self.assertNotIn(("row-column", 0), dialog.slots)
            self.assertEqual(dialog.image_colors[("row-column", 1)][:4], "0xFF")
            self.assertNotIn(("logo-original", 0), dialog.slots)
            self.assertNotIn(("logo", 0), dialog.slots)
            self.assertNotIn(("channel", 0), dialog.slots)
            # Name sits left of the logo and the list starts on the logo.
            self.assertEqual([item.label for item in items], ["One", ""])
            self.assertTrue(items[1].art["thumb"].startswith("image://https%3A%2F%2Flogos"))
            self.assertEqual(native[list_id].selected, 1)
            self.assertEqual(dialog.properties[guide.BRANDING_SLIDE_PROPERTY], "true")
            dialog.onAction(Action(184))
            self.assertEqual(dialog.selected_channel, 1)
            self.assertEqual(native[group_id].x, -4000)
            self.assertTrue(dialog.slots[("channel", 1)][1].label)
            self.assertEqual(dialog.image_colors[("row-column", 0)][:4], "0xFF")
            dialog.onAction(Action(184))
            self.assertEqual(native[group_id].x, cell[0])
            self.assertEqual(native[group_id].y, dialog.slots[("row", 2)][0][0][1])
            self.assertNotIn(("row-column", 2), dialog.slots)
            self.assertIs(native[list_id].items, items)
            self.assertEqual(len(items), 2)
            self.assertEqual(items[0].label, "Three")
            self.assertIn("three.png", items[1].art["thumb"])
            dialog.close()

        WindowXMLDialog.modal_callback = interact
        WindowXMLDialog.dimensions = (1920, 1080)
        WindowXMLDialog.xml_branding = True
        try:
            with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(),
                                              "xbmcgui": fake_xbmcgui(Window())}):
                open_guide(["one", "two", "three"], lambda *_: [], lambda *_: [], str,
                           ADDON_ROOT, self.fail, "slide-test", datetime.timezone.utc,
                           peek_branding=lambda: {"one": ("One", logos["one"]),
                                                  "three": ("Three", logos["three"])})
        finally:
            WindowXMLDialog.modal_callback = None
            WindowXMLDialog.dimensions = (1280, 720)
            WindowXMLDialog.xml_branding = False

    def test_narrow_cell_time_is_whole_or_absent(self):
        # Cells measured in Kodi screenshots that rendered as "15:…" and "14:…".
        self.assertEqual(guide.fit_event_label("15:43", "Desperate", 52, 720), "")
        self.assertEqual(guide.fit_event_label("14:42", "Hubert", 70, 1080), "")
        for height in (720, 1080, 1200):
            needed = 16 + 5 * height / 80 + 4
            self.assertEqual(guide.fit_event_label("14:42", "Hubert", int(needed) - 1, height), "")
            self.assertEqual(guide.fit_event_label("14:42", "Hubert", -(-needed // 1), height),
                             "14:42")
        self.assertEqual(guide.fit_event_label("14:42", "Hubert & Staller", 300, 1080),
                         "14:42  Hubert & Staller")

    def test_preview_setting_and_native_control_contract(self):
        root = ET.parse(os.path.join(ADDON_ROOT, "resources", "settings.xml")).getroot()
        setting = root.find(".//setting[@id='guide_mini_picture']")
        self.assertEqual((setting.get("type"), setting.get("default")), ("bool", "true"))
        xml = ET.parse(os.path.join(
            ADDON_ROOT, "resources", "skins", "Default", "1080i", "guide.xml"))
        full = xml.find(".//control[@type='videowindow'][@id='104']")
        self.assertEqual((full.findtext("width"), full.findtext("height")), ("1920", "1080"))
        full_condition = "String.IsEqual(Window.Property(simplitv_t.guide.fullscreen),true)"
        self.assertEqual(full.findtext("visible"), full_condition)
        opaque = xml.find(".//control[@type='image'][@id='1']")
        translucent = xml.find(".//control[@type='image'][@id='2']")
        self.assertIsNone(opaque.find("visible"))
        controls = list(xml.find("./controls"))
        self.assertLess(controls.index(opaque), controls.index(full))
        self.assertLess(controls.index(full), controls.index(translucent))
        self.assertEqual(translucent.findtext("visible"), full_condition)
        self.assertNotEqual(translucent.findtext("colordiffuse")[:2], "FF")
        group = xml.find(".//control[@type='group'][@id='100']")
        video = group.find("./control[@type='videowindow'][@id='101']")
        self.assertEqual(video.findtext("visible"),
                         "String.IsEqual(Window.Property(simplitv_t.guide.video),true)")
        self.assertEqual((video.findtext("width"), video.findtext("height")), ("312", "176"))
        self.assertEqual((group.findtext("width"), group.findtext("height")), ("312", "176"))
        group = xml.find(".//control[@type='group'][@id='102']")
        video = group.find("./control[@type='videowindow'][@id='103']")
        self.assertEqual((video.findtext("width"), video.findtext("height")), ("216", "121"))

    def test_preview_gates_current_stream_without_changing_grid_or_tuning(self):
        for owned in (True, False):
            with self.subTest(owned=owned):
                playing = types.SimpleNamespace(active=True, matches=True, setting=True)
                playback = {
                    "player": types.SimpleNamespace(isPlayingVideo=lambda: playing.active),
                    "matches": lambda: playing.matches,
                    "owned_window": owned,
                }
                media = fake_xbmc()
                gui = fake_xbmcgui(Window())
                starts = []

                def interact(dialog):
                    self.assertTrue(dialog.mini_active)
                    self.assertEqual(dialog.properties["simplitv_t.guide.video"], "true")
                    self.assertRaises(RuntimeError, dialog.getControl, 101)
                    rows = [(c.x, c.y, c.width, c.height)
                            for k, (_, c) in dialog.slots.items()
                            if isinstance(k, tuple) and k[0] == "row"]
                    self.assertGreaterEqual(dialog.video.x, dialog.detail_label.x + dialog.detail_label.width)
                    self.assertLessEqual(dialog.video.y + 121, dialog.watch_button.y)
                    dialog.onAction(Action(4))
                    self.assertEqual(starts, [])
                    playing.setting = False
                    dialog._render()
                    self.assertFalse(dialog.mini_active)
                    self.assertEqual(dialog.properties["simplitv_t.guide.video"], "")
                    self.assertTrue(dialog.fullscreen_video)
                    self.assertEqual(dialog.properties["simplitv_t.guide.fullscreen"], "true")
                    self.assertFalse(dialog.video.visible)
                    self.assertFalse(dialog.video_small.visible)
                    self.assertTrue(dialog.image_colors["header"].startswith("0xD4"))
                    self.assertTrue(dialog.image_colors["axis"].startswith("0xD4"))
                    self.assertTrue(dialog.image_colors[("row", 0)].startswith("0x60"))
                    self.assertTrue(dialog.image_colors["footer-bottom"].startswith("0xD4"))
                    self.assertTrue(dialog.image_colors["footer-video"].startswith("0xD4"))
                    self.assertEqual(rows, [(c.x, c.y, c.width, c.height)
                                            for k, (_, c) in dialog.slots.items()
                                            if isinstance(k, tuple) and k[0] == "row"])
                    playing.setting = True
                    playing.matches = False
                    dialog._render()
                    self.assertFalse(dialog.mini_active)
                    self.assertFalse(dialog.fullscreen_video)
                    self.assertEqual(dialog.properties["simplitv_t.guide.fullscreen"], "")
                    self.assertTrue(dialog.image_colors["header"].startswith("0xFF"))
                    self.assertTrue(dialog.image_colors["axis"].startswith("0x00"))
                    playing.matches = True
                    playing.active = False
                    dialog._render()
                    self.assertFalse(dialog.mini_active)
                    self.assertFalse(dialog.fullscreen_video)
                    playing.active = True
                    dialog._render()
                    self.assertTrue(dialog.mini_active)
                    self.assertFalse(dialog.fullscreen_video)
                    dialog._return_to_stream(activate=False)

                WindowXMLDialog.modal_callback = interact
                try:
                    with mock.patch.dict(sys.modules, {"xbmc": media, "xbmcgui": gui}):
                        result = open_guide(
                            ["one", "two"], lambda *_: [], lambda *_: [], str,
                            ADDON_ROOT, self.fail, "preview-test", datetime.timezone.utc,
                            start_playback=lambda *args: starts.append(args),
                            owned_playback=playback, mini_picture=lambda: playing.setting)
                finally:
                    WindowXMLDialog.modal_callback = None
                self.assertIs(result["player"], playback["player"])
                self.assertTrue(result["fullscreen"])
                self.assertEqual(starts, [])

    def test_preview_fits_details_area_without_changing_grid(self):
        for dimensions, expected in (((1920, 1080), (312, 176)),
                                     ((640, 480), (216, 121)),
                                     ((320, 360), None)):
            with self.subTest(dimensions=dimensions):
                WindowXMLDialog.dimensions = dimensions
                playback = {
                    "player": types.SimpleNamespace(isPlayingVideo=lambda: True),
                    "matches": lambda: True,
                }
                media = fake_xbmc()
                gui = fake_xbmcgui(Window())

                def interact(dialog):
                    self.assertEqual(dialog._video_size(), expected)
                    self.assertEqual(dialog.mini_active, expected is not None)
                    self.assertEqual(dialog.fullscreen_video, expected is None)
                    rows = [(c.x, c.y, c.width, c.height)
                            for k, (_, c) in dialog.slots.items()
                            if isinstance(k, tuple) and k[0] == "row"]
                    if expected:
                        self.assertEqual((dialog.video.width, dialog.video.height), expected)
                        self.assertLessEqual(dialog.video.y + expected[1] + 8, dialog.watch_button.y)
                        self.assertLessEqual(dialog.detail_label.x + dialog.detail_label.width,
                                             dialog.video.x)
                    dialog.close()
                    self.assertEqual(len(rows), dialog.visible_count)

                WindowXMLDialog.modal_callback = interact
                try:
                    with mock.patch.dict(sys.modules, {"xbmc": media, "xbmcgui": gui}):
                        open_guide(
                            ["one"] * 12, lambda *_: [], lambda *_: [], str,
                            ADDON_ROOT, self.fail, "small-preview", datetime.timezone.utc,
                            owned_playback=playback, mini_picture=lambda: True)
                finally:
                    WindowXMLDialog.modal_callback = None
                    WindowXMLDialog.dimensions = (1280, 720)

    def test_fullscreen_background_transitions_and_tuning_remain_safe(self):
        state = types.SimpleNamespace(playing=True, matches=True, setting=False)
        playback = {
            "player": types.SimpleNamespace(isPlayingVideo=lambda: state.playing),
            "matches": lambda: state.matches,
        }
        now = datetime.datetime.now(datetime.timezone.utc)
        event = {
            "id": "one", "title": "Programme",
            "start": (now - datetime.timedelta(minutes=5)).isoformat(),
            "stop": (now + datetime.timedelta(minutes=30)).isoformat(),
            "tileChannel": {"codename": "one"},
        }
        media = fake_xbmc()
        gui = fake_xbmcgui(Window())

        def interact(dialog):
            event_key = ("event-fill", guide.programme_key(event))
            self.assertTrue(dialog.fullscreen_video)
            self.assertTrue(dialog.image_colors[event_key].startswith("0x80"))
            state.playing = False
            dialog._apply_pending()
            self.assertFalse(dialog.fullscreen_video)
            self.assertTrue(dialog.image_colors[event_key].startswith("0xFF"))
            state.playing = True
            dialog._apply_pending()
            self.assertTrue(dialog.fullscreen_video)
            dialog.startup = ("Station", None, None, "Station")
            dialog._render()
            self.assertFalse(dialog.fullscreen_video)
            self.assertEqual(dialog.properties["simplitv_t.guide.fullscreen"], "")
            self.assertIn("startup-black", dialog.slots)
            dialog.startup = None
            state.setting = True
            dialog._render()
            self.assertTrue(dialog.mini_active)
            self.assertFalse(dialog.fullscreen_video)
            self.assertTrue(dialog.image_colors[event_key].startswith("0xFF"))
            dialog.close()

        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch.dict(sys.modules, {"xbmc": media, "xbmcgui": gui}):
                open_guide(
                    ["one"], lambda *_: [event], lambda *_: [], str,
                    ADDON_ROOT, self.fail, "background-test", datetime.timezone.utc,
                    owned_playback=playback, mini_picture=lambda: state.setting)
        finally:
            WindowXMLDialog.modal_callback = None

    def test_footer_stays_behind_controls_across_preview_and_stop_transitions(self):
        for initially_preview in (True, False):
            with self.subTest(initially_preview=initially_preview):
                state = types.SimpleNamespace(playing=True, setting=initially_preview)
                playback = {
                    "player": types.SimpleNamespace(isPlayingVideo=lambda: state.playing),
                    "matches": lambda: True,
                }
                media = fake_xbmc()
                gui = fake_xbmcgui(Window())

                def interact(dialog):
                    keys = ("footer-top", "footer-left", "footer-right",
                            "footer-bottom", "footer-video")
                    footer = [dialog.slots[key][1] for key in keys]

                    def check_order():
                        self.assertEqual(footer, [dialog.slots[key][1] for key in keys])
                        indices = [dialog._controls.index(control) for control in footer]
                        for key in ("watch", "restart", "settings"):
                            self.assertLess(max(indices), dialog._controls.index(dialog.slots[key][1]))

                    check_order()
                    state.setting = not state.setting
                    dialog._apply_pending()
                    check_order()
                    state.playing = False
                    dialog._apply_pending()
                    check_order()
                    self.assertTrue(all(dialog.image_colors[key].startswith("0xFF") for key in keys))
                    state.playing = True
                    state.setting = True
                    dialog._apply_pending()
                    check_order()
                    self.assertTrue(dialog.image_colors["footer-video"].startswith("0x00"))
                    dialog.close()

                WindowXMLDialog.modal_callback = interact
                try:
                    with mock.patch.dict(sys.modules, {"xbmc": media, "xbmcgui": gui}):
                        open_guide(
                            ["one"], lambda *_: [], lambda *_: [], str,
                            ADDON_ROOT, self.fail, "footer-order", datetime.timezone.utc,
                            owned_playback=playback, mini_picture=lambda: state.setting)
                finally:
                    WindowXMLDialog.modal_callback = None

    def test_abort_during_guide_startup_skips_native_close_and_late_callbacks(self):
        state = types.SimpleNamespace(aborted=False)
        media = fake_xbmc()
        gui = fake_xbmcgui(Window())

        def wait(_):
            dialog = WindowXMLDialog.last_instance
            state.aborted = True
            dialog.onInit()
            dialog.onAction(Action(10))
            return True

        class AbortingMonitor(media.Monitor):
            def abortRequested(self):
                return state.aborted

            def waitForAbort(self, seconds):
                return wait(seconds)

        media.Monitor = AbortingMonitor
        with mock.patch.dict(sys.modules, {"xbmc": media, "xbmcgui": gui}):
            result = guide.open_guide(
                ["one"], lambda *_: self.fail("loaded a page after abort"), None, str,
                ADDON_ROOT, self.fail, "abort-guide", datetime.timezone.utc)
        dialog = WindowXMLDialog.last_instance
        self.assertIsNone(result)
        self.assertTrue(dialog.cancel.is_set())
        self.assertFalse(dialog.initialized)
        self.assertFalse(dialog.was_closed)  # No native window message during shutdown.

    def open_guide_with_kodi(self, xbmc, window, interact, logs, **kwargs):
        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": fake_xbmcgui(window)}):
                return open_guide(["1"], lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                                  logs.append, "teardown", datetime.timezone.utc, **kwargs)
        finally:
            WindowXMLDialog.modal_callback = None

    def test_kodi_closing_guide_window_ends_only_its_own_guide(self):
        xbmc, window, logs, steps = fake_xbmc(), Window(), [], []

        def interact(dialog):
            steps.append(dialog)
            token = window.getProperty(guide.GUIDE_INSTANCE_PROPERTY)
            self.assertRegex(token, "^[0-9a-f]{16}$")
            if len(steps) == 1:
                # An earlier guide's late unload, and other senders, must not end this one.
                xbmc.notify_all(guide.GUIDE_ADDON_ID, "guide_unloaded.0123456789abcdef")
                xbmc.notify_all("other.addon", "guide_unloaded." + token)
            elif len(steps) == 2:
                self.assertFalse(dialog.was_closed)
                # Dialog.Close(all,true) or Home: Kodi removes the window without a Python callback.
                xbmc.notify_all(guide.GUIDE_ADDON_ID, "guide_unloaded." + token)

        result = self.open_guide_with_kodi(xbmc, window, interact, logs)
        self.assertIsNone(result)
        self.assertEqual(len(steps), 2)
        self.assertTrue(steps[0].was_closed)
        self.assertIn("Kodi closed the guide window; ending the guide.", logs)

    def test_kodi_closing_guide_waits_for_running_playback_handoff(self):
        def succeed():
            yield
            yield
            return {"channel": "1"}

        def fail():
            yield
            raise RuntimeError("signed url")

        for handoff, expected in ((succeed, {"channel": "1"}), (fail, None)):
            with self.subTest(handoff=handoff.__name__):
                xbmc, window, logs, steps = fake_xbmc(), Window(), [], []

                def interact(dialog):
                    steps.append(dialog)
                    if len(steps) == 1:
                        dialog.startup = ("1", None, None, "1")
                        dialog.handoff = handoff()
                        # Switching to fullscreen video can unload the guide mid-handoff.
                        xbmc.notify_all(guide.GUIDE_ADDON_ID, "guide_unloaded."
                                        + window.getProperty(guide.GUIDE_INSTANCE_PROPERTY))
                    elif dialog.handoff is not None:
                        self.assertFalse(dialog.was_closed)

                result = self.open_guide_with_kodi(xbmc, window, interact, logs)
                self.assertEqual(result, expected)
                self.assertTrue(steps[0].was_closed)
                self.assertEqual("Kodi closed the guide window; ending the guide." in logs,
                                 expected is None)

    def test_disabled_or_removed_addon_ends_guide(self):
        xbmc, window, logs, steps = fake_xbmc(), Window(), [], []
        enabled = mock.Mock(side_effect=[True, True, False])

        with mock.patch.object(guide, "ADDON_CHECK_SECONDS", 0):
            result = self.open_guide_with_kodi(xbmc, window, steps.append, logs,
                                               addon_enabled=enabled)
        self.assertIsNone(result)
        self.assertEqual(enabled.call_count, 3)
        self.assertTrue(steps[0].was_closed)
        self.assertIn("The add-on was disabled or removed; ending the guide.", logs)

    def test_guide_xml_announces_unload_for_the_open_guide(self):
        with open(os.path.join(ADDON_ROOT, "resources", "skins", "Default", "1080i", "guide.xml"),
                  encoding="utf-8") as source:
            unload = ET.parse(source).getroot().findtext("onunload")
        self.assertEqual(unload, "NotifyAll({},{}$INFO[Window(Home).Property({})])".format(
            guide.GUIDE_ADDON_ID, guide.GUIDE_UNLOADED[len("Other."):],
            guide.GUIDE_INSTANCE_PROPERTY))

    def test_remote_settings_remains_reachable_without_channel_data(self):
        for language in ("en", "de"):
            for status in ("loading", "", "error"):
                opened = []
                window = Window()
                saved = '{"channel":"two","view":0}'
                window.setProperty("simplitv_t.guide.selection.remote-account", saved)
                previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
                sys.modules.update(xbmc=fake_xbmc(language), xbmcgui=fake_xbmcgui(window))

                def interact(dialog):
                    labels = guide.GUIDE_TEXT[language == "de"]
                    self.assertNotIn("main-menu", dialog.slots)
                    self.assertEqual(dialog.settings_button.label, labels["settings"])
                    self.assertIn("Zurück Schließen" if language == "de" else "Back Close",
                                  dialog.control_labels["help"])
                    self.assertEqual(dialog.getFocusId(), dialog.settings_button.getId())
                    dialog.onAction(Action(2))
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), dialog.settings_button.getId())
                    for action in (3, 4):
                        dialog.onAction(Action(action))
                        dialog.pump_focus()
                        self.assertEqual(dialog.getFocusId(), dialog.settings_button.getId())
                    dialog.onClick(dialog.getFocusId())
                    self.assertEqual(opened, ["settings"])
                    self.assertFalse(dialog.closed)
                    dialog._render()
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), dialog.settings_button.getId())
                    dialog.onAction(Action(1))
                    dialog.pump_focus()
                    dialog.onAction(Action(92))

                WindowXMLDialog.modal_callback = interact
                try:
                    result = open_guide(
                        [], lambda *_: self.fail("Unexpected data probe"), lambda *_: [],
                        str, ADDON_ROOT, lambda *_: None, "remote-account",
                        datetime.timezone.utc, access_status=status,
                        open_settings=lambda: opened.append("settings"))
                    self.assertIsNone(result)
                    self.assertEqual(window.getProperty(
                        "simplitv_t.guide.selection.remote-account"), saved)
                finally:
                    WindowXMLDialog.modal_callback = None
                    for name, module in previous.items():
                        if module is None:
                            sys.modules.pop(name, None)
                        else:
                            sys.modules[name] = module

    def test_initial_back_closes_without_playback_and_down_reaches_settings(self):
        for channels in ([], ["one"]):
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))

            def interact(dialog):
                if channels:
                    dialog.onAction(Action(4))
                    dialog.pump_focus()
                self.assertEqual(dialog.getFocusId(), dialog.settings_button.getId())
                dialog.onAction(Action(92))

            WindowXMLDialog.modal_callback = interact
            try:
                self.assertIsNone(open_guide(
                    channels, lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                    lambda *_: None, "back-account", datetime.timezone.utc,
                    start_playback=lambda *_: self.fail("Unexpected playback")))
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_startup_logo_uses_shared_normalized_cache_without_remote_rendering(self):
        logo = "https://example.invalid/logo.png"
        self.logo_cache.get = mock.Mock(return_value=None)
        self.assertIsNone(guide.local_startup_logo(None, logo))
        self.logo_cache.get.return_value = os.path.join(ADDON_ROOT, "normalized.png")
        self.assertEqual(guide.local_startup_logo(None, logo),
                         os.path.join(ADDON_ROOT, "normalized.png"))
        self.logo_cache.get.assert_called_with(logo)

    def test_playable_only_waits_for_grants_and_restores_selection(self):
        window = Window()
        window.setProperty("simplitv_t.guide.selection.synthetic-account", '{"channel":"two"}')
        states = iter([([], "error"), (["one", "two"], "")])
        seen = []

        def interact(dialog):
            seen.append((list(dialog.channels), dialog.detail_label.label))
            if len(seen) == 1:
                self.assertFalse(dialog.watch_button.enabled)
            if len(seen) == 2:
                self.assertFalse(dialog.watch_button.enabled)
            if len(seen) == 3:
                self.assertEqual(dialog.channels[dialog.selected_channel], "two")
                self.assertTrue(dialog.watch_button.enabled)
                dialog.onAction(Action(92))
            dialog.check_channels_after = 0

        previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
        sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(window))
        WindowXMLDialog.modal_callback = interact
        try:
            open_guide(
                [], lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                lambda *_: None, "synthetic-account", datetime.timezone.utc,
                refresh_channels=lambda: next(states), access_status="loading")
            self.assertEqual(seen[0], ([], "Checking channel access…"))
            self.assertEqual(seen[1], ([], "Channel access could not be checked"))
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

    def test_header_clock_and_marker_advance_without_input(self):
        timezone = datetime.timezone(datetime.timedelta(hours=2))
        initial = datetime.datetime(2026, 6, 1, 10, 15, 5, tzinfo=datetime.timezone.utc)
        for language, date in (("de", "01.06.2026"), ("en", "01 Jun 2026")):
            now = initial.timestamp()
            clock = types.SimpleNamespace(time=lambda: now, monotonic=time.monotonic)
            ticks = []

            def interact(dialog):
                nonlocal now
                marker = dialog.slots["now-line", dialog.marker_layer][1]
                ticks.append((dialog.control_labels["status"], marker.x))
                if len(ticks) < 3:
                    now += 30
                else:
                    dialog.onAction(Action(92))

            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            original_clock = guide.time
            guide.time = clock
            sys.modules.update(xbmc=fake_xbmc(language), xbmcgui=fake_xbmcgui(Window()))
            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(
                    ["one"], lambda *_: [], lambda *_: self.fail("Unexpected data fetch"),
                    str, ADDON_ROOT, lambda *_: None, "synthetic-account", timezone)
                self.assertEqual([status for status, _ in ticks],
                                 [date + ", 12:15", date + ", 12:15", date + ", 12:16"])
                self.assertEqual(ticks[0][1], ticks[1][1])
                self.assertGreater(ticks[2][1], ticks[1][1])
            finally:
                guide.time = original_clock
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_now_line_is_clipped_to_timeline_and_actual_rows(self):
        from unittest.mock import patch

        now = datetime.datetime(2026, 6, 1, 10, tzinfo=datetime.timezone.utc).timestamp()
        clock = types.SimpleNamespace(time=lambda: now, monotonic=time.monotonic)

        def interact(dialog):
            grid_top = dialog._header_height() + guide.GUIDE_AXIS_HEIGHT
            grid_bottom = dialog.height - dialog._footer_height() - dialog._grid_gap()
            row_height = (grid_bottom - dialog._row_basis_top()) // dialog.visible_count
            gap_y = guide.guide_tile_gaps(dialog.width, dialog.height)[1]
            left = (max(124, int(dialog.width * 0.12)) + guide.GUIDE_NUMBER_COLUMN
                    - guide.GUIDE_CELL_TRIM + 18)
            right = dialog.width - max(18, int(dialog.width * 0.02))
            self.assertGreater(dialog.visible_count, 2)
            for elapsed, expected_x, expected_width in (
                    (0, left, 2),
                    (guide.TIMELINE_SECONDS // 2, (left + right) // 2 - 1, 2),
                    (guide.TIMELINE_SECONDS, right - 2, 2)):
                dialog.view_start = now - elapsed
                dialog._render()
                line = dialog.slots["now-line", dialog.marker_layer][1]
                self.assertEqual((line.x, line.y, line.width, line.height),
                                 (expected_x, grid_top, expected_width, row_height * 2 - gap_y))
                self.assertEqual(dialog.image_colors[("now-line", dialog.marker_layer)],
                                 "0x" + guide.TIMELINE_MARKER_COLOR)
                self.assertNotIn("now", dialog.slots)
            dialog.channels.clear()
            dialog._render()
            self.assertFalse(any(isinstance(key, tuple) and key[0] == "now-line"
                                 for key in dialog.slots))
            self.assertNotIn("now", dialog.slots)
            dialog.onAction(Action(92))

        WindowXMLDialog.modal_callback = interact
        try:
            with patch.object(guide, "time", clock), patch.dict(
                    sys.modules, {"xbmc": fake_xbmc(), "xbmcgui": fake_xbmcgui(Window())}):
                open_guide(["one", "two"], lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                           lambda *_: None, "synthetic-account", datetime.timezone.utc)
        finally:
            WindowXMLDialog.modal_callback = None

    def test_playback_handoff_keeps_guide_visible_and_accepts_only_one_click(self):
        for outcome in ("success", "failure", "cancel"):
            states = []
            notifications = []

            def start_playback(selection):
                dialog = WindowXMLDialog.last_instance
                self.assertIn("startup-static", dialog.slots)
                self.assertNotIn("startup-plate", dialog.slots)
                field, station, snow, status = (dialog.slots[key][1] for key in (
                    "startup-static", "startup-station", ("startup-interference", None),
                    "startup-status"))
                self.assertLess(field.getId(), station.getId())
                self.assertLess(station.getId(), snow.getId())
                self.assertEqual((snow.x, snow.width), (field.x, field.width))
                self.assertEqual((field.x, field.y, field.width, field.height),
                                 (0, 0, dialog.width, dialog.height))
                self.assertEqual(dialog.startup_frame, 0)
                self.assertTrue(field.visible)
                start = dialog.startup_clock
                frames = set()
                frame_controls = [dialog.slots[key][1] for key in
                                  ["startup-static"] + [("startup-static", index)
                                                       for index in range(1, len(frameset[0]))]]
                for step in range(18):
                    dialog.startup_clock = time.monotonic() - (step + 0.25) / 12
                    dialog._animate_startup()
                    frames.add(dialog.startup_frame)
                    self.assertEqual(sum(control.visible for control in frame_controls), 1)
                    self.assertTrue(frame_controls[dialog.startup_frame].visible)
                self.assertGreaterEqual(len(frames), 16)
                dialog.startup_clock = start
                self.assertTrue(all(os.path.isfile(control.filename) for control in frame_controls))
                self.assertTrue(os.path.isfile(snow.filename))
                self.assertTrue(status.shadowColor)
                self.assertEqual(dialog.control_labels["startup-station"], "001  one")
                self.assertTrue(os.path.isfile(dialog.slots["startup-static"][1].filename))
                return simulate_playback(selection)

            def simulate_playback(selection):
                try:
                    states.append(selection)
                    self.assertFalse(WindowXMLDialog.last_instance.was_closed)
                    yield
                    dialog = WindowXMLDialog.last_instance
                    logo = dialog.slots["startup-logo"][1]
                    snow = dialog.slots[("startup-interference", dialog.startup[2])][1]
                    self.assertLess(logo.getId(), snow.getId())
                    self.assertEqual((logo.width, logo.height), (448, 208))
                    self.assertEqual(logo.aspectRatio, 2)
                    self.assertLessEqual(snow.y, logo.y)
                    self.assertGreaterEqual(snow.y + snow.height, logo.y + logo.height)
                    self.assertLessEqual(snow.y + snow.height, dialog.slots["startup-station"][1].y)
                    if outcome == "failure":
                        raise RuntimeError("synthetic playback failure")
                    states.append("ready")
                    return "owned-playback"
                finally:
                    states.append("closed")

            def interact(dialog):
                if dialog.handoff is None and not states:
                    button = dialog.watch_button.getId()
                    dialog.onClick(button)
                    dialog.onAction(Action(7))
                    dialog.onClick(button)
                    self.assertFalse(dialog.was_closed)
                    self.assertIn("Starting playback", dialog.control_labels["status"])
                elif outcome == "cancel" or notifications:
                    self.assertEqual("startup-static" in dialog.slots, outcome == "cancel")
                    self.assertFalse(dialog.was_closed)
                    dialog.onAction(Action(92))

            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(),
                               xbmcgui=fake_xbmcgui(Window(), notifications=notifications))
            original_lookup = guide.local_startup_logo
            guide.local_startup_logo = lambda *_: "special://thumbnails/a/demo.png"
            WindowXMLDialog.modal_callback = interact
            try:
                # The UI harness only needs existing files; cache and PNG output are tested separately.
                placeholder = os.path.join(ADDON_ROOT, "resources", "skins", "Default", "media", "guide-solid.png")
                frameset = ((placeholder,) * 36, (placeholder,) * 36)
                result = open_guide(
                    ["one"], lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                    lambda *_: None, "synthetic-account", datetime.timezone.utc,
                    channel_logo=lambda *_: "https://example.invalid/logo.png",
                    start_playback=start_playback, peek_crt=lambda: frameset)
                expected = [{"channel": "one", "metadata": {
                    "title": "one", "plot": "", "logo": "https://example.invalid/logo.png"}}]
                if outcome == "success":
                    expected.append("ready")
                self.assertEqual(states, expected + ["closed"])
                self.assertEqual(result, "owned-playback" if outcome == "success" else None)
                self.assertEqual(len(notifications), int(outcome == "failure"))
            finally:
                guide.local_startup_logo = original_lookup
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_cold_tune_stays_black_with_local_logo_after_noise_becomes_ready(self):
        from unittest.mock import patch

        seen = []
        art = "special://thumbnails/a/demo.png"

        def start_playback(_):
            dialog = WindowXMLDialog.last_instance
            black = dialog.slots["startup-black"][1]
            self.assertEqual((black.x, black.y, black.width, black.height),
                             (0, 0, dialog.width, dialog.height))
            self.assertEqual(black.colorDiffuse, "0xFF000000")
            self.assertNotIn("startup-logo", dialog.slots)
            seen.append("acquiring")
            yield
            logo = dialog.slots["startup-logo"][1]
            self.assertEqual(logo.filename, guide.guide_logo_texture(art, 448, 208))
            self.assertEqual((logo.width, logo.height, logo.aspectRatio), (448, 208, 2))
            self.assertGreater(logo.getId(), black.getId())
            keys = {key for key in dialog.slots if isinstance(key, str) and key.startswith("startup-")}
            self.assertEqual(keys, {"startup-black", "startup-logo", "startup-station"})
            self.assertEqual(dialog.control_labels["startup-station"], "001  one")
            seen.append("ready")
            return "owned-playback"

        def interact(dialog):
            if dialog.handoff is None and not seen:
                dialog.onClick(dialog.watch_button.getId())

        def peek_crt():
            return (("snow",), ("signal",)) if seen else None

        WindowXMLDialog.modal_callback = interact
        try:
            with patch.dict(sys.modules, {"xbmc": fake_xbmc(), "xbmcgui": fake_xbmcgui(Window())}), \
                    patch.object(guide, "local_startup_logo", return_value=art):
                result = open_guide(
                    ["one"], lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                    lambda *_: None, "synthetic-account", datetime.timezone.utc,
                    channel_logo=lambda *_: "https://example.invalid/logo.png",
                    start_playback=start_playback, peek_crt=peek_crt)
            self.assertEqual((result, seen), ("owned-playback", ["acquiring", "ready"]))
        finally:
            WindowXMLDialog.modal_callback = None

    def test_return_to_owned_paused_stream_and_stop_are_separate_from_back(self):
        for action in ("button", "owned-window", "empty-lineup", "tab", "native-fullscreen", "back", "stop", "replaced", "ended"):
            state = {"playing": True, "matches": True}
            stopped, commands = [], []
            current_window = [10025]
            player = types.SimpleNamespace(isPlayingVideo=lambda: state["playing"],
                                           paused=True, position=452.25)

            def stop():
                stopped.append(True)
                state["playing"] = False

            player.stop = stop
            owned = {"player": player, "matches": lambda: state["matches"], "fullscreen": True}
            if action == "owned-window":
                owned["owned_window"] = True

            def interact(dialog):
                self.assertIsNotNone(dialog.return_button)
                old_button = dialog.return_button.getId()
                if action == "empty-lineup":
                    dialog.onAction(Action(117))
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), old_button)
                    self.assertFalse(dialog.watch_button.enabled)
                    dialog.onClick(old_button)
                elif action in ("button", "owned-window"):
                    dialog.onAction(Action(117))
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), old_button)
                    dialog.onAction(Action(1))
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), dialog.watch_button.getId())
                    dialog.onAction(Action(2))
                    dialog.pump_focus()
                    self.assertEqual(dialog.getFocusId(), old_button)
                    dialog.onClick(old_button)
                elif action == "tab":
                    dialog.onAction(Action(18))
                elif action == "native-fullscreen":
                    current_window[0] = 12005
                elif action == "back":
                    dialog.onAction(Action(92))
                elif action == "stop":
                    dialog.onAction(Action(13))
                    self.assertIsNone(dialog.return_button)
                    self.assertFalse(dialog.closed)
                    dialog.onAction(Action(92))
                else:
                    state["matches" if action == "replaced" else "playing"] = False
                    dialog._apply_pending()
                    self.assertIsNone(dialog.return_button)
                    dialog.onClick(old_button)
                    dialog.onAction(Action(18))
                    self.assertFalse(dialog.closed)
                    dialog.onAction(Action(92))

            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            xbmc = fake_xbmc()
            xbmc.executebuiltin = commands.append
            gui = fake_xbmcgui(Window())
            gui.getCurrentWindowId = lambda: current_window[0]
            sys.modules.update(xbmc=xbmc, xbmcgui=gui)
            WindowXMLDialog.modal_callback = interact
            try:
                result = open_guide(
                    [] if action == "empty-lineup" else ["one"],
                    lambda *_: [], lambda *_: self.fail("unexpected fetch"),
                    str, ADDON_ROOT, lambda *_: None, "owned", datetime.timezone.utc,
                    start_playback=lambda *_: self.fail("return must not acquire or play"),
                    owned_playback=owned)
                if action in ("button", "owned-window", "empty-lineup", "tab", "native-fullscreen"):
                    self.assertIs(result["player"], player)
                    self.assertEqual(result["fullscreen"], action == "native-fullscreen")
                    self.assertEqual(commands, [] if action in ("native-fullscreen", "owned-window") else
                                     ["ActivateWindow(fullscreenvideo)"])
                else:
                    self.assertIsNone(result)
                    self.assertEqual(commands, [])
                self.assertEqual(stopped, [True] if action == "stop" else [])
                self.assertTrue(player.paused)
                self.assertEqual(player.position, 452.25)
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_short_rows_and_footer_fit_without_glyphs_markup_or_partial_lines(self):
        now = int(time.time())
        event = {
            "id": "layout", "title": "Programme title", "isCatchupEnabled": True, "isBlackouted": False,
            "description": "First<br />Second &amp; third<p>" + "Long description " * 120 + "</p>",
            "start": datetime.datetime.fromtimestamp(now - 300, datetime.timezone.utc).isoformat(),
            "stop": datetime.datetime.fromtimestamp(now + 1800, datetime.timezone.utc).isoformat(),
            "tileChannel": {"codename": "one"}}
        for dimensions in ((1280, 720), (1920, 1080), (960, 600)):
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc("de"), xbmcgui=fake_xbmcgui(Window()))
            WindowXMLDialog.dimensions = dimensions

            def interact(dialog):
                labels = [control for key, (_, control) in dialog.slots.items()
                          if isinstance(key, tuple) and key[0] == "synopsis"]
                self.assertTrue(labels)
                self.assertTrue(labels[0].label.startswith("First"))
                self.assertNotIn("<", "".join(label.label for label in labels))
                self.assertNotIn("&amp;", "".join(label.label for label in labels))
                self.assertTrue(labels[-1].label.endswith("…"))
                self.assertTrue(all(label.height == 28 and label.width > 0 for label in labels))
                self.assertLess(labels[-1].y + labels[-1].height, dialog.watch_button.y)
                for control in (dialog.watch_button, dialog.start_button, dialog.slots["help"][1]):
                    self.assertLessEqual(control.y + control.height, dialog.height)
                    self.assertLessEqual(control.x + control.width, dialog.width)
                badge = dialog.getControl(next(iter(dialog.restart_controls)))
                body = dialog.getControl(next(iter(dialog.event_controls)))
                self.assertEqual(badge.label, "")
                self.assertEqual(badge.x + 2, body.x)
                self.assertEqual(badge.y + 14, body.y)
                self.assertEqual((badge.width, badge.height), (28, 28))
                dialog.onAction(Action(92))

            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(["one"] + ["other{}".format(i) for i in range(15)],
                           lambda *_: [event], lambda *_: [], str, ADDON_ROOT, lambda *_: None,
                           "layout", datetime.timezone.utc,
                           rewind_observation=lambda _: {"seconds": 7200, "format": "DASH/Widevine"})
            finally:
                WindowXMLDialog.dimensions = (1280, 720)
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_mojibake_repairs_only_complete_valid_sequences_in_mixed_text(self):
        self.assertEqual(guide.repair_mojibake("KÃ¼che â€“ GrÃ¶ÃŸe"), "Küche – Größe")
        for text in ("Küche", "Ã la carte", "plain", "\u00e0\u0080\u0080", "â€"):
            with self.subTest(text=text):
                self.assertEqual(guide.repair_mojibake(text), text)
        for encoding in ("cp1252", "latin-1"):
            garbled = "„Ä 😀".encode("utf-8").decode(encoding)
            self.assertEqual(guide.repair_mojibake("schön " + garbled), "schön „Ä 😀")
        self.assertEqual(guide.description_text("Die KÃ¼che<br>Die Küche – Ã la carte"),
                         "Die Küche\nDie Küche – Ã la carte")
        # Kodi clipped wrapped lines estimated at 11 px/char, dropping words mid-synopsis.
        synopsis = ("Phoebe will sich ein eigenes Apartment nehmen, und auch Paige überlegt, mit Henry "
                    "zusammenzuziehen. Doch zuvor müssen sie sich erst mit den Dämonen Pilar und Savard "
                    "herumschlagen.")
        lines = guide.synopsis_lines(synopsis, 1820, 4)
        self.assertEqual(" ".join(lines), synopsis)
        self.assertTrue(all(len(line) * 12.4 <= 1820 for line in lines))
        metadata = guide.playback_metadata("PULS 4", None, {
            "title": "In der KÃ¼che", "description": "SchÃ¶n und gemütlich"})
        self.assertEqual((metadata["title"], metadata["plot"]),
                         ("PULS 4 — In der Küche", "Schön und gemütlich"))

    def test_playback_metadata_matches_live_or_selected_catchup_programme(self):
        now = int(time.time())

        def event(identifier, title, start, stop):
            return {
                "id": identifier, "codename": identifier, "title": title,
                "description": "First<br>Second &amp; third",
                "isBlackouted": False, "isCatchupEnabled": True,
                "start": datetime.datetime.fromtimestamp(now + start, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(now + stop, datetime.timezone.utc).isoformat(),
                "tileChannel": {"codename": "one", "title": "Station", "logoUrlOnDark": "station.png"},
            }

        past = event("past", "Past", -1800, -300)
        current = event("current", "Current", -300, 300)
        future = event("future", "Future", 300, 1800)
        for action, selected, title in (("watch_live", future, "Station — Current"),
                                        ("catchup", past, "Station — Past")):
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))
            received = []

            def start_playback(selection):
                received.append(selection)
                yield
                return "owned-playback"

            def interact(dialog):
                if dialog.handoff is None and not received:
                    dialog._select_event(selected)
                    dialog._activate(action)

            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(["one"], lambda *_: [past, current, future], lambda *_: [],
                           str, ADDON_ROOT, lambda *_: None, "metadata", datetime.timezone.utc,
                           start_playback=start_playback, catchup_eligible=lambda *_: True)
                self.assertEqual(len(received), 1)
                self.assertEqual(received[0]["metadata"], {
                    "title": title, "plot": "First\nSecond & third", "logo": "station.png"})
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_native_activation_starts_one_playable_programme(self):
        for offset, stop, restart, gesture in (
                (-120, 120, False, 7), (-1200, -600, True, 100), (120, 600, True, 7)):
            now = int(time.time())
            event = {
                "id": "test", "title": "Programme", "isCatchupEnabled": restart, "isBlackouted": False,
                "start": datetime.datetime.fromtimestamp(now + offset, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(now + stop, datetime.timezone.utc).isoformat(),
                "tileChannel": {"codename": "one"},
            }
            notifications = []

            def interact(dialog):
                button = next(iter(dialog.event_controls))
                # Kodi's native button emits onClick before the corresponding onAction.
                dialog.onClick(button)
                dialog.onAction(Action(gesture))
                if offset > 0:
                    self.assertTrue(not dialog.closed)
                    self.assertEqual(len(notifications), 1)
                    dialog.onAction(Action(92))
                else:
                    self.assertTrue(dialog.closed)
                    dialog.onClick(dialog.watch_button.getId())

            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(),
                               xbmcgui=fake_xbmcgui(Window(), notifications=notifications))
            WindowXMLDialog.modal_callback = interact
            try:
                result = open_guide(
                    ["one"], lambda *_: [event], lambda *_: [], str, ADDON_ROOT,
                    lambda *_: None, "synthetic-account", datetime.timezone.utc,
                    rewind_observation=lambda _: {"seconds": 7200, "format": "DASH/Widevine"})
                expected = None if offset > 0 else {"channel": "one"}
                if stop < 0:
                    expected["start"] = float(now + offset)
                    expected["stop"] = float(now + stop)
                    expected["programme_id"] = "test"
                self.assertEqual(result, expected)
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_catchup_badge_selects_provider_playback_not_rewind(self):
        now = int(time.time())
        event = {"id": "prg.1", "codename": "programme.1", "title": "Programme",
                 "isBlackouted": False, "isCatchupEnabled": True,
                 "start": datetime.datetime.fromtimestamp(now - 3000, datetime.timezone.utc).isoformat(),
                 "stop": datetime.datetime.fromtimestamp(now - 600, datetime.timezone.utc).isoformat(),
                 "tileChannel": {"codename": "one"}}
        previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
        sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))

        def interact(dialog):
            event_id = next(iter(dialog.event_controls))
            dialog.focused_control = dialog.getControl(event_id)
            dialog.onFocus(event_id)
            badge_id = next(iter(dialog.restart_controls))
            badge = dialog.getControl(badge_id)
            self.assertTrue(badge.noFocusTexture.endswith("guide-catchup.png"))
            self.assertEqual(dialog.start_button.label, "Watch Catch-up")
            self.assertEqual(dialog.control_labels["rewind"], "Catch-up: available for this programme")
            dialog.onClick(badge_id)

        WindowXMLDialog.modal_callback = interact
        try:
            result = open_guide(
                ["one"], lambda *_: [event], lambda *_: [], str, ADDON_ROOT,
                lambda *_: None, "catchup-account", datetime.timezone.utc,
                rewind_observation=lambda _: {"seconds": 7200, "format": "DASH/Widevine"},
                timeshift_denied=lambda _: True,
                catchup_eligible=lambda programme, _: programme is event)
            self.assertEqual(result["channel"], "one")
            self.assertIs(result["catchup"], event)
            self.assertNotIn("start", result)
            self.assertIn("request", result)
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

    def test_rewind_status_matches_programme_and_channel_availability(self):
        now = int(time.time())
        for blacked_out, denied, expected in (
                (True, False, "Rewind: unavailable for this programme"),
                (False, True, "Rewind: unavailable on this channel"),
                (False, False, "Rewind: up to about 1 h 25 min")):
            with self.subTest(blacked_out=blacked_out, denied=denied):
                event = {
                    "id": "current", "title": "Programme", "isBlackouted": blacked_out,
                    "start": datetime.datetime.fromtimestamp(now - 300, datetime.timezone.utc).isoformat(),
                    "stop": datetime.datetime.fromtimestamp(now + 600, datetime.timezone.utc).isoformat(),
                    "tileChannel": {"codename": "one"}}

                def interact(dialog):
                    button = next(iter(dialog.event_controls))
                    dialog.focused_control = dialog.getControl(button)
                    dialog.onFocus(button)
                    self.assertEqual(dialog.control_labels["rewind"], expected)
                    self.assertEqual(dialog.can_start, not (blacked_out or denied))
                    self.assertEqual(bool(dialog.restart_controls), not (blacked_out or denied))
                    dialog.onAction(Action(92))

                WindowXMLDialog.modal_callback = interact
                try:
                    with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(),
                                                       "xbmcgui": fake_xbmcgui(Window())}):
                        open_guide(
                            ["one"], lambda *_: [event], lambda *_: [], str, ADDON_ROOT,
                            self.fail, "rewind-status", datetime.timezone.utc,
                            rewind_observation=lambda _: {"seconds": 5100},
                            timeshift_denied=lambda _: denied)
                finally:
                    WindowXMLDialog.modal_callback = None

    def test_rewind_badge_uses_observation_or_default_and_respects_denials(self):
        now = int(time.time())
        event = {
            "id": "partial", "title": "Programme", "isCatchupEnabled": False,
            "isBlackouted": False,
            "start": datetime.datetime.fromtimestamp(now - 2400, datetime.timezone.utc).isoformat(),
            "stop": datetime.datetime.fromtimestamp(now - 400, datetime.timezone.utc).isoformat(),
            "tileChannel": {"codename": "one"}}
        for observation, denied, blacked_out, expected in (
                ({"seconds": 1200, "format": "DASH/Widevine"}, False, False, True),
                (None, False, False, True),
                ({"seconds": 300, "format": "DASH/Widevine"}, False, False, False),
                ({"seconds": 1200, "format": "DASH/Widevine"}, True, False, False),
                ({"seconds": 1200, "format": "DASH/Widevine"}, False, True, False)):
            event["isBlackouted"] = blacked_out
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))

            def interact(dialog):
                button = next(iter(dialog.event_controls))
                dialog.focused_control = dialog.getControl(button)
                dialog.onFocus(button)
                self.assertEqual(bool(dialog.restart_controls), expected)
                self.assertEqual(dialog.can_start, expected)
                if expected:
                    if observation is not None:
                        self.assertIn("this programme from", dialog.control_labels["rewind"])
                    else:
                        self.assertEqual(dialog.control_labels["rewind"], "Rewind: length not known yet")
                    badge = dialog.getControl(next(iter(dialog.restart_controls)))
                    self.assertTrue(badge.noFocusTexture.endswith("guide-rewind.png"))
                else:
                    self.assertEqual(
                        dialog.control_labels["rewind"],
                        "Rewind: unavailable on this channel" if denied
                        else "Rewind: unavailable for this programme")
                dialog.onAction(Action(92))

            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(["one"], lambda *_: [event], lambda *_: [], str, ADDON_ROOT,
                           lambda *_: None, "rewind-test", datetime.timezone.utc,
                           rewind_observation=lambda _: observation,
                           timeshift_denied=lambda _: denied)
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_inline_restart_and_short_tile_context_route_to_exact_programme(self):
        now = int(time.time())
        for action in ("primary", "restart", "short", "clipped", "stale"):
            short = action == "short"
            clipped = action == "clipped"
            start = now - (20 if short else 10800 if clipped else 1800)
            end = now + (20 if short else 1800)
            event = {
                "id": "test", "title": "Programme", "isCatchupEnabled": True, "isBlackouted": False,
                "start": datetime.datetime.fromtimestamp(start, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(end, datetime.timezone.utc).isoformat(),
                "tileChannel": {"codename": "two"},
            }
            notifications = []

            def interact(dialog):
                button = next(iter(dialog.event_controls))
                if clipped:
                    self.assertFalse(dialog.restart_controls)
                    dialog.focused_control = dialog.getControl(button)
                    dialog.onFocus(button)
                    restart = dialog.start_button.getId()
                    self.assertTrue(dialog.can_start)
                else:
                    restart = next(iter(dialog.restart_controls))
                    main_area, restart_area = map(dialog.getControl, (button, restart))
                    self.assertEqual(restart_area.label, "")
                    self.assertTrue(os.path.isfile(restart_area.noFocusTexture))
                    self.assertNotEqual(restart_area.focusTexture, restart_area.noFocusTexture)
                    self.assertTrue(os.path.isfile(restart_area.focusTexture))
                    self.assertEqual(restart_area.x + 2, main_area.x)
                    self.assertEqual(restart_area.y + 14, main_area.y)
                dialog.onClick(button if action == "primary" else restart)
                dialog.onAction(Action(100))
                if action == "stale":
                    self.assertFalse(dialog.closed)
                    self.assertEqual(len(notifications), 1)
                    dialog.onAction(Action(92))

            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(
                Window(), notifications=notifications, context_choice=1))
            WindowXMLDialog.modal_callback = interact
            try:
                result = open_guide(
                    ["one", "two"], lambda *_: [event], lambda *_: [], str, ADDON_ROOT,
                    lambda *_: None, "synthetic-account", datetime.timezone.utc,
                    confirm_restart=lambda _, event: action != "stale",
                    rewind_observation=lambda _: {"seconds": 14400, "format": "DASH/Widevine"})
                expected = None if action == "stale" else {"channel": "two"}
                if action in ("restart", "short", "clipped"):
                    expected["start"] = float(start)
                    expected["stop"] = float(end)
                    expected["programme_id"] = "test"
                self.assertEqual(result, expected)
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_clipped_tile_shows_scheduled_start_without_changing_geometry_or_restart(self):
        timezone = datetime.timezone(datetime.timedelta(hours=1))
        viewport = datetime.datetime(2026, 11, 18, 14, 30, tzinfo=timezone).timestamp()
        start = datetime.datetime(2026, 11, 18, 13, 25, tzinfo=timezone).timestamp()
        stop = datetime.datetime(2026, 11, 18, 15, 13, tzinfo=timezone).timestamp()
        event = {
            "id": "clipped", "title": "WaPo Bodensee",
            "isCatchupEnabled": True, "isBlackouted": False,
            "start": datetime.datetime.fromtimestamp(
                start, datetime.timezone.utc).isoformat(),
            "stop": datetime.datetime.fromtimestamp(
                stop, datetime.timezone.utc).isoformat(),
            "tileChannel": {"codename": "one"},
        }
        window = Window()
        previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
        sys.modules.update(xbmc=fake_xbmc(),
                           xbmcgui=fake_xbmcgui(window))

        def interact(dialog):
            if getattr(dialog, "clipped_tile_verified", False):
                return
            dialog.view_start = dialog._snap(viewport)
            dialog.anchor = viewport + 60
            dialog._request_view(immediate=True)
            dialog._resolve_selection()
            dialog._render()

            key = guide.programme_key(event)
            button_id = next(
                control_id for control_id, value in dialog.event_controls.items()
                if value[0] == key
            )
            button = dialog.getControl(button_id)
            self.assertTrue(button.label.startswith("13:25  WaPo Bodensee"))
            self.assertTrue(dialog.detail_label.label.startswith("13:25–15:13"))

            pad = max(18, int(dialog.width * 0.02))
            left = (max(124, int(dialog.width * 0.12)) + guide.GUIDE_NUMBER_COLUMN
                    - guide.GUIDE_CELL_TRIM)
            timeline_x = left + 18
            timeline_width = max(100, dialog.width - timeline_x - pad)
            scale = timeline_width / guide.TIMELINE_SECONDS
            x1 = max(timeline_x, int(timeline_x + (start - viewport) * scale))
            x2 = min(timeline_x + timeline_width,
                     int(timeline_x + (stop - viewport) * scale))
            gap_x = guide.guide_tile_gaps(dialog.width, dialog.height)[0]
            self.assertEqual(button.x, x1)
            self.assertEqual(button.width, max(1, x2 - x1 - gap_x))

            self.assertFalse(dialog.restart_controls)
            self.assertTrue(dialog.can_start)
            dialog.onClick(dialog.start_button.getId())
            dialog.clipped_tile_verified = True

        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch("guide.time.time", return_value=viewport + 60):
                result = open_guide(
                    ["one"], lambda *_: [event], lambda *_: self.fail(
                        "the clipped tile should use the cached event"),
                    str, ADDON_ROOT, lambda _: None, "clipped-account", timezone,
                    rewind_observation=lambda _: {"seconds": 7200, "format": "DASH/Widevine"})
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

        self.assertEqual(result, {"channel": "one", "start": float(start), "stop": float(stop),
                                  "programme_id": "clipped"})

    def test_page_actions_move_visible_pages_and_keep_time_focus(self):
        now = int(time.time())
        channels = ["channel-{}".format(index) for index in range(25)]

        def cached(_, visible):
            return [{"id": code, "title": code,
                     "start": datetime.datetime.fromtimestamp(
                         now - 900, datetime.timezone.utc).isoformat(),
                     "stop": datetime.datetime.fromtimestamp(
                         now + 900, datetime.timezone.utc).isoformat(),
                     "tileChannel": {"codename": code}} for code in visible]

        previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
        sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))

        def interact(dialog):
            size = dialog.visible_count
            self.assertGreater(size, 5)
            self.assertLess(size * 3, len(channels))
            for _ in range(5):
                dialog.onAction(Action(4))
            anchor = dialog.anchor

            def expect(index):
                self.assertEqual(dialog.selected_channel, index)
                self.assertEqual(dialog.first_channel,
                                 min((index // size) * size, len(channels) - size))
                self.assertEqual(dialog.anchor, anchor)
                self.assertEqual(guide.programme_key(dialog.selected_programme)[0], channels[index])
                self.assertEqual(dialog.request[0][1],
                                 tuple(channels[dialog.first_channel:dialog.first_channel + size]))
                self.assertEqual(len(dialog.request[0][1]), size)

            expect(5)
            dialog.onAction(Action(6))
            expect(5 + size)
            dialog.onAction(Action(6))
            expect(5 + 2 * size)
            dialog.onAction(Action(6))
            expect(len(channels) - 1)
            dialog.onAction(Action(6))
            expect(len(channels) - 1)
            dialog.onAction(Action(5))
            expect(len(channels) - 1 - size)
            dialog.onAction(Action(5))
            expect(len(channels) - 1 - 2 * size)
            dialog.onAction(Action(5))
            expect(len(channels) - 1 - 3 * size)
            dialog.onAction(Action(5))
            expect(len(channels) - 1 - 3 * size)
            dialog.onAction(Action(184))
            expect(len(channels) - 3 * size)
            dialog.onAction(Action(185))
            expect(len(channels) - 1 - 3 * size)
            dialog.onAction(Action(3))
            expect(len(channels) - 2 - 3 * size)
            dialog.onAction(Action(92))

        WindowXMLDialog.modal_callback = interact
        try:
            open_guide(channels, cached, lambda *_: self.fail("cached page should not load"),
                       str, ADDON_ROOT, lambda *_: None, "page-account", datetime.timezone.utc)
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

    def test_remote_footer_arrows_restore_grid_without_changing_selection(self):
        now = datetime.datetime.now(datetime.timezone.utc)
        channels = ["one", "two", "three"]
        events = [{
            "id": channel, "title": channel,
            "start": (now - datetime.timedelta(minutes=5)).isoformat(),
            "stop": (now + datetime.timedelta(minutes=25)).isoformat(),
            "tileChannel": {"codename": channel},
        } for channel in channels]

        def interact(dialog):
            dialog._move_channel(1)
            for index in (1, 2):
                dialog._move_channel(index - dialog.selected_channel)
                for footer in ("watch_button", "settings_button"):
                    for arrow in (3, 4):
                        dialog.pump_focus()
                        selected = dialog.selected_programme
                        anchor, view = dialog.anchor, dialog.view_start
                        dialog.onAction(Action(117))
                        dialog._focus(getattr(dialog, footer))
                        dialog.pump_focus()
                        dialog.onAction(Action(arrow))
                        dialog.pump_focus()
                        self.assertFalse(dialog.footer_mode)
                        self.assertEqual(dialog.selected_channel, index)
                        self.assertEqual(dialog.selected_programme, selected)
                        self.assertEqual((dialog.anchor, dialog.view_start), (anchor, view))
                        self.assertIn(dialog.getFocusId(), dialog.event_controls)
                if index == 2:
                    dialog.onAction(Action(4))
                    self.assertTrue(dialog.footer_mode)
                    dialog.onAction(Action(3))
                    self.assertFalse(dialog.footer_mode)
                    self.assertEqual(dialog.selected_channel, 2)
            dialog.onAction(Action(92))

        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(),
                                              "xbmcgui": fake_xbmcgui(Window())}):
                open_guide(channels, lambda *_: events, lambda *_: events, str,
                           ADDON_ROOT, self.fail, "footer-arrows", datetime.timezone.utc)
        finally:
            WindowXMLDialog.modal_callback = None

    def test_page_actions_on_short_or_empty_lineup(self):
        for channels in ([], ["one", "two"]):
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))

            def interact(dialog):
                if channels:
                    dialog.onAction(Action(4))
                    self.assertEqual(dialog.selected_channel, 1)
                before = dialog.selected_channel, dialog.anchor
                dialog.onAction(Action(5))
                dialog.onAction(Action(6))
                self.assertEqual((dialog.selected_channel, dialog.anchor), before)
                dialog.onAction(Action(92))

            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(channels, lambda *_: [], lambda *_: [], str, ADDON_ROOT,
                           lambda *_: None, "short-page", datetime.timezone.utc)
            finally:
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module

    def test_latest_view_wins_while_empty_and_watch_remains_reachable(self):
        requests = []
        release_old = threading.Event()
        stale_cancelled = []
        channels = ["channel-{}".format(i) for i in range(35)]

        def make_event(start, channel, title):
            return {"id": title, "title": title, "start": start.isoformat(),
                    "stop": (start + datetime.timedelta(hours=1)).isoformat(),
                    "tileChannel": {"codename": channel}}

        def load(start, visible_channels, cancelled, publish):
            requests.append((start, visible_channels))
            if len(requests) == 1:
                assert release_old.wait(3)
                stale_cancelled.append(cancelled())
                return [make_event(start, visible_channels[0], "Stale programme")]
            return [make_event(start, visible_channels[0], "Active programme")]

        latest = []

        def interact(dialog):
            if not requests:
                return
            if not latest:
                self.assertEqual(dialog.getFocusId(), dialog.watch_button.getId())
                original_anchor = dialog.anchor
                dialog.onAction(Action(4))
                self.assertEqual(dialog.selected_channel, 1)
                self.assertEqual(dialog.anchor, original_anchor)
                dialog.onAction(Action(3))
                dialog.onAction(Action(2))
                self.assertGreater(dialog.view_start, requests[0][0].timestamp())
                for _ in range(2):
                    dialog.onAction(Action(6))
                anchor = dialog.anchor
                dialog.onAction(Action(185))
                dialog.onAction(Action(184))
                self.assertEqual(dialog.selected_channel, 2 * dialog.visible_count)
                self.assertEqual(dialog.anchor, anchor)
                latest.append(dialog.request[0])
                self.assertEqual(len(requests), 1)
                release_old.set()
            elif not dialog.loading:
                self.assertEqual(requests[1:], latest)
                self.assertEqual(stale_cancelled, [True])
                self.assertIn("Active programme", dialog.detail_label.label)
                self.assertEqual(dialog.getFocusId(), next(iter(dialog.event_controls)))
                dialog.onAction(Action(117))
                dialog.pump_focus()
                self.assertEqual(dialog.getFocusId(), dialog.watch_button.getId())
                dialog.onClick(dialog.getFocusId())

        previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
        sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(Window()))
        WindowXMLDialog.modal_callback = interact
        try:
            result = open_guide(
                channels, lambda *_: None, load, str, ADDON_ROOT,
                lambda message: None, "synthetic-account", datetime.timezone.utc)
            self.assertEqual(result, {"channel": latest[0][1][0]})
        finally:
            release_old.set()
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

    def test_open_guide_constructs_and_renders_channel_names_and_logos(self):
        window = Window()
        xbmc = fake_xbmc("de")
        xbmcgui = fake_xbmcgui(window)
        previous = {
            name: sys.modules.get(name)
            for name in ("xbmc", "xbmcgui")
        }
        sys.modules["xbmc"] = xbmc
        sys.modules["xbmcgui"] = xbmcgui
        try:
            now = time.time()
            programme = {
                "id": "event-1",
                "title": "Current programme",
                "description": "First synopsis line.\n" + "Long synopsis text. " * 40,
                "isCatchupEnabled": True, "isBlackouted": False,
                "start": datetime.datetime.fromtimestamp(
                    now - 600, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(
                    now + 1200, datetime.timezone.utc).isoformat(),
                "tileChannel": {
                    "codename": "channel-1",
                    "title": "Provider channel name",
                    "logoUrlOnDark": "special://provider/channel-one.png",
                },
            }
            programme_without_logo = {
                "id": "event-2",
                "title": "Upcoming programme",
                "start": datetime.datetime.fromtimestamp(
                    now + 1800, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(
                    now + 3600, datetime.timezone.utc).isoformat(),
                "tileChannel": {
                    "codename": "channel-3",
                    "title": "Provider fallback name",
                },
            }
            next_programme = {
                "id": "event-3",
                "title": "Next programme",
                "start": datetime.datetime.fromtimestamp(
                    now + 1200, datetime.timezone.utc).isoformat(),
                "stop": datetime.datetime.fromtimestamp(
                    now + 2400, datetime.timezone.utc).isoformat(),
                "tileChannel": {
                    "codename": "channel-1",
                    "title": "Provider channel name",
                    "logoUrl": "special://provider/channel-one-fallback.png",
                },
            }
            static_names = {
                "channel-1": "Static one",
                "channel-2": "Static two",
                "channel-3": "Static three",
            }

            def interact(dialog):
                current_id = next(
                    control_id for control_id, value in dialog.event_controls.items()
                    if value[1]["title"] == "Current programme"
                )
                self.assertEqual(dialog.getFocusId(), current_id)
                self.assertIn("Current programme", dialog.detail_label.label)
                self.assertTrue("First synopsis" not in dialog.detail_label.label)
                lines = [control for key, (_, control) in dialog.slots.items()
                         if isinstance(key, tuple) and key[0] == "synopsis"]
                self.assertTrue(lines[0].label.startswith("First synopsis"))
                self.assertTrue(lines[-1].label.endswith("…"))
                self.assertEqual(dialog.start_button.label, "Zurückspulen versuchen")
                self.assertNotIn("now", dialog.slots)
                self.assertFalse(any(getattr(control, "label", "") in ("JETZT", "NOW")
                                     for _, control in dialog.slots.values()))
                rows = [control for key, (_, control) in dialog.slots.items()
                        if isinstance(key, tuple) and key[0] == "row"]
                name = dialog.slots[("channel", 0)][1]
                logo = dialog.slots[("logo", 0)][1]
                self.assertEqual((logo.x + logo.width // 2, logo.y + logo.height // 2),
                                 (name.x + name.width // 2, name.y + name.height // 2))
                self.assertEqual(logo.width, name.width)
                self.assertEqual((logo.width, logo.height), guide.logo_box(name.width, rows[0].height - 6))
                self.assertGreater(logo.y, rows[0].y)
                self.assertLess(logo.y + logo.height, rows[0].y + rows[0].height)
                self.assertLess(name.x + name.width, dialog.getControl(current_id).x)
                self.assertIn("start=100 end=0", logo.animations[0][1])
                self.assertIn("start=0 end=100", name.animations[0][1])
                self.assertNotIn(("channel", 1), dialog.slots)
                self.assertNotIn(("logo", 2), dialog.slots)
                self.assertTrue(dialog.slots[("channel", 2)][1].label)
                marker = next(control for key, (_, control) in dialog.slots.items()
                              if isinstance(key, tuple) and key[0] == "now-line")
                self.assertGreater(marker.y + marker.height, rows[-1].y)
                self.assertGreater(marker.getId(), current_id)
                title = dialog.getControl(current_id)
                self.assertEqual((title.alignment, title.textOffsetY), (4, 0))
                self.assertIn("Current programme", title.label)
                self.assertLess(lines[-1].y + lines[-1].height, dialog.watch_button.y)
                dialog.onAction(Action(2))
                self.assertEqual(logo.animation_updates, 1)
                self.assertEqual(
                    dialog.selected_programme["title"], "Next programme")
                self.assertIn("Next programme", dialog.detail_label.label)
                dialog.onAction(Action(1))
                self.assertEqual(
                    dialog.selected_programme["title"], "Current programme")
                dialog.onAction(Action(184))
                self.assertEqual(dialog.selected_channel, 1)
                self.assertEqual(logo.animations, [])
                self.assertNotIn(("channel", 0), dialog.slots)
                self.assertIn(("channel", 1), dialog.slots)
                self.assertIn(
                    "keine Programmdaten", dialog.detail_label.label)
                dialog.onAction(Action(185))
                self.assertEqual(dialog.selected_channel, 0)
                self.assertIn("Current programme", dialog.detail_label.label)
                dialog.onAction(Action(92))

            WindowXMLDialog.modal_callback = interact
            result = open_guide(
                ["channel-1", "channel-2", "channel-3"],
                lambda *_: [programme, next_programme, programme_without_logo],
                lambda *_: self.fail("cache hit must not start the worker"),
                lambda channel: static_names[channel],
                ADDON_ROOT,
                lambda message: None,
                "synthetic-account",
                datetime.timezone.utc,
                lambda channel, title: (os.path.join(ADDON_ROOT, "icon.png") if channel == "channel-3"
                                        else "special://mapped/{}.png".format(title.replace(" ", "-"))),
                rewind_observation=lambda _: {"seconds": 7200, "format": "DASH/Widevine"},
            )
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

        self.assertIsNone(result)
        self.assertEqual(
            WindowXMLDialog.constructor_args,
            ("guide.xml", ADDON_ROOT, "Default", "1080i")
        )
        controls = WindowXMLDialog.last_instance._controls
        labels = [control.label for control in controls
                  if isinstance(control, ControlLabel)]
        images = [control for control in controls if isinstance(control, ControlImage)]
        self.assertIn("simpliTVᵀ  |  Live TV", labels)
        self.assertIn("Provider channel name", labels)
        self.assertNotIn("Static two", labels)
        self.assertIn("Provider fallback name", labels)
        self.assertTrue(any(
            image.filename.startswith("image://special%3A%2F%2Fprovider%2Fchannel-one.png/transform?")
            and "scaling_algorithm=lanczos" in image.filename
            and image.aspectRatio == 2 for image in images
        ))
        self.assertTrue(any(
            image.filename.startswith("image://special%3A%2F%2Fmapped%2FStatic-two.png/transform?")
            and image.aspectRatio == 2 for image in images
        ))
        self.assertFalse(any(image.filename == os.path.join(ADDON_ROOT, "icon.png") for image in images))
        skins = os.path.join(ADDON_ROOT, "resources", "skins", "Default")
        texture = ET.parse(os.path.join(skins, "1080i", "guide.xml")).findtext(".//texture")
        self.assertTrue(os.path.isfile(os.path.join(skins, "media", texture)))

    def test_render_failure_logs_and_closes_owned_dialog(self):
        window = Window()
        xbmc = fake_xbmc()

        def failing_label(*args, **kwargs):
            raise TypeError("synthetic render failure")

        xbmcgui = fake_xbmcgui(window, failing_label)
        previous = {
            name: sys.modules.get(name)
            for name in ("xbmc", "xbmcgui")
        }
        sys.modules["xbmc"] = xbmc
        sys.modules["xbmcgui"] = xbmcgui
        log_messages = []
        try:
            with self.assertRaises(RuntimeError):
                open_guide(
                    ["channel-1"], lambda *_: [], lambda *_: [],
                    lambda channel: "Channel one", ADDON_ROOT,
                    log_messages.append, "synthetic-account",
                    datetime.timezone.utc
                )
        finally:
            WindowXMLDialog.modal_callback = None
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

        dialog = WindowXMLDialog.last_instance
        self.assertTrue(dialog.was_closed)
        self.assertTrue(dialog.cancel.is_set())
        self.assertTrue(any("Guide render failed" in message for message in log_messages))
        self.assertTrue(any("Traceback" in message for message in log_messages))

    def test_immediate_fetch_failure_repaints_without_remote_input(self):
        class DeferredLabel(ControlLabel):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.painted_label = self.label

            def setAnimations(self, animations):
                super().setAnimations(animations)
                # Model Kodi's idle frame retaining queued label-only updates.
                self.painted_label = self.label

        def load(*_):
            raise LiveDataError("synthetic immediate failure")

        def interact(dialog):
            if not dialog.loading:
                status = dialog.slots["status"][1]
                self.assertEqual(status.painted_label, "Programme data unavailable")
                self.assertEqual(dialog.getFocusId(), dialog.watch_button.getId())
                dialog.close()

        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch.dict(sys.modules, {"xbmc": fake_xbmc(),
                                              "xbmcgui": fake_xbmcgui(
                                                  Window(), control_label=DeferredLabel)}):
                open_guide(["one"], lambda *_: None, load, str, ADDON_ROOT,
                           lambda _: None, "immediate-error", datetime.timezone.utc)
        finally:
            WindowXMLDialog.modal_callback = None

    def test_provider_fetch_failure_reaches_localized_notification(self):
        notifications, logs = [], []
        failure = LiveDataError("", provider=ProviderFailure(403, 9602))

        def load(*_):
            raise failure

        def interact(dialog):
            if not dialog.loading:
                self.assertEqual(len(notifications), 1)
                self.assertTrue(notifications[0].startswith("simpliTV Fehler 9602 (HTTP 403)"))
                self.assertIn("VPN", notifications[0])
                dialog.close()

        xbmc = fake_xbmc()
        xbmc.getLanguage = lambda *_: "de"
        WindowXMLDialog.modal_callback = interact
        try:
            with mock.patch.dict(sys.modules, {"xbmc": xbmc, "xbmcgui": fake_xbmcgui(
                    Window(), notifications=notifications)}):
                open_guide(["one"], lambda *_: None, load, str, ADDON_ROOT,
                           logs.append, "provider-error", datetime.timezone.utc)
        finally:
            WindowXMLDialog.modal_callback = None

    def test_background_completion_failure_and_late_results(self):
        for outcome in ("complete", "partial failure", "failure", "close"):
            release_worker = threading.Event()
            worker_done = threading.Event()
            saw_partial = []
            log_messages = []
            now = datetime.datetime.now(datetime.timezone.utc)
            programme = {
                "id": 1, "title": "Arrived in background",
                "start": (now - datetime.timedelta(minutes=5)).isoformat(),
                "stop": (now + datetime.timedelta(minutes=5)).isoformat(),
                "tileChannel": {"codename": "channel-1"},
            }

            def load(visible, channels, cancelled, publish):
                try:
                    if outcome == "failure":
                        raise LiveDataError("synthetic listing failure")
                    if outcome != "close":
                        publish((programme,))
                    if not release_worker.wait(4):
                        raise AssertionError("UI did not receive progress")
                    if outcome == "partial failure":
                        raise LiveDataError("synthetic second range failure")
                    if outcome == "close":
                        assert cancelled()
                        publish((programme,))
                    return [programme]
                finally:
                    worker_done.set()

            def interact(dialog):
                if outcome == "close":
                    if dialog.loading:
                        dialog.onAction(Action(92))
                    return
                if dialog.loading and dialog.programmes:
                    saw_partial.append(True)
                    self.assertIn("Arrived in background", dialog.detail_label.label)
                    if len(saw_partial) == 1:
                        focus_snapshot[:] = [dialog.getFocusId(), dialog.focus_calls,
                                             dialog.removals, dialog._next_id]
                    release_worker.set()
                if not dialog.loading:
                    if outcome != "failure":
                        self.assertEqual(
                            [dialog.getFocusId(), dialog.focus_calls, dialog.removals,
                             dialog._next_id], focus_snapshot)
                    dialog.onAction(Action(92))

            focus_snapshot = []
            window = Window()
            previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcgui")}
            sys.modules.update(xbmc=fake_xbmc(), xbmcgui=fake_xbmcgui(window))
            WindowXMLDialog.modal_callback = interact
            try:
                open_guide(
                    ["channel-1"], lambda *_: None, load, lambda _: "Channel one",
                    ADDON_ROOT, log_messages.append, "synthetic-account",
                    datetime.timezone.utc
                )
                dialog = WindowXMLDialog.last_instance
                release_worker.set()
                self.assertTrue(worker_done.wait(5))
                self.assertTrue(dialog.cancel.is_set())
                self.assertIsNone(dialog.pending)
                labels = [control.label for control in dialog._controls
                          if isinstance(control, ControlLabel)]
                if outcome == "close":
                    self.assertEqual(dialog.programmes, [])
                else:
                    self.assertEqual(dialog.loading, False)
                    self.assertEqual(bool(saw_partial), outcome != "failure")
                    if outcome == "failure":
                        self.assertIn("Programme data unavailable", labels)
                        self.assertEqual(dialog.programmes, [])
                    else:
                        self.assertEqual(list(dialog.programmes), [programme])
                    if outcome == "partial failure":
                        self.assertIn("Programme guide incomplete", labels)
                    if outcome.endswith("failure"):
                        self.assertTrue(bool(log_messages))
            finally:
                release_worker.set()
                WindowXMLDialog.modal_callback = None
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module


if __name__ == "__main__":
    unittest.main()
