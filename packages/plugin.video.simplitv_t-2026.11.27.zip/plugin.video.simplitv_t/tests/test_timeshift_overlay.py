import datetime
import json
import os
import sys
import types
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import timeshift_overlay as overlay
from seek_timeline import SeekGesture, boundary_target, strip_cells
from seek_schedule import SeekSchedule


class TimeshiftTests(unittest.TestCase):
    def test_seek_burst_accumulates_from_pending_and_resets_step(self):
        state = SeekGesture()
        for i, target in enumerate((430, 460, 490, 520, 640, 760)):
            state.tap(1, 400, 900, i / 10)
            self.assertEqual(state.pending(i / 10), target)
            self.assertIsNone(state.dispatch(900, i / 10))
        self.assertEqual(state.dispatch(700, 1.06), 700)
        state.tap(-1, 400, 700, 1.1)
        self.assertEqual(state.pending(1.1), 670)
        state.tap(-1, 400, 700, 2)
        self.assertIsNone(state.dispatch(700, 2.55))
        state.observe(700, 700, 2.55)
        self.assertEqual(state.dispatch(700, 2.56), 640)
        state.observe(640, 700, 2.6)
        self.assertIsNone(state.pending(2.6))
        state.tap(-1, 4, 700, 4)
        self.assertEqual(state.dispatch(700, 4.6), 0)

    def test_ten_rapid_skips_ignore_bad_readback_and_send_one_seek(self):
        state = SeekGesture()
        state.observe(14380, 14400, 0)
        for i in range(10):
            now = i * 0.12
            position = state.observe(2147486 if i else 14380, 14400, now)
            state.skip(-600, position, 14400, now)
            self.assertIsNone(state.dispatch(14400, now))
        self.assertEqual(state.dispatch(14400, 1.7), 8380)
        self.assertEqual(state.observe(14386, 14400, 1.8), 14380)
        self.assertEqual(state.observe(0, 14400, 1.9), 14380)
        self.assertEqual(state.observe(8381, 14400, 2), 8381)
        self.assertIsNone(state.pending(2))

    def test_quiet_gap_tap_survives_inflight_seek(self):
        state = SeekGesture()
        state.observe(1000, 2000, 0)
        state.tap(-1, 1000, 2000, 0)
        self.assertEqual(state.dispatch(2000, 0.6), 970)
        position = state.observe(1999, 2000, 1.2)
        self.assertEqual(position, 1000)
        state.tap(-1, position, 2000, 1.2)
        self.assertEqual(state.pending(1.2), 940)
        self.assertIsNone(state.dispatch(2000, 1.8))
        state.observe(971, 2000, 1.9)
        self.assertEqual(state.dispatch(2000, 1.9), 940)

    def test_native_pending_ignores_collapsed_preview_between_steps(self):
        pending = overlay.NativeSeekTarget()
        samples = [
            (0.0, True, "03:59:10", 14380, 14350),
            (0.4, True, "03:59:04", 14380, 14344),
            (0.8, True, "03:59:35", 14375, 14344),
            (1.0, False, "", 14375, 14344),
            (1.26, False, "", 14345, None),
        ]
        for now, seeking, preview, position, expected in samples:
            target = pending.update(seeking, lambda: preview, position, 14400, now)
            self.assertEqual(target, expected)
            label = overlay.overlay_label(position if target is None else target, 14400, 1_700_000_000)
            self.assertNotIn("-00:00:25", label)
        self.assertIn("-00:00:55", label)

    def test_native_pending_expires_without_a_new_preview_or_arrival(self):
        pending = overlay.NativeSeekTarget()
        self.assertEqual(pending.update(True, lambda: "03:50:30", 14390, 14400, 0), 13830)
        self.assertEqual(pending.update(True, lambda: "03:50:30", 14390, 14400, 0.3), 13830)
        self.assertEqual(pending.update(True, lambda: "", None, 14400, 0.6), 13830)
        self.assertIsNone(pending.update(True, lambda: "03:59:50", 14390, 14400, 0.81))
        self.assertIsNone(pending.update(True, lambda: "03:50:30", 14390, 14400, 0.85))
        self.assertEqual(pending.update(True, lambda: "03:50:00", 14390, 14400, 0.9), 13800)

    def test_background_schedule_covers_rewind_and_survives_cache_expiry(self):
        edge, duration = 1_700_000_000, 14400
        fresh = [(edge - 600, edge + 600, "Current")]
        calls = []

        def load(channel, start, stop, cancelled):
            calls.append((channel, start, stop))
            iso = lambda seconds: datetime.datetime.fromtimestamp(
                seconds, datetime.timezone.utc).isoformat()
            return [{"tileChannel": {"codename": channel}, "start": iso(start),
                     "stop": iso(stop), "title": "Fetched"}]

        schedule = SeekSchedule("one", lambda _: fresh, self.fail, load)
        try:
            self.assertEqual(schedule.update(edge, duration, 1), fresh)
            schedule.worker.join(1)
            self.assertFalse(schedule.worker.is_alive())
            rows = schedule.update(edge, duration, 2)
            self.assertLessEqual(min(row[0] for row in rows), edge - duration)
            self.assertGreaterEqual(max(row[1] for row in rows), edge)
            self.assertEqual(len(calls), 2)
            fresh.clear()
            self.assertEqual(schedule.update(edge + 310, duration, 312), rows)
            schedule.worker.join(1)
            refreshed = schedule.update(edge + 310, duration, 313)
            self.assertEqual(len(calls), 3)
            self.assertGreater(calls[-1][1], edge - 600)
            self.assertGreaterEqual(max(row[1] for row in refreshed), edge + 310)
        finally:
            schedule.close()

    def test_tagged_hold_replaces_queued_taps_and_jumps_only_once(self):
        state = SeekGesture()
        state.tap(-1, 500, 900, 0)
        state.tap(-1, 500, 900, 0.3)
        self.assertEqual(state.hold_origin(-1, 500, 0.51), 500)
        self.assertIsNone(state.dispatch(900, 1))
        self.assertIsNone(state.hold_origin(-1, 500, 0.6))
        self.assertIsNone(state.hold_origin(-1, 500, 0.7))
        state.tap(-1, 500, 900, 0.9)
        self.assertEqual(state.hold_origin(-1, 500, 1.4), 500)

    def test_opposite_hold_uses_queued_target_ahead_of_inflight_seek(self):
        state = SeekGesture()
        state.observe(10040, 14400, 0)
        state.tap(-1, 10040, 14400, 0)
        self.assertEqual(state.dispatch(14400, 0.6), 10010)
        state.tap(-1, 10040, 14400, 0.7)
        self.assertEqual(state.hold_origin(1, 10040, 0.8), 9980)
        self.assertEqual(state.target, 9980)

        same = SeekGesture()
        same.observe(10040, 14400, 0)
        same.tap(-1, 10040, 14400, 0)
        self.assertEqual(same.dispatch(14400, 0.6), 10010)
        same.tap(-1, 10040, 14400, 0.7)
        self.assertEqual(same.hold_origin(-1, 10040, 0.8), 9980)

    def test_forward_jump_only_advances_past_a_confirmed_boundary(self):
        rows = [(0, 10000, "current"), (10000, 12000, "next")]
        state = SeekGesture()
        state.observe(8500, 14400, 0)
        self.assertEqual(boundary_target(rows, state.boundary_position(9998), 14400, 14400, 1), 10000)
        state.queue(10000, 14400, 0, boundary=True)
        self.assertEqual(state.dispatch(14400, 0), 10000)
        self.assertEqual(state.observe(9998, 14400, 0.1), 9998)
        self.assertEqual(boundary_target(rows, state.boundary_position(9998), 14400, 14400, 1), 12000)
        self.assertEqual(state.boundary_position(9980), 9980)
        state.observe(9980, 14400, 0.15)
        self.assertEqual(state.boundary_position(9998), 9998)
        state.queue(9998, 14400, 0.2)
        self.assertEqual(state.dispatch(14400, 0.2), 9998)
        state.observe(9998, 14400, 0.3)
        self.assertEqual(state.boundary_position(9998), 9998)

    def test_boundaries_and_strip_clip_to_window_and_leave_schedule_gaps(self):
        rows = [(0, 100, "expired"), (100, 220, "first"),
                (300, 400, "second"), (400, 550, "airing"), (550, 650, "future")]
        self.assertEqual(strip_cells(rows, 350, 500, 350),
                         [(0, 70, "first"), (150, 100, "second"), (250, 100, "airing")])
        self.assertEqual(boundary_target(rows, 250, 350, 500, -1), 150)
        self.assertEqual(boundary_target(rows, 258, 350, 500, -1), 150)
        self.assertEqual(boundary_target(rows, 264, 350, 500, -1), 250)
        self.assertEqual(boundary_target(rows, 50, 350, 500, -1), 0)
        self.assertEqual(boundary_target(rows, 270, 350, 500, 1), 350)
        self.assertEqual(boundary_target(rows, 170, 350, 500, 1), 250)
        self.assertIsNone(boundary_target(rows, 100, 350, 500, 1))

    def test_strip_uses_one_marker_for_pending_and_actual_landing(self):
        window, addon = Mock(), Mock()
        props = {}
        window.getWidth.return_value = 1000
        window.getHeight.return_value = 500
        window.setProperty.side_effect = props.__setitem__
        window.getProperty.side_effect = props.get
        window.clearProperty.side_effect = props.pop
        addon.getAddonInfo.return_value = "addon-path"
        gui = types.SimpleNamespace(ControlImage=lambda *_, **kw: Mock(),
                                    ControlLabel=lambda *args, **kw: Mock(bounds=args[:4], options=kw))
        with patch.dict(sys.modules, {"xbmcgui": gui}), \
                patch.object(overlay, "skin_font", side_effect=lambda fonts=("font13",): fonts[0]):
            strip = overlay.SeekStrip(window, addon, overlay.SHOW_CONDITION)
        edge = 1_700_002_800
        strip.update([(edge - 14400, edge - 7200, "First"),
                      (edge - 5040, edge + 200, "Second")], 3600, 14400, edge, 10800)
        strip.marker.setPosition.assert_called_once_with(
            strip.left + round(10800 / 14400 * strip.width), strip.top)
        # The guide's safe margins at the bottom and right.
        self.assertEqual(strip.top + 2 * strip.row, 500 - 12)
        self.assertEqual(strip.left + strip.width, 1000 - 20)
        self.assertEqual(len(strip.controls), 4 + 2 * len(strip.tiles + strip.ruler))
        strip.controls[2].setAnimations.assert_called_once_with(overlay.FADE)
        start = datetime.datetime.fromtimestamp(edge - 5040).strftime("%H:%M")
        self.assertEqual(strip.tiles[2][1].setLabel.call_args.args, (start + "  Second",))
        self.assertIsNone(strip.layout[1][2])
        strip.tiles[1][1].setVisible.assert_called_with(False)
        # The marker sits in "Second": it alone gets the guide's selected-cell colour.
        strip.tiles[2][0].setColorDiffuse.assert_called_with(overlay.TILE_ACTIVE_COLOR)
        strip.tiles[0][0].setColorDiffuse.assert_called_with(overlay.TILE_COLOR)
        title = strip.tiles[2][1]
        self.assertEqual(title.bounds[1::2], (strip.tile_y, 24))
        self.assertEqual(title.options["alignment"], 4)
        self.assertEqual(title.options["font"], "font10")
        tick_x = overlay.ruler_ticks(14400, edge, strip.width, strip.tick_width * 1.5)[2][0]
        self.assertEqual(strip.ruler[2][0].setPosition.call_args.args[0], strip.left + tick_x)
        self.assertEqual(strip.marker.setAnimations.call_args.args, (overlay.FADE,))
        self.assertIn(overlay.SHOW_CONDITION, strip.marker.setVisibleCondition.call_args.args[0])
        strip.update([], 9600, 14400, edge, None)
        strip.ruler[2][0].setVisible.assert_called_with(True)
        strip.marker.setPosition.assert_called_with(
            strip.left + round(9600 / 14400 * strip.width), strip.top)
        strip.tiles[1][1].setVisible.assert_called_with(False)
        strip.hide()
        self.assertFalse(props)
        strip.close()
        window.removeControls.assert_called_once_with(strip.controls)

    def test_strip_highlight_survives_relayout_and_tile_reuse(self):
        window, addon = Mock(), Mock()
        window.getWidth.return_value = 1000
        window.getHeight.return_value = 500
        addon.getAddonInfo.return_value = "addon-path"
        gui = types.SimpleNamespace(ControlImage=lambda *_, **kw: Mock(),
                                    ControlLabel=lambda *_, **kw: Mock())
        with patch.dict(sys.modules, {"xbmcgui": gui}), \
                patch.object(overlay, "skin_font", side_effect=lambda fonts=("font13",): fonts[0]):
            strip = overlay.SeekStrip(window, addon, overlay.SHOW_CONDITION)
        edge = 1_700_002_800

        def colours():
            return [tile.setColorDiffuse.call_args.args[0] if tile.setColorDiffuse.called
                    else overlay.TILE_COLOR for tile, _ in strip.tiles]

        halves = [(edge - 14400, edge - 7200, "A"), (edge - 7200, edge, "B")]
        strip.update(halves, 10800, 14400, edge, None)
        self.assertEqual(colours()[:2], [overlay.TILE_COLOR, overlay.TILE_ACTIVE_COLOR])
        # New layout, and the playhead now falls in tile 0.
        strip.update([(edge - 14400, edge - 3600, "C"), (edge - 3600, edge, "D")],
                     3600, 14400, edge, None)
        self.assertEqual(colours()[:2], [overlay.TILE_ACTIVE_COLOR, overlay.TILE_LIVE_COLOR])
        # No cells: nothing may stay highlighted, even on hidden tiles awaiting reuse.
        strip.update([], 3600, 14400, edge, None)
        self.assertNotIn(overlay.TILE_ACTIVE_COLOR, colours())
        strip.update(halves, 10800, 14400, edge, None)
        self.assertEqual(colours().count(overlay.TILE_ACTIVE_COLOR), 1)
        self.assertEqual(colours()[:2], [overlay.TILE_COLOR, overlay.TILE_ACTIVE_COLOR])

    def test_owned_badge_follows_marker_and_clamps_away_from_ruler(self):
        window, addon, gui = Mock(), Mock(), Mock()
        window.getWidth.return_value = 720
        window.getHeight.return_value = 480
        addon.getAddonInfo.return_value = "addon-path"
        with patch.dict(sys.modules, {"xbmcgui": gui}), patch.object(overlay, "skin_font", return_value="font13"):
            strip = overlay.SeekStrip(window, addon, status=True)
        strip.update([], 20, 100, 100, 0, status="21:47 · −1:40")
        left, width = strip.status_bounds
        self.assertGreaterEqual(left, 0)
        self.assertLessEqual(strip.status_y + strip.row, strip.ruler_y)
        strip.update([], 20, 100, 100, 50, status="21:48 · −0:50")
        self.assertAlmostEqual(strip.status_bounds[0] + width / 2, strip.marker_x, delta=2)
        strip.update([], 20, 100, 100, 100, status="LIVE")
        left, live_width = strip.status_bounds
        self.assertLess(live_width, width)
        self.assertLessEqual(left + live_width, 720)

    def test_strip_shows_the_logo_alone_or_the_name_without_one(self):
        window, addon, gui = Mock(), Mock(), Mock()
        window.getWidth.return_value = 1280
        window.getHeight.return_value = 720
        addon.getAddonInfo.return_value = "addon-path"
        gui.ControlImage.side_effect = lambda *args, **kw: Mock(bounds=args[:4], kind="image")
        gui.ControlLabel.side_effect = lambda *args, **kw: Mock(bounds=args[:4], kind="label",
                                                                 title=args[4])
        with patch.dict(sys.modules, {"xbmcgui": gui}), patch.object(overlay, "skin_font", return_value="font10"):
            with_logo = overlay.SeekStrip(window, addon, logo="cached.png", station="Station")
            without = overlay.SeekStrip(window, addon, station="Station")
        logo = with_logo.controls[2]
        self.assertEqual(logo.kind, "image")
        self.assertFalse(any(getattr(c, "title", None) == "Station" for c in with_logo.controls))
        # No logo/name cross-fade: the logo only fades in and out with the strip.
        logo.setAnimations.assert_called_once_with(overlay.FADE)
        name = without.controls[2]
        self.assertEqual((name.kind, name.title), ("label", "Station"))
        name.setAnimations.assert_called_once_with(overlay.FADE)
        # Both sit centred on the strip's two rows, inside the bottom margin.
        for strip, control in ((with_logo, logo), (without, name)):
            self.assertEqual(control.bounds[1] + control.bounds[3] // 2, strip.top + strip.row)
            self.assertLessEqual(strip.top + 2 * strip.row, 720 - strip.bottom_margin)

    def test_numbered_strip_matches_guide_column_and_preserves_logo_size(self):
        from guide import GUIDE_CELL_TRIM, GUIDE_NUMBER_COLUMN, guide_tile_gaps

        window, addon, gui = Mock(), Mock(), Mock()
        window.getWidth.return_value = 1280
        window.getHeight.return_value = 720
        addon.getAddonInfo.return_value = "addon-path"
        gui.ControlImage.side_effect = lambda *args, **kw: Mock(bounds=args[:4], kind="image")
        gui.ControlLabel.side_effect = lambda *args, **kw: Mock(bounds=args[:4], kind="label",
                                                                 title=args[4])
        with patch.dict(sys.modules, {"xbmcgui": gui}), patch.object(overlay, "skin_font", return_value="font10"):
            plain = overlay.SeekStrip(window, addon, logo="cached.png", station="Station")
            numbered = overlay.SeekStrip(window, addon, logo="cached.png", station="Station", number=130)
        self.assertEqual(numbered.left, max(124, int(1280 * .12))
                         + GUIDE_NUMBER_COLUMN - GUIDE_CELL_TRIM + 18)
        self.assertEqual(numbered.gap, guide_tile_gaps(1280, 720)[0])
        self.assertEqual(numbered.controls[2].bounds[2], plain.controls[2].bounds[2])
        number = next(control for control in numbered.controls if getattr(control, "title", None) == "130")
        self.assertLessEqual(number.bounds[0] + number.bounds[2], numbered.controls[2].bounds[0])

    def test_strip_leaves_narrow_tiles_blank_and_prescales_logo(self):
        window, addon, gui = Mock(), Mock(), Mock()
        window.getWidth.return_value = 1280
        window.getHeight.return_value = 720
        addon.getAddonInfo.return_value = "addon-path"
        gui.ControlImage.side_effect = lambda *args, **kw: Mock(args=args)
        gui.ControlLabel.side_effect = lambda *args, **kw: Mock()
        with patch.dict(sys.modules, {"xbmcgui": gui}), patch.object(overlay, "skin_font", return_value="font10"):
            strip = overlay.SeekStrip(window, addon, logo="special://thumbnails/a/b.png", station="S",
                                      status=True)
        logo = strip.controls[2]
        self.assertTrue(logo.args[4].startswith("image://special%3A%2F%2Fthumbnails"), logo.args[4])
        self.assertIn("scaling_algorithm=lanczos", logo.args[4])
        edge = 1_700_002_800
        # 14400 s over ~1152 px: 3 min is ~24 px, 6 min ~48 px, 2 h is wide.
        strip.update([(edge - 7200, edge - 7020, "Tiny"), (edge - 7020, edge - 6660, "Short"),
                      (edge - 6660, edge, "Long programme")], 7000, 14400, edge, None)
        texts = [tile[1].setLabel.call_args.args[0] if tile[1].setLabel.called else ""
                 for tile in strip.tiles[:4]]
        self.assertIsNone(strip.layout[0][2])
        self.assertEqual(texts[:2], ["", ""])
        self.assertEqual(texts[2], "")
        self.assertTrue(texts[3].endswith("  Long programme"))
        for _, label in strip.tiles[:3]:
            label.setVisible.assert_called_with(False)
        self.assertFalse(any("…" in text or ".." in text for text in texts))

    def test_overlay_uses_supported_label_constructor(self):
        controls = []

        def control_label(x, y, width, height, label, font="font13",
                          textColor="FFFFFFFF", disabledColor="", alignment=0,
                          hasPath=False, angle=0):
            control = Mock()
            controls.append(control)
            return control

        window = Mock()
        window.getWidth.return_value = 1920
        window.getHeight.return_value = 1080
        addon = Mock()
        addon.getAddonInfo.return_value = "addon-path"
        gui = types.SimpleNamespace(
            Window=lambda window_id: window,
            ControlImage=Mock(), ControlLabel=control_label
        )
        with patch.dict(sys.modules, {"xbmcgui": gui}), \
                patch.object(overlay, "skin_font", return_value="font13"):
            instance = overlay.Overlay(addon)
            instance.update("test")
            instance.close()
        controls[0].setLabel.assert_called_once_with("test", shadowColor="FF000000")
        for control in instance.controls:
            control.setAnimations.assert_called_once_with([
                ("Visible", "effect=fade start=0 end=100 time=200"),
                ("Hidden", "effect=fade start=100 end=0 time=200"),
            ])
        window.removeControls.assert_called_once()

    def test_time_labels(self):
        for text, seconds in [("03:50:30", 13830), ("09:30", 570),
                              ("-00:00:10", -10), ("+00:00:10", 10),
                              ("00:00:00", 0), ("", None)]:
            with self.subTest(text=text):
                self.assertEqual(overlay.parse_time(text), seconds)

    def test_invalid_time_labels(self):
        for text in ["unknown", "00:99:00", "1:2:3:4", "00:x"]:
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    overlay.parse_time(text)

    def test_pending_destination_and_clock(self):
        now = datetime.datetime(2026, 11, 6, 16, 4, 0).timestamp()
        label = overlay.overlay_label(13830, 14400, now)
        self.assertEqual(label, "[B]-00:09:30[/B]  [COLOR FF999999]/ 04:00:00[/COLOR]"
                         "     Sendezeit ~ [B]15:54:30[/B]")
        self.assertTrue(overlay.overlay_label(13830, 14400, now, german=False).endswith(
            "     Broadcast time ~ [B]15:54:30[/B]"))

    def test_seek_boundaries(self):
        now = datetime.datetime(2026, 11, 6, 16, 4).timestamp()
        self.assertIn("-00:00:00", overlay.overlay_label(15000, 14400, now))
        self.assertIn("-04:00:00", overlay.overlay_label(-10, 14400, now))

    def test_midnight(self):
        now = datetime.datetime(2026, 11, 7, 0, 5).timestamp()
        self.assertIn("23:55:00", overlay.overlay_label(13800, 14400, now))

    def test_pause_with_frozen_duration_keeps_broadcast_time_fixed(self):
        clock = overlay.PauseClock()
        now = datetime.datetime(2026, 11, 6, 16, 4).timestamp()
        for elapsed in (0, 1, 30, 60):
            extra = clock.update(14400, True, elapsed)
            label = overlay.overlay_label(13830, 14400, now + elapsed, extra)
            self.assertIn("-" + overlay.format_duration(570 + elapsed), label)
            self.assertIn("15:54:30", label)
            self.assertIn("/ 04:00:00", label)

    def test_pause_with_growing_duration_does_not_double_count(self):
        clock = overlay.PauseClock()
        self.assertEqual(clock.update(14400, True, 0), 0)
        self.assertEqual(clock.update(14430, True, 30), 0)

    def test_resume_preserves_delay_until_duration_catches_up(self):
        clock = overlay.PauseClock()
        clock.update(14400, True, 0)
        self.assertEqual(clock.update(14400, False, 60), 60)
        self.assertEqual(clock.update(14400, False, 61), 60)
        self.assertEqual(clock.update(14460, False, 61), 0)

    def test_pending_seek_while_paused_changes_broadcast_target(self):
        clock = overlay.PauseClock()
        now = datetime.datetime(2026, 11, 6, 16, 4).timestamp()
        clock.update(14400, True, 0)
        extra = clock.update(14400, True, 30)
        label = overlay.overlay_label(13770, 14400, now + 30, extra)
        self.assertIn("-00:11:00", label)
        self.assertIn("15:53:30", label)

    def test_invalid_timeline(self):
        for position, duration in [(0, 0), (0, -1), (float("nan"), 14400),
                                   (0, float("inf"))]:
            with self.assertRaises(ValueError):
                overlay.overlay_label(position, duration, 0)

    def test_worker_updates_pending_seek_and_cleans_up(self):
        request = json.dumps({"url": "https://example.invalid/live.mpd", "token": "test",
                              "channel": "one", "account": "test-scope"})
        properties = {overlay.REQUEST_PROPERTY: request}
        home = Mock()
        home.getProperty.side_effect = lambda name: properties.get(name, "")
        home.setProperty.side_effect = lambda name, value: properties.update({name: value})
        home.clearProperty.side_effect = lambda name: properties.pop(name, None)
        addon = Mock()
        addon.getSetting.return_value = "true"
        player = Mock()
        player.isPlayingVideo.side_effect = [True, True, False]
        player.getPlayingFile.return_value = "https://example.invalid/live.mpd|User-Agent=test"
        player.getTotalTime.return_value = 14400
        player.getTime.return_value = 14390
        monitor = Mock()
        monitor.abortRequested.return_value = False
        xbmc = types.SimpleNamespace(
            Monitor=lambda: monitor, Player=lambda: player,
            getSkinDir=lambda: "skin.estuary", getCondVisibility=lambda condition: True,
            ISO_639_1=0, getLanguage=lambda _: "de",
            getInfoLabel=lambda label: "03:50:30", log=Mock(),
            LOGWARNING=2, LOGERROR=3
        )
        modules = {
            "xbmc": xbmc,
            "xbmcaddon": types.SimpleNamespace(Addon=lambda *args: addon),
            "xbmcgui": types.SimpleNamespace(Window=lambda window_id: home, Dialog=Mock())
        }
        instance, strip = Mock(), Mock()
        rows = [(1_699_985_600, 1_700_000_000, "One")]
        with patch.dict(sys.modules, modules), \
                patch.object(overlay, "Overlay", return_value=instance), \
                patch.object(overlay, "SeekStrip", return_value=strip), \
                patch.object(overlay, "load_schedule", None), \
                patch.object(overlay.time, "time", return_value=1_700_000_000), \
                patch.object(overlay, "channel_schedule", return_value=rows) as schedule:
            overlay.run()
        self.assertIn("-00:09:30", instance.update.call_args.args[0])
        self.assertEqual(schedule.call_args.args[0].account, "test-scope")
        self.assertEqual(schedule.call_args.args[1], "one")
        self.assertEqual(strip.update.call_args.args[:3], (rows, 14390, 14400))
        self.assertEqual(strip.update.call_args.args[4], 13830)
        strip.close.assert_called_once()
        instance.close.assert_called_once()
        self.assertEqual(properties, {})

    def test_disabled_overlay_does_not_launch(self):
        addon = Mock()
        addon.getSetting.return_value = "false"
        builtin = Mock()
        window = Mock()
        modules = {
            "xbmc": types.SimpleNamespace(executebuiltin=builtin),
            "xbmcaddon": types.SimpleNamespace(Addon=lambda: addon),
            "xbmcgui": types.SimpleNamespace(Window=window)
        }
        with patch.dict(sys.modules, modules):
            overlay.launch("https://example.invalid/live.mpd")
        builtin.assert_not_called()
        window.assert_not_called()

    def test_direct_playback_remembers_only_after_matching_video_starts(self):
        properties = {}
        home, addon, player, monitor = Mock(), Mock(), Mock(), Mock()
        home.getProperty.side_effect = lambda name: properties.get(name, "")
        home.setProperty.side_effect = lambda name, value: properties.update({name: value})
        home.clearProperty.side_effect = lambda name: properties.pop(name, None)
        addon.getSetting.return_value = "false"  # The overlay itself may be disabled.
        addon.getAddonInfo.return_value = "addon-path"
        player.isPlayingVideo.side_effect = [False, True]
        player.getPlayingFile.return_value = "https://example.invalid/live.mpd"
        monitor.abortRequested.return_value = False
        modules = {
            "xbmc": types.SimpleNamespace(executebuiltin=Mock(), Monitor=lambda: monitor,
                                          Player=lambda: player),
            "xbmcaddon": types.SimpleNamespace(Addon=lambda *_: addon),
            "xbmcgui": types.SimpleNamespace(Window=lambda _: home),
        }
        with patch.dict(sys.modules, modules), \
                patch.object(overlay, "remember_started_channel") as remember:
            overlay.launch("https://example.invalid/live.mpd", "one", "account", remember=True)
            self.assertTrue(json.loads(properties[overlay.REQUEST_PROPERTY])["remember"])
            remember.assert_not_called()
            overlay.run()
            remember.assert_called_once_with(addon, "one", "account")
        self.assertEqual(properties, {})

    def test_started_channel_is_not_saved_for_a_changed_account_or_disabled_setting(self):
        addon, session, store = Mock(), Mock(), Mock()
        addon.getSetting.return_value = "true"
        session.account, session.username = "new-account", "new-user"
        session.lock_path = os.path.join("profile", "auth.lock")
        modules = {"xbmc": types.SimpleNamespace(log=Mock(), LOGWARNING=2),
                   "auth_session": types.SimpleNamespace(kodi_session=lambda: session),
                   "guide_store": types.SimpleNamespace(GuideStore=lambda *_: store)}
        with patch.dict(sys.modules, modules):
            overlay.remember_started_channel(addon, "one", "old-account")
            store.write_last_channel.assert_not_called()
            overlay.remember_started_channel(addon, "one", "new-account")
            store.write_last_channel.assert_called_once_with("one")
            addon.getSetting.return_value = "false"
            overlay.remember_started_channel(addon, "two", "new-account")
            store.write_last_channel.assert_called_once()

    def test_native_overlay_request_carries_lineup_number(self):
        addon, window, builtin = Mock(), Mock(), Mock()
        addon.getSetting.return_value = "true"
        addon.getAddonInfo.return_value = "addon-path"
        modules = {
            "xbmc": types.SimpleNamespace(executebuiltin=builtin),
            "xbmcaddon": types.SimpleNamespace(Addon=lambda: addon),
            "xbmcgui": types.SimpleNamespace(Window=lambda _: window),
        }
        with patch.dict(sys.modules, modules):
            overlay.launch("https://example.invalid/live.mpd|headers", "station", "account",
                           "logo", "Station", number=130)
        key, value = window.setProperty.call_args.args
        self.assertEqual(key, overlay.REQUEST_PROPERTY)
        request = json.loads(value)
        self.assertEqual((request["number"], request["channel"], request["station"]),
                         (130, "station", "Station"))
        self.assertEqual(request["url"], "https://example.invalid/live.mpd")
        builtin.assert_called_once()


if __name__ == "__main__":
    unittest.main()
