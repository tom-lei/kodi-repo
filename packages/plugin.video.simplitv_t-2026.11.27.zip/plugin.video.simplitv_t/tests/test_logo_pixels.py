import struct
import unittest
import zlib
from unittest import mock

from logo_pixels import SIGNATURE, UnsupportedPNG, _chunk, _paeth, prepare_logo, trim_png


def png(width, height, pixels, colour=6, filters=None, extra=b""):
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[colour]
    stride = width * channels
    previous = bytes(stride)
    raw = bytearray()
    for y in range(height):
        row = pixels[y * stride:(y + 1) * stride]
        kind = filters[y] if filters else 0
        raw.append(kind)
        for x, value in enumerate(row):
            left = row[x - channels] if x >= channels else 0
            upper_left = previous[x - channels] if x >= channels else 0
            prediction = (0, left, previous[x], (left + previous[x]) // 2,
                          _paeth(left, previous[x], upper_left))[kind]
            raw.append((value - prediction) & 255)
        previous = row
    return (SIGNATURE + _chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, colour, 0, 0, 0))
            + extra + _chunk(b"IDAT", zlib.compress(bytes(raw))) + _chunk(b"IEND", b""))


def decoded(image):
    width, height = struct.unpack_from(">II", image, 16)
    length = struct.unpack_from(">I", image, 33)[0]
    raw = zlib.decompress(image[41:41 + length])
    return width, height, b"".join(raw[y * (width * 4 + 1) + 1:(y + 1) * (width * 4 + 1)]
                                for y in range(height))


class LogoPixelsTests(unittest.TestCase):
    def test_generic_frame_callback_keeps_source_crop_and_centres_a_bounded_canvas(self):
        source = png(3, 1, b"\xff" * 12)
        crop, framed = prepare_logo(source, lambda _: ((10, 6), (8, 2)))
        self.assertEqual(decoded(crop), (3, 1, b"\xff" * 12))
        width, height, pixels = decoded(framed)
        self.assertEqual((width, height), (40, 24))
        visible = [(i % width, i // width) for i, alpha in enumerate(pixels[3::4]) if alpha]
        xs, ys = zip(*visible)
        self.assertEqual((max(xs) - min(xs) + 1, max(ys) - min(ys) + 1), (32, 8))
        self.assertEqual((min(xs), min(ys)), (4, 8))

    def test_padding_does_not_change_visible_artwork_or_soft_edges(self):
        art = bytes((255, 0, 0, 8, 0, 255, 0, 255, 0, 0, 255, 200, 5, 6, 7, 7))
        padded = bytes(4 * 4) + bytes(4) + art[:8] + bytes(4)
        padded += bytes(4) + art[8:] + bytes(4) + bytes(4 * 4)
        self.assertEqual(decoded(trim_png(png(4, 4, padded))), (2, 2, art))
        self.assertEqual(trim_png(png(4, 4, padded)), trim_png(png(2, 2, art)))

    def test_all_png_filters_reconstruct_identical_rgba(self):
        pixels = bytes((x * 53 + 17) % 256 for x in range(3 * 5 * 4))
        image = trim_png(png(3, 5, pixels, filters=[0, 1, 2, 3, 4]))
        self.assertEqual(decoded(image), (3, 5, pixels))

    def test_palette_and_colour_key_transparency(self):
        palette = _chunk(b"PLTE", b"\0\0\0\xff\xff\xff") + _chunk(b"tRNS", b"\0\xff")
        self.assertEqual(decoded(trim_png(png(3, 1, b"\0\1\0", 3, extra=palette))),
                         (1, 1, b"\xff\xff\xff\xff"))
        transparent = _chunk(b"tRNS", struct.pack(">HHH", 1, 2, 3))
        self.assertEqual(decoded(trim_png(png(3, 1, b"\1\2\3\xff\0\0\1\2\3", 2, extra=transparent))),
                         (1, 1, b"\xff\0\0\xff"))

    def test_grayscale_alpha_and_opaque_images(self):
        self.assertEqual(decoded(trim_png(png(3, 1, b"\x10\0\x80\x80\x20\0", 4))),
                         (1, 1, b"\x80\x80\x80\x80"))
        self.assertEqual(decoded(trim_png(png(1, 1, b"\x80", 0))),
                         (1, 1, b"\x80\x80\x80\xff"))
        self.assertEqual(decoded(trim_png(png(1, 1, b"\1\2\3", 2))),
                         (1, 1, b"\1\2\3\xff"))

    def test_invisible_fringe_does_not_inflate_bounds(self):
        self.assertEqual(decoded(trim_png(png(3, 1, bytes((1, 2, 3, 7, 4, 5, 6, 8, 7, 8, 9, 1))))),
                         (1, 1, bytes((4, 5, 6, 8))))
        with self.assertRaises(ValueError):
            trim_png(png(1, 1, b"\0\0\0\0"))

    def test_processing_budget_bounds_slow_decode(self):
        with mock.patch("logo_pixels.time.monotonic", side_effect=[0, 11]):
            with self.assertRaisesRegex(ValueError, "time limit"):
                trim_png(png(1, 1, b"\xff" * 4))

    def test_corrupt_truncated_and_bomb_images_fail_bounded(self):
        image = png(1, 1, b"\xff" * 4)
        for invalid in (image[:-3], image[:45] + b"bad" + image[48:],
                        SIGNATURE + _chunk(b"IHDR", struct.pack(">IIBBBBB", 99999, 1, 8, 6, 0, 0, 0))
                        + _chunk(b"IEND", b""),
                        SIGNATURE + _chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0))
                        + _chunk(b"IDAT", zlib.compress(bytes(100000))) + _chunk(b"IEND", b"")):
            with self.subTest(length=len(invalid)), self.assertRaises(ValueError):
                trim_png(invalid)
        with self.assertRaises(UnsupportedPNG):
            trim_png(b"\xff\xd8jpeg")
        header = _chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 1))
        with self.assertRaises(UnsupportedPNG):
            trim_png(SIGNATURE + header + _chunk(b"IEND", b""))


if __name__ == "__main__":
    unittest.main()
