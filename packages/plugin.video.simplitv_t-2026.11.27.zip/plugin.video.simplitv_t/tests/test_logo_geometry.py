import unittest

from logo_geometry import LOGO_CELL, guide_frame, logo_box, target_logo_size


class LogoGeometryTests(unittest.TestCase):
    def test_scales_each_source_geometry_by_25_percent(self):
        geometry = (1920, 1080, 1824, 394)
        width, height = target_logo_size(geometry)
        self.assertAlmostEqual(width, 95)
        self.assertAlmostEqual(height, 20.520833, places=5)
        self.assertEqual(guide_frame(geometry), (LOGO_CELL, (width, height)))

    def test_logo_box_fits_without_upscaling(self):
        self.assertEqual(logo_box(176, 45), (176, 45))
        self.assertEqual(logo_box(400, 200), (176, 45))
        self.assertEqual(logo_box(96, 24), (94, 24))
        self.assertEqual(logo_box(100, 18), (70, 18))

    def test_uses_each_artwork_own_padding_and_shape(self):
        padded = (1920, 1080, 1824, 394)
        full_bleed = (1824, 394, 1824, 394)
        self.assertNotEqual(target_logo_size(padded), target_logo_size(full_bleed))

    def test_tall_artwork_and_wide_outlier_are_limited_uniformly(self):
        for geometry, axis, edge in (((1920, 1080, 1920, 910), 1, LOGO_CELL[1]),
                                     ((167, 20, 167, 20), 0, LOGO_CELL[0]),
                                     ((10, 169, 10, 169), 1, LOGO_CELL[1]),
                                     ((1280, 251, 1280, 251), 0, LOGO_CELL[0])):
            with self.subTest(geometry=geometry):
                width, height = target_logo_size(geometry)
                self.assertEqual((width, height)[axis], edge)
                self.assertAlmostEqual(width / height, geometry[2] / geometry[3])
