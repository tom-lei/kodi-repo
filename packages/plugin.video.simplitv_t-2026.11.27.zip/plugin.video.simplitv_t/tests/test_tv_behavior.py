import datetime
import types
import unittest

from tv_behavior import (SETTINGS_SHORTCUT, ChannelNumber, ProgrammeBanner, StationHistory,
                         lineup_numbers, live_target, number_channel, number_status, numbered,
                         programme_banner)


class TvBehaviorTests(unittest.TestCase):
    def test_lineup_numbers_survive_filtering_and_invalid_digits_are_consumed(self):
        numbers = lineup_numbers(["one", "hidden", "three"])
        visible = ["one", "three"]
        self.assertEqual(numbers, {"one": 1, "hidden": 2, "three": 3})
        self.assertEqual(number_channel(3, numbers, visible), ("three", ""))
        self.assertEqual(number_channel(2, numbers, visible), ("hidden", "hidden"))
        self.assertEqual(number_channel(0, numbers, visible), (None, "unknown"))
        self.assertEqual(number_channel(99, numbers, visible), (None, "unknown"))
        self.assertEqual(number_status("2", numbers, visible, str.upper, True),
                         "2_  →  002 HIDDEN (ausgeblendet)")
        self.assertEqual(number_status("99", numbers, visible, str, False),
                         "99_  →  099 not assigned")
        self.assertEqual(numbered(3, "Station"), "003  Station")
        self.assertEqual(numbered(3, "003  Station"), "003  Station")

        entry = ChannelNumber()
        entry.press(58, 0)
        self.assertEqual(entry.take(0, confirm=True), 0)
        self.assertIsNone(entry.take(0, confirm=True))
        for digit in (0, 0, 3):
            entry.press(58 + digit, 1)
        self.assertEqual(entry.take(2.5), 3)

    def test_settings_shortcut_requires_exactly_three_zeroes(self):
        for digits, expected in (("0", 0), ("00", 0), ("000", SETTINGS_SHORTCUT),
                                 ("0001", 1), ("0000", 0), ("005", 5)):
            for confirm in (True, False):
                with self.subTest(digits=digits, confirm=confirm):
                    entry = ChannelNumber()
                    for index, digit in enumerate(digits):
                        entry.press(58 + int(digit), index / 10)
                    self.assertEqual(entry.is_settings(), digits == "000")
                    if digits == "000":
                        self.assertEqual(number_status(
                            entry.digits, {}, [], str, True, entry.is_settings()),
                            "000_  →  Einstellungen")
                    self.assertIsNone(entry.take(entry.until - .01))
                    self.assertEqual(entry.take(entry.until if not confirm else 0, confirm), expected)
                    self.assertIsNone(entry.take(entry.until, True))

    def test_banner_progress_is_proportional_and_yields_to_seek_display(self):
        class Control:
            def __init__(self, *args, **kwargs):
                self.width = args[2]
                self.y, self.height = args[1], args[3]
                self.font = kwargs.get("font")

            def setWidth(self, width):
                self.width = width

            def setVisible(self, visible):
                self.visible = visible

            def setAnimations(self, _):
                pass

            def setVisibleCondition(self, _):
                pass

            def setLabel(self, label, **_):
                self.text = label

        window = types.SimpleNamespace(getWidth=lambda: 1920, getHeight=lambda: 1080,
                                       addControls=lambda _: None)
        gui = types.SimpleNamespace(ControlImage=Control, ControlLabel=Control)
        addon = types.SimpleNamespace(getAddonInfo=lambda _: "")
        banner = ProgrammeBanner(window, addon, gui, "font13", [], bottom=True,
                                 fonts=("font12", "font36_title", "font10"))
        self.assertEqual(banner.background.y + banner.background.height, 1080)
        station, title, following = banner.labels
        self.assertGreater(title.height, following.height)
        self.assertNotEqual(title.font, following.font)
        self.assertGreater(title.y, station.y + station.height)
        self.assertGreater(following.y, title.y + title.height)
        banner.show(("Station", "Current · until 21:00", "Next: News", 25))
        banner.update(True)
        self.assertTrue(banner.progress.visible)
        self.assertEqual(banner.progress.width, round(banner.track.width / 4))
        banner.update(False)
        self.assertFalse(any(control.visible for control in banner.controls))
        banner.show(("Station", "", "", 0))
        banner.update(True)
        self.assertTrue(banner.labels[0].visible)
        self.assertFalse(banner.track.visible)
        self.assertFalse(banner.progress.visible)

    def test_banner_obstruction_cancels_fades_and_gates_both_window_types(self):
        class Control:
            def __init__(self, *args, **kwargs):
                self.visible = False
                self.condition = ""
                self.animations = []

            def setWidth(self, width):
                pass

            def setVisible(self, visible):
                self.visible = visible

            def setVisibleCondition(self, condition):
                self.condition = condition

            def setAnimations(self, animations):
                self.animations = animations

            def setLabel(self, label, **kwargs):
                pass

        window = types.SimpleNamespace(getWidth=lambda: 1920, getHeight=lambda: 1080,
                                       addControls=lambda _: None)
        gui = types.SimpleNamespace(ControlImage=Control, ControlLabel=Control)
        addon = types.SimpleNamespace(getAddonInfo=lambda _: "")
        fade = [("Visible", "effect=fade start=0 end=100 time=200"),
                ("Hidden", "effect=fade start=100 end=0 time=200")]
        for bottom in (False, True):
            with self.subTest(bottom=bottom):
                banner = ProgrammeBanner(window, addon, gui, "font13", fade, bottom=bottom)
                banner.show(("Station", "Programme", "Next", 50))
                banner.update(True)
                self.assertTrue(banner.background.visible)
                for control in banner.controls:
                    self.assertIn("!Window.IsVisible(videoosd)", control.condition)
                    self.assertIn("!Window.IsVisible(fullscreeninfo)", control.condition)
                    self.assertNotIn("Hidden", [event for event, _ in control.animations])
                    self.assertIn("reversible=false", dict(control.animations)["Visible"])

                # Obstruction must also stop a fade after the logical banner expired.
                banner.until = 0
                banner.update(True)
                for control in banner.controls:
                    control.visible = True
                    control.animations = fade
                banner.update(False)
                self.assertFalse(any(control.visible for control in banner.controls))
                self.assertTrue(all(not control.animations for control in banner.controls))

                banner.show(("Station", "Programme", "Next", 50))
                banner.update(False)
                self.assertFalse(any(control.visible for control in banner.controls))
                banner.update(True)
                self.assertTrue(banner.background.visible)

    def test_lifted_banner_moves_above_video_controls_and_lingers_after_them(self):
        class Control:
            def __init__(self, *args, **kwargs):
                self.y, self.height = args[1], args[3]
                self.visible, self.condition, self.animations = False, "", []

            def setVisible(self, visible):
                self.visible = visible

            def setVisibleCondition(self, condition):
                self.condition = condition

            def setAnimations(self, animations):
                self.animations = animations

            def __getattr__(self, name):
                return lambda *args, **kwargs: None

        window = types.SimpleNamespace(getWidth=lambda: 1920, getHeight=lambda: 1080,
                                       addControls=lambda _: None)
        gui = types.SimpleNamespace(ControlImage=Control, ControlLabel=Control)
        addon = types.SimpleNamespace(getAddonInfo=lambda _: "")
        fade = [("Visible", "effect=fade start=0 end=100 time=200")]

        def lifted_bottom(banner):
            lift = dict(banner.background.animations)["Conditional"]
            self.assertIn("condition=Window.IsVisible(videoosd)", lift)
            return (banner.background.y + banner.background.height
                    + int(lift.split("end=0,")[1].split()[0]))

        # The skin's controls start at line 900 (Estuary) or 700; the banner sits just above.
        for controls in (900, 700):
            banner = ProgrammeBanner(window, addon, gui, "font13", fade, bottom=True,
                                     lift=controls / 1080)
            self.assertTrue(controls - 30 <= lifted_bottom(banner) <= controls,
                            lifted_bottom(banner))
        # Unknown controls: the top edge; controls too high to fit under: the top edge too.
        for lift in (True, .1):
            banner = ProgrammeBanner(window, addon, gui, "font13", fade, bottom=True, lift=lift)
            self.assertLess(lifted_bottom(banner), 300)
        # The skin has no bottom controls: nothing to avoid.
        unmoved = ProgrammeBanner(window, addon, gui, "font13", fade, bottom=True, lift=1.0)
        self.assertNotIn("Conditional", dict(unmoved.background.animations))
        self.assertEqual(unmoved.background.condition, "!Window.IsVisible(fullscreeninfo)")

        banner = ProgrammeBanner(window, addon, gui, "font13", fade, bottom=True, lift=900 / 1080)
        for control in banner.controls:
            self.assertEqual(control.condition, "!Window.IsVisible(fullscreeninfo)")

        banner.show(("Station", "Programme", "Next", 50))
        banner.until = 0
        banner.update(True, osd=True)
        self.assertTrue(banner.background.visible)
        banner.update(False, osd=True)  # Fullscreen info still hides it, keeping the lift.
        self.assertFalse(banner.background.visible)
        self.assertEqual(banner.background.animations, banner.raised)
        banner.update(True, osd=True)
        banner.update(True)
        self.assertTrue(banner.background.visible, "Banner slides back before expiring")
        banner.until = 0
        banner.update(True)
        self.assertFalse(banner.background.visible)

        static = ProgrammeBanner(window, addon, gui, "font13", fade, bottom=True)
        static.show(("Station", "Programme", "Next", 50))
        static.until = 0
        static.update(True, osd=True)
        self.assertFalse(static.background.visible)
        self.assertNotIn("Conditional", dict(static.background.animations))

    def test_history_only_rotates_on_distinct_success(self):
        history = StationHistory()
        history.started("one")
        self.assertIsNone(history.target(["one", "two"]))
        history.started("two")
        history.started("two")
        self.assertEqual(history.target(["one", "two"]), "one")
        self.assertIsNone(history.target(["two"]))
        history.started("one")
        self.assertEqual(history.target(["one", "two"]), "two")

    def test_live_target_requires_current_seekable_live_stream_and_real_delay(self):
        enabled = {"Player.SeekEnabled"}
        kodi = types.SimpleNamespace(getCondVisibility=enabled.__contains__)
        player = types.SimpleNamespace(isPlayingVideo=lambda: True, getTime=lambda: 80,
                                       getTotalTime=lambda: 100)
        playback = dict(player=player, matches=lambda: True, live=True)
        self.assertEqual(live_target(playback, kodi), 100)
        player.getTime = lambda: 96
        self.assertIsNone(live_target(playback, kodi))
        player.getTime = lambda: 80
        enabled.add("Player.Seeking")
        self.assertIsNone(live_target(playback, kodi))
        enabled.remove("Player.Seeking")
        self.assertIsNone(live_target(dict(playback, matches=lambda: False), kodi))
        self.assertIsNone(live_target(dict(playback, live=False), kodi))

    def test_banner_uses_current_and_following_cached_entries(self):
        def event(code, start, stop, title):
            return dict(tileChannel={"codename": code}, start=start, stop=stop, title=title)

        stamp = "2026-11-20T20:"
        now = datetime.datetime.fromisoformat(stamp + "10:00+00:00").timestamp()
        current = event("one", stamp + "00:00Z", stamp + "20:00Z", "News")
        upcoming = event("one", stamp + "20:00Z", stamp + "50:00Z", "Movie")
        noise = event("two", stamp + "09:00Z", stamp + "20:00Z", "Other")
        station, title, next_title, progress = programme_banner(
            (noise, upcoming, current), "one", "Station", now)
        self.assertEqual(station, "Station")
        self.assertIn("News", title)
        self.assertEqual(next_title, "Next: Movie")
        self.assertEqual(progress, 50)
        self.assertEqual(programme_banner((noise, upcoming), "one", "Station", now),
                         ("Station", "", "", 0))
