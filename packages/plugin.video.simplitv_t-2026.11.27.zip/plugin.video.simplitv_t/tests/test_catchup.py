import copy
import datetime
import unittest

from catchup import catchup_available
from guide import available_actions


def stamp(seconds):
    return datetime.datetime.fromtimestamp(seconds, datetime.timezone.utc).isoformat()


class CatchupTests(unittest.TestCase):
    def setUp(self):
        self.now = 1800000000
        self.event = {
            "id": "prg.1", "codename": "programme.1",
            "start": stamp(self.now - 7200), "stop": stamp(self.now - 3600),
            "isCatchupEnabled": True, "isBlackouted": False,
            "catchupAvailableFrom": stamp(self.now - 3500),
            "catchupAvailableTo": stamp(self.now + 3600),
            "tileChannel": {"codename": "channel", "tileId": "chn.1"}}
        self.access = {
            "account_catchup_enabled": True, "catchup_agreement_missing": False,
            "catchup_channels": {"chn.1": {
                "canPlay": True, "catchupEnabled": True,
                "catchupFrom": stamp(self.now - 10000),
                "catchupTo": stamp(self.now + 10000)}}}
        self.policy = {"available_immediately": False, "publication_delay": 5, "stop_margin": 5, "channels": {
            "chn.1": {"codename": "channel", "isCatchupEnabled": True,
                      "isBlackouted": False, "hasPlayableStream": True, "stop_margin": None}}}

    def check(self, event=None, access=None, policy=None, now=None):
        return catchup_available(event if event is not None else self.event,
                                 access if access is not None else self.access,
                                 policy if policy is not None else self.policy,
                                 self.now if now is None else now)

    def test_affirmative_rights_and_publication_are_required(self):
        self.assertTrue(self.check())
        for field in ("isCatchupEnabled", "isBlackouted", "codename"):
            event = copy.deepcopy(self.event)
            del event[field]
            self.assertFalse(self.check(event=event), field)
        for field, value in (("isBlackouted", True), ("isCatchupEnabled", False),
                             ("codename", "id:prg.1"), ("catchupAvailableTo", stamp(self.now - 1))):
            event = copy.deepcopy(self.event)
            event[field] = value
            self.assertFalse(self.check(event=event), field)
        event = copy.deepcopy(self.event)
        event["tileChannel"]["tileId"] = "chn.2"
        self.assertFalse(self.check(event=event))
        event["tileChannel"]["tileId"] = "chn.1"
        event["stop"] = stamp(self.now + 1)
        self.assertFalse(self.check(event=event))

    def test_optional_dates_do_not_grant_or_deny_by_themselves(self):
        event = copy.deepcopy(self.event)
        access = copy.deepcopy(self.access)
        for field in ("catchupAvailableFrom", "catchupAvailableTo"):
            event.pop(field)
        for field in ("catchupFrom", "catchupTo"):
            access["catchup_channels"]["chn.1"].pop(field)
        self.assertTrue(self.check(event=event, access=access))
        access["catchup_channels"]["chn.1"]["catchupFrom"] = None
        event["catchupAvailableTo"] = None
        self.assertTrue(self.check(event=event, access=access))
        access["account_catchup_enabled"] = False
        self.assertFalse(self.check(event=event, access=access))
        access["account_catchup_enabled"] = True
        access["catchup_channels"]["chn.1"]["catchupEnabled"] = False
        self.assertFalse(self.check(event=event, access=access))
        access["catchup_channels"]["chn.1"]["catchupEnabled"] = True
        event["isCatchupEnabled"] = False
        self.assertFalse(self.check(event=event, access=access))

    def test_date_bounds_are_optional_but_present_bounds_must_be_valid(self):
        for field in ("catchupAvailableFrom", "catchupAvailableTo"):
            event = copy.deepcopy(self.event)
            event.pop(field)
            self.assertTrue(self.check(event=event), field)
            event[field] = ""
            self.assertFalse(self.check(event=event), field)
            event[field] = 123
            self.assertFalse(self.check(event=event), field)
        event = copy.deepcopy(self.event)
        event["catchupAvailableFrom"] = stamp(self.now + 1)
        self.assertFalse(self.check(event=event))
        event["catchupAvailableFrom"] = stamp(self.now - 3500)
        event["catchupAvailableTo"] = stamp(self.now)
        self.assertTrue(self.check(event=event))
        event.pop("catchupAvailableFrom")
        self.assertFalse(self.check(event=event))
        event["catchupAvailableFrom"] = stamp(self.now + 1)
        event["catchupAvailableTo"] = stamp(self.now - 1)
        self.assertFalse(self.check(event=event))
        for field in ("catchupFrom", "catchupTo"):
            access = copy.deepcopy(self.access)
            access["catchup_channels"]["chn.1"].pop(field)
            self.assertTrue(self.check(access=access), field)
            access["catchup_channels"]["chn.1"][field] = "invalid"
            self.assertFalse(self.check(access=access), field)

    def test_channel_account_and_processing_denials(self):
        for key, value in (("account_catchup_enabled", False),
                           ("catchup_agreement_missing", True),
                           ("catchup_agreement_missing", None)):
            access = copy.deepcopy(self.access)
            access[key] = value
            self.assertFalse(self.check(access=access), key)
        for key, value in (("canPlay", False), ("catchupEnabled", False),
                           ("catchupFrom", stamp(self.now)), ("catchupTo", "invalid")):
            access = copy.deepcopy(self.access)
            access["catchup_channels"]["chn.1"][key] = value
            self.assertFalse(self.check(access=access), key)
        for key, value in (("isCatchupEnabled", False), ("isBlackouted", True),
                           ("hasPlayableStream", None), ("codename", "other")):
            policy = copy.deepcopy(self.policy)
            policy["channels"]["chn.1"][key] = value
            self.assertFalse(self.check(policy=policy), key)
        self.assertFalse(self.check(now=self.now - 3600 + 305))
        self.assertTrue(self.check(now=self.now - 3600 + 306))
        policy = copy.deepcopy(self.policy)
        policy["publication_delay"] = None
        self.assertFalse(self.check(policy=policy))
        policy["available_immediately"] = True
        event = copy.deepcopy(self.event)
        event["catchupAvailableFrom"] = stamp(self.now - 3600)
        self.assertTrue(self.check(event=event, policy=policy, now=self.now - 3600 + 1))
        policy["available_immediately"] = None
        self.assertFalse(self.check(policy=policy))

    def test_catchup_precedes_and_does_not_alias_rewind(self):
        self.assertEqual(available_actions(self.event, self.now, {"seconds": 9000}, False, True),
                         ("catchup",))
        self.assertEqual(available_actions(self.event, self.now, {"seconds": 9000}, False, False),
                         ("start_from_beginning",))


if __name__ == "__main__":
    unittest.main()
