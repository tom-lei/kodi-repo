import ast
import datetime
import os
import sys
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from guide import (
    GUIDE_PAST_SECONDS, _format_time, adjacent_programme,
    available_actions, channel_direction_for_action, guide_window,
    nearest_programme, programme_key, replay_badge_x, replay_start
)


def programme(channel, title, start, stop, **metadata):
    result = {
        "id": title,
        "title": title,
        "start": datetime.datetime.fromtimestamp(
            start, datetime.timezone.utc).isoformat(),
        "stop": datetime.datetime.fromtimestamp(
            stop, datetime.timezone.utc).isoformat(),
        "tileChannel": {"codename": channel}
    }
    result.update(metadata)
    return result


class GuideLogicTests(unittest.TestCase):
    def test_badge_target_distinguishes_full_partial_and_unverified_replay(self):
        event = programme("one", "Programme", 100, 200, isCatchupEnabled=False,
                          isBlackouted=False)
        self.assertEqual(replay_start(event, 220), ("estimated", 100))
        full = replay_start(event, 220, {"seconds": 140})
        partial = replay_start(event, 220, {"seconds": 90})
        self.assertEqual(full, ("estimated", 100))
        self.assertEqual(partial, ("partial", 130))
        self.assertIsNone(replay_start(event, 220, {"seconds": 20}))
        for seconds in (None, 0, -1, float("nan"), True, "140"):
            self.assertEqual(replay_start(event, 220, {"seconds": seconds}), ("estimated", 100))
        self.assertIsNone(replay_start(event, 220, {"seconds": 140}, True))
        self.assertIsNone(replay_start(dict(event, isBlackouted=True), 220, {"seconds": 140}))
        self.assertIsNone(replay_start(dict(event, isBlackouted=None), 220, {"seconds": 140}))
        self.assertEqual(replay_badge_x(full, 100, 200, 1, 200), 200)
        self.assertEqual(replay_badge_x(partial, 100, 200, 1, 200), 230)
        self.assertIsNone(replay_badge_x(full, 110, 200, 1, 200))
        self.assertEqual(replay_badge_x(partial, 120, 200, 1, 200), 210)
        self.assertEqual(replay_badge_x(("partial", 199), 100, 200, 1, 200), 299)
        self.assertIsNone(replay_badge_x(("partial", 200), 100, 200, 1, 200))

    def test_guide_window_is_a_browsing_horizon_not_a_rewind_limit(self):
        now = 1_800_000_000
        start, end = guide_window(now)
        self.assertGreaterEqual(GUIDE_PAST_SECONDS, 4 * 60 * 60)
        self.assertEqual(start.timestamp(), now - GUIDE_PAST_SECONDS)
        self.assertEqual(end.timestamp(), now + 21 * 60 * 60)

    def test_local_time_conversion_uses_supplied_timezone(self):
        start = datetime.datetime(2026, 3, 29, 0, 30, tzinfo=datetime.timezone.utc)
        before_dst = datetime.timezone(datetime.timedelta(hours=1))
        after_dst = datetime.timezone(datetime.timedelta(hours=2))
        self.assertEqual(datetime.datetime.fromtimestamp(start.timestamp(), before_dst).hour, 1)
        self.assertEqual(datetime.datetime.fromtimestamp(
            (start + datetime.timedelta(hours=1)).timestamp(), after_dst).hour, 3)

    @unittest.skipUnless(hasattr(time, "tzset"), "Changing the process timezone requires tzset")
    def test_system_local_time_tracks_daylight_saving_transition(self):
        previous = os.environ.get("TZ")
        try:
            os.environ["TZ"] = "CET-1CEST,M3.5.0,M10.5.0/3"
            time.tzset()
            utc = datetime.timezone.utc
            cases = (
                (datetime.datetime(2026, 3, 29, 0, 30, tzinfo=utc), "01:30"),
                (datetime.datetime(2026, 3, 29, 1, 30, tzinfo=utc), "03:30"),
                (datetime.datetime(2026, 10, 25, 0, 30, tzinfo=utc), "02:30"),
                (datetime.datetime(2026, 10, 25, 1, 30, tzinfo=utc), "02:30"),
            )
            for instant, expected in cases:
                with self.subTest(instant=instant):
                    self.assertEqual(_format_time(instant.timestamp(), None), expected)
        finally:
            if previous is None:
                os.environ.pop("TZ", None)
            else:
                os.environ["TZ"] = previous
            time.tzset()

    def test_watch_and_rewind_are_independent_of_catchup(self):
        now = 1_800_000_000
        current = programme("one", "current", now - 60, now + 1800,
                            isCatchupEnabled=True, isBlackouted=False)
        rewind = {"seconds": 1800}
        self.assertEqual(available_actions(current, now, rewind),
                         ("watch_live", "start_from_beginning"))
        no_catchup = dict(current, isCatchupEnabled=False)
        self.assertEqual(available_actions(no_catchup, now, rewind),
                         ("watch_live", "start_from_beginning"))
        unknown = dict(current)
        unknown.pop("isCatchupEnabled")
        self.assertEqual(available_actions(unknown, now, rewind),
                         ("watch_live", "start_from_beginning"))
        self.assertEqual(available_actions(current, now), ("watch_live", "start_from_beginning"))
        self.assertEqual(available_actions(current, now, rewind, True), ("watch_live",))

    def test_rewind_requires_estimated_overlap(self):
        now = 1_800_000_000
        within_buffer = programme(
            "one", "recent", now - 60,
            now - 1, isCatchupEnabled=True, isBlackouted=False)
        outside_buffer = programme(
            "one", "old",             now - 4 * 3600, now - 3601,
            isCatchupEnabled=True, isBlackouted=False)
        future = programme("one", "future", now + 1, now + 3600,
                           isCatchupEnabled=True, isBlackouted=False)
        self.assertEqual(available_actions(within_buffer, now, {"seconds": 3600}),
                         ("start_from_beginning",))
        self.assertEqual(available_actions(outside_buffer, now, {"seconds": 3600}), ())
        self.assertEqual(available_actions(future, now, {"seconds": 3600}), ())
        self.assertIsNone(programme_key({"start": "invalid"}))

    def test_unmeasured_rewind_uses_three_hours_without_mutating_observation(self):
        now = 1_800_000_000
        recent = programme("one", "recent", now - 2 * 3600, now - 3600, isBlackouted=False)
        partial = programme("one", "partial", now - 4 * 3600, now - 2 * 3600, isBlackouted=False)
        old = programme("one", "old", now - 5 * 3600, now - 4 * 3600, isBlackouted=False)
        observation = {"seconds": None, "format": "HLS"}
        self.assertEqual(replay_start(recent, now, observation), ("estimated", now - 2 * 3600))
        self.assertEqual(observation, {"seconds": None, "format": "HLS"})
        self.assertEqual(replay_start(partial, now), ("partial", now - 3 * 3600))
        self.assertIsNone(replay_start(old, now))
        self.assertIsNone(replay_start(recent, now, None, True))
        self.assertIsNone(replay_start(dict(recent, isBlackouted=True), now))
        self.assertIsNone(replay_start(recent, now, {"seconds": 1800}))

    def test_horizontal_navigation_and_vertical_channel_time_matching(self):
        now = 1_800_000_000
        events = [
            programme("one", "early", now - 3600, now - 1800),
            programme("one", "current", now - 1800, now + 1800),
            programme("one", "later", now + 1800, now + 3600),
            programme("two", "other", now - 1200, now + 1200)
        ]
        current = nearest_programme(events, "one", now)
        self.assertEqual(current["title"], "current")
        self.assertEqual(adjacent_programme(events, "one", current, -1)["title"], "early")
        self.assertEqual(adjacent_programme(events, "one", current, 1)["title"], "later")
        self.assertIsNone(adjacent_programme(events, "one", events[0], -1))
        self.assertEqual(nearest_programme(events, "two", now)["title"], "other")
        with self.assertRaises(ValueError):
            adjacent_programme(events, "one", current, 0)

    def test_kodi_channel_actions_and_arrow_navigation_are_scoped(self):
        actions = {3: -1, 4: 1, 184: 1, 185: -1}
        for action_id, expected in actions.items():
            self.assertEqual(
                channel_direction_for_action(action_id, 3, 4, 184, 185), expected)
        self.assertIsNone(channel_direction_for_action(183, 3, 4, 184, 185))
        self.assertEqual(channel_direction_for_action(184, None, None, 184, 185), 1)
        self.assertEqual(channel_direction_for_action(185, None, None, 184, 185), -1)


class LiveTvBootstrapTests(unittest.TestCase):
    def test_os_is_imported_before_guide_lock_path_initialization(self):
        addon_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        with open(os.path.join(addon_root, "default.py"), encoding="utf-8-sig") as source_file:
            tree = ast.parse(source_file.read())

        os_import = next(
            (index for index, node in enumerate(tree.body)
             if isinstance(node, ast.Import)
             and any(alias.name == "os" for alias in node.names)),
            None
        )
        lock_path_assignment = next(
            index for index, node in enumerate(tree.body)
            if isinstance(node, ast.Assign)
            and any(isinstance(target, ast.Name) and target.id == "guide_lock_path"
                    for target in node.targets)
        )
        self.assertIsNotNone(os_import)
        self.assertLess(os_import, lock_path_assignment)

if __name__ == "__main__":
    unittest.main()
