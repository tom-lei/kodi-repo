"""Bounded provider diagnostics containing only numbers and approved stock text."""

import json
import re
from dataclasses import dataclass
from typing import Optional


MAX_ERROR_BYTES = 16 * 1024
CODE = re.compile(r"[0-9]{1,6}")
ERROR_TEXT = (
    {
        "request": "The provider request failed.",
        "connection": "Could not connect. Check your connection and try again.",
        "proxy": "Could not use Kodi's configured proxy. Check Kodi's network settings; no direct connection was attempted.",
        "invalid_json": "The provider returned invalid JSON.",
        "unexpected": "The provider returned an unexpected response.",
        "maintenance": "The service is temporarily unavailable. Try again later.",
        "session": "Your session is no longer valid. Try signing in again.",
        "product": "This content is not available.",
        "region": "Access is restricted in this region. Check your location and disable any VPN or proxy.",
        "denied": "Access denied.",
    },
    {
        "request": "Die Anbieteranfrage ist fehlgeschlagen.",
        "connection": "Keine Verbindung möglich. Prüfe die Internetverbindung und versuche es erneut.",
        "proxy": "Kodis eingestellter Proxy konnte nicht verwendet werden. Prüfe die Netzwerkeinstellungen; es wurde keine direkte Verbindung versucht.",
        "invalid_json": "Der Anbieter hat ungültiges JSON zurückgegeben.",
        "unexpected": "Der Anbieter hat eine unerwartete Antwort zurückgegeben.",
        "maintenance": "Der Dienst ist vorübergehend nicht verfügbar. Versuche es später erneut.",
        "session": "Die Sitzung ist nicht mehr gültig. Versuche, dich erneut anzumelden.",
        "product": "Dieser Inhalt ist nicht verfügbar.",
        "region": "Der Zugriff ist regional beschränkt. Prüfe deinen Standort und deaktiviere VPN oder Proxy.",
        "denied": "Zugriff verweigert.",
    },
)
# Verified in the public simpliTV web client's API error constants; see developer docs.
KNOWN_CODES = {5: "maintenance", 9003: "session", 9500: "product", 9602: "region"}
SAFE_MESSAGES = {
    "general_error": "request", "general error": "request",
    "request failed": "request", "an unexpected error occurred": "request",
    "access denied": "denied", "access_denied": "denied",
    "service unavailable": "maintenance",
}


def numeric_code(value):
    if isinstance(value, str) and CODE.fullmatch(value):
        value = int(value)
    return value if type(value) is int and 0 < value <= 999999 else None


@dataclass(frozen=True)
class ProviderFailure:
    status: Optional[int] = None
    code: Optional[int] = None
    message_key: Optional[str] = None
    reason: str = "request"

    def message(self, german=False):
        status = self.status if type(self.status) is int and 100 <= self.status <= 599 else None
        code = numeric_code(self.code)
        heading = "simpliTV Fehler" if german else "simpliTV error"
        if code is not None:
            heading += " {}".format(code)
        if status is not None:
            heading += " (HTTP {})".format(status)
        text = ERROR_TEXT[bool(german)]
        key = KNOWN_CODES.get(code) or (
            self.message_key if self.message_key in SAFE_MESSAGES.values() else
            self.reason if isinstance(self.reason, str) else "request")
        return "{}: {}".format(heading, text.get(key, text["request"]))

    def to_dict(self):
        return {"status": self.status, "code": self.code,
                "message_key": self.message_key, "reason": self.reason}


class ProviderError(RuntimeError):
    def __init__(self, message, *, provider=None):
        self.provider = provider
        super().__init__(provider.message() if isinstance(provider, ProviderFailure) else message)


def provider_message(error, german=False):
    failure = error.provider if isinstance(error, ProviderError) else None
    return failure.message(german) if isinstance(failure, ProviderFailure) else ""


def cached_provider_message(data, german=False):
    if not isinstance(data, dict):
        return ""
    return ProviderFailure(*(data.get(key) for key in
                             ("status", "code", "message_key", "reason"))).message(german)


def is_json_media(response):
    headers = getattr(response, "headers", None)
    try:
        value = next((item for key, item in headers.items()
                      if isinstance(key, str) and key.lower() == "content-type"), None)
    except (AttributeError, TypeError):
        return False
    if not isinstance(value, str):
        return False
    media = value.split(";", 1)[0].strip().lower()
    kind, _, subtype = media.partition("/")
    return kind == "application" and (subtype == "json" or (
        subtype.endswith("+json") and len(subtype) > 5))


def provider_failure(response=None, reason="request"):
    status = getattr(response, "status_code", None)
    if type(status) is not int or not 100 <= status <= 599:
        status = None
    body = getattr(response, "content", None)
    code = message_key = None
    if is_json_media(response) and isinstance(body, bytes) and 0 < len(body) <= MAX_ERROR_BYTES:
        try:
            data = json.loads(body.decode("utf-8-sig"))
        except (ValueError, UnicodeError, RecursionError):
            data = None
        if isinstance(data, dict):
            containers = [data.get(key) for key in ("result", "Result", "error", "Error")]
            for item in containers + [data]:
                if not isinstance(item, dict):
                    continue
                if code is None:
                    code = next((value for key in ("code", "Code", "errorCode", "ErrorCode")
                                 if (value := numeric_code(item.get(key))) is not None), None)
                for key in (() if message_key else
                            ("messageCodename", "MessageCodename", "message", "Message")):
                    value = item.get(key)
                    if isinstance(value, str) and len(value) <= 120:
                        message_key = SAFE_MESSAGES.get(value.strip().lower().rstrip("."))
                        if message_key:
                            break
                if code is not None and message_key:
                    break
    return ProviderFailure(status, code, message_key, reason)


def provider_json(response, error_type):
    if not 200 <= response.status_code < 300:
        raise error_type("", provider=provider_failure(response))
    try:
        data = response.json()
    except ValueError:
        raise error_type("", provider=provider_failure(response, "invalid_json")) from None
    if not isinstance(data, dict):
        raise error_type("", provider=provider_failure(response, "unexpected"))
    return data
