"""Requests transport using Kodi's proxy settings, without a direct fallback."""

import json
import ipaddress
import threading
from urllib.parse import quote

import requests


class KodiProxyError(requests.RequestException):
    """A safe diagnostic; never include settings or transport exception text."""


PROXY_SCHEMES = {0: "http", 1: "socks4", 2: "socks4a", 3: "socks5", 4: "socks5h", 5: "https"}


def proxy_settings():
    import xbmc

    def setting(name):
        try:
            reply = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue",
                "params": {"setting": "network." + name},
            })))
            return reply["result"]["value"]
        except (ValueError, TypeError, KeyError, AttributeError, RuntimeError):
            raise KodiProxyError("Cannot read Kodi proxy settings") from None

    enabled = setting("usehttpproxy")
    if type(enabled) is not bool:
        raise KodiProxyError("Cannot read Kodi proxy settings")
    if not enabled:
        return None
    kind = setting("httpproxytype")
    host = setting("httpproxyserver")
    port = setting("httpproxyport")
    username = setting("httpproxyusername")
    password = setting("httpproxypassword")
    if (type(kind) is not int or kind not in PROXY_SCHEMES
            or not isinstance(host, str) or not host or host != host.strip()
            or any(char in host for char in "/@?#\\ ") or any(ord(char) < 32 for char in host)
            or type(port) is not int or not 1 <= port <= 65535
            or not isinstance(username, str) or not isinstance(password, str)):
        raise KodiProxyError("Kodi proxy configuration is invalid or unsupported")
    if kind in (1, 2, 3, 4):
        try:
            import socks
            if not callable(getattr(socks, "create_connection", None)):
                raise ImportError
        except ImportError:
            raise KodiProxyError("Kodi SOCKS proxy requires PySocks support") from None
    if kind == 5:
        from requests.packages import urllib3
        try:
            version = tuple(int(part) for part in urllib3.__version__.split(".")[:2])
        except (ValueError, AttributeError):
            version = ()
        if version < (1, 26):
            raise KodiProxyError("Kodi HTTPS proxy requires newer urllib3 support")
    if ":" in host or "[" in host or "]" in host:
        try:
            host = "[" + str(ipaddress.IPv6Address(host.strip("[]"))) + "]"
        except ValueError:
            raise KodiProxyError("Kodi proxy configuration is invalid or unsupported") from None
    credentials = ""
    if username or password:
        credentials = quote(username, safe="") + ":" + quote(password, safe="") + "@"
    url = "{}://{}{}:{}".format(PROXY_SCHEMES[kind], credentials, host, port)
    return {"http": url, "https": url, "all": url}


class KodiSession(requests.Session):
    def __init__(self):
        super().__init__()
        self._proxy_lock = threading.RLock()

    def request(self, method, url, **kwargs):
        with self._proxy_lock:
            proxies = proxy_settings()
            if proxies is None:
                return super().request(method, url, **kwargs)
            previous = self.trust_env
            self.trust_env = False
            kwargs["proxies"] = proxies
            try:
                return super().request(method, url, **kwargs)
            except requests.RequestException:
                raise KodiProxyError("Request through Kodi proxy failed") from None
            finally:
                self.trust_env = previous


def request(method, url, **kwargs):
    with KodiSession() as session:
        return session.request(method, url, **kwargs)
