"""Shared, cache-only helpers for TV navigation and programme information."""

import datetime
import time

from seek_timeline import sane_timeline


LIVE_GAP = 12
SETTINGS_SHORTCUT = "settings"


class ChannelNumber:
    """Number-key entry for lineup numbers (Kodi REMOTE_0..9 = 58..67)."""

    TIMEOUT = 1.5

    def __init__(self):
        self.digits = ""
        self.until = 0.0
        self.truncated = False

    def press(self, action_id, now):
        if not 58 <= action_id <= 67:
            return None
        if now >= self.until:
            self.digits = ""
            self.truncated = False
        self.truncated |= len(self.digits) >= 3
        self.digits = (self.digits + str(action_id - 58))[-3:]
        self.until = now + self.TIMEOUT
        return self.digits

    def is_settings(self):
        return self.digits == "000" and not self.truncated

    def take(self, now, confirm=False):
        if not self.digits or not confirm and now < self.until:
            return None
        number = SETTINGS_SHORTCUT if self.is_settings() else int(self.digits)
        self.digits = ""
        self.truncated = False
        return number


def lineup_numbers(channels):
    numbers = {}
    for position, channel in enumerate(channels, 1):
        numbers.setdefault(channel, position)
    return numbers


def number_text(number):
    return "{:03d}".format(number) if type(number) is int and number > 0 else ""


def numbered(number, title):
    prefix = number_text(number)
    title = title or ""
    if not prefix or title.startswith(prefix + "  "):
        return title
    return "{}  {}".format(prefix, title) if title else prefix


def number_channel(number, numbers, visible):
    channel = next((code for code, position in numbers.items() if position == number), None)
    if channel is None:
        return None, "unknown"
    return (channel, "") if channel in visible else (channel, "hidden")


def number_status(digits, numbers, visible, channel_name, german=False, settings_shortcut=False):
    if settings_shortcut:
        return "{}_  →  {}".format(digits, "Einstellungen" if german else "Settings")
    number = int(digits)
    channel, reason = number_channel(number, numbers, visible)
    target = "{:03d}".format(number)
    if reason == "unknown":
        return "{}_  →  {} {}".format(digits, target, "nicht belegt" if german else "not assigned")
    title = channel_name(channel) or channel
    suffix = " (ausgeblendet)" if german else " (hidden)"
    return "{}_  →  {} {}{}".format(digits, target, title, suffix if reason else "")


class StationHistory:
    def __init__(self):
        self.current = self.previous = None

    def started(self, channel):
        if channel and channel != self.current:
            self.previous, self.current = self.current, channel

    def target(self, allowed):
        return self.previous if self.previous in allowed else None


def live_target(playback, xbmc):
    if not playback or not playback.get("live"):
        return None
    try:
        player = playback["player"]
        if (not player.isPlayingVideo() or not playback["matches"]()
                or not xbmc.getCondVisibility("Player.SeekEnabled")
                or xbmc.getCondVisibility("Player.Seeking")):
            return None
        position, duration = player.getTime(), player.getTotalTime()
        if sane_timeline(position, duration) and duration - position >= LIVE_GAP:
            return duration
    except RuntimeError:
        return None
    return None


def programme_banner(events, channel, station, now, german=False):
    from guide import repair_mojibake
    from live_cache import now_next_programmes

    current, following = next(now_next_programmes(events, [channel], now))[1]

    def title(entry):
        value = entry[2].get("title") if entry else None
        return repair_mojibake(value).strip() if isinstance(value, str) else ""

    heading = title(current)
    if not heading:
        return station, "", "", 0
    start, stop, _ = current
    ends = datetime.datetime.fromtimestamp(stop).strftime("%H:%M")
    upcoming = title(following)
    return (station, "{}  ·  {} {}".format(heading, "bis" if german else "until", ends),
            ("Danach: " if german else "Next: ") + upcoming if upcoming else "",
            100 * (now - start) / (stop - start))


class ProgrammeBanner:
    def __init__(self, window, addon, xbmcgui, font, fade, *, bottom=False, fonts=None, lift=False):
        import os

        width, height = window.getWidth(), window.getHeight()
        left, top = int(width * .12), int(height * .16)
        wide = int(width * .76)
        row = max(24, int(height * .032))
        rows = (row, row, row)
        inset, gap = 16, 0
        if bottom:
            rows = (max(23, round(height * .030)), max(28, round(height * .040)),
                    max(22, round(height * .028)))
            gap = max(2, round(height * .004))
            left, wide = 0, width
            inset = min(20, max(4, width // 30))
        body = sum(rows) + 2 * gap
        if bottom:
            top = height - body - 16
        solid = os.path.join(addon.getAddonInfo("path"), "resources", "skins", "Default",
                             "media", "guide-solid.png")
        self.background = xbmcgui.ControlImage(
            left, top, wide, body + 16, solid, colorDiffuse="FF101722")
        self.progress_width = max(1, wide - 2 * inset)
        colors = ("FFE0E7F0", "FFFFFFFF", "FFB8C6D8") if bottom else ("FFFFFFFF",) * 3
        self.labels = [xbmcgui.ControlLabel(left + inset, top + sum(rows[:i]) + i * gap + 4,
                                           self.progress_width, size, "", font=face,
                                           textColor=color, alignment=4)
                       for i, (size, face, color) in enumerate(zip(rows, fonts or (font,) * 3, colors))]
        self.track = xbmcgui.ControlImage(left + inset, top + body + 6,
                                          self.progress_width, 4, solid, colorDiffuse="FF334155")
        self.progress = xbmcgui.ControlImage(left + inset, top + body + 6,
                                             1, 4, solid, colorDiffuse="FF80D6FF")
        self.controls = [self.background, *self.labels, self.track, self.progress]
        # A hide animation, or a reversible fade-in, can linger under Kodi's OSD.
        self.fade = [(event, attrs + " reversible=false" if event == "Visible" else attrs)
                     for event, attrs in fade if event != "Hidden"]
        # A lifted banner rises above the skin's video controls natively, without waiting for
        # the next Python tick. lift is the controls' top edge as a fraction of the screen
        # height; True means unknown controls, so the banner moves to the top edge instead.
        self.lift = bool(bottom and lift is not False and lift is not None)
        self.raised = []
        if self.lift:
            end = top + body + 16
            target = (round(height * float(lift) - max(4, height * .01))
                      if lift is not True else None)
            if target is None or target - body - 16 < height * .05:
                target = round(height * .05) + body + 16
            offset = min(0, target - end) if lift is True or float(lift) < 1 else 0
            if offset:
                self.raised = [("Conditional", "effect=slide end=0,{} time=250 tween=cubic "
                                "easing=out condition=Window.IsVisible(videoosd)".format(offset))]
        window.addControls(self.controls)
        for control in self.controls:
            control.setVisible(False)
            control.setAnimations(self.fade + self.raised)
            control.setVisibleCondition("!Window.IsVisible(fullscreeninfo)" if self.lift else
                                        "!Window.IsVisible(videoosd) + !Window.IsVisible(fullscreeninfo)")
        self.until = 0
        self.model = ("", "", "", 0)
        self.visible = False
        self.obstructed = False
        self.osd = False

    def show(self, model):
        self.model = model
        for control, label in zip(self.labels, model[:3]):
            control.setLabel(label, shadowColor="FF000000")
        self.progress.setWidth(max(1, round(self.progress_width * model[3] / 100)))
        self.until = time.monotonic() + 4
        self.visible = None

    def update(self, unobstructed, osd=False):
        now = time.monotonic()
        osd = self.lift and osd
        if self.osd and not osd:
            # Let the banner slide back down before it expires.
            self.until = max(self.until, now + 2)
        self.osd = osd
        visible = unobstructed and ((osd and bool(self.model[0])) or now < self.until)
        obstructed = not unobstructed
        if visible == self.visible and obstructed == self.obstructed:
            return
        self.visible = visible
        if obstructed != self.obstructed:
            for control in self.controls:
                control.setAnimations(self.raised if obstructed else self.fade + self.raised)
            self.obstructed = obstructed
        self.background.setVisible(visible)
        for control, text in zip(self.labels, self.model[:3]):
            control.setVisible(visible and bool(text))
        self.track.setVisible(visible and bool(self.model[1]))
        self.progress.setVisible(visible and self.model[3] > 0)

    def close(self, window):
        window.removeControls(self.controls)


TRACE_PROPERTY = "simplitv_t.dev.input_trace"


def input_trace(event, **fields):
    import xbmc
    import xbmcgui

    window = xbmcgui.Window(10000)
    if window.getProperty(TRACE_PROPERTY) == "1":
        import json

        xbmc.log("simpliTV input trace " + json.dumps(
            dict(fields, event=event, t=round(time.monotonic(), 3))), xbmc.LOGINFO)
