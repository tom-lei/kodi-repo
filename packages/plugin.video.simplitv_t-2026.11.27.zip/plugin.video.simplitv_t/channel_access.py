import json
import os
import re
from urllib.parse import urlsplit

from live_cache import LiveDataError
from provider_errors import ProviderFailure, provider_failure, provider_message


CACHE_KEY = "live-channel-grants-v3"
CHANNEL_TILE_CACHE_KEY = "channel-tiles-v2"
BRANDING_KEY = "channel-branding"
CATCHUP_POLICY_KEY = "catchup-policy-v2"
CACHE_SECONDS = 5 * 60
CHANNEL_TILE_ID = re.compile(r"chn\.(0|[1-9][0-9]{0,9})")
MAX_PROFILE_ID = 2147483647
ACCESS_TEXT = (
    {"loading": "Checking channel access…", "error": "Channel access could not be checked",
     "partial": "Channel access check incomplete", "empty": "No channels confirmed playable",
     "settings": "Live TV settings", "hint": "Turn off ‘Show only playable channels’ in Live TV settings to see all channels."},
    {"loading": "Senderberechtigungen werden geprüft…", "error": "Senderberechtigungen konnten nicht geprüft werden",
     "partial": "Senderberechtigungen unvollständig", "empty": "Keine abspielbaren Sender bestätigt",
     "settings": "Live-TV-Einstellungen", "hint": "Für alle Sender „Nur abspielbare Sender anzeigen“ in den Live-TV-Einstellungen ausschalten."},
)


def channel_profile_id(tile_id):
    match = CHANNEL_TILE_ID.fullmatch(tile_id) if isinstance(tile_id, str) else None
    channel_id = int(match[1]) if match else None
    return channel_id if channel_id is not None and channel_id <= MAX_PROFILE_ID else None


def playable_only_enabled(addon):
    return addon.getSetting("hide_unplayable_channels") != "false"


def channel_details(session, ids):
    response = session._request("POST", "/v2/Tile/GetTiles", data=json.dumps({
        "platformCodename": "www", "isParentalControlEnabled": "false",
        "requestedTiles": [{"id": "chn.{}".format(item)} for item in sorted(ids)],
    }))
    tiles = session._json(response).get("tiles")
    if not isinstance(tiles, list):
        raise LiveDataError("", provider=provider_failure(response, "unexpected"))
    return tiles


def channel_branding(tiles, lineup):
    expected = {(code, key) for code, key in lineup if key is not None}
    output, seen = {}, set()
    for tile in tiles:
        if not isinstance(tile, dict):
            continue
        code = tile.get("codename")
        key = channel_profile_id(tile.get("id"))
        if not isinstance(code, str) or (code, key) not in expected:
            continue
        if code in seen:
            output.pop(code, None)
            continue
        seen.add(code)
        name, images = tile.get("title"), tile.get("images")
        logos = {}
        for image in images if isinstance(images, list) else ():
            if not isinstance(image, dict):
                continue
            role, url = image.get("role"), image.get("url")
            if role != "icon-on-dark" or not isinstance(url, str):
                continue
            try:
                parts = urlsplit(url)
                if parts.scheme == "https" and parts.hostname and not parts.username:
                    logos.setdefault(role, url)
            except ValueError:
                continue
        logo = logos.get("icon-on-dark")
        output[code] = [name.strip() if isinstance(name, str) and name.strip() else None, logo]
    return output


def load_channel_grants(session, token, lineup):
    response = session._request("GET", "/v1/OrsUser/GetProfile", params={
        "platformCodename": "www", "token": token
    })
    profile = session._json(response)
    if isinstance(profile.get("result"), dict) and profile["result"].get("success") is False:
        raise LiveDataError("", provider=provider_failure(response))
    entries = profile.get("availableChannels")
    if not isinstance(entries, list):
        raise LiveDataError("", provider=provider_failure(response, "unexpected"))
    allowed = set()
    timeshift_denied = set()
    conflicting = set()
    catchup_channels = {}
    seen_catchup = set()
    for entry in entries:
        if (not isinstance(entry, dict) or type(entry.get("id")) is not int
                or not 0 <= entry["id"] <= MAX_PROFILE_ID):
            continue
        channel_id = entry["id"]
        tile_id = "chn.{}".format(channel_id)
        if tile_id in seen_catchup:
            catchup_channels.pop(tile_id, None)
        else:
            seen_catchup.add(tile_id)
            catchup_channels[tile_id] = {
                key: entry[key] for key in ("canPlay", "catchupEnabled", "catchupFrom", "catchupTo")
                if key in entry}
        if entry.get("timeshiftEnabled") is False:
            timeshift_denied.add(channel_id)
        if entry.get("canPlay") is True:
            allowed.add(channel_id)
        else:
            conflicting.add(channel_id)
    grants = allowed - conflicting
    candidates = sorted({item for _, item in lineup if item is not None} - grants)
    if len(candidates) > 500:
        raise LiveDataError("Too many live channel access entries")
    free, branding = {}, {}
    incomplete = False
    failure = None
    for offset in range(0, len(candidates), 100):
        batch = set(candidates[offset:offset + 100])
        try:
            tiles = channel_details(session, batch)
        except RuntimeError as error:
            session.log("Cannot check free live channels: {}".format(
                provider_message(error) or type(error).__name__))
            failure = getattr(error, "provider", None)
            incomplete = True
            break
        branding.update(channel_branding(tiles, [(code, key) for code, key in lineup
                                                if key in batch]))
        seen = set()
        for tile in tiles:
            if not isinstance(tile, dict):
                continue
            channel_id = channel_profile_id(tile.get("id"))
            if channel_id not in batch:
                continue
            if channel_id in seen:
                free.pop(channel_id, None)
                continue
            seen.add(channel_id)
            opts = tile.get("purchaseOptions")
            code = tile.get("codename")
            if (isinstance(opts, dict) and type(opts.get("freeAccessType")) is int
                    and opts["freeAccessType"] == 1 and opts.get("products") == []
                    and isinstance(code, str) and code):
                free[channel_id] = code
        incomplete |= seen != batch
    result = {"status": "partial" if incomplete else "ready", "branding": branding,
            "profile": sorted(grants), "free": [[key, value] for key, value in free.items()],
            "timeshift_denied": sorted(timeshift_denied),
            "account_catchup_enabled": profile.get("catchupEnabled") is True,
            "catchup_agreement_missing": profile.get("catchupAgreementMissing"),
            "catchup_channels": catchup_channels,
            "account_timeshift_denied": (profile.get("timeshiftEnabled") is False
                                        or profile.get("timeshiftAgreementMissing") is True)}
    if isinstance(failure, ProviderFailure):
        result["provider_error"] = failure.to_dict()
    return result


def prepare_catchup_policy(session, cache, channel_seconds):
    lineup = cache.peek(CHANNEL_TILE_CACHE_KEY, channel_seconds)
    if not lineup:
        return

    def load():
        response = session._request("GET", "/v2/InsysGoBootstrap/SystemBootstrap",
                                    params={"platformCodename": "www"})
        data = session._json(response)
        result = data.get("result", data.get("Result"))
        if not isinstance(result, dict) or result.get("success", result.get("Success")) is not True:
            raise LiveDataError("", provider=provider_failure(response))
        settings = data.get("settings", data.get("Settings"))
        if not isinstance(settings, dict):
            raise LiveDataError("Missing catch-up publication settings")
        ids = sorted({key for _, key in lineup if key is not None})
        if len(ids) > 500:
            raise LiveDataError("Too many catch-up channel entries")
        expected = {(code, key) for code, key in lineup}
        channels, seen = {}, set()
        for offset in range(0, len(ids), 100):
            for tile in channel_details(session, set(ids[offset:offset + 100])):
                if not isinstance(tile, dict):
                    continue
                identity = tile.get("id")
                key = channel_profile_id(identity)
                if (tile.get("codename"), key) not in expected:
                    continue
                if identity in seen:
                    channels.pop(identity, None)
                    continue
                seen.add(identity)
                channels[identity] = {
                    "codename": tile.get("codename"),
                    "isCatchupEnabled": tile.get("isCatchupEnabled"),
                    "isBlackouted": tile.get("isBlackouted"),
                    "hasPlayableStream": tile.get("hasPlayableStream"),
                    "stop_margin": tile.get("pvrStopTimeMinutesMargin")}
        return {"channels": channels,
                "available_immediately": settings.get(
                    "Video.Pvr.General.AreCatchupsAvailableImmediatelyAfterBroadcast"),
                "publication_delay": settings.get("Video.Pvr.General.NpvrPublicationDelaySeconds"),
                "stop_margin": settings.get("Video.Pvr.General.StopTimeMinutesMargin")}

    lock = os.path.join(os.path.dirname(session.lock_path), "catchup-policy.lock")
    return cache.get_with_lock(CATCHUP_POLICY_KEY, load, CACHE_SECONDS, lock,
                               wait_seconds=2, identity=lineup)


def prepare_channel_grants(session, cache, auth_error, channel_seconds):
    lineup = cache.peek(CHANNEL_TILE_CACHE_KEY, channel_seconds)
    if lineup is None:
        session.log("Live channel access skipped: channel list is unavailable")
        return None

    def load():
        try:
            return load_channel_grants(session, session.token(), lineup)
        except (auth_error, LiveDataError) as error:
            session.log("Live channel access unavailable: {}".format(error))
            if isinstance(getattr(error, "provider", None), ProviderFailure):
                return {"status": "error", "profile": [], "free": [],
                        "provider_error": error.provider.to_dict()}
        return {"status": "error", "profile": [], "free": []}

    session.log("Checking live channel access for {} catalog channels".format(len(lineup)))
    lock = os.path.join(os.path.dirname(session.lock_path), "live-channel-access.lock")
    access = cache.get_with_lock(CACHE_KEY, load, CACHE_SECONDS, lock, wait_seconds=2, identity=lineup)
    session.log("Live channel access {}: {} profile grants, {} free channels".format(
        access["status"], len(access["profile"]), len(access["free"])))
    return access


def prepare_channel_branding(session, cache, channel_seconds, seed):
    lineup = cache.peek(CHANNEL_TILE_CACHE_KEY, channel_seconds)
    if not lineup:
        return

    def load():
        branding = dict(seed)
        ids = sorted({key for code, key in lineup if key is not None and code not in branding})
        if len(ids) > 500:
            raise LiveDataError("Too many live channel branding entries")
        for offset in range(0, len(ids), 100):
            batch = set(ids[offset:offset + 100])
            try:
                tiles = channel_details(session, batch)
            except RuntimeError as error:
                session.log("Live channel branding unavailable: {}".format(type(error).__name__))
                break
            branding.update(channel_branding(tiles, [(code, key) for code, key in lineup
                                                    if key in batch]))
        return branding

    lock = os.path.join(os.path.dirname(session.lock_path), "live-channel-branding.lock")
    cache.get_with_lock(BRANDING_KEY, load, channel_seconds, lock, wait_seconds=2, identity=lineup)


def filter_live_channels(tiles, access, enabled):
    if not enabled:
        return [code for code, _ in tiles], ""
    if access is None:
        return [], "loading"
    grants = set(access["profile"])
    free = {tuple(entry) for entry in access["free"]}
    channels = [code for code, key in tiles if key in grants or (key, code) in free]
    return channels, access["status"] if access["status"] != "ready" else ("" if channels else "empty")
