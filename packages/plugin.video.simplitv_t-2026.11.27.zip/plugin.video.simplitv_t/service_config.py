import hashlib
import json


API_ROOT = "https://api.app.austrostream.at"
FILES_ROOT = "https://files.app.austrostream.at"
CHANNEL_LOGO_ROOT = FILES_ROOT
PORTAL_ROOT = "https://streaming.simpli.at"
TENANT_CODENAME = "simplitv"


def service_scope(api_root, tenant):
    return hashlib.sha256(json.dumps([api_root, tenant]).encode("utf-8")).hexdigest()
