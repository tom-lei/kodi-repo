"""Watch settings changes made outside the add-on's own settings dialog."""

import threading
import time

import xbmc
import xbmcaddon

from auth_session import configured, credentials, start_credential_check


class SettingsMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.addon = xbmcaddon.Addon("plugin.video.simplitv_t")
        self.current = credentials(self.addon)
        self.deadline = None
        self.lock = threading.Lock()

    def onSettingsChanged(self):
        current = credentials(self.addon)
        with self.lock:
            if current != self.current:
                self.current = current
                self.deadline = time.monotonic() + 0.6 if configured(current) else None

    def run(self):
        while not self.waitForAbort(0.2):
            with self.lock:
                ready = (self.deadline is not None and time.monotonic() >= self.deadline
                         and not xbmc.getCondVisibility("Window.IsVisible(addonsettings)"))
                if ready:
                    self.deadline = None
            if ready:
                start_credential_check()


if __name__ == "__main__":
    SettingsMonitor().run()
