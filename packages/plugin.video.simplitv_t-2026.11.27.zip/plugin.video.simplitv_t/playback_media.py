"""Select one compatible media format and its associated DRM."""

import re
from urllib.parse import urlsplit


_MISSING = object()
WIDEVINE = "com.widevine.alpha"


def _field(entry, name, default=_MISSING):
    return entry.get(name, entry.get(name[0].lower() + name[1:], default))


def _items(entry, name):
    for key in (name, name[0].lower() + name[1:]):
        values = entry.get(key)
        if isinstance(values, list) and values:
            return values
    return []


def media_files(response):
    return _items(response, "MediaFiles")


def _http_url(value):
    if not isinstance(value, str) or not value or any(c.isspace() or c == "|" for c in value):
        return None
    try:
        parts = urlsplit(value)
        if parts.scheme in ("https", "http") and parts.hostname:
            return parts
    except ValueError:
        pass
    return None


def _widevine_license(entries):
    if isinstance(entries, list):
        for drm in entries:
            if not isinstance(drm, dict):
                continue
            name = _field(drm, "DrmSystem")
            if not isinstance(name, str) or name.strip().casefold() not in ("widevine", WIDEVINE):
                continue
            server = _field(drm, "LicenseServerUrl")
            challenge = _field(drm, "DrmChallengeCustomData")
            if _http_url(server) and isinstance(challenge, str):
                return server, challenge
    return None


def _legacy_manifest(parts, source, target):
    # Keep the old counterpart naming on the chosen manifest path only.
    converted = re.sub(r"(?<=/)" + source + r"(?=(?:_nodrm|4h)?/)", target, parts.path)
    converted = converted.replace(source + "_live", target + "_live")
    extension = ".mpd" if target == "dash" else ".m3u8"
    converted = converted.rsplit(".", 1)[0] + extension
    return parts._replace(path=converted).geturl()


def select_playback(response):
    files = media_files(response)
    root_drm = _field(response, "DrmInfo")
    root_protected = _field(response, "IsDrmProtected", False)
    choices = {}
    for media in files:
        if not isinstance(media, dict):
            continue
        formats = _items(media, "Formats")
        media_drm = _field(media, "DrmInfo")
        scoped_protection = any(
            _field(fmt, "IsDrmProtected", False) is not False
            or _field(fmt, "DrmInfo") not in (_MISSING, [])
            for fmt in formats if isinstance(fmt, dict)
        )
        for fmt in formats:
            if not isinstance(fmt, dict):
                continue
            url = _field(fmt, "Url")
            parts = _http_url(url)
            if parts is None:
                continue
            path = parts.path.lower()
            if not path.endswith((".mpd", ".m3u8")):
                continue
            dash = path.endswith(".mpd")
            format_drm = _field(fmt, "DrmInfo")
            protected = (any(flag is not False for flag in (
                root_protected, _field(media, "IsDrmProtected", False),
                _field(fmt, "IsDrmProtected", False)))
                or any(entries is not _MISSING and entries != []
                       for entries in (format_drm, media_drm, root_drm)))
            if protected:
                entries = format_drm if format_drm is not _MISSING else media_drm
                if entries is _MISSING and len(files) == 1:
                    entries = root_drm
                license_data = _widevine_license(entries)
                if license_data is None:
                    continue
                manifest = url if dash else _legacy_manifest(parts, "hls", "dash")
                choices.setdefault(0 if dash else 3, (manifest, *license_data))
            else:
                # Another format's license is neither usable here nor proof this
                # unlabeled format is clear.
                if (scoped_protection and format_drm is _MISSING and media_drm is _MISSING
                        and root_drm is _MISSING
                        and _field(fmt, "IsDrmProtected") is _MISSING
                        and _field(media, "IsDrmProtected") is _MISSING
                        and _field(response, "IsDrmProtected") is _MISSING):
                    continue
                choices.setdefault(1 if dash else 2, (url, "false", "false"))
    if not choices:
        raise ValueError("simpliTV returned no compatible playback format or DRM")
    return choices[min(choices)]
