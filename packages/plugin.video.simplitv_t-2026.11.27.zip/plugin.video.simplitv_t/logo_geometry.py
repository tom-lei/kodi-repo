"""simpliTV guide-logo sizing policy."""


LOGO_CELL = (176, 45)


def target_logo_size(geometry, cell=LOGO_CELL):
    """Return original visible artwork enlarged by 25%, limited by the cell."""
    canvas_w, canvas_h, art_w, art_h = geometry
    cell_w, cell_h = cell
    old_scale = min(cell_w / canvas_w, cell_h / canvas_h)
    scale = min(1.25 * old_scale, cell_w / art_w, cell_h / art_h)
    return min(cell_w, art_w * scale), min(cell_h, art_h * scale)


def guide_frame(geometry):
    """Return cell and visible-art dimensions for the provider-neutral encoder."""
    return LOGO_CELL, target_logo_size(geometry)


def logo_box(width, height):
    """Fit the guide frame inside an available screen rectangle."""
    cell_w, cell_h = LOGO_CELL
    scale = min(1.0, width / cell_w, height / cell_h)
    return max(1, round(cell_w * scale)), max(1, round(cell_h * scale))
