"""Shared channel artwork cache for Magenta TV ATᵀ and simpliTVᵀ (GPL-3.0-or-later)."""

import hashlib
import os
import re
import sqlite3
import tempfile
import threading
import time
from collections import OrderedDict
from pathlib import Path

from logo_pixels import ALPHA_THRESHOLD, MAX_BYTES, RULE_VERSION, prepare_logo, trim_png


MAX_ENTRIES = 256
MAX_DISK = 64 * 1024 * 1024
HTTP_TTL = 24 * 3600
IDLE_SECONDS = 2


def _suffix(data):
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if data.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if data[:6] in (b"GIF87a", b"GIF89a"):
        return ".gif"
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        return ".webp"
    raise ValueError("Unknown image format")


class LogoCache:
    """get() and revision are UI-safe. All I/O and decoding run on one owned worker."""

    def __init__(self, profile, fetch, log, local_path=None, guide_frame=None):
        suffix = "-framed" if guide_frame is not None else ""
        self.root = Path(profile) / ("channel-logos-v{}-a{}{}".format(
            RULE_VERSION, ALPHA_THRESHOLD, suffix))
        self.fetch = fetch
        self.log = log
        self.local_path = local_path
        self.guide_frame = guide_frame
        self._condition = threading.Condition()
        self._ready = OrderedDict()
        self._pending = OrderedDict()
        self._active = None
        self._thread = None
        self._closed = False
        self.revision = 0

    def get(self, source, *, framed=False):
        if not isinstance(source, str) or not source or len(source) > 8192:
            return None
        with self._condition:
            if self._closed:
                return None
            path, until = self._ready.get(source, (None, 0))
            if until <= time.monotonic() and source not in self._pending and source != self._active:
                if len(self._pending) >= MAX_ENTRIES:
                    self._pending.popitem(last=False)
                self._pending[source] = None
                if self._thread is None:
                    self._thread = threading.Thread(target=self._run, name="channel-logos", daemon=True)
                    self._thread.start()
                self._condition.notify()
            return path[int(framed)] if isinstance(path, tuple) else path

    def close(self):
        with self._condition:
            self._closed = True
            self._pending.clear()
            self._condition.notify_all()
            thread = self._thread
        if thread is not None:
            thread.join()

    def _publish(self, source, path, ttl):
        with self._condition:
            old, _ = self._ready.get(source, (None, 0))
            self._ready[source] = (path, time.monotonic() + ttl)
            self._ready.move_to_end(source)
            if len(self._ready) > MAX_ENTRIES:
                self._ready.popitem(last=False)
            if path != old:
                self.revision += 1

    def _run(self):
        db = None
        try:
            while True:
                with self._condition:
                    ready = self._condition.wait_for(lambda: self._closed or self._pending, IDLE_SECONDS)
                    if self._closed or not ready:
                        self._thread = None
                        return
                    source, _ = self._pending.popitem(last=False)
                    self._active = source
                try:
                    if db is None:
                        self.root.mkdir(exist_ok=True, parents=True)
                        db = sqlite3.connect(str(self.root / "index.db"), timeout=3)
                        if self.guide_frame is None:
                            db.execute("CREATE TABLE IF NOT EXISTS logos (id TEXT PRIMARY KEY, file TEXT, "
                                       "size INTEGER, checked REAL, stamp TEXT, etag TEXT, modified TEXT)")
                        else:
                            db.execute("CREATE TABLE IF NOT EXISTS logos (id TEXT PRIMARY KEY, file TEXT, frame TEXT, "
                                       "size INTEGER, checked REAL, stamp TEXT, etag TEXT, modified TEXT)")
                    self._load(db, source)
                except (OSError, ValueError, sqlite3.Error, RuntimeError) as error:
                    self.log("Channel artwork unavailable: " + type(error).__name__)
                    with self._condition:
                        path = self._ready.get(source, (None, 0))[0]
                    self._publish(source, path, 300)
                finally:
                    with self._condition:
                        self._active = None
        finally:
            if db is not None:
                db.close()

    def _load(self, db, entry):
        source = entry
        key = hashlib.sha256(source.encode("utf-8")).hexdigest()
        columns = "file, checked, stamp, etag, modified"
        if self.guide_frame is not None:
            columns = "file, frame, checked, stamp, etag, modified"
        row = db.execute("SELECT {} FROM logos WHERE id=?".format(columns), (key,)).fetchone()
        if row and not self._file(row[0]).is_file():
            row = None
        if row and self.guide_frame is not None and not self._file(row[1]).is_file():
            row = None
        remote = source.startswith(("https://", "http://"))
        now = time.time()
        ttl = HTTP_TTL if remote else 60
        if row:
            if self.guide_frame is None:
                path = str(self.root / row[0])
                checked, stamp, etag, modified = row[1:]
            else:
                path = (str(self.root / row[0]), str(self.root / row[1]))
                checked, stamp, etag, modified = row[2:]
            remaining = checked + ttl - now
            self._publish(source, path, min(ttl, max(0, remaining)))
            if remote and remaining > 0:
                return
        headers = {}
        stamp = ""
        if remote:
            if row and etag:
                headers["If-None-Match"] = etag
            if row and modified:
                headers["If-Modified-Since"] = modified
            status, headers, data = self.fetch(source, headers)
            if row and status == 304:
                with db:
                    db.execute("UPDATE logos SET checked=? WHERE id=? AND file=?", (now, key, row[0]))
                self._publish(source, path, ttl)
                return
            if status != 200:
                raise ValueError("Artwork request failed")
        else:
            local = self.local_path(source) if self.local_path is not None else None
            if not local or not os.path.isabs(local) or str(local).startswith(("\\\\", "//")):
                raise ValueError("Not a local image")
            with open(local, "rb") as stream:
                stat = os.fstat(stream.fileno())
                stamp = "{}:{}".format(stat.st_mtime_ns, stat.st_size)
                if row and (row[3] if self.guide_frame is not None else row[2]) == stamp:
                    self._publish(source, path, ttl)
                    return
                data = stream.read(MAX_BYTES + 1)
        if not data or len(data) > MAX_BYTES:
            raise ValueError("Artwork size limit")
        ext = _suffix(data)
        # One digest keeps Kodi Omega on Windows below MAX_PATH in long profiles.
        name = hashlib.sha256(bytes.fromhex(key) + hashlib.sha256(data).digest()).hexdigest() + ext
        frame_data = None
        frame = name
        if self.guide_frame is not None and ext == ".png":
            try:
                data, frame_data = prepare_logo(data, self.guide_frame)
                frame = hashlib.sha256(b"frame" + name.encode("ascii")).hexdigest() + ext
            except ValueError as error:
                self.log("Using original channel artwork: " + type(error).__name__)
        elif (not row or row[0] != name) and ext == ".png":
            try:
                data = trim_png(data)
            except ValueError as error:
                self.log("Using original channel artwork: " + type(error).__name__)
        if len(data) > MAX_DISK:
            raise ValueError("Artwork cache size limit")
        # Serialize file publication/eviction too: Kodi can run several interpreters.
        dest = self._file(name)
        frame_dest = self._file(frame)
        with db:
            db.execute("BEGIN IMMEDIATE")
            if not dest.is_file():
                with tempfile.NamedTemporaryFile(dir=str(self.root), delete=False) as temp:
                    try:
                        temp.write(data)
                        temp.close()
                        os.replace(temp.name, dest)
                    finally:
                        if os.path.exists(temp.name):
                            os.unlink(temp.name)
            if frame_data is not None and not frame_dest.is_file():
                with tempfile.NamedTemporaryFile(dir=str(self.root), delete=False) as temp:
                    try:
                        temp.write(frame_data)
                        temp.close()
                        os.replace(temp.name, frame_dest)
                    finally:
                        if os.path.exists(temp.name):
                            os.unlink(temp.name)
            old = db.execute("SELECT file{} FROM logos WHERE id=?".format(
                ",frame" if self.guide_frame is not None else ""), (key,)).fetchone()
            def validator(field):
                value = headers.get(field, "")
                return value if isinstance(value, str) and len(value) <= 512 and "\n" not in value and "\r" not in value else ""
            if self.guide_frame is None:
                db.execute("INSERT OR REPLACE INTO logos VALUES(?,?,?,?,?,?,?)", (
                    key, name, dest.stat().st_size, now, stamp, validator("ETag"), validator("Last-Modified")))
            else:
                db.execute("INSERT OR REPLACE INTO logos VALUES(?,?,?,?,?,?,?,?)", (
                    key, name, frame, dest.stat().st_size
                    + (frame_dest.stat().st_size if frame != name else 0),
                    now, stamp, validator("ETag"), validator("Last-Modified")))
            if old:
                for obsolete in old:
                    if obsolete and obsolete not in (name, frame):
                        self._file(obsolete).unlink(missing_ok=True)
            size = 0
            query = "SELECT id,file,size FROM logos ORDER BY checked DESC, rowid DESC"
            if self.guide_frame is not None:
                query = "SELECT id,file,frame,size FROM logos ORDER BY checked DESC, rowid DESC"
            for index, item in enumerate(db.execute(query).fetchall()):
                victim, filename, length = item[0], item[1], item[-1]
                filenames = {filename}
                if self.guide_frame is not None:
                    filenames.add(item[2])
                size += length
                if index >= MAX_ENTRIES or size > MAX_DISK:
                    for obsolete in filenames:
                        self._file(obsolete).unlink(missing_ok=True)
                    db.execute("DELETE FROM logos WHERE id=?", (victim,))
                    with self._condition:
                        for url, (cached, _) in list(self._ready.items()):
                            cached_paths = cached if isinstance(cached, tuple) else (cached,)
                            if any(value == str(self.root / file) for value in cached_paths for file in filenames):
                                del self._ready[url]
                                self.revision += 1
        self._publish(source, (str(dest), str(frame_dest))
                      if self.guide_frame is not None else str(dest), ttl)

    def _file(self, name):
        if not isinstance(name, str) or not re.fullmatch(r"[a-f0-9]{64}\.(?:png|jpg|gif|webp)", name):
            raise ValueError("Invalid artwork cache entry")
        return self.root / name
