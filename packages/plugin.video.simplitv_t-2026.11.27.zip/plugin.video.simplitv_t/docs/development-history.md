# simpliTVᵀ development history

This is the history of the Kodi add-on `plugin.video.simplitv_t`, maintained
separately from the original `plugin.video.simplitv` by Publish3r and
sunsettrack4. The [changelog](../changelog.txt) carries forward the original
add-on's entries from March 2023 through May 2026. Those entries record the
original Live TV, restart, recordings and guide work, plus compatibility
fixes for logos, EPG, streams and metadata. They are not releases of this fork.

The fork kept the simpliTV account and device model, Austrostream API and
Widevine playback, but became a guide-first, Live TV-only add-on. The source
history starts at `2c17e9c`, a retained November 2026 snapshot with the
`2026.11.17` version label. By then the fork had a cached, remote-navigable
grid, verified channel filtering, guide playback and a separate add-on ID.
It subsequently incorporated the original add-on's November 2026 service
migration selectively. Git does not reconstruct the work before that first
snapshot; the version label alone does not establish a published package.

## Retained November 2026 builds

The source commits were reconstructed from retained build artifacts. Version
labels and commit dates are not necessarily the dates the packages appeared.
Public packages were published through the Kodi package repository, not as
GitHub Releases in this source repository.

| Version | Source | Status and changes |
| --- | --- | --- |
| `2026.11.22` | `5a6842b` | [Published package](https://github.com/tom-lei/kodi-repo/commit/4972712). The first retained complete published snapshot: guide-first navigation, catalogue artwork, owned player and channel switching, programme jumps, the broadcast-time overlay, CRT tuning, Catch-up, estimated rewind, and provider-selected stream formats with compatibility fallbacks. |
| `2026.11.23` | `719b2e8` | Private candidate. Kept the active video behind a translucent guide when the mini-picture was inactive. Its original isolated trial did not reach the guide, so the trial did not validate the backdrop. |
| `2026.11.24` | `8a3c259` | Mistakenly future-dated **private** candidate, not a public release. Adjusted backdrop layering and footer readability. Later synthetic screenshots verified the labels and stopped backdrop, not moving video. |
| `2026.11.23.1` | `b527673` | Private, version-only correction of the mistaken date. Same code as the preceding candidate; no new native run. |
| `2026.11.23.2` | `d114923` | Private candidate. Removed channel rows from the recovery directory while retaining Programme Guide, Live TV settings and guide playback. Directory handling was tested offline, not in Kodi for this package. |
| `2026.11.23.3` | `6ed78bf` | [Published package](https://github.com/tom-lei/kodi-repo/commit/1f41b9d). Fixed programme-boundary seeks when another seek is pending, without treating ordinary near-boundary playback as a completed jump. Later synthetic Kodi and authorized provider trials exercised repeat jumps; physical remote input and independent broadcast-clock alignment were not verified. |
| `2026.11.27` | version commit | Release candidate prepared for publication through the Kodi package repository; it is not a package until that repository publishes it. Packages all post-release implementation below, through `55151a1`. Offline tests passed; this package was not run in Kodi. |

The changes below are the source work released as `2026.11.27`.

## Post-release implementation

| Milestone | What changed |
| --- | --- |
| Guide audit (`f9a8c05`) | Restored movement from footer actions back to the grid, filled the last page, separated rows from programme cells, made loading failures repaint, completed German Back help, and reset future-only views after returning from playback. Added disposable Kodi JSON-RPC and EventServer tests. |
| Guide and player polish (`118e2af`–`4beb3db`) | Simplified separators, narrow tiles, header/help and the details panel; introduced PVR-style channel numbers and `000` Settings; gave the selected channel a clipped logo/name carousel. The owned player opens Kodi's OSD on OK, keeps the seek marker in bounds, and positions the programme banner above the active skin's controls. Programme times follow the device's timezone; protected playback checks Widevine through InputStream Helper. |
| Access and diagnostics (`4beb3db`–`bf4ffcc`) | Updated channel access and account onboarding, aligned rewind status with programme availability and kept localized provider diagnostics without exposing response bodies. Provider error bodies are interpreted only for JSON media types. |
| Time ruler and proxy (`862f379`–`cc7c241`) | Iterated on hour-label alignment without moving the first channel row. Routed Python HTTP through Kodi's configured proxy with no direct fallback on proxy failure; native playback and native image retrieval continue through Kodi. |
| Station logos (`b18cef5`–`12c7c74`) | Added background alpha cropping, cached high-density framing and shared textures for the guide, tuning screen and seek strip. Replaced an initial common size with each simpliTV source asset's original visible size enlarged by 25%, preserving aspect ratio and capping at the guide cell. The selected row holds its name until cold artwork can be shown; logos and frame geometry remain simpliTV-specific. Intermediate station reference tables were superseded by calculation from source images. |
| Guide lifecycle (`ee1b854`) | Return to the guide-started Catch-up or rewind airing when playback ends. Close an orphaned guide when its Kodi window unloads or the add-on is disabled; preserve Back and pending playback handoff. |
| Channel switching (`55151a1`) | Start tuning on the next player update without a fixed debounce. Preserve the latest requested channel while a submitted tune completes, and keep Kodi's native startup dialog from swallowing channel keys when it belongs to that tune. Authorization is still checked before submission. |

## Cross-add-on changes

The Magenta TV ATᵀ review used its integration through `cde31ad`. Its
`722a076` no-Home-flash change was already covered by simpliTVᵀ's retained
player window and windowed playback. `dcbf312` informed played-airing focus;
only the orphaned-guide portion of `4159e18` was applicable. `66f2d1d` and
`cde31ad` informed immediate channel changes and the native startup-input
fix. simpliTVᵀ already remembered newer channel requests after submission;
the update loop now also owns generator cancellation when a newer request
supersedes acquisition.

Shared guide ideas and logo cache work do not imply shared catalogue data,
logo sizing policy or playback rights. Magenta's Replay arrow redesign was
intentionally excluded; simpliTVᵀ keeps its clock badge and ⏪ marker.
Magenta-only Replay acquisition, login/lease reuse, licence relay, device and
CDM logic, and its logo URL validation are not used in simpliTVᵀ.

## Verification and limits

- The reconstruction commits record archive inventories and offline results
  for the retained packages. Those checks do not imply each candidate was
  played in Kodi or released.
- Disposable Windows Kodi runs exercised guide layout and logo sizing at
  1080p and 720p. The final presented-window captures show the cold name
  fallback and three full logo phases at both sizes. Earlier Kodi DirectX
  readbacks could be stale and were not evidence of displayed clipping.
- A disposable Kodi with a local logging proxy checked redirects, HTTPS
  `CONNECT` and no direct fallback through an invalid or unavailable proxy.
- The guide lifecycle was tested in disposable 1080p Kodi with synthetic
  listings and video: Back, ignored foreign unloads, owned unload, preserved
  handoff, same-window zapping, Stop refocusing the played airing, and
  disabling a disposable add-on. Activating Home without unloading the
  dialog correctly left the guide active.
- For `55151a1`, offline discovery ran 230 tests with one skip, including
  the migration doctests (33 scenarios). In disposable Kodi 21 on Windows
  at 1080p, the first P+ press started acquisition in 31 ms in one run.
  A second P+ press before the first delayed loopback stream had video was
  retained: the player reached the third channel without leaving its window.
  Both startup dialogs were dismissed before AV start. This is a local input
  and window-lifecycle check, not a provider tuning-speed measurement.
- Current offline and disposable tests are not proof of provider entitlement
  or network playback. Real Catch-up with an entitled account, PlayReady-only
  streams, physical remotes, and the final handoff on Android or LibreELEC
  were not validated by these runs. PlayReady-only playback is unsupported.

See the [developer reference](developer.md#development-and-tests) for
reproducible checks and the [user guide](../README.md) for current controls.
