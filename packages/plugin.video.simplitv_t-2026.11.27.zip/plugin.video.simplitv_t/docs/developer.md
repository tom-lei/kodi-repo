# simpliTVᵀ developer reference

For installation, controls and settings, see the [user guide](../README.md).
For the release and integration timeline, see the [development history](development-history.md).

simpliTVᵀ (`plugin.video.simplitv_t`) is a Kodi 21 video add-on for the live TV
service at <https://streaming.simpli.at/tv>. It is a modified version of the
original **simpliTV** add-on (`plugin.video.simplitv`) by **Publish3r** and
**sunsettrack4**; see [Credits](#credits). Both add-ons can be installed side by
side. simpliTVᵀ does not change the original add-on's files or settings.

A simpliTV account is required. The add-on only plays what the signed-in account
is entitled to; it does not bypass rights, Timeshift or Catch-up restrictions.

## Contents

- [Requirements and installation](#requirements-and-installation)
- [Features](#features)
- [Settings](#settings)
- [Usage and controls](#usage-and-controls)
- [Add-on player](#add-on-player)
- [Timeshift overlay and broadcast clock](#timeshift-overlay-and-broadcast-clock)
- [Rewind and Catch-up](#rewind-and-catch-up)
- [Playback, authentication and caching](#playback-authentication-and-caching)
- [Known limitations](#known-limitations)
- [Changes compared to the original add-on](#changes-compared-to-the-original-add-on)
- [Development and tests](#development-and-tests)
- [Credits](#credits)
- [License](#license)

## Requirements and installation

- Kodi 21 (Omega) with Python 3.
- `inputstream.adaptive`, `script.module.inputstreamhelper`, and
  `script.module.requests`. Before protected DASH playback, InputStream Helper
  checks Widevine and prompts for installation when needed. Clear DASH and HLS
  also use `inputstream.adaptive` but do not require Widevine. Programme times
  use the device's local timezone, including daylight-saving transitions.
- Install the add-on folder as `plugin.video.simplitv_t` in Kodi's `addons`
  directory, restart Kodi, and enter the e-mail address and password in the
  add-on settings.

## Features

- **Live TV only.** The add-on opens straight into a full-screen programme guide.
  There is no main menu, separate date-based guide or recordings browser.
  Provider recordings and account data are not changed.
- **Programme guide (EPG).** A rolling grid from seven hours ago to 21 hours
  ahead shows:
  - channel logos and names;
  - a local date and clock;
  - a red current-time line with a small marker on the time ruler;
  - programme details with a synopsis.

  Unavailable programmes are dimmed. The current-time marker advances every
  minute and spans only the displayed channel rows.
- **Guide mini-picture.** The current stream is displayed in the details area
  while the guide is open, without starting another stream or changing grid
  dimensions. Playback and audio continue, including a paused or rewound state.
  When the setting is off or the layout is too small for the mini-picture,
  matching playback appears behind the translucent guide instead. The guide
  stays opaque without matching playback or while tuning.
- **Channel logos.** Dark-background logos come from the provider's channel
  records, loaded in background batches, or programme tiles. If none is
  available, the station name is shown rather than a coloured logo. Channels
  are never hidden just because a logo is missing.
- **Verified channel access.** By default only channels the signed-in profile can
  play, or that the provider marks as free, are listed.
- **Live TV, Rewind and Catch-up from the guide.** Current programmes start live.
  For past programmes, simpliTVᵀ offers either provider Catch-up (teal play
  action) or an estimated rewind in the live buffer (amber action). These are
  shown only when they can be justified.
- **Correct titles in Kodi.** The station name, programme title, plot and artwork
  are passed directly to the player, so Kodi shows "ORF 1 — Programme" rather
  than a manifest file name.
- **Mojibake repair.** Double-encoded UTF-8 in EPG titles and synopses (for
  example `KÃ¼che`) is repaired to `Küche`. Each complete garbled sequence
  is decoded separately, so correctly encoded text in the same synopsis is preserved.
- **Tuning screen.** While a channel starts, a CRT-style TV-static animation
  plays with the station logo and name. It is silent and never delays playback.
  It can be switched off, which leaves a black screen with the logo.
- **Portable timeshift overlay.** While seeking or paused, an overlay shows the
  distance behind live and an approximate broadcast time, e.g. `Sendezeit ~ 15:54:30`.
- **Add-on player.** A playback window with
  P+/P− zapping and its own seek display.
- **Fast start.** Sign-in is prepared in the background, and channels, guide
  pages and branding are cached.
- **Recovery directory.** If the guide cannot be shown, Programme Guide and
  Live TV settings remain available without a channel list.

## Settings

| Category | Setting | Default | Description |
| --- | --- | --- | --- |
| General / Allgemein | Email / Password | empty | Account credentials. |
| General / Allgemein | Log out / switch account | — | Clear the saved credentials and cached sign-in. |
| General / Allgemein | Show portable timeshift overlay | on | Show the seek/pause overlay with the approximate broadcast time. |
| General / Allgemein | Show TV static while tuning | on | Show animated TV static on the tuning screen. When off, a black screen with the station logo is shown, even if static frames are cached. |
| Live TV | Show only playable channels | on | List only channels with confirmed live access or free access. Turn off to see the whole lineup. |
| Live TV | Show current channel in guide | on | Show the already-playing stream in the guide details area. |
| Live TV | Remember last channel | on | Select the last successfully started channel on a fresh guide launch, without autoplay. |
| About | Credits and license | — | Select any row to open the localized credits and license viewer. |

The guide's **Settings / Einstellungen** action opens this dialog. It is
available even while channels are loading, or when the lineup is empty or failed
to load.

## Usage and controls

### Programme guide

| Key (remote / keyboard) | Action |
| --- | --- |
| Left / Right | Previous / next programme |
| Up / Down | Previous / next channel; from the action row, return to the selected programme without changing channel/time |
| Page Up / Page Down (P+ / P− on stock remotes) | One visible page of channels up / down |
| Channel Up / Down actions | One channel up / down |
| Number keys | Select the full-lineup channel number; hidden or unassigned numbers do not tune |
| `000` | Open Settings on OK or after 1.5 seconds; an active stream keeps playing |
| OK / Select | Play: live for current programmes; Catch-up or estimated rewind for eligible past programmes |
| Menu / C (context menu) | Focus the action row: **Watch live**, **Try rewind** / **Catch-up**, **Settings**, **Return to stream** |
| Tab / Fullscreen / Display | Return to the stream that simpliTVᵀ is still playing |
| Back / Esc | Close the guide |

Programmes with a teal play badge can be watched via provider Catch-up. An
amber badge marks an estimated rewind in the live buffer. Its left edge marks
the programme start or the estimated partial-rewind start. Badges are raised
across the row boundary, may overlap on short programmes, and are hidden if
their anchor is outside the visible timeline. Channel numbers are assigned
before access filtering, so hidden channels leave gaps.

In stock fullscreen playback:

- a short Back/Esc returns to the guide without stopping the stream;
- Stop (on a keyboard, long-press Backspace) stops it and returns to the guide.

**Return to stream** resumes the same stream without retuning or seeking. It
disappears when that stream ends or another item replaces it.

The final channel page stays filled when the lineup is longer than one page.
During a session the guide normally reopens on the last selected channel and
programme. When guide-started Catch-up or rewind ends, it refocuses the played
airing if that airing is still in the guide.
On a fresh launch, it selects the last watched channel if the setting is enabled
and that channel is still visible; it never autoplays. Returning from
playback resets a future-only viewport to now, but preserves current/past
selection restoration. Back from the
guide lands on a recovery directory with **Programme Guide** and
**Live TV settings** entries.

### Tuning screen

The tuning screen fits the centred station artwork into a 448 × 208 logical
box, with proportional scaling on small windows. Translucent snow passes in
front of the logo and stops above the station name. Frames are generated in the
background and reused across restarts. Until they are ready, or when **Show TV
static while tuning** is off, the enlarged logo remains clean on black. Back
cancels the tune.

The v3 cache holds 48 neutral greyscale frames and their matching translucent
logo overlays. It samples independent odd and even fields, filters Gaussian
noise along each scanline, and applies CRT gamma, occasional impulse streaks,
faint persistence, and a rolling brightness band. Playback targets 25 fps;
Kodi may skip frames if rendering falls behind. Generation is cancellable and
never holds up a tune.

## Add-on player

The owned player adds Last Channel and Go Live to its context menu when
available. The guide offers them under TV options without intercepting stock
fullscreen keys. History belongs to the current guide session and rotates
only after successful playback. Go Live seeks the current stream. In the owned
player, a settled short landing gets at most one retry to the freshly reported
edge; it warns only if the retry still leaves a meaningful gap. It never retunes.

The tune banner reads cached listings only. Info reopens it in the owned
player. It shares the bottom area with the seek strip; the strip takes
precedence. The roomier owned timeline has a separate badge row above the
ruler. The badge follows the pending or actual marker, stays inside the bar,
and shows approximate local broadcast time plus the live offset, switching
to `LIVE` below the live-gap threshold. The programme banner emphasizes the
current title over the station and next programme. Replay uses a compact
position/duration row. Stock fullscreen retains Kodi's Info and its existing
overlay. To diagnose owned input or
guide tunes, run `RunScript(<addon-path>\tests\dev\input_trace.py,on)`.
Filter `kodi.log` for `simpliTV input trace`, which records action IDs, tune
start events, seek targets and player readback, not account data or URLs.
Run the same script with `off` to disable it.

The guide starts live TV, restart and provider Catch-up in the add-on player.
If its window fails to open, the same playing stream continues in Kodi fullscreen.
Existing direct Kodi plugin resolver links use native playback: they do not
have a guide session to own the window and its Back/Stop lifecycle. The add-on
does not change Kodi's keymaps or PVR setup.

| Key | Action |
| --- | --- |
| P+ / Page Up, P− / Page Down | Next / previous playable channel |
| Left / Right | Seek −/+ 30 seconds; after four same-direction taps, further taps in that burst seek −/+ 2 minutes |
| Hold Left / Right (where Kodi supplies a long-press action) | Jump to a known programme start / end or live; the context menu has the same commands |
| Up / Down | Seek −/+ 10 minutes |
| Play / Pause | Kodi play/pause |
| OK / Select | Kodi's video controls (OSD: rewind, pause, stop, …); Back closes them |
| Info | Channel banner (describes the programme on screen when timeshifted) |
| `000` | Open Settings without stopping or retuning the active stream |
| Context menu | Audio, subtitle and live programme-boundary actions |
| Back | Return to the guide; playback continues |
| Stop | Stop playback and return to the guide (played channel or airing selected) |
| Fullscreen / Display | Switch to Kodi's stock fullscreen player. Back from there returns to the guide with the current channel selected. |

During Kodi shutdown, the owned-player and guide loops share an abort monitor.
An abort cancels the guide return and pending work without sending a native
window-close request into Kodi's own window teardown. The guide also exits on
its own window-unload notification unless a playback handoff is pending, or
when Kodi reports that the add-on has been disabled or removed.

Zapping:

- uses cached access grants and rechecks them before playing;
- starts on the next player update, with no debounce delay, and keeps the
  same player window while showing the tuning screen;
- replaces unsubmitted tunes with the latest requested channel and retains
  further input while submitted playback starts. The retained window can
  dismiss its own Kodi startup dialog so that it does not swallow channel keys.

The owned window is a Python WindowXML, so Kodi applies its Global keymap
there: OK arrives as Select (7), not FullscreenVideo's OSD (24). The window
maps both to `ActivateWindow(videoosd)`; the player loop keeps running under
the OSD, and the seek strip and banner stay hidden while it is visible.
Estuary's seek bar does not appear in the owned window; the seek strip labels
tiles with "HH:MM  Title" (time only or blank when narrow, never "…" stubs) and
highlights the tile under the marker. The stock fullscreen path retains Kodi's
input and native display alongside the portable overlay.

Omega's Python `Action` exposes the button code, but not C++ `GetHoldTime()` or
key release. The owned player uses `CKey::MODIFIER_LONG` when it reaches the
window as Left/Right. A short debounce groups tap bursts and allows a flagged
hold to replace the queued tap. Inputs that provide only repeated ordinary
actions remain taps; a held CEC button may therefore behave like a burst of
ordinary taps. Use the context-menu jumps when the remote has no long flag.

## Timeshift overlay and broadcast clock

During seeking, for three seconds afterwards, and while paused or rewinding,
live playback shows:

`-00:09:30 / 04:00:00     Sendezeit ~ 15:54:30` (English: `Broadcast time ~ 15:54:30`)

- `-00:09:30` is the pending position's distance from the reported live end.
- The gray value is Kodi's reported timeline length.
- The `~` time is the computer clock minus that distance. It is an estimate,
  not a broadcast timestamp. Delivery latency, manifest refresh timing and the
  computer clock can shift it.
- While paused, the distance grows and the clock stays at the paused picture's
  time.

In stock fullscreen the overlay is non-interactive. It does not replace the
skin's seek bar or intercept keys. The owned player draws the same display
itself. Turn it off with **Show portable timeshift overlay**.

The full-width bottom strip reserves its left tenth for station branding.
Guide logos use the available channel cell with a small inset and keep their
aspect ratio. Remote guide logos load through a Lanczos-prescaled `image://`
transform near their drawn size; a hidden copy of the original URL keeps it in
Kodi's texture cache for the tuning screen and strip. The selected guide row and visible seek strip cross-fade
between the logo and name without moving tiles or focus. The strip uses cached
artwork only; when none is available, the name stays visible.
Local-time ruler ticks, programme tiles and the translucent
red playhead share the remaining timeline. The line and upper clock use the
pending target during a seek and return to player readback on arrival or expiry. Both paths
use the same local-clock estimate for EPG alignment. The ruler stays visible
across gaps in the schedule. In stock fullscreen the strip sits below Estuary's
seek bar and hides while its video controls or fullscreen info are open.
Programme text is vertically centered inside each tile in both the guide and
seek strip. The strip prefers the skin's compact font so titles fit at 720p.
In stock fullscreen, a native seek preview that collapses to the current
position does not replace a pending target. The overlay displays fresh player
time once playback reaches that target within two seconds or the preview
expires; it cannot predict a native destination Kodi has not reported.
The strip fades in/out. Its per-playback snapshot retains known rows past guide
cache expiry and backfills the reported rewind range through bounded anonymous
EPG metadata requests on a background worker. While viewing, it refreshes the
live edge every five minutes; missing data stays blank. Seeks themselves make
no network requests. Kodi's Python API
doesn't expose exact seekable segment bounds, so Kodi and the demuxer still
determine where a seek actually lands.

## Rewind and Catch-up

**Provider Catch-up** (teal):

- Uses the programme's exact provider codename and normal acquisition. It
  requires explicit provider success.
- Offered only for past programmes when all of these permit it: fresh account,
  channel and programme flags; blackout state; supplied channel or programme
  date bounds; and publication delay.
- Missing optional date bounds do not deny Catch-up. Malformed dates or missing
  or ambiguous rights hide it.
- A refused Catch-up request is reported. It never falls back to rewind.

**Estimated rewind** (amber):

- Seeks inside the live buffer, using the last observed player-reported duration of
  that channel, or an unsaved three-hour assumption when none is valid. The
  guide never opens streams to measure it.
- Offered only when the estimated window overlaps the programme, and never for:
  - future programmes;
  - blackout or unknown blackout state;
  - an explicit account or channel Timeshift denial.
- At start, the fresh reported timeline is rechecked. If the programme predates
  it, playback starts at the earliest available point, potentially after the
  selected programme. The seek must settle or an error is shown.
- Kodi and inputstream.adaptive report elapsed time, not an absolute content
  clock. A settled seek can therefore land a few minutes away from the
  scheduled start. The guide labels these values as estimates.

## Playback, authentication and caching

**Service and DRM**

- The API is `https://api.app.austrostream.at` with tenant `simplitv`.
- Files and logos use `https://files.app.austrostream.at`.
- Provider-returned URLs are used unchanged. Tenant headers go only to the API.
- DRM playback prefers the provider's DASH manifest and selects Widevine by
  system name. PlayReady-only streams are unsupported.
- Protected streams are never treated as clear.
- Clear streams use inputstream.adaptive without DRM properties, preferring
  provider-returned DASH and otherwise using provider-returned HLS.
- Older single-transport responses keep the original CDN path fallback.

**Authentication**

- Missing credentials open Settings after an explanation. The settings service
  checks changed credentials with authentication only, reports the result, and
  does not prevent saving on failure. It does not register a provider device.
- Sign-out clears saved credentials and the in-memory authentication cache.
  Stale sessions cannot continue using cached credentials after account changes.
- Sign-in is prepared by a background script when the add-on opens. A file lock
  makes the foreground wait for that result.
- The token and device key are kept in Kodi memory for 30 minutes. No extra
  credential files are written.
- A rejected acquisition (HTTP 401/403, or a failed HTTP 200 response with a
  cached device) refreshes once and retries.
- A device is registered only if a successful lookup returns no devices.

**Provider errors**

All Python HTTP uses `kodi_network.KodiSession` or `kodi_network.request`,
including authentication, guide metadata and playback-schedule refresh.
The transport reads Kodi's `network.usehttpproxy` and proxy type, server, port
and credentials through JSON-RPC for each request. When enabled, the proxy
applies to HTTP, HTTPS and redirects, even for loopback targets or when
environment `NO_PROXY` would otherwise bypass it. Proxy credentials are only
sent on the proxy hop and never included in diagnostics. Invalid or unreadable
settings, missing transport support and proxy connection failures stop the
request; there is no direct retry.

HTTP proxies are supported by Requests. SOCKS4/4a/5/5-hostname require PySocks
in Kodi's Python environment; HTTPS proxies require urllib3 1.26 or newer.
Without that support the add-on reports a proxy error, rather than bypassing it.
With Kodi's proxy disabled, existing Requests/environment behavior is preserved.
Native artwork and media fetching remain in Kodi/inputstream.adaptive's network
stack; this add-on has no Python loopback media relay.

Provider failures retain the HTTP status and a validated numeric error code in
sign-in dialogs, credential-check notifications, guide/player failures and
channel-access notifications. Background playback-schedule failures keep the
same safe detail in the log without interrupting playback.

Error JSON parsing is capped at 16 KiB and only happens when the response
`Content-Type` is `application/json` or an `application/*+json` type (case and
parameters such as `charset` are ignored). A missing or other media type keeps
the HTTP status only, even if the body happens to be valid JSON. This gate
applies only to error diagnostics; successful API responses are unaffected.
Only numeric codes of up to six ASCII
digits and exact approved stock messages/codenames are accepted. Arbitrary
provider text, URLs, credentials, tokens and identifiers are never included;
unknown text is replaced by a localized fallback, not merely URL-redacted.
Malformed, oversized or non-JSON bodies still preserve the HTTP status.

Mappings verified on 25 November 2026 in the public
[simpliTV client](https://streaming.simpli.at/assets/index-l9SJCXUa.js):
`API_SERVICE_MODE=5`, `API_INVALID_TOKEN=9003`,
`PRODUCT_NOT_AVAILABLE=9500`, and `REGION_RESTRICTED_ACCESS_DENIED=9602`.
These are translated into short English/German explanations. Magenta's code
`2838` has no verified simpliTV meaning and is deliberately left unmapped.
The existing authentication refresh/retry rules are unchanged.

**Caches**

| Data | Lifetime | Storage |
| --- | --- | --- |
| Channel list | 15 minutes | Kodi memory |
| Branding | 15 minutes | Kodi memory |
| Access checks | 5 minutes | Kodi memory |
| Guide pages, programme details and flags | 5 minutes | Memory, plus visible pages in the versioned `guide-cache` folder in the add-on's userdata, so they survive restarts |
| CRT static frames | No expiry; rebuilt when incomplete or incompatible | `crt-cache` folder |
| Last watched channel | Until disabled or replaced | Account-scoped `guide-cache` slot |

All caches are scoped to the account and service where relevant. Expired pages
are refreshed in the background, and playback always rechecks fresh data.
`guide-cache` stores no media URLs, credentials, device identifiers or
entitlement responses. Errors are never cached as empty schedules.

## Known limitations

- **Player compatibility.** It was tested live on Kodi 21 / Windows
  using simulated remote events. Physical remotes, other platforms and other
  skins are not verified. Kodi's single-item play request can reset the playback
  position of an existing playlist, though no entries are added or removed.
- **Video aspect.** In the owned player the video keeps its aspect ratio inside
  the Kodi window, exactly like stock fullscreen. When the Kodi window is not
  16:9, black bars are expected. Kodi's video view mode is not changed.
- **Rewind and broadcast times are estimates.** See above.
- **Catch-up is unverified for the developer's account**, which has no replay
  entitlement. Acquisition and playback with replay rights have not been tested
  live.
- **PlayReady-only channels do not play.**

## Changes compared to the original add-on

simpliTVᵀ was forked from the original simpliTV add-on and later aligned with
its 2026.11.17–2026.11.19 service migration. Changes were adopted selectively,
not by overwriting the code. Compared with the original 2026.11.20 release:

**Navigation and UI**

- The add-on opens straight into a full programme-guide window. The original
  shows a flat channel list with a four-entry mini EPG in the plot.
- Recording screens, the main menu, Start screen setting and the old separate
  TV guide are removed (live TV only).
- The guide adds:
  - keyboard/remote navigation, including page-wise Page Up/Down;
  - a current-time line with a subtle marker;
  - a programme detail footer;
  - an action row with Settings, which stays reachable on errors;
  - restoration of the last selection;
  - Return to stream.
- The recovery directory offers Programme Guide and Live TV settings without
  listing channels.
- Dark-background logos come from batched provider channel records or tiles.
  Channels without suitable artwork use their station names.
- The CRT tuning screen has a TV-static setting.
- The guide opens the add-on player with P+/P− zapping and its own seek
  display.
- There is a portable timeshift overlay with an approximate broadcast clock.

**Playback**

- Explicit selection of provider-returned formats and Widevine by DRM system
  name. The original takes the first format and rewrites URLs.
- Legacy rewriting is kept only as a fallback.
- Estimated live-buffer rewind with verified seeking, labelled as an estimate.
- Provider Catch-up with conservative, fresh rights gating.
- Station, programme title, plot and artwork are passed directly to Kodi.
- Repair of double-encoded UTF-8 in EPG text.

**Access, authentication and caching**

- "Show only playable channels" setting (verified account or free access). The
  original 2026.11.20 has "Show Free Channels only" instead.
- Background sign-in preparation with file locking.
- In-memory token/device reuse and one-time refresh on rejection.
- `accessToken` is accepted when `token` is missing.
- Scoped memory and disk caches for channels, guide pages, branding and access.

**Kept from the original**

- Login settings and the account/device model.
- The device-key lookup. simpliTVᵀ keeps its query-token lookup, which was
  verified to return a device key without a Bearer header.
- The Austrostream API and tenant.
- Widevine via inputstream.adaptive.

## Development and tests

The `tests` folder contains an offline harness with fake Kodi modules. It needs
Requests but no account, external network access or running Kodi; proxy tests
start a temporary loopback HTTP server. Run it with Kodi's bundled Python
(or Python 3.8+) from the add-on folder:

```
python -m unittest discover -s tests
```

For real Kodi input-path regressions, use **only an idle disposable profile**
and a local synthetic video at least 60 seconds long. Never use your normal
profile or a provider stream. In that Kodi instance, invoke:

```
RunScript("C:\path\to\addon\tests\dev\guide_remote.py","C:\test-results","C:\synthetic.y4m","eventserver")
```

EventServer must already be enabled and listening on localhost UDP 9777;
verify its listener belongs to the disposable Kodi process before running.
The driver sends one-shot `R1` remote-button packets through Kodi's
`remote.xml` keymap: arrows, Select, Back, Menu, Info, page/channel buttons,
Play/Pause and Stop. It does not change settings or silently fall back.
Use `"jsonrpc"` as the final argument to exercise Kodi's `Input.ExecuteAction`
path instead. Neither path tests actual physical remote hardware or OS HID
delivery; HID simulation additionally requires foreground focus on Kodi.

The five scenarios cover footer focus, full final pages and separator geometry,
immediate loading errors, German help, future-view playback return, and
player seek/pause/info/channel/stop controls. They use synthetic schedules and
temporarily observe native Kodi windows; the dedicated test selection property,
language function and window classes are restored afterward. Only the matching
synthetic video is stopped. Results include sent inputs and received action IDs.
Inspect the saved screenshots too, especially `immediate-load-error.png`:
cached label values alone cannot prove that Kodi repainted an idle frame.
Repeat with smaller Kodi windows to check scaled layouts. These checks do not
validate authentication, DRM, provider playback, or physical remote mappings.

## Channel logo normalization

`logo_pixels.py` and `channel_logos.py` provide provider-neutral image
processing shared with Magenta TV AT. The guide, channel carousel and seek strip
use a centred **176 x 45** logical texture frame. The visible art is 25% larger
than the station's own original artwork in that cell, capped uniformly at the cell edge
without stretching. The sizing policy is local to simpliTV and uses the source
PNG canvas and visible alpha bounds, not station-name lookups or hand-tuned
display sizes. The tuning splash uses the cropped logo without this frame.

The worker crops non-interlaced, 8-bit PNGs to the bounds with alpha >= 8,
preserving all RGBA samples within those bounds. RGB/gray transparency keys and
indexed transparency are supported. JPEG, WebP, GIF and unsupported PNG encodings
retain their original padding and use Kodi's normal cell fitting. A cold or failed
cache shows the station name. When artwork arrives after the guide opens, the
selected row keeps its fallback name until the carousel reaches the first logo;
warm opens still start on the logo.
Kodi still performs the Lanczos downscale, bucketed to 32 x 16 texture sizes;
original remote textures are not submitted for rendering.

All fetching goes through `kodi_network` on one background worker, never the UI.
Input is capped at 8 MiB / 4096 pixels per axis / 64 MiB decoded, and decoding
has a 10-second budget. The profile cache uses atomic writes and source/content
SHA-256 identities, without storing URLs. It holds at most 256 entries / 64 MiB.
Local changes are checked every minute; HTTP sources are conditionally revalidated
after 24 hours using ETag/Last-Modified. Stale cached images remain usable offline.
The worker exits after two idle seconds and can restart on demand.

## Credits

- **Publish3r** and **sunsettrack4**: authors of the original simpliTV Kodi
  add-on (`plugin.video.simplitv`). simpliTVᵀ is based on their work.
- **Tom**: simpliTVᵀ modifications.
- simpliTVᵀ is unofficial and not affiliated with or endorsed by the simpliTV
  service provider. Product names belong to their respective owners.

## License

simpliTVᵀ is free software under the GNU General Public License, version 3 or
(at your option) any later version. See [LICENSE.txt](../LICENSE.txt) and the
full text in [COPYING](../COPYING).
