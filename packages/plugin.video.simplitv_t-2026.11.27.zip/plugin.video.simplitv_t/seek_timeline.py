"""Seek gestures and wall-clock alignment for the reported live timeline."""

import math


LONG_BUTTON = 0x01000000  # Kodi CKey::MODIFIER_LONG
BURST_GAP = 0.8
SEEK_SETTLE = 3.0
PROGRAMME_START_TOLERANCE = 12


def clamp(position, duration):
    return max(0, min(duration, position))


class SeekGesture:
    def __init__(self):
        self.direction = self.count = 0
        self.last = float("-inf")
        self.held = False
        self.target = self.due = None
        self.expires = 0
        self.burst_origin = None
        self.inflight = self.position = None
        self.target_boundary = self.inflight_boundary = False
        self.arrived_boundary = None
        self.position_time = 0

    def observe(self, position, duration, now):
        if sane_timeline(position, duration):
            position = clamp(position, duration)
            if self.inflight is not None and abs(position - self.inflight) <= 4:
                self.arrived_boundary = self.inflight if self.inflight_boundary else None
                self.inflight = None
                self.inflight_boundary = False
                self.position, self.position_time = position, now
            elif self.inflight is None or now >= self.expires:
                self.inflight = None
                self.inflight_boundary = False
                if self.arrived_boundary is not None and abs(position - self.arrived_boundary) > 4:
                    self.arrived_boundary = None
                self.position, self.position_time = position, now
            elif self.position is not None and abs(position - self.position) <= 1 + now - self.position_time:
                self.position, self.position_time = position, now
        if now >= self.expires:
            self.inflight = None
            self.inflight_boundary = False
        return self.position

    def pending(self, now):
        if self.target is not None:
            return self.target
        return self.inflight if now < self.expires else None

    def tap(self, direction, position, duration, now):
        pending = self.pending(now)
        base = position if pending is None else pending
        if direction != self.direction or now - self.last >= BURST_GAP or self.held:
            self.count = 0
            self.burst_origin = base
        self.direction, self.last, self.held = direction, now, False
        self.count += 1
        step = 30 if self.count <= 4 else 120
        # Give Kodi's keyboard long modifier a chance to replace the first tap.
        self.queue(base + direction * step, duration, now + 0.55)

    def skip(self, seconds, position, duration, now):
        pending = self.pending(now)
        self.count = self.direction = 0
        self.held = False
        self.burst_origin = None
        self.queue((position if pending is None else pending) + seconds, duration, now + 0.55)

    def hold_origin(self, direction, position, now):
        if self.held and direction == self.direction and now - self.last < BURST_GAP:
            self.last = now
            return None
        pending = self.pending(now)
        if pending is not None:
            position = pending
        if (direction == self.direction and now - self.last < BURST_GAP
                and self.due is not None):
            if self.inflight is None and self.burst_origin is not None:
                position = self.burst_origin
            self.target = self.due = None
        self.direction, self.last, self.held = direction, now, True
        self.count = 0
        return position

    def boundary_position(self, position):
        if self.arrived_boundary is not None and abs(position - self.arrived_boundary) <= 4:
            return self.arrived_boundary
        return position

    def queue(self, target, duration, due, boundary=False):
        self.target, self.due = clamp(target, duration), due
        self.target_boundary = boundary

    def dispatch(self, duration, now):
        if (self.due is None or now < self.due
                or (self.inflight is not None and now < self.expires)):
            return None
        self.inflight = clamp(self.target, duration)
        self.inflight_boundary = self.target_boundary
        self.arrived_boundary = None
        self.target = self.due = None
        self.expires = now + SEEK_SETTLE
        return self.inflight


def sane_timeline(position, duration):
    return (math.isfinite(position) and math.isfinite(duration)
            and duration > 0 and 0 <= position <= duration + 2)


def boundary_target(rows, position, duration, edge, direction):
    """Return a known programme boundary in seconds on the player clock."""
    oldest = edge - duration
    actual = oldest + clamp(position, duration)
    if direction < 0:
        # At a boundary, or just after segment-aligned readback, go to the
        # previous start. Ignore starts of programmes already outside the buffer.
        starts = [start for start, stop, _ in rows
                  if stop > oldest and start < actual - PROGRAMME_START_TOLERANCE]
        return clamp(max(starts) - oldest, duration) if starts else None
    for start, stop, _ in reversed(rows):
        if start <= actual < stop:
            return clamp(stop - oldest, duration)
    return None


def strip_cells(rows, duration, edge, width):
    """Clip programme tiles against the timeline; leave uncovered intervals blank."""
    oldest = edge - duration
    cells = []
    for start, stop, title in rows:
        start, stop = max(start, oldest), min(stop, edge)
        if stop <= start:
            continue
        left, right = (round((point - oldest) * width / duration) for point in (start, stop))
        if right > left:
            cells.append((left, right - left, title))
    return cells
