import math
import re

from live_cache import LiveDataError, broadcast_timestamp


CODE = re.compile(r"[A-Za-z0-9_.-]{1,128}")


def _window(value, lower, upper):
    try:
        start = broadcast_timestamp(lower) if lower is not None else None
        stop = broadcast_timestamp(upper) if upper is not None else None
        if start is not None and stop is not None:
            return start <= stop and start <= value <= stop
        if start is not None:
            return value > start
        if stop is not None:
            return value < stop
        return True
    except (LiveDataError, TypeError, ValueError, OverflowError, OSError):
        return False


def catchup_available(programme, access, policy, now):
    if not isinstance(programme, dict) or not isinstance(access, dict) or not isinstance(policy, dict):
        return False
    channel = programme.get("tileChannel")
    if not isinstance(channel, dict):
        return False
    code = programme.get("codename")
    tile_id = channel.get("tileId")
    if (not isinstance(code, str) or not CODE.fullmatch(code)
            or not isinstance(tile_id, str) or not re.fullmatch(r"chn\.(0|[1-9][0-9]{0,9})", tile_id)):
        return False
    try:
        start = broadcast_timestamp(programme.get("start"))
        stop = broadcast_timestamp(programme.get("stop"))
    except (LiveDataError, ValueError, OverflowError, OSError):
        return False
    if not math.isfinite(now) or start >= stop or stop >= now:
        return False
    if (access.get("account_catchup_enabled") is not True
            or access.get("catchup_agreement_missing") is not False
            or programme.get("isCatchupEnabled") is not True
            or programme.get("isBlackouted") is not False):
        return False
    entry = access.get("catchup_channels", {}).get(tile_id)
    station = policy.get("channels", {}).get(tile_id)
    if (not isinstance(entry, dict) or not isinstance(station, dict)
            or entry.get("canPlay") is not True or entry.get("catchupEnabled") is not True
            or station.get("codename") != channel.get("codename")
            or station.get("isCatchupEnabled") is not True
            or station.get("hasPlayableStream") is not True
            or station.get("isBlackouted") is not False):
        return False
    if not _window(start, entry.get("catchupFrom"), entry.get("catchupTo")):
        return False
    if not _window(now, programme.get("catchupAvailableFrom"), programme.get("catchupAvailableTo")):
        return False
    immediate = policy.get("available_immediately")
    if immediate is True:
        return True
    if immediate is not False:
        return False
    delay, margin = policy.get("publication_delay"), station.get("stop_margin")
    if margin is None:
        margin = policy.get("stop_margin")
    if (type(delay) not in (int, float) or type(margin) not in (int, float)
            or not math.isfinite(delay) or not math.isfinite(margin)
            or delay < 0 or margin < 0):
        return False
    return now > stop + delay + 60 * margin
