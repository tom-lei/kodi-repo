"""Playback-scoped schedule snapshot with anonymous background EPG refresh."""

import datetime
import threading
import kodi_network

from live_cache import GUIDE_SLICE, LiveDataCancelled, LiveDataError, fetch_programmes
from provider_errors import provider_failure, provider_json, provider_message


REFRESH_SECONDS = 300
MAX_LOOKBACK = 48 * 3600


def load_schedule(channel, start, stop, cancelled):
    import requests
    from auth_session import API_HEADERS

    def public_json(method, url, **kwargs):
        try:
            response = kodi_network.request(method, url, headers=API_HEADERS, timeout=8,
                                        allow_redirects=False, **kwargs)
        except kodi_network.KodiProxyError:
            raise LiveDataError("", provider=provider_failure(reason="proxy")) from None
        except requests.RequestException as error:
            raise LiveDataError("", provider=provider_failure(
                getattr(error, "response", None), "connection")) from None
        payload = provider_json(response, LiveDataError)
        result = payload.get("result", payload.get("Result"))
        if isinstance(result, dict) and result.get("success", result.get("Success")) is False:
            raise LiveDataError("", provider=provider_failure(response))
        return payload

    start, stop = (datetime.datetime.fromtimestamp(value, datetime.timezone.utc)
                   for value in (start, stop))
    return fetch_programmes(public_json, start=start, end=stop, cancelled=cancelled,
                            channels=frozenset((channel,)))


def schedule_rows(events, channel):
    from guide import programme_key, repair_mojibake

    intervals = {}
    for event in events:
        key = programme_key(event)
        if key is not None and key[0] == channel and (key[2], key[3]) not in intervals:
            title = event.get("title")
            intervals[key[2], key[3]] = repair_mojibake(title).strip() if isinstance(title, str) else ""
    return [(start, stop, title) for (start, stop), title in sorted(intervals.items())]


class SeekSchedule:
    def __init__(self, channel, peek, log, load=None):
        self.channel, self.peek, self.log, self.load = channel, peek, log, load
        self.rows = []
        self.covered = None
        self.next_read = self.next_fetch = 0
        self.done = threading.Event()
        self.worker = self.result = None
        self.failure_detail = ""

    def update(self, edge, duration, now):
        oldest = edge - min(duration, MAX_LOOKBACK)
        if now >= self.next_read:
            self.merge(self.peek(self.channel), replace=False)
            self.next_read = now + 15
        if self.worker is not None and not self.worker.is_alive():
            good, ranges, failed = self.result
            self.merge(good)
            for start, stop in ranges:
                first, last = self.covered or (start, stop)
                self.covered = min(first, start), max(last, stop)
            if failed:
                self.log(self.failure_detail or "Could not refresh playback schedule")
            self.next_fetch = now + (30 if failed else REFRESH_SECONDS)
            self.worker = self.result = None
        self.rows = [row for row in self.rows if row[1] > oldest - 1800]
        if (self.load is not None and not self.done.is_set()
                and self.worker is None and now >= self.next_fetch):
            first, last = self.covered or (edge, edge)
            start = oldest - 1800 if oldest < first or self.covered is None else min(last - 300, edge - 300)
            self.worker = threading.Thread(target=self.refresh, args=(start, edge + 300), daemon=True)
            self.worker.start()
        return self.rows

    def merge(self, rows, replace=True):
        if rows:
            by_start = {row[0]: row for row in self.rows}
            for row in rows:
                if replace or row[0] not in by_start:
                    by_start[row[0]] = row
            self.rows = [by_start[start] for start in sorted(by_start)]

    def refresh(self, start, stop):
        rows, ranges, failed = [], [], False
        self.failure_detail = ""
        try:
            while start < stop and not self.done.is_set():
                # Fetch newest chunks first: publish the partial result even if older data fails.
                left = max(start, stop - GUIDE_SLICE.total_seconds())
                events = self.load(self.channel, left, stop, self.done.is_set)
                rows.extend(schedule_rows(events, self.channel))
                ranges.append((left, stop))
                stop = left
        except LiveDataCancelled:
            pass
        except (LiveDataError, OverflowError, OSError, ValueError) as error:
            self.failure_detail = provider_message(error)
            failed = True
        finally:
            self.result = rows, ranges, failed

    def close(self):
        self.done.set()
