import datetime
import html
import json
import math
import os
import re
import threading
import textwrap
import time
import traceback
from channel_access import ACCESS_TEXT
from timeshift_overlay import format_duration
from crt_noise import FPS as CRT_FPS, tuning_logo_size

TIMELINE_MARKER_COLOR = "80E45D5D"
TIMELINE_MARKER_WIDTH = 2


def branding_fade(logo, condition="true"):
    start, end = (100, 0) if logo else (0, 100)
    return [("Conditional", "effect=fade start={} end={} delay=650 time=1250 "
             "pulse=true reversible=false condition={}".format(start, end, condition))]

from live_cache import LiveDataCancelled, LiveDataError, broadcast_timestamp


GUIDE_PAST_SECONDS = 7 * 60 * 60
GUIDE_FUTURE_SECONDS = 21 * 60 * 60
TIMELINE_SECONDS = 4 * 60 * 60
TIMELINE_STEP_SECONDS = 30 * 60
# Kodi 21's ActionIDs.h; these are actions, not remote keycodes.
ACTION_CHANNEL_UP = 184
ACTION_CHANNEL_DOWN = 185
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6

GUIDE_TEXT = (
    {
        "live": "Live TV", "loading": "Loading programme details…",
        "more": "Loading more programmes…", "incomplete": "Programme guide incomplete",
        "error": "Programme data unavailable",
        "programme": "Programme",
        "empty": "No programme information is available for this time.",
        "watch": "Watch live", "restart": "Try rewind", "unavailable": "Rewind unavailable",
        "catchup": "Watch Catch-up",
        "navigate": "←/→ Programmes   ↑/↓ Channels   PgUp/PgDn Pages", "actions": "OK Play   Menu Options   Back Close",
        "not_playable": "This programme cannot be played.",
        "starting": "Starting playback…", "playback_error": "Playback could not start.",
        "startup_cancel": "Back to cancel",
        "return_stream": "Return to stream",
        "tv_actions": "TV options",
        "last_channel": "Last channel",
        "go_live": "Go live",
        "guide": "Programme Guide", "settings": "Settings",
        "rewind_unknown": "Stream rewind: unknown",
        "rewind_observed": "Stream rewind: last reported ~{} ({})",
        "restart_estimated": "Try rewind — estimated window and position.",
        "restart_partial": "Try rewind from approximately {} — estimated window and position.",
        "restart_bounds": "Could not place the programme start on the reported stream timeline.",
        "refresh_rights": "Refreshing programme data. Try restarting again shortly.",
    },
    {
        "live": "Live TV", "loading": "Programmdetails werden geladen…",
        "more": "Weitere Sendungen werden geladen…", "incomplete": "TV-Guide unvollständig",
        "error": "Programmdaten nicht verfügbar",
        "programme": "Sendung",
        "empty": "Für diese Zeit sind keine Programmdaten verfügbar.",
        "watch": "Live ansehen", "restart": "Zurückspulen versuchen", "unavailable": "Zurückspulen nicht möglich",
        "catchup": "Catch-up ansehen",
        "navigate": "←/→ Sendungen   ↑/↓ Sender   Bild↑/Bild↓ Seiten", "actions": "OK Abspielen   Menü Optionen",
        "not_playable": "Diese Sendung kann nicht abgespielt werden.",
        "starting": "Wiedergabe startet…", "playback_error": "Wiedergabe konnte nicht gestartet werden.",
        "startup_cancel": "Zurück zum Abbrechen",
        "return_stream": "Zurück zum Stream",
        "tv_actions": "TV-Optionen",
        "last_channel": "Letzter Sender",
        "go_live": "Zu Live",
        "guide": "Programmübersicht", "settings": "Einstellungen",
        "rewind_unknown": "Zurückspulen im Stream: unbekannt",
        "rewind_observed": "Zurückspulen im Stream: zuletzt gemeldet ~{} ({})",
        "restart_estimated": "Zurückspulen versuchen — Bereich und Position geschätzt.",
        "restart_partial": "Zurückspulen ab ca. {} versuchen — Bereich und Position geschätzt.",
        "restart_bounds": "Der Sendungsbeginn ließ sich nicht auf der gemeldeten Zeitleiste bestimmen.",
        "refresh_rights": "Programmdaten werden aktualisiert. Bitte erneut versuchen.",
    },
)


def guide_window(now=None):
    now = time.time() if now is None else float(now)
    if not math.isfinite(now):
        raise LiveDataError("Invalid guide time")
    start = datetime.datetime.fromtimestamp(
        now - GUIDE_PAST_SECONDS, datetime.timezone.utc)
    end = datetime.datetime.fromtimestamp(
        now + GUIDE_FUTURE_SECONDS, datetime.timezone.utc)
    return start, end


def programme_key(programme):
    if not isinstance(programme, dict):
        return None
    channel_data = programme.get("tileChannel")
    if not isinstance(channel_data, dict):
        return None
    channel = channel_data.get("codename")
    if not isinstance(channel, str):
        return None
    try:
        start = broadcast_timestamp(programme["start"])
        stop = broadcast_timestamp(programme["stop"])
    except (KeyError, LiveDataError):
        return None
    if stop <= start:
        return None
    return channel, str(programme.get("id", "")), start, stop


def available_actions(programme, now=None, rewind=None, timeshift_denied=False, catchup=False):
    now = time.time() if now is None else float(now)
    key = programme_key(programme)
    if key is None:
        return ()
    start, stop = key[2], key[3]
    actions = []
    if start <= now < stop:
        actions.append("watch_live")
    if catchup:
        actions.append("catchup")
    elif replay_start(programme, now, rewind, timeshift_denied) is not None:
        actions.append("start_from_beginning")
    return tuple(actions)


def replay_start(programme, now, rewind=None, timeshift_denied=False):
    """Estimate a target from an observation or an uncached three-hour default."""
    key = programme_key(programme)
    if key is None or timeshift_denied or programme.get("isBlackouted") is not False:
        return None
    seconds = rewind.get("seconds") if isinstance(rewind, dict) else None
    if type(seconds) not in (int, float) or not math.isfinite(seconds) or not 1 <= seconds <= 48 * 3600:
        seconds = 3 * 3600
    _, _, start, stop = key
    if start >= now:
        return None
    target = max(start, now - seconds)
    if target >= min(stop, now):
        return None
    return ("estimated" if target == start else "partial"), target


def replay_badge_x(target, view_start, scale, timeline_x, cell_left, cell_right, size):
    if target is None or target[1] < view_start:
        return None
    x = max(cell_left, int(timeline_x + (target[1] - view_start) * scale))
    return x if x + size <= cell_right else None


UTF8_CONTINUATION = ("[\u0080-\u00bf\u0152\u0153\u0160\u0161\u0178"
                     "\u017d\u017e\u0192\u02c6\u02dc\u2013-\u2026\u2030\u2039\u203a\u20ac\u2122]")
MOJIBAKE = re.compile(
    "[\u00c2-\u00df]" + UTF8_CONTINUATION
    + "|[\u00e0-\u00ef]" + UTF8_CONTINUATION + "{2}"
    + "|[\u00f0-\u00f4]" + UTF8_CONTINUATION + "{3}"
)


def repair_mojibake(value):
    if not isinstance(value, str):
        return value

    def decode_sequence(match):
        sequence = match.group()
        raw = bytearray((ord(sequence[0]),))
        for char in sequence[1:]:
            # Latin-1 control characters are already the original byte values.
            if ord(char) <= 0xBF:
                raw.append(ord(char))
            else:
                raw.extend(char.encode("cp1252"))
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            return sequence

    return MOJIBAKE.sub(decode_sequence, value)


def description_text(value):
    value = html.unescape(repair_mojibake(value))
    value = re.sub(r"(?i)<(?:br\s*/?|/p|/div)>", "\n", value)
    value = re.sub(r"<[^>]*>", "", value)
    return "\n".join(" ".join(line.split()) for line in value.splitlines()).strip()


def synopsis_lines(value, width, count):
    lines = []
    for paragraph in description_text(value).splitlines():
        lines.extend(textwrap.wrap(paragraph, width=max(12, int(width // 11))) or [""])
    if len(lines) > count and count:
        lines[count - 1] = lines[count - 1].rstrip(" .") + "…"
    return lines[:count]


class OutsideTimeline(ValueError):
    pass


def channel_programmes(programmes, channel):
    matching = []
    for programme in programmes or ():
        key = programme_key(programme)
        if key is not None and key[0] == channel:
            matching.append((key[2], key[3], programme))
    matching.sort(key=lambda item: (item[0], item[1]))
    return [item[2] for item in matching]


def nearest_programme(programmes, channel, target_time):
    events = channel_programmes(programmes, channel)
    if not events:
        return None
    for event in events:
        key = programme_key(event)
        if key[2] <= target_time < key[3]:
            return event
    return min(
        events,
        key=lambda event: min(
            abs(programme_key(event)[2] - target_time),
            abs(programme_key(event)[3] - target_time)
        )
    )


def adjacent_programme(programmes, channel, selected, direction):
    if direction not in (-1, 1):
        raise ValueError("direction must be -1 or 1")
    events = channel_programmes(programmes, channel)
    if not events:
        return None
    selected_key = programme_key(selected) if selected is not None else None
    if selected_key is None:
        return events[0] if direction > 0 else events[-1]
    for index, event in enumerate(events):
        if programme_key(event) == selected_key:
            next_index = index + direction
            return events[next_index] if 0 <= next_index < len(events) else None
    target = selected_key[2]
    return nearest_programme(events, channel, target)


def channel_direction_for_action(action_id, move_up, move_down,
                                 channel_up=None, channel_down=None):
    if move_up is not None and action_id == move_up:
        return -1
    if move_down is not None and action_id == move_down:
        return 1
    if channel_up is not None and action_id == channel_up:
        return 1
    if channel_down is not None and action_id == channel_down:
        return -1
    return None


def _format_time(timestamp, timezone):
    return datetime.datetime.fromtimestamp(timestamp, timezone).strftime("%H:%M")


def local_startup_logo(xbmc, logo):
    """Look up only a local file; never submit a remote texture for rendering."""
    if not logo:
        return None
    import xbmcvfs

    if logo.startswith("special://") or (os.path.isabs(logo) and not logo.startswith(("\\\\", "//"))):
        path = xbmcvfs.translatePath(logo)
        if os.path.isabs(path) and not path.startswith(("\\\\", "//")) and os.path.isfile(path):
            return logo
        return None
    if not logo.startswith(("https://", "http://")):
        return None
    rpc = {"jsonrpc": "2.0", "id": 1, "method": "Textures.GetTextures",
           "params": {"properties": ["cachedurl"],
                      "filter": {"field": "url", "operator": "is", "value": logo}}}
    response = json.loads(xbmc.executeJSONRPC(json.dumps(rpc)))
    for row in response.get("result", {}).get("textures") or ():
        path = row.get("cachedurl", "")
        if re.fullmatch(r"[a-f0-9]/[a-f0-9]+\.(?:png|jpg|webp)", path):
            cached = "special://thumbnails/" + path
            if os.path.isfile(xbmcvfs.translatePath(cached)):
                return cached
    return None


def channel_presentation(channel, event, branding, channel_name, fallback_logo=None):
    title, logo = branding.get(channel, (None, None))
    tile = event.get("tileChannel") if event else None
    if isinstance(tile, dict) and tile.get("codename") == channel:
        if not title and isinstance(tile.get("title"), str) and tile["title"].strip():
            title = tile["title"]
        if not logo:
            logo = next((tile[key] for key in ("logoUrlOnDark", "logoUrl")
                         if isinstance(tile.get(key), str) and tile[key].strip()), None)
    title = title or channel_name(channel)
    if not logo and fallback_logo:
        logo = fallback_logo(channel, title)
    return title, logo


def playback_metadata(channel_title, logo, event):
    title = event.get("title") if isinstance(event, dict) else None
    title = repair_mojibake(title).strip() if isinstance(title, str) else ""
    description = event.get("description") if isinstance(event, dict) else None
    return {
        "title": "{} — {}".format(channel_title, title) if title else channel_title,
        "plot": description_text(description) if isinstance(description, str) else "",
        "logo": logo,
    }


def open_guide(channels, peek_programmes, load_programmes, channel_name,
               addon_path, log, account_key, timezone, channel_logo=None,
               start_playback=None, refresh_channels=None, access_status="",
               rewind_observation=None, confirm_restart=None, owned_playback=None,
               open_settings=None, peek_branding=None, peek_crt=None, timeshift_denied=None,
               catchup_eligible=None, peek_catchup_state=None, monitor=None, playback_actions=None,
               mini_picture=None):
    import xbmc
    import xbmcgui

    if monitor is None:
        monitor = xbmc.Monitor()
    if monitor.abortRequested():
        return None
    window = xbmcgui.Window(10000)
    german = xbmc.getLanguage(xbmc.ISO_639_1) == "de"
    text = GUIDE_TEXT[german]
    access_text = ACCESS_TEXT[german]
    selection_property = "simplitv_t.guide.selection." + account_key
    solid_texture = os.path.join(
        addon_path, "resources", "skins", "Default", "media", "guide-solid.png")
    badge_texture = os.path.join(os.path.dirname(solid_texture), "guide-rewind.png")
    catchup_texture = os.path.join(os.path.dirname(solid_texture), "guide-catchup.png")

    class GuideDialog(xbmcgui.WindowXMLDialog):
        def __init__(self, xml_filename, script_path, default_skin, default_res):
            super().__init__(xml_filename, script_path, default_skin, default_res)
            self.channels = list(channels)
            self.access_status = access_status
            self.check_channels_after = time.monotonic() + 1
            self.programmes = []
            self.events_by_channel = {}
            self.loading = False
            self.error = ""
            self.timezone = timezone
            self.channel_name = channel_name
            self.channel_logo = channel_logo
            self.branding = peek_branding() if peek_branding is not None else {}
            self.log = log
            self.cancel = threading.Event()
            self.closed = False
            self.pending = None
            self.pending_lock = threading.Lock()
            self.request = None
            self.worker_request = None
            self.fetch_after = 0
            self.slots = {}
            self.image_colors = {}
            self.control_labels = {}
            self.button_enabled = {}
            self.footer_mode = False
            self.focus_requested = None
            self.event_controls = {}
            self.restart_controls = {}
            self.rewind_data = {}
            self.catchup_state = None
            self.fresh_catchup_events = {}
            self.action_controls = {}
            self.selected_channel = 0
            self.first_channel = 0
            self.selected_programme = None
            self.restore_key = None
            self.detail_label = None
            self.start_button = None
            self.visible_count = 1
            self.rendered_minute = None
            self.marker_layer = 0
            self.animated_branding = None
            self.ui_error = None
            self.initialized = False
            self.result = None
            self.handoff = None
            self.startup = None
            self.startup_clock = 0
            self.startup_frame = None
            self.startup_textures = None
            self.can_return = False
            self.mini_active = False
            self.fullscreen_video = False
            now = time.time()
            self.anchor = now
            self.view_start = self._snap(now - 90 * 60)
            self.first_view = self._snap(now - GUIDE_PAST_SECONDS)
            self.last_view = self._snap(now + GUIDE_FUTURE_SECONDS - TIMELINE_SECONDS)
            self._restore_selection()

        def _snap(self, timestamp):
            return math.floor(timestamp / TIMELINE_STEP_SECONDS) * TIMELINE_STEP_SECONDS

        def _restore_selection(self):
            try:
                state = json.loads(window.getProperty(selection_property) or "{}")
                channel = state.get("channel")
                if channel in self.channels:
                    self.selected_channel = self.channels.index(channel)
                    self.restore_key = (state.get("programme_id"), state.get("programme_start"))
                    saved_view = state.get("view")
                    saved_anchor = state.get("anchor")
                    if (isinstance(saved_view, (int, float))
                            and self.first_view <= saved_view <= self.last_view):
                        self.view_start = self._snap(saved_view)
                    if (isinstance(saved_anchor, (int, float))
                            and self.view_start <= saved_anchor
                            < self.view_start + TIMELINE_SECONDS):
                        self.anchor = saved_anchor
            except (AttributeError, TypeError, ValueError):
                return

        def _save_selection(self):
            channel = (self.channels[self.selected_channel]
                       if self.channels and self.selected_channel < len(self.channels) else "")
            selected = programme_key(self.selected_programme) if self.selected_programme else None
            window.setProperty(selection_property, json.dumps({
                "channel": channel,
                "view": self.view_start,
                "anchor": self.anchor,
                "programme_start": selected[2] if selected else None,
                "programme_id": selected[1] if selected else ""
            }))

        def onInit(self):
            if self.closed or monitor.abortRequested():
                return
            try:
                self.width = self.getWidth() or 1280
                self.height = self.getHeight() or 720
                self.video_large = self.getControl(100)
                self.video_small = self.getControl(102)
                self.video_large.setVisible(False)
                self.video_small.setVisible(False)
                grid_height = (self.height - self._footer_height() - 18
                               - max(58, int(self.height * 0.085)) - 44)
                self.visible_count = max(1, min(12, grid_height // 48))
                self._ensure_selected_channel_visible()
                self._request_view(immediate=True)
                self._render()
                self.initialized = not self.closed
            except Exception as error:
                self._fail_ui("initialization", error)

        def _resolve_selection(self):
            candidates = self._visible_events(self.channels[self.selected_channel]) if self.channels else []
            key = programme_key(self.selected_programme)
            self.selected_programme = next(
                (event for event in candidates if programme_key(event) == key), None)
            if self.selected_programme is None and self.restore_key is not None:
                self.selected_programme = next(
                    (event for event in candidates if programme_key(event)[1:3] == self.restore_key),
                    None)
                if self.selected_programme is not None or not self.loading:
                    self.restore_key = None
            if self.selected_programme is None:
                # A partially loaded row must not pull the time cursor to a different slot.
                self.selected_programme = next(
                    (event for event in candidates
                     if programme_key(event)[2] <= self.anchor < programme_key(event)[3]),
                    None)

        def _visible_events(self, channel):
            return [event for event in self.events_by_channel.get(channel, ())
                    if self._event_is_visible(event, self.view_start,
                                              self.view_start + TIMELINE_SECONDS)]

        def _set_programmes(self, programmes):
            self.programmes = programmes
            self.events_by_channel = {}
            for event in programmes:
                key = programme_key(event)
                if key is not None:
                    self.events_by_channel.setdefault(key[0], []).append((key[2:4], event))
            for channel, events in self.events_by_channel.items():
                self.events_by_channel[channel] = [
                    event for _, event in sorted(events, key=lambda value: value[0])]

        def _request_view(self, immediate=False):
            channels = tuple(self.channels[self.first_channel:self.first_channel + self.visible_count])
            key = (datetime.datetime.fromtimestamp(self.view_start, datetime.timezone.utc), channels)
            if not channels or (self.request is not None and key == self.request[0]):
                return
            self.request = (key, object())
            cached = peek_programmes(*key)
            self._set_programmes(list(cached) if cached is not None else [
                event for channel in channels for event in self._visible_events(channel)
            ])
            self.loading = cached is None
            self.error = ""
            self.fetch_after = time.monotonic() + (0 if immediate else 0.15)
            self._resolve_selection()

        def _start_worker(self):
            if (monitor.abortRequested() or not self.loading or self.worker_request is not None
                    or time.monotonic() < self.fetch_after):
                return
            request = self.worker_request = self.request

            def cancelled():
                return self.cancel.is_set() or self.request is not request

            def queue_result(programmes, loading, error=""):
                with self.pending_lock:
                    if not self.cancel.is_set():
                        self.pending = (request, programmes, loading, error)

            def worker():
                latest = None

                def publish(programmes):
                    nonlocal latest
                    latest = programmes
                    queue_result(latest, True)

                try:
                    result = load_programmes(*request[0], cancelled, publish)
                    queue_result(result, False)
                except LiveDataCancelled:
                    queue_result(latest, False, "Programme guide fetch cancelled")
                except Exception as error:
                    message = str(error) if isinstance(error, LiveDataError) else (
                        "Unexpected programme guide fetch failure ({})"
                        .format(type(error).__name__))
                    if not cancelled():
                        self.log("Programme guide: " + message)
                    queue_result(latest, False, message)

            threading.Thread(target=worker, name="simpliTV-guide", daemon=True).start()

        def _apply_pending(self):
            if monitor.abortRequested():
                return
            if peek_catchup_state is not None and time.monotonic() >= self.check_channels_after:
                state = peek_catchup_state()
                if state != self.catchup_state:
                    self._render()
                if peek_branding is None and refresh_channels is None:
                    self.check_channels_after = time.monotonic() + 1
            if peek_branding is not None and time.monotonic() >= self.check_channels_after:
                updated_branding = peek_branding()
                if updated_branding and updated_branding != self.branding:
                    self.branding = updated_branding
                    self._render()
                if refresh_channels is None:
                    self.check_channels_after = time.monotonic() + 1
            if refresh_channels is not None and time.monotonic() >= self.check_channels_after:
                updated, status = refresh_channels()
                self.check_channels_after = time.monotonic() + 1
                status_changed = status != self.access_status
                self.access_status = status
                if updated != self.channels:
                    old_index = self.selected_channel
                    selected = self.channels[old_index] if self.channels else None
                    if self.channels and not updated:
                        self._save_selection()
                    self.channels = list(updated)
                    if selected is None and self.channels:
                        self._restore_selection()
                    elif selected in self.channels:
                        self.selected_channel = self.channels.index(selected)
                    else:
                        self.selected_channel = max(0, min(old_index, len(self.channels) - 1))
                        self.selected_programme = None
                        self.restore_key = None
                    self._ensure_selected_channel_visible()
                    if self.channels:
                        self._request_view()
                    else:
                        self.request = None
                        self.loading = False
                        self._set_programmes([])
                    self._render()
                elif status_changed:
                    self._render()
            with self.pending_lock:
                pending, self.pending = self.pending, None
            if pending is not None and not self.closed:
                request, result, loading, error = pending
                if not loading:
                    self.worker_request = None
                if request is self.request:
                    data = list(result) if result is not None else self.programmes
                    if (data, loading, error) != (self.programmes, self.loading, self.error):
                        if data != self.programmes:
                            self._set_programmes(data)
                        self.loading, self.error = loading, error
                        self._resolve_selection()
                        self._render()
            if not self.closed:
                playing = self._owned_playing()
                if (self.can_return != playing
                        or self.mini_active != self._mini_picture_active(playing)):
                    self._render()
                if self.rendered_minute != int(time.time() // 60):
                    if (confirm_restart is not None and self.request is not None and not self.loading
                            and peek_programmes(*self.request[0]) is None):
                        self._refresh_view()
                    self._render()
                self._start_worker()

        def _refresh_view(self):
            self.request = (self.request[0], object())
            self.loading = True
            self.fetch_after = time.monotonic()

        def _control(self, key, spec, create):
            self.used_slots.add(key)
            previous = self.slots.get(key)
            if previous is not None:
                last_spec, control = previous
                if last_spec == spec:
                    return control
                self.retired.append(control)
                self.image_colors.pop(key, None)
                self.control_labels.pop(key, None)
                self.button_enabled.pop(key, None)
            control = create()
            self.slots[key] = (spec, control)
            self.additions.append(control)
            return control

        def _image(self, key, x, y, width, height, color, filename=solid_texture, aspect=0):
            geometry = (int(x), int(y), int(width), int(height))
            control = self._control(key, (geometry, filename, aspect), lambda:
                xbmcgui.ControlImage(*geometry, filename, aspectRatio=aspect, colorDiffuse=color))
            if self.image_colors.get(key) != color:
                if key in self.image_colors:
                    control.setColorDiffuse(color)
                self.image_colors[key] = color
            return control

        def _label(self, key, x, y, width, height, text, size, color, alignment=0, shadow=""):
            geometry = (int(x), int(y), int(width), int(height))
            control = self._control(key, (geometry, size, color, alignment, shadow), lambda:
                xbmcgui.ControlLabel(*geometry, text, font=size, textColor=color, alignment=alignment))
            if self.control_labels.get(key) != text:
                if shadow:
                    control.setLabel(text, shadowColor=shadow)
                elif key in self.control_labels:
                    control.setLabel(text)
                self.control_labels[key] = text
            return control

        def _synopsis(self, x, y, width, height, value):
            line_height = 28
            for index, line in enumerate(synopsis_lines(value, width, max(0, int(height // line_height)))):
                self._label(("synopsis", index), x, y + index * line_height,
                            width, line_height, line, "font12", "0xFFB8C6D8")

        def _button(self, key, x, y, width, height, text, enabled=True, size="font13",
                    texture="", focused_texture=None, center_y=False):
            geometry = (int(x), int(y), int(width), int(height))
            focus = texture if focused_texture is None else focused_texture
            alignment = 6 if texture else (4 if center_y else 0)
            control = self._control(key, (geometry, size, texture, focus, alignment), lambda: xbmcgui.ControlButton(
                *geometry, text, font=size,
                textColor="0xFFF1F5F9", focusedColor="0xFF80D6FF",
                disabledColor="0xFF7B8492", shadowColor="0x80000000",
                focusTexture=focus, noFocusTexture=texture,
                alignment=alignment,
                textOffsetX=0 if texture else 8, textOffsetY=0 if alignment & 4 else 2
            ))
            if self.control_labels.get(key) != text:
                if key in self.control_labels:
                    control.setLabel(text)
                self.control_labels[key] = text
            if self.button_enabled.get(key) != enabled:
                self.enable_updates.append((control, enabled))
                self.button_enabled[key] = enabled
            return control

        def _fail_ui(self, phase, error):
            self.ui_error = error
            self.result = None
            if not monitor.abortRequested():
                self.log("Guide {} failed: {}".format(phase, error))
                self.log(traceback.format_exc())
            self.close()

        def _event_title(self, event):
            title = event.get("title")
            return repair_mojibake(title) if isinstance(title, str) and title else text["programme"]

        def _footer_height(self):
            return max(220, int(self.height * 0.25))

        def _render_startup(self):
            title, _, art = self.startup
            width, height = self.width, self.height
            logo_width, logo_height = tuning_logo_size(width, height)
            if self.startup_textures is None:
                self._image("startup-black", 0, 0, width, height, "0xFF000000")
                if art:
                    self._image("startup-logo", (width - logo_width) // 2, (height - logo_height) // 2,
                                logo_width, logo_height, "0xFFFFFFFF", art, 2)
                return
            static_textures, interference_textures = self.startup_textures
            for frame, texture in enumerate(static_textures):
                key = "startup-static" if frame == 0 else ("startup-static", frame)
                self._image(key, 0, 0, width, height, "0xFFFFFFFF", texture)
            content_height = logo_height + 100 if art else 100
            center = max(0, (height - content_height) // 2)
            label_width = max(1, min(544, width - 16))
            left = (width - label_width) // 2
            if art:
                self._image("startup-logo", (width - logo_width) // 2, center,
                            logo_width, logo_height, "0xEADBE8EF", art, 2)
            station_top = center + (logo_height + 5 if art else 0)
            self._label("startup-station", left, station_top, label_width, 35,
                        title, "font14", "0xFFF6FAFF", 6, "FF101722")
            signal_top = max(0, center - 3)
            for frame, texture in enumerate(interference_textures):
                key = ("startup-interference", art) if frame == 0 else ("startup-interference", art, frame)
                self._image(key, 0, signal_top, width, min(height, station_top) - signal_top,
                            "0xFFFFFFFF", texture)
            self._label("startup-status", left, station_top + 38,
                        label_width, 30, text["starting"], "font13", "0xFFFFFFFF", 6, "FF101722")
            self._label("startup-cancel", left, station_top + 69, label_width, 24,
                        text["startup_cancel"], "font10", "0xFFF2F7FC", 6, "FF101722")
            self.startup_frame = None

        def _animate_startup(self):
            if self.startup is None or self.startup_textures is None:
                return
            count = len(self.startup_textures[0])
            frame = int(max(0, time.monotonic() - self.startup_clock) * CRT_FPS) % count
            if self.startup_frame != frame:
                art = self.startup[2]
                def set_frame(index, visible):
                    field = "startup-static" if index == 0 else ("startup-static", index)
                    snow = ("startup-interference", art) if index == 0 else ("startup-interference", art, index)
                    self.slots[field][1].setVisible(visible)
                    self.slots[snow][1].setVisible(visible)
                if self.startup_frame is None:
                    for index in range(count):
                        set_frame(index, index == frame)
                else:
                    set_frame(frame, True)
                    set_frame(self.startup_frame, False)
                self.startup_frame = frame

        def _owned_playing(self):
            if owned_playback is None:
                return False
            try:
                return owned_playback["player"].isPlayingVideo() and owned_playback["matches"]()
            except RuntimeError:
                return False

        def _mini_picture_active(self, playing=None):
            if playing is None:
                playing = self._owned_playing()
            return (self._video_size() is not None
                    and self.startup is None and mini_picture is not None
                    and mini_picture() and playing)

        def _video_size(self):
            # Kodi exposes the XML groups to Python, but not their video controls.
            pad = max(18, int(self.width * 0.02))
            available_height = self._footer_height() - 94
            for width, height in ((312, 176), (216, 121)):
                if (self.height >= 360 and available_height >= height
                        and self.width - pad * 2 - width - 36 >= 180):
                    return width, height
            return None

        def _return_to_stream(self, activate=True):
            if self._owned_playing() and not self.closed and self.startup is None:
                self._save_selection()
                self.result = dict(owned_playback, fullscreen=not activate)
                self.close()
                if activate and not owned_playback.get("owned_window"):
                    if self._owned_playing():
                        xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
                    else:
                        self.result = None
            elif activate:
                self._render()

        def _channel_presentation(self, channel, events, now):
            current = next(
                (event for event in events
                 if programme_key(event)[2] <= now < programme_key(event)[3]),
                None
            )
            event = current or nearest_programme(self.events_by_channel.get(channel, ()), channel, now)
            return channel_presentation(channel, event, self.branding, self.channel_name,
                                        self.channel_logo)

        def _event_is_visible(self, event, start, end):
            key = programme_key(event)
            return key is not None and key[2] < end and key[3] > start

        def _replay(self, event, now):
            key = programme_key(event)
            if key is None:
                return None
            rewind, denied = self._rewind_data(key[0])
            return replay_start(event, now, rewind, denied)

        def _rewind_data(self, channel):
            if channel not in self.rewind_data:
                self.rewind_data[channel] = (
                    rewind_observation(channel) if rewind_observation else None,
                    timeshift_denied(channel) if timeshift_denied else False)
            return self.rewind_data[channel]

        def _actions(self, event, now=None):
            now = time.time() if now is None else now
            key = programme_key(event)
            if key is None:
                return ()
            rewind, denied = self._rewind_data(key[0])
            fresh = self.fresh_catchup_events.get(key)
            allowed = (fresh is not None and fresh.get("codename") == event.get("codename")
                       and catchup_eligible(fresh, now)) if catchup_eligible else False
            return available_actions(event, now, rewind, denied,
                                     allowed)

        def _render(self):
            if self.closed or monitor.abortRequested():
                return
            try:
                self._render_controls()
            except Exception as error:
                self._fail_ui("render", error)

        def _focus_id(self):
            try:
                return self.getFocusId()
            except RuntimeError:
                return None

        def _focus(self, control):
            target = control.getId()
            if target == self._focus_id() and self.focus_requested in (None, target):
                self.focus_requested = None
            elif target != self.focus_requested:
                self.focus_requested = target
                self.setFocus(control)

        def _render_controls(self):
            if self.closed:
                return
            if peek_catchup_state is not None:
                self.catchup_state = peek_catchup_state()
            cached = peek_programmes(*self.request[0]) if self.request is not None else None
            self.fresh_catchup_events = {
                programme_key(event): event for event in (cached or ())
                if programme_key(event) is not None}
            focused = self._focus_id()
            self.used_slots = set()
            self.retired = []
            self.additions = []
            self.enable_updates = []
            self.text_updates = []
            self.rewind_data = {}
            event_buttons = []
            restart_buttons = []

            width, height = self.width, self.height
            pad = max(18, int(width * 0.02))
            left = max(124, int(width * 0.15))
            timeline_x = left + 18
            timeline_width = max(100, width - timeline_x - pad)
            footer_height = self._footer_height()
            header_height = max(58, int(height * 0.085))
            axis_height = 36
            grid_top = header_height + axis_height + 8
            grid_bottom = height - footer_height - 18
            row_count = self.visible_count
            row_height = max(36, int((grid_bottom - grid_top) / row_count))
            window_end = self.view_start + TIMELINE_SECONDS
            scale = timeline_width / TIMELINE_SECONDS
            now = time.time()
            self.rendered_minute = int(now // 60)
            local_now = datetime.datetime.fromtimestamp(now, self.timezone)

            footer_y = height - footer_height
            button_y = height - 78
            video_size = self._video_size()
            video_width, video_height = video_size or (0, 0)
            video_x = width - pad - 12 - video_width
            video_y = footer_y + 8
            video_fits = video_size is not None
            self.can_return = self._owned_playing()
            self.mini_active = self._mini_picture_active(self.can_return)
            self.fullscreen_video = bool(self.can_return and not self.mini_active
                                         and self.startup is None)

            def surface(color, alpha):
                return "0x" + alpha + color[4:] if self.fullscreen_video else color

            # Keep footer controls in the same draw order when the preview changes.
            if video_fits:
                self.video = self.video_large if video_width == 312 else self.video_small
                self.video.setPosition(video_x, video_y)
            self._image("header", 0, 0, width, header_height, surface("0xFF202C3A", "D4"))
            self._label("title", pad, 9, width * 0.42, 34, "simpliTVᵀ  |  " + text["live"], "font14",
                        "0xFFF1F5F9")
            date_format = "%d.%m.%Y, %H:%M" if german else "%d %b %Y, %H:%M"
            status = (text["starting"] if self.startup is not None else
                      access_text[self.access_status] if self.access_status else
                      text["more" if self.programmes else "loading"] if self.loading else
                      text["incomplete" if self.programmes else "error"] if self.error else
                      local_now.strftime(date_format))
            self._label("status", width * 0.51, 15, width * 0.46, 26, status, "font13",
                        "0xFFB8C6D8", alignment=2)

            self._image("axis", 0, header_height, width, axis_height + 8,
                        "0xD4202C3A" if self.fullscreen_video else "0x00202C3A")
            first_tick = math.ceil(self.view_start / 3600) * 3600
            tick = first_tick
            while tick <= window_end:
                x = int(timeline_x + (tick - self.view_start) * scale)
                self._label(("tick", tick), min(x + 4, width - pad - 70),
                            header_height + 2, 70, axis_height - 4,
                            _format_time(tick, self.timezone), "font12", "0xFF9AAABD")
                tick += 3600

            channel_window = self.channels[
                self.first_channel:self.first_channel + row_count
            ]
            animated_branding = None
            for row, channel in enumerate(channel_window):
                y = grid_top + row * row_height
                events = self._visible_events(channel)
                channel_title, channel_logo_url = self._channel_presentation(
                    channel, events, now
                )
                channel_selected = self.first_channel + row == self.selected_channel
                row_color = ("0xFF325063" if channel_selected else
                             "0xFF202A37" if row % 2 == 0 else "0xFF1B2430")
                self._image(("row", row), pad, y + 2, width - pad * 2, row_height - 3,
                            surface(row_color, "60"))
                label_height = 24
                label_y = y + (row_height - label_height) // 2
                label_width = left - pad - 16
                logo = None
                if (isinstance(channel_logo_url, str) and channel_logo_url.strip()
                        and os.path.normcase(os.path.normpath(channel_logo_url))
                        != os.path.normcase(os.path.join(addon_path, "icon.png"))):
                    logo_width = label_width
                    logo_height = row_height - 8
                    logo_x = pad + 8 + (label_width - logo_width) // 2
                    logo_y = y + (row_height - logo_height) // 2
                    logo = self._image(("logo", row), logo_x, logo_y,
                                       logo_width, logo_height, "0xFFFFFFFF", channel_logo_url, 2)
                if logo is None or channel_selected:
                    name = self._label(("channel", row), pad + 8, label_y, label_width, label_height,
                                       channel_title, "font10", "0xFFE0E7EF", alignment=6)
                    if logo is not None:
                        animated_branding = (channel, logo, name)
                for event in events:
                    key = programme_key(event)
                    start, stop = key[2], key[3]
                    x1 = max(timeline_x, int(timeline_x + (start - self.view_start) * scale))
                    x2 = min(timeline_x + timeline_width,
                             int(timeline_x + (stop - self.view_start) * scale))
                    event_width = max(1, x2 - x1 - 2)
                    key_id = key
                    is_selected = programme_key(self.selected_programme) == key_id
                    actions = self._actions(event, now)
                    if is_selected:
                        color = "0xFF3B7593"
                    elif "watch_live" in actions:
                        color = "0xFF31566E"
                    elif "start_from_beginning" in actions or "catchup" in actions:
                        color = "0xFF35465B"
                    else:
                        color = "0xFF303944"
                    self._image(("event-fill", key), x1 + 1, y + 4,
                                event_width, row_height - 8, surface(color, "80"))
                    label = _format_time(start, self.timezone) + "  " + self._event_title(event)
                    # The play badge is an action, not an availability marker.
                    replay = (("catchup", start) if "catchup" in actions
                              else self._replay(event, now))
                    badge_size = 24
                    badge_x = (replay_badge_x(
                        ("estimated", start) if replay else None, self.view_start, scale, timeline_x, x1 + 1,
                        x1 + 1 + event_width, badge_size)
                        if row_height >= 44 and event_width > badge_size + 3 else None)
                    body_offset = badge_size + 3 if badge_x is not None else 0
                    button = self._button(
                        ("event", key), x1 + 1 + body_offset, y + 4,
                        max(1, event_width - body_offset), row_height - 8, label,
                        size="font12", center_y=True
                    )
                    event_buttons.append((button, key_id, event))
                    if badge_x is not None:
                        hit = self._button(
                            ("event-lower", key), x1 + 1, y + 4 + badge_size,
                            body_offset, row_height - 8 - badge_size, "")
                        event_buttons.append((hit, key_id, event))
                    if replay is not None and (badge_x is not None or is_selected):
                        # A selected sliver or offscreen start gets an action in
                        # this row's gutter, never a false anchor on the timeline.
                        badge_left = badge_x if badge_x is not None else timeline_x - badge_size - 2
                        texture = catchup_texture if replay[0] == "catchup" else badge_texture
                        restart = self._button(
                            ("event-restart", key), badge_left, y + 4,
                            badge_size, badge_size, "", size="font10",
                            texture=texture, focused_texture=texture.replace(".png", "-focus.png"))
                        restart_buttons.append((restart, key_id, event))

            current_x = int(timeline_x + (self.rendered_minute * 60 - self.view_start) * scale)
            timeline_right = timeline_x + timeline_width
            if channel_window and timeline_x <= current_x <= timeline_right:
                # Append the line above any newly added cells in Kodi's draw order.
                if self.additions:
                    self.marker_layer += 1
                line_left = max(timeline_x, min(current_x - 1, timeline_right - TIMELINE_MARKER_WIDTH))
                self._image(("now-line", self.marker_layer), line_left, grid_top,
                            TIMELINE_MARKER_WIDTH, row_height * len(channel_window),
                            "0x" + TIMELINE_MARKER_COLOR)

            if video_fits:
                footer_color = surface("0xFF202C3A", "D4")
                self._image("footer-top", pad, footer_y, width - pad * 2, 8, footer_color)
                self._image("footer-left", pad, video_y, video_x - pad, video_height, footer_color)
                self._image("footer-right", video_x + video_width, video_y,
                            width - pad - video_x - video_width, video_height, footer_color)
                self._image("footer-bottom", pad, video_y + video_height, width - pad * 2,
                            height - 4 - video_y - video_height, footer_color)
                self._image("footer-video", video_x, video_y, video_width, video_height,
                            "0x00202C3A" if self.mini_active else footer_color)
            else:
                self._image("footer", pad, footer_y, width - pad * 2, footer_height - 4,
                            surface("0xFF202C3A", "D4"))
            channel = self.channels[self.selected_channel] if self.channels else ""
            selected = self.selected_programme
            synopsis = ""
            if selected is not None:
                key = programme_key(selected)
                period = "{}–{}".format(
                    _format_time(key[2], self.timezone),
                    _format_time(key[3], self.timezone)
                )
                detail = "{}   {}".format(period, self._event_title(selected))
                description = selected.get("description", "")
                if isinstance(description, str):
                    synopsis = description.strip()
            else:
                if self.access_status and not self.channels:
                    detail = access_text[self.access_status]
                    synopsis = access_text["hint"]
                else:
                    detail = text["loading" if self.loading else "empty"]
            detail_width = width - pad * 2 - 24
            info_width = video_x - pad - 24 if self.mini_active else detail_width
            self.detail_label = self._label(
                "detail", pad + 12, footer_y + 8, info_width, 38,
                detail, "font14", "0xFFE7EDF5")

            button_y = height - 78
            rewind = self._rewind_data(channel)[0] if channel else None
            if channel:
                status = (text["rewind_observed"].format(format_duration(rewind["seconds"]),
                                                        rewind["format"])
                          if rewind and rewind["seconds"] is not None else text["rewind_unknown"])
                selected_actions = self._actions(selected, now) if selected is not None else ()
                replay = (self._replay(selected, now) if selected is not None
                          and "catchup" not in selected_actions else None)
                if replay:
                    status += "   " + (text["restart_partial"].format(_format_time(replay[1], self.timezone))
                                       if replay[0] == "partial" else text["restart_estimated"])
                self._label("rewind", pad + 12, footer_y + 43, info_width, 23,
                            status, "font10", "0xFF9AAABD")
            synopsis_y = footer_y + (69 if channel else 49)
            self._synopsis(pad + 12, synopsis_y, info_width, button_y - synopsis_y - 5, synopsis)
            last, edge = playback_actions() if playback_actions is not None and not self.startup else (None, None)
            has_tv_actions = last in self.channels or edge is not None
            watch_width = restart_width = return_width = int(
                (detail_width - (60 if self.can_return and has_tv_actions else 48))
                / (5 if self.can_return and has_tv_actions else 4))
            watch = self._button(
                "watch", pad + 12, button_y, watch_width, 40, text["watch"], enabled=bool(channel))
            actions = self._actions(selected, now) if selected is not None else ()
            start_action = "catchup" if "catchup" in actions else "start_from_beginning"
            can_start = start_action in actions
            start_button = self._button(
                "restart", pad + 24 + watch_width, button_y, restart_width, 40,
                text["catchup" if start_action == "catchup" else "restart" if can_start else "unavailable"],
                enabled=can_start, size="font12"
            )
            self.watch_button, self.start_button, self.can_start = watch, start_button, can_start
            return_button = (self._button(
                "return-stream", pad + 36 + watch_width + restart_width, button_y,
                return_width, 40, text["return_stream"], size="font12") if self.can_return else None)
            self.return_button = return_button
            settings_x = pad + 48 + watch_width + restart_width + (return_width if return_button else 0)
            settings_button = self._button(
                "settings", settings_x,
                button_y, watch_width, 40, text["settings"], size="font12")
            self.settings_button = settings_button
            tv_button = self.tv_button = (self._button(
                "tv-options", settings_x + watch_width + 12, button_y,
                watch_width, 40, text["tv_actions"], size="font12") if has_tv_actions else None)
            self._label("help", pad + 12, height - 31, detail_width, 26,
                        text["navigate"] + "   " + text["actions"], "font10", "0xFF9AAABD")
            self._image("accent", 0, 0, width, 2, "0xFF4A9BC5")
            if self.startup is not None:
                self._render_startup()
            for key in self.slots.keys() - self.used_slots:
                self.retired.append(self.slots.pop(key)[1])
                self.image_colors.pop(key, None)
                self.control_labels.pop(key, None)
                self.button_enabled.pop(key, None)
            branding_changed = self.animated_branding != animated_branding
            if branding_changed and self.animated_branding is not None and not monitor.abortRequested():
                self.animated_branding[1].setAnimations([])
            if self.retired:
                if monitor.abortRequested():
                    return
                self.removeControls(self.retired)
            if self.additions:
                if monitor.abortRequested():
                    return
                self.addControls(self.additions)
            self.video_large.setVisible(self.mini_active and video_size == (312, 176))
            self.video_small.setVisible(self.mini_active and video_size == (216, 121))
            self.setProperty("simplitv_t.guide.video", "true" if self.mini_active else "")
            self.setProperty("simplitv_t.guide.fullscreen", "true" if self.fullscreen_video else "")
            if monitor.abortRequested():
                return
            if branding_changed:
                self.animated_branding = animated_branding
                if animated_branding is not None:
                    _, logo, name = animated_branding
                    logo.setAnimations(branding_fade(True))
                    name.setAnimations(branding_fade(False))
            self._animate_startup()
            for control, enabled in self.enable_updates:
                control.setEnabled(enabled)
            for control, value in self.text_updates:
                control.setText(value)
            self.event_controls = {
                button.getId(): (key, event) for button, key, event in event_buttons
            }
            self.restart_controls = {
                button.getId(): (key, event) for button, key, event in restart_buttons
            }
            self.action_controls = {
                watch.getId(): "watch_live", start_button.getId(): start_action,
                settings_button.getId(): "settings",
            }
            if return_button is not None:
                self.action_controls[return_button.getId()] = "return_to_stream"
            if tv_button is not None:
                self.action_controls[tv_button.getId()] = "tv_options"

            effective_focus = self.focus_requested or focused
            if self.footer_mode:
                footer = [button for button in (watch if channel else None,
                                               start_button if can_start else None, return_button,
                                               settings_button, tv_button)
                          if button is not None]
                target = next((button for button in footer if button.getId() == effective_focus),
                              footer[0] if footer else watch)
            else:
                selected_key = programme_key(selected)
                target = next((button for button, key, _ in restart_buttons
                               if key == selected_key and button.getId() == effective_focus), None)
                if target is None:
                    primary = [button for button, key, _ in event_buttons if key == selected_key]
                    target = next((button for button in primary if button.getId() == effective_focus),
                                  primary[0] if primary else watch)
            if not channel:
                self.footer_mode = True
                available_footer = {settings_button.getId()}
                if return_button:
                    available_footer.add(return_button.getId())
                if effective_focus not in available_footer:
                    target = return_button or settings_button
            self._focus(target)

        def _select_event(self, event):
            self.restore_key = None
            self.selected_programme = event
            key = programme_key(event) if event else None
            if key is not None:
                if key[0] in self.channels:
                    self.selected_channel = self.channels.index(key[0])
                self.anchor = (max(key[2], self.view_start)
                               + min(key[3], self.view_start + TIMELINE_SECONDS)) / 2
            self._save_selection()
            self._render()

        def _ensure_selected_channel_visible(self):
            self.first_channel = self.selected_channel // self.visible_count * self.visible_count

        def _move_channel(self, direction):
            if not self.channels:
                return
            self.footer_mode = False
            target = min(
                max(0, self.selected_channel + direction), len(self.channels) - 1)
            if target != self.selected_channel:
                self.restore_key = None
                self.selected_programme = None
            self.selected_channel = target
            self._ensure_selected_channel_visible()
            self._request_view()
            self._resolve_selection()
            self._save_selection()
            self._render()

        def _move_page(self, direction):
            page = self.first_channel + direction * self.visible_count
            if not 0 <= page < len(self.channels):
                self._move_channel(0)
                return
            offset = self.selected_channel - self.first_channel
            target = min(page + offset, len(self.channels) - 1)
            self._move_channel(target - self.selected_channel)

        def _move_programme(self, direction):
            if not self.channels:
                return
            channel = self.channels[self.selected_channel]
            events = self._visible_events(channel)
            if self.selected_programme is not None:
                event = adjacent_programme(events, channel, self.selected_programme, direction)
            elif direction > 0:
                event = next((e for e in events if programme_key(e)[2] >= self.anchor), None)
            else:
                event = next((e for e in reversed(events) if programme_key(e)[3] <= self.anchor), None)
            if event is not None:
                self._select_event(event)
                return
            # Move by a full viewport at its edge, keeping all request keys aligned.
            target = min(max(self.view_start + direction * TIMELINE_SECONDS,
                             self.first_view), self.last_view)
            if target == self.view_start:
                return
            boundary = self.view_start + (TIMELINE_SECONDS if direction > 0 else -1)
            self.view_start = target
            self.anchor = min(max(boundary, target), target + TIMELINE_SECONDS - 1)
            self.restore_key = None
            self.selected_programme = None
            self._request_view()
            self._save_selection()
            self._render()

        def onFocus(self, control_id):
            if monitor.abortRequested():
                return
            if self.closed or self.handoff is not None or control_id != self._focus_id():
                return
            if self.focus_requested is not None:
                if control_id != self.focus_requested:
                    return
                self.focus_requested = None
            value = self.event_controls.get(control_id) or self.restart_controls.get(control_id)
            if value is not None:
                key, event = value
                if key != programme_key(self.selected_programme):
                    self.footer_mode = False
                    self._select_event(event)

        def onClick(self, control_id):
            if self.closed or self.handoff is not None or monitor.abortRequested():
                return
            restart = control_id in self.restart_controls
            value = self.restart_controls.get(control_id) if restart else self.event_controls.get(control_id)
            if value is not None:
                self.footer_mode = False
                self._select_event(value[1])
                if self.closed:
                    return
                actions = self._actions(self.selected_programme)
                if restart:
                    self._activate("catchup" if "catchup" in actions else "start_from_beginning")
                elif actions:
                    self._activate(actions[0])
                else:
                    xbmcgui.Dialog().notification("simpliTVᵀ", text["not_playable"], time=3000)
                return

            self._activate(self.action_controls.get(control_id))

        def _activate(self, action_name):
            if action_name == "settings" and not self.closed and self.startup is None:
                if self.channels:
                    self._save_selection()
                if open_settings is not None:
                    open_settings()
                return
            if action_name == "return_to_stream" and not self.closed and self.startup is None:
                self._return_to_stream()
                return
            if action_name == "tv_options" and not self.closed and self.startup is None:
                last, edge = playback_actions()
                options = []
                if last in self.channels:
                    options.append((text["last_channel"], last))
                if edge is not None:
                    options.append((text["go_live"], None))
                if not options:
                    self._render()
                    return
                choice = xbmcgui.Dialog().contextmenu([label for label, _ in options])
                if not 0 <= choice < len(options) or monitor.abortRequested():
                    return
                channel = options[choice][1]
                fresh_last, fresh_edge = playback_actions()
                if channel is None:
                    if fresh_edge is not None and self._owned_playing():
                        try:
                            owned_playback["player"].seekTime(fresh_edge)
                        except RuntimeError as error:
                            self.log("Go Live seek failed: {}".format(type(error).__name__))
                        else:
                            self._return_to_stream()
                    return
                if channel == fresh_last and channel in self.channels:
                    self.selected_channel = self.channels.index(channel)
                    self._ensure_selected_channel_visible()
                    self._resolve_selection()
                    self._activate("watch_live")
                return
            channel = self.channels[self.selected_channel] if self.channels else ""
            if not channel or self.closed or self.startup is not None:
                return
            if action_name == "watch_live":
                self.result = {"channel": channel}
            elif action_name == "catchup" and self.selected_programme:
                if "catchup" not in self._actions(self.selected_programme):
                    return
                self.result = {"channel": channel, "catchup": self.selected_programme,
                               "request": self.request[0]}
            elif action_name == "start_from_beginning" and self.selected_programme:
                replay = self._replay(self.selected_programme, time.time())
                if replay is None:
                    return
                if (confirm_restart is not None
                        and not confirm_restart(self.request[0], self.selected_programme)):
                    if not self.loading:
                        self._refresh_view()
                    xbmcgui.Dialog().notification("simpliTVᵀ", text["refresh_rights"], time=3000)
                    return
                self.result = {
                    "channel": channel,
                    "start": programme_key(self.selected_programme)[2],
                    "stop": programme_key(self.selected_programme)[3]
                }
            else:
                return
            self._save_selection()
            if start_playback is None:
                self.close()
            else:
                selection = self.result
                self.result = None
                now = time.time()
                title, logo = self._channel_presentation(channel, self._visible_events(channel), now)
                event = self.selected_programme
                if action_name == "watch_live":
                    event = next((candidate for candidate in self.events_by_channel.get(channel, ())
                                  if programme_key(candidate)[2] <= now < programme_key(candidate)[3]), None)
                selection["metadata"] = playback_metadata(title, logo, event)
                self.startup = (title, logo, None)
                self.startup_textures = peek_crt() if peek_crt is not None else None
                self.startup_clock = time.monotonic()
                self._render()
                if not self.closed:
                    self.handoff = start_playback(selection)

        def _advance_handoff(self):
            try:
                next(self.handoff)
                title, logo, art = self.startup
                if logo:
                    try:
                        art = local_startup_logo(xbmc, logo)
                    except (ImportError, OSError, RuntimeError, TypeError, ValueError, AttributeError) as error:
                        self.log("Startup logo cache unavailable: {}".format(type(error).__name__))
                    self.startup = (title, None, art)
                    if art:
                        self._render()
            except StopIteration as finished:
                self.result = finished.value
                self.close()
            except Exception as error:
                # Playback exceptions can contain signed media URLs.
                self.log("Guide playback failed: {}".format(type(error).__name__))
                self.handoff = None
                self.startup = None
                self.startup_textures = None
                self._render()
                message = "restart_bounds" if isinstance(error, OutsideTimeline) else "playback_error"
                xbmcgui.Dialog().notification("simpliTVᵀ", text[message], time=5000)

        def onAction(self, action):
            if self.closed or monitor.abortRequested():
                return
            try:
                self._handle_action(action.getId())
            except Exception as error:
                self._fail_ui("action", error)

        def _handle_action(self, action_id):
            channel_direction = channel_direction_for_action(
                action_id,
                getattr(xbmcgui, "ACTION_MOVE_UP", 3),
                getattr(xbmcgui, "ACTION_MOVE_DOWN", 4),
                getattr(xbmcgui, "ACTION_CHANNEL_UP", ACTION_CHANNEL_UP),
                getattr(xbmcgui, "ACTION_CHANNEL_DOWN", ACTION_CHANNEL_DOWN)
            )
            if action_id == getattr(xbmcgui, "ACTION_STOP", 13):
                if self._owned_playing():
                    owned_playback["player"].stop()
                    self._render()
            elif action_id in (
                    getattr(xbmcgui, "ACTION_PREVIOUS_MENU", 10),
                    getattr(xbmcgui, "ACTION_NAV_BACK", 92)):
                self.close()
            elif self.handoff is not None:
                return
            elif action_id == getattr(xbmcgui, "ACTION_SHOW_GUI", 18):
                self._activate("return_to_stream")
            elif action_id == getattr(xbmcgui, "ACTION_MOUSE_RIGHT_CLICK", 101):
                value = (self.event_controls.get(self._focus_id())
                         or self.restart_controls.get(self._focus_id()))
                if value is not None:
                    self._select_event(value[1])
                    actions = self._actions(value[1])
                    if len(actions) == 2:
                        choice = xbmcgui.Dialog().contextmenu([
                            text["watch"], text["catchup" if actions[1] == "catchup" else "restart"]])
                        if choice in (0, 1):
                            self._activate(actions[choice])
            elif action_id == getattr(xbmcgui, "ACTION_CONTEXT_MENU", 117):
                self.footer_mode = True
                actions = self._actions(self.selected_programme)
                self._focus(self.return_button if self.can_return else
                            self.start_button if actions in (("start_from_beginning",), ("catchup",)) else
                            self.watch_button if self.channels else self.settings_button)
            elif action_id in (ACTION_PAGE_UP, ACTION_PAGE_DOWN):
                if self.channels:
                    self._move_page(-1 if action_id == ACTION_PAGE_UP else 1)
            elif channel_direction is not None:
                if self.channels:
                    if (action_id == getattr(xbmcgui, "ACTION_MOVE_DOWN", 4)
                            and not self.footer_mode
                            and self.selected_channel == len(self.channels) - 1):
                        self.footer_mode = True
                        self._focus(self.settings_button)
                    else:
                        self._move_channel(channel_direction)
            elif action_id in (1, 2):
                if self.footer_mode:
                    footer = [button for button in (
                        self.watch_button if self.channels else None,
                        self.start_button if self.can_start else None, self.return_button,
                        self.settings_button, self.tv_button)
                              if button is not None]
                    ids = [button.getId() for button in footer]
                    focus = self.focus_requested or self._focus_id()
                    index = ids.index(focus) if focus in ids else 0
                    if footer:
                        self._focus(footer[max(0, min(len(footer) - 1, index + (-1 if action_id == 1 else 1)))])
                else:
                    self._move_programme(-1 if action_id == 1 else 1)

        def close(self):
            if self.handoff is not None:
                self.handoff.close()
                self.handoff = None
            self.startup = None
            if self.closed:
                return
            self.closed = True
            self.cancel.set()
            with self.pending_lock:
                self.pending = None
            # Kodi owns window teardown on application shutdown.
            if not monitor.abortRequested():
                super().close()

        def onDeinit(self):
            self.closed = True
            self.cancel.set()

    if monitor.abortRequested():
        return None
    dialog = GuideDialog("guide.xml", addon_path, "Default", "1080i")
    try:
        if monitor.abortRequested():
            return None
        dialog.show()
        if monitor.abortRequested():
            return None
        init_deadline = time.monotonic() + 5
        # Monitor waits dispatch onInit/onDeinit. Polling Window.IsVisible can
        # block on Kodi's GUI during a Stop-to-guide return followed by Quit.
        while not dialog.closed and not monitor.abortRequested():
            # Kodi handles Tab/Fullscreen before dispatching actions to Python dialogs.
            if (dialog.handoff is None and dialog._owned_playing()
                    and xbmcgui.getCurrentWindowId() == 12005):
                dialog._return_to_stream(activate=False)
                break
            if dialog.initialized:
                if dialog.handoff is not None:
                    dialog._animate_startup()
                    dialog._advance_handoff()
                elif not dialog.closed:
                    dialog._apply_pending()
            elif time.monotonic() >= init_deadline:
                raise RuntimeError("Guide initialization callback did not run")
            delay = 0.02 if dialog.startup_frame is not None else (0.04 if dialog.handoff is not None else 0.1)
            if not dialog.closed and monitor.waitForAbort(delay):
                break
    except Exception as error:
        if monitor.abortRequested():
            return None
        dialog._fail_ui("modal", error)
        raise RuntimeError("Guide dialog could not be opened") from error
    finally:
        dialog.close()
    if monitor.abortRequested():
        return None
    if dialog.ui_error is not None:
        raise RuntimeError("Guide rendering failed") from dialog.ui_error
    return dialog.result
