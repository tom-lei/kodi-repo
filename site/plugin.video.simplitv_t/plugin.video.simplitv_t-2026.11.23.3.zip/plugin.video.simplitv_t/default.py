import sys
import os
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import datetime
import math
import requests
import json
import time
import threading
import uuid
import traceback
import tzlocal
from timeshift_overlay import channel_schedule, launch as launch_timeshift_overlay
from tv_behavior import StationHistory, input_trace, live_target
from seek_schedule import load_schedule
import crt_noise
from player_window import open_player_window
from auth_session import AuthError, API_HEADERS, kodi_session, start_preparation
from channel_access import (
    ACCESS_TEXT, BRANDING_KEY, CACHE_KEY, CACHE_SECONDS, CHANNEL_TILE_CACHE_KEY, CATCHUP_POLICY_KEY, channel_profile_id,
    filter_live_channels, playable_only_enabled
)
from service_config import API_ROOT, CHANNEL_LOGO_ROOT, PORTAL_ROOT, TENANT_CODENAME
from playback_media import WIDEVINE, select_playback
from live_cache import (
    LiveCache, LiveDataCancelled, LiveDataError, broadcast_timestamp, now_next_programmes,
    CHANNEL_SECONDS, EPG_SECONDS, guide_cache_slot, load_guide_page, claim_guide_session
)
from guide import (GUIDE_TEXT, OutsideTimeline, channel_presentation, open_guide,
                   playback_metadata, programme_key, replay_start)
from guide_store import GuideStore, MAX_REWIND_SECONDS
from catchup import catchup_available

GUIDE_PLAYBACK_PROPERTY = "simplitv_t.guide.playback"
FULLSCREEN_VIDEO_WINDOW = 12005

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo("name")
KODI_ov20 = int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 20
KODI_un21 = int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) <= 20

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

addon_icon = addon.getAddonInfo("icon")

username = addon.getSetting("username")

api_headers = API_HEADERS
data_headers = {
    'User-Agent': API_HEADERS['User-Agent'], 'Accept': 'application/json',
    'X-Tenant-Codename': API_HEADERS['X-Tenant-Codename']
}
stream_headers = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'
license_headers = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0&Referer=' + PORTAL_ROOT + '/'

auth = kodi_session()
guide_lock_path = os.path.join(os.path.dirname(auth.lock_path), "guide.lock")
def guide_log(message):
    xbmc.log("[{}] {}".format(addon_name, message), xbmc.LOGWARNING)


guide_store = GuideStore(os.path.dirname(auth.lock_path), API_ROOT, TENANT_CODENAME,
                         username, guide_log)
live_cache = LiveCache(xbmcgui.Window(10000), auth.account, guide_log, guide_store=guide_store)

mode = args.get('mode', None)
if mode is None and addon_handle >= 0:
    start_preparation()
    crt_noise.start_preparation(os.path.dirname(auth.lock_path), addon)
start = args.get('start', None)

local_timezone = tzlocal.get_localzone()

def live_json(method, url, **kwargs):
    try:
        response = requests.request(
            method, url, timeout=15, headers=api_headers, allow_redirects=False, **kwargs
        )
    except requests.RequestException:
        raise LiveDataError("Live TV data request failed") from None
    if not 200 <= response.status_code < 300:
        raise LiveDataError("Live TV data returned HTTP {}".format(response.status_code))
    try:
        data = response.json()
    except ValueError:
        raise LiveDataError("Live TV data returned invalid JSON") from None
    if not isinstance(data, dict):
        raise LiveDataError("Live TV data returned an unexpected response")
    return data

def peek_guide_programmes(start_time, channels):
    key, identity = guide_cache_slot("page", start_time, channels)
    return live_cache.peek(key, EPG_SECONDS, identity)

def load_guide_programmes(start_time, channels, cancelled, publish):
    return load_guide_page(live_cache, guide_lock_path, live_json,
                           start_time, channels, cancelled, publish)

def confirm_guide_restart(request, programme):
    key = programme_key(programme)
    if key is None:
        return False
    return any(programme_key(event) == key and replay_start(
        event, time.time(), rewind_observation(key[0]), timeshift_denied(key[0])) is not None
               for event in (peek_guide_programmes(*request) or ()))


def rewind_observation(channel):
    # False selects the existing Widevine cache partition.
    return guide_store.read_rewind(channel, False)


def timeshift_denied(channel):
    lineup = live_cache.peek(CHANNEL_TILE_CACHE_KEY, CHANNEL_SECONDS)
    if not lineup:
        return True
    access = live_cache.peek(CACHE_KEY, CACHE_SECONDS, lineup)
    if not isinstance(access, dict) or access.get("status") == "error":
        return True
    ids = {identity for code, identity in lineup if code == channel and identity is not None}
    return (access.get("account_timeshift_denied") is True
            or bool(ids.intersection(access.get("timeshift_denied", ()))))


def peek_catchup_state():
    lineup = live_cache.peek(CHANNEL_TILE_CACHE_KEY, CHANNEL_SECONDS)
    if not lineup:
        return None, None
    access = live_cache.peek(CACHE_KEY, CACHE_SECONDS, lineup)
    policy = live_cache.peek(CATCHUP_POLICY_KEY, CACHE_SECONDS, lineup)
    return access, policy


def catchup_eligible(event, now):
    access, policy = peek_catchup_state()
    return catchup_available(event, access, policy, now)


def confirm_guide_catchup(request, programme):
    key = programme_key(programme)
    if key is None:
        return False
    return any(programme_key(event) == key and event.get("codename") == programme.get("codename")
               and catchup_eligible(event, time.time())
               for event in (peek_guide_programmes(*request) or ()))


def remember_rewind(channel, media, duration):
    if duration is not None and math.isfinite(duration) and 1 <= duration <= MAX_REWIND_SECONDS:
        path = urllib.parse.urlsplit(media[0]).path.lower()
        stream_format = ("DASH/Widevine" if media[1] != "false"
                         else "DASH/Clear" if path.endswith(".mpd") else "HLS/Clear")
        guide_store.write_rewind(channel, False, stream_format, duration)


def play(stream_url, stream_drm_license_server, stream_drm_challenge_data, codename,
         guide_player=None, metadata=None, windowed=False):
    url = stream_url
    if metadata is None:
        title = xbmc.getInfoLabel("ListItem.Title") or channelname(codename)
        plot = xbmc.getInfoLabel("ListItem.Plot")
        art = {
            "fanart": xbmc.getInfoLabel("ListItem.Fanart") or addon.getAddonInfo("fanart"),
            "thumb": xbmc.getInfoLabel("ListItem.Thumb") or static_channel_logo(codename, title),
            "icon": xbmc.getInfoLabel("ListItem.Icon") or static_channel_logo(codename, title),
        }
    else:
        title = metadata.get("title") or channelname(codename)
        plot = metadata.get("plot") or ""
        logo = metadata.get("logo") or static_channel_logo(codename, title)
        art = {"fanart": addon.getAddonInfo("fanart"), "thumb": logo, "icon": logo}
    play_item = xbmcgui.ListItem(label=title, path=url)
    play_item.setContentLookup(False)
    if KODI_ov20:
        info = play_item.getVideoInfoTag()
        info.setTitle(title)
        info.setPlot(plot)
    else:
        play_item.setInfo("video", {"title": title, "plot": plot})
    play_item.setArt(art)
    adaptive = 'inputstream.adaptive'
    play_item.setProperty('inputstream', adaptive)
    hls = stream_drm_license_server == "false" and urllib.parse.urlsplit(url).path.lower().endswith(".m3u8")
    play_item.setMimeType('application/vnd.apple.mpegurl' if hls else 'application/dash+xml')
    if KODI_un21: # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
        play_item.setProperty(adaptive + '.manifest_type', 'hls' if hls else 'mpd')
    if KODI_ov20:
        play_item.setProperty(adaptive + '.manifest_headers', f"User-Agent={stream_headers}")
    else: # DEPRECATED ON Kodi v20, please use 'inputstream.adaptive.manifest_headers' instead.
        play_item.setProperty(adaptive + '.stream_headers', f"User-Agent={stream_headers}")
    if stream_drm_license_server != "false":
        play_item.setProperty(adaptive + '.license_key', f"{stream_drm_license_server}|User-Agent={license_headers}&drmchallengecustomdata={urllib.parse.quote(stream_drm_challenge_data)}&Content-Type=application/octet-stream|R{{SSM}}|")
        play_item.setProperty(adaptive + '.license_type', WIDEVINE)
    play_item.setProperty('IsPlayable', 'true')
    if guide_player is not None:
        play_item.setProperty(GUIDE_PLAYBACK_PROPERTY, guide_player.request_id)
        if windowed:
            guide_player.play(item=url, listitem=play_item, windowed=True)
        else:
            guide_player.play(item=url, listitem=play_item)
        return url
    xbmcplugin.setResolvedUrl(addon_handle, True, play_item)
    xbmc.Player().play(item=url, listitem=play_item)
    launch_timeshift_overlay(url, codename, auth.account, art["icon"], channelname(codename))
    
def token():
    try:
        return auth.token()
    except AuthError as error:
        xbmc.log("[simpliTVᵀ] " + str(error), xbmc.LOGERROR)
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('[B]Error[/B]', 'Login error.', 5000, addon_icon))
        raise
    
def channelname(channel):
    name = channel.replace("-", " ")
    name = name.upper()
    if name.endswith(' HD'):
        name = name[:-3]
    if name.endswith('HD'):
        name = name[:-2]
    return name
    
def logomapper(name):
    if name == "ORF1":
        logo = CHANNEL_LOGO_ROOT + "/files/orf1-hd-bunt.png"
    elif name == "ORF2NO":
        logo = CHANNEL_LOGO_ROOT + "/files/orf-no-e-hd-bunt.png"
    elif name == "ATV":
        logo = CHANNEL_LOGO_ROOT + "/files/atv-hd-bunt.png"
    elif name == "PULS4AUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/puls4-hd-bunt.png"
    elif name == "PU4":
        logo = CHANNEL_LOGO_ROOT + "/files/puls4-hd-bunt.png"
    elif name == "SERVUSTV AUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/servustv-hd-bunt.png"
    elif name == "ORF III":
        logo = CHANNEL_LOGO_ROOT + "/files/orf3-hd-bunt.png"
    elif name == "ATV 2":
        logo = CHANNEL_LOGO_ROOT + "/files/atv2-bunt.png"
    elif name == "OE24TV":
        logo = CHANNEL_LOGO_ROOT + "/files/oe24-tv-bunt.png"
    elif name == "PULS24":
        logo = CHANNEL_LOGO_ROOT + "/files/puls24-bunt.png"
    elif name == "PROSIEBENAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/pro7-hd-bunt.png"
    elif name == "SAT1AUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/sat1-hd-bunt.png"
    elif name == "RTLAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/rtl-austria-hd-bunt.png"
    elif name == "VOXAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/vox-hd-bunt.png"
    elif name == "ZDF":
        logo = CHANNEL_LOGO_ROOT + "/files/zdf-hd-bunt.png"
    elif name == "ARD":
        logo = CHANNEL_LOGO_ROOT + "/files/ard-hd-bunt.png"
    elif name == "KABELEINSAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/kabel1-hd-austria-bunt.png"
    elif name == "SAT1GOLDAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/sat1-gold-hd-bunt.png"
    elif name == "3SAT":
        logo = CHANNEL_LOGO_ROOT + "/files/3sat-hd-bunt.png"
    elif name == "SIXXAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/sixx-austria-hd-bunt.png"
    elif name == "PROSIEBENMAXXAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/pro7-maxx-austria-bunt.png"
    elif name == "N TV":
        logo = CHANNEL_LOGO_ROOT + "/files/ntv-hd-bunt.png"
    elif name == "RTLZWEIAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/rtl-zwei-hd-bunt.png"
    elif name == "ZDFNEO":
        logo = CHANNEL_LOGO_ROOT + "/files/zdf-neo-hd-bunt.png"
    elif name == "ZDFINFO":
        logo = CHANNEL_LOGO_ROOT + "/files/zdf-info-hd-bunt.png"
    elif name == "RTLUP AUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/rtluphd-kopie.png"
    elif name == "BFS":
        logo = CHANNEL_LOGO_ROOT + "/files/br-hd-bunt.png"
    elif name == "NITRO AUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/nitro-logo-hd.png"
    elif name == "TELE 5":
        logo = CHANNEL_LOGO_ROOT + "/files/tele-5-bunt.png"
    elif name == "COMEDY CENTRAL":
        logo = CHANNEL_LOGO_ROOT + "/files/comedy-central-austria-bunt.png"
    elif name == "ORF SPORT PLUS":
        logo = CHANNEL_LOGO_ROOT + "/files/orf-sport-plus-hd-bunt.png"
    elif name == "EUROSPORT1AUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/eurosport-1-hd-bunt.png"
    elif name == "SPORT1":
        logo = CHANNEL_LOGO_ROOT + "/files/sport1-hd-bunt.png"
    elif name == "LAOLA1TV":
        logo = CHANNEL_LOGO_ROOT + "/files/laola1-logo-rgb.jpg"
    elif name == "K19":
        logo = CHANNEL_LOGO_ROOT + "/files/element-1k19-logo.png"
    elif name == "ARTE":
        logo = CHANNEL_LOGO_ROOT + "/files/arte-hd-bunt.png"
    elif name == "TLCAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/tlc-hd-bunt.png"
    elif name == "KABELEINSDOKU":
        logo = CHANNEL_LOGO_ROOT + "/files/kabel1-doku-austria-bunt.png"
    elif name == "DMAXAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/dmax-hd-bunt.png"
    elif name == "PHOENIX":
        logo = CHANNEL_LOGO_ROOT + "/files/phoenix-bunt.png"
    elif name == "N24 DOKU":
        logo = CHANNEL_LOGO_ROOT + "/files/078-n24doku-1024x218.png"
    elif name == "SCHAU TV":
        logo = CHANNEL_LOGO_ROOT + "/files/kurier-tv-logo-cmyk-b.png"
    elif name == "KRONETV":
        logo = CHANNEL_LOGO_ROOT + "/files/kronetv-bunt.png"
    elif name == "R9 OESTERREICH":
        logo = CHANNEL_LOGO_ROOT + "/files/logor9.png"
    elif name == "WELT":
        logo = CHANNEL_LOGO_ROOT + "/files/welt-bunt.png"
    elif name == "TAGESSCHAU 24":
        logo = CHANNEL_LOGO_ROOT + "/files/069-tagesschau24hd-1024x208.png"
    elif name == "BILD TV":
        logo = CHANNEL_LOGO_ROOT + "/files/bild-tv-logo-august-2021.png"
    elif name == "CNN":
        logo = CHANNEL_LOGO_ROOT + "/files/cnn-bunt.png"
    elif name == "EURONEWS ENGLISH":
        logo = CHANNEL_LOGO_ROOT + "/files/logo-euronews-white-on-neon-rgb-kopie.png"
    elif name == "AL JAZEERA ENGLISH":
        logo = CHANNEL_LOGO_ROOT + "/files/aje-logo-rgb.png"
    elif name == "BLOOMBERG EUROPE":
        logo = CHANNEL_LOGO_ROOT + "/files/075-bloomberg-921x248.png"
    elif name == "TVP WORLD":
        logo = CHANNEL_LOGO_ROOT + "/files/tvp-world-logo-2022.jpg"
    elif name == "SUPERRTL AUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/super-rtl-hd-logo-orange.png"
    elif name == "KIKA":
        logo = CHANNEL_LOGO_ROOT + "/files/kika-hd-bunt.png"
    elif name == "NICKELODEON":
        logo = CHANNEL_LOGO_ROOT + "/files/nick-austria-bunt.png"
    elif name == "RIC":
        logo = CHANNEL_LOGO_ROOT + "/files/ric-bunt.png"
    elif name == "FIX UND FOXI":
        logo = CHANNEL_LOGO_ROOT + "/files/fix-foxi-bunt.png"
    elif name == "ORF2":
        logo = CHANNEL_LOGO_ROOT + "/files/orf2-hd-bunt.png"
    elif name == "ORF2OO":
        logo = CHANNEL_LOGO_ROOT + "/files/orf-oo-e-hd-bunt.png"
    elif name == "ORF2ST":
        logo = CHANNEL_LOGO_ROOT + "/files/orf-steiermark-hd-bunt.png"
    elif name == "ORF2T":
        logo = CHANNEL_LOGO_ROOT + "/files/orf-tirol-hd-bunt.png"
    elif name == "ORF2B":
        logo = CHANNEL_LOGO_ROOT + "/files/orf-hd-burgenland-bunt.png"
    elif name == "ORF2K":
        logo = CHANNEL_LOGO_ROOT + "/files/orf-hd-ka-ernten-bunt.png"
    elif name == "ORF2S":
        logo = CHANNEL_LOGO_ROOT + "/files/orf-salzburg-hd-bunt.png"
    elif name == "ORF2V":
        logo = CHANNEL_LOGO_ROOT + "/files/orf-vorarlberg-hd-bunt.png"
    elif name == "KT1":
        logo = CHANNEL_LOGO_ROOT + "/files/kt1.png"
    elif name == "WNTV":
        logo = CHANNEL_LOGO_ROOT + "/files/wntv-ihr-privatfernsehen-logo-1801150443.jpg"
    elif name == "W24":
        logo = CHANNEL_LOGO_ROOT + "/files/100-w24.png"
    elif name == "N1 NOE TV":
        logo = CHANNEL_LOGO_ROOT + "/files/senderlogo-oesterreichprogramm-n1.png"
    elif name == "LT1":
        logo = CHANNEL_LOGO_ROOT + "/files/lt1-logo-neu.png"
    elif name == "TV1 OOE":
        logo = CHANNEL_LOGO_ROOT + "/files/rz-logo-tv1-pos-rgb.jpg"
    elif name == "TIROLTV":
        logo = CHANNEL_LOGO_ROOT + "/files/tiroltv.png"
    elif name == "LAENDLETV":
        logo = CHANNEL_LOGO_ROOT + "/files/landletv-s-auf-w.png"
    elif name == "DORFTV":
        logo = CHANNEL_LOGO_ROOT + "/files/dorftv-kopie-2.png"
    elif name == "ONE":
        logo = CHANNEL_LOGO_ROOT + "/files/one-hd-bunt.png"
    elif name == "SWR BW":
        logo = CHANNEL_LOGO_ROOT + "/files/062-swtbwhd-366x71.png"
    elif name == "SR FERNSEHEN":
        logo = CHANNEL_LOGO_ROOT + "/files/067-srfernsehenhd-1024x627.png"
    elif name == "NDR":
        logo = CHANNEL_LOGO_ROOT + "/files/ndr-hd-bunt.png"
    elif name == "WDR KÖLN":
        logo = CHANNEL_LOGO_ROOT + "/files/063-wdrhd-1024x341.png"
    elif name == "MDR SACHSEN":
        logo = CHANNEL_LOGO_ROOT + "/files/mdr-rgb.png"
    elif name == "HR FERNSEHEN":
        logo = CHANNEL_LOGO_ROOT + "/files/065-hr-fernsehenhd-170x75.png"
    elif name == "RBB BERLIN":
        logo = CHANNEL_LOGO_ROOT + "/files/rbb-rgb.png"
    elif name == "ARD ALPHA":
        logo = CHANNEL_LOGO_ROOT + "/files/ardaplha-rgb.png"
    elif name == "RADIO BREMEN":
        logo = CHANNEL_LOGO_ROOT + "/files/radio-bremen-rgb.jpg"
    elif name == "OE3 VISUAL RADIO":
        logo = CHANNEL_LOGO_ROOT + "/files/oe3-logo.png"
    elif name == "MTVAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/mtv-hd-bunt.png"
    elif name == "DELUXEMUSICAUSTRIA":
        logo = CHANNEL_LOGO_ROOT + "/files/deluxe-music-hd-bunt.png"
    elif name == "MELODIETV":
        logo = CHANNEL_LOGO_ROOT + "/files/093-melodietv-573x538.png"
    elif name == "SCHLAGER DELUXE":
        logo = CHANNEL_LOGO_ROOT + "/files/schlager-deluxe-logo.png"
    elif name == "DEUTSCHES MUSIKFERNSEHEN":
        logo = CHANNEL_LOGO_ROOT + "/files/deutsches-musik-fernsehen-infarbe.jpg"
    elif name == "VOLKSMUSIK TV":
        logo = CHANNEL_LOGO_ROOT + "/files/911px-volksmusik-tv-logosvg.png"
    elif name == "MEI MUSI TV":
        logo = CHANNEL_LOGO_ROOT + "/files/mei-musi-tv.png"
    elif name == "STARPARADISES TV":
        logo = CHANNEL_LOGO_ROOT + "/files/starparadies.png"
    elif name == "LILO TV":
        logo = CHANNEL_LOGO_ROOT + "/files/lilo-color.png"
    elif name == "HGTV":
        logo = CHANNEL_LOGO_ROOT + "/files/hgtv-bunt.png"
    elif name == "ARCADIA TV":
        logo = CHANNEL_LOGO_ROOT + "/files/arcadiaworld.png"
    elif name == "SONNENKLARTV":
        logo = CHANNEL_LOGO_ROOT + "/files/sk-tv-clm-rgb.png"
    elif name == "BIBELTV":
        logo = CHANNEL_LOGO_ROOT + "/files/084-bibeltvhd-1024x198.png"
    elif name == "FASHION TV":
        logo = CHANNEL_LOGO_ROOT + "/files/fashiontv-logo-blue-vertical-1.png"
    elif name == "PLAYBOY TV":
        logo = CHANNEL_LOGO_ROOT + "/files/dorcel-2022-playboytveurope-logo-noir-transparent.png"
    elif name == "HUSTLER TV":
        logo = CHANNEL_LOGO_ROOT + "/files/hustlertv-light.jpg"
    elif name == "DORCEL TV":
        logo = CHANNEL_LOGO_ROOT + "/files/2022-dorceltv-black-rvb.jpg"
    else:
        logo = addon_icon
    return logo


def static_channel_logo(channel, title):
    logo = logomapper(title)
    return logomapper(channelname(channel)) if logo == addon_icon else logo


def get_channel_tiles():
    return live_cache.get(CHANNEL_TILE_CACHE_KEY, load_channel_tiles, CHANNEL_SECONDS)

def load_channel_tiles():
    channels_url = API_ROOT + '/v1/EpgTile/FilterChannelTiles'
    channels_post = json.dumps({'isParentalControlEnabled': 'false', 'platformCodename': 'www', 'token': token()})
    channels_resp = live_json("POST", channels_url, data=channels_post)
    try:
        tiles = channels_resp["channels"][0]["tiles"]
        if any(not isinstance(tile["codename"], str) for tile in tiles):
            raise LiveDataError("Invalid channel identifier")
        return [[tile["codename"], channel_profile_id(tile.get("id"))]
                for tile in tiles]
    except (KeyError, IndexError, TypeError):
        raise LiveDataError("Invalid channel list") from None

def run_live_tv_guide(startup=False):
    lock_path = os.path.join(os.path.dirname(guide_lock_path), "guide-session.lock")
    try:
        with claim_guide_session(lock_path) as claimed:
            if claimed:
                if startup and not prepare_guide_anchor():
                    return
                if not startup:
                    crt_noise.start_preparation(os.path.dirname(guide_lock_path), addon)
                load_live_tv()
    except LiveDataError as error:
        xbmc.log("[{}] {}".format(addon_name, error), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(addon_name, str(error), addon_icon, 5000)


def prepare_guide_anchor():
    # Root directory resolution must finish before a command opens the dialog.
    monitor = xbmc.Monitor()
    deadline = time.monotonic() + 10
    while not monitor.abortRequested() and time.monotonic() < deadline:
        window, folder = guide_container()
        if folder.rstrip("/") == base_url.rstrip("/") and xbmcgui.getCurrentWindowDialogId() in (0, 9999):
            break
        if monitor.waitForAbort(0.05):
            return False
    else:
        guide_log("Guide launch cancelled: root directory did not become active")
        return False
    if monitor.abortRequested():
        return False
    anchor = build_url({"mode": "livetv-recovery"})
    xbmc.executebuiltin('Container.Update("{}",replace)'.format(anchor))
    while not monitor.abortRequested() and time.monotonic() < deadline:
        current_window, folder = guide_container()
        if current_window == window and folder == anchor and xbmcgui.getCurrentWindowDialogId() in (0, 9999):
            return True
        if monitor.waitForAbort(0.05):
            return False
    guide_log("Guide launch cancelled: recovery directory did not become active")
    return False


def add_recovery_controls(access_status=""):
    german = xbmc.getLanguage(xbmc.ISO_639_1) == "de"
    settings = ACCESS_TEXT[german]["settings"]
    if access_status:
        settings = "{} — {}".format(ACCESS_TEXT[german][access_status], settings)
    for label, route in ((GUIDE_TEXT[german]["guide"], "livetv"),
                         (settings, "live-access-settings")):
        item = xbmcgui.ListItem(label)
        item.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(addon_handle, build_url({"mode": route}), item, isFolder=False)


def load_live_tv():
    try:
        channel_tiles = get_channel_tiles()
    except (LiveDataError, AuthError) as error:
        xbmc.log("[{}] {}".format(addon_name, error), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(addon_name, str(error), addon.getAddonInfo("icon"), 5000)
        if addon_handle >= 0:
            add_recovery_controls("error")
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        else:
            show_live_tv_guide([], access_status="error")
        return
    enabled = playable_only_enabled(addon)
    fetch_deadline = None
    branding_requested = False

    def cached_branding():
        nonlocal branding_requested
        branding = live_cache.peek(BRANDING_KEY, CHANNEL_SECONDS, channel_tiles)
        if branding is None and not branding_requested and channel_tiles:
            branding_requested = True
            start_preparation(live_access=True)
        return branding or {}

    def filter_cached_channels():
        nonlocal fetch_deadline, branding_requested
        access = live_cache.peek(CACHE_KEY, CACHE_SECONDS, channel_tiles)
        if access is not None:
            fetch_deadline = None
        elif fetch_deadline is None:
            fetch_deadline = time.monotonic() + 65
            branding_requested = True
            start_preparation(live_access=True)
        elif time.monotonic() >= fetch_deadline:
            return [], "error"
        return filter_live_channels(channel_tiles, access, True)

    channels_find, access_status = (filter_cached_channels() if enabled
                                    else filter_live_channels(channel_tiles, None, False))
    if (not branding_requested
            and ((not enabled and live_cache.peek(CACHE_KEY, CACHE_SECONDS, channel_tiles) is None)
                 or live_cache.peek(CATCHUP_POLICY_KEY, CACHE_SECONDS, channel_tiles) is None)):
        start_preparation(live_access=True)
    if addon_handle >= 0:
        add_recovery_controls(access_status)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    else:
        show_live_tv_guide(channels_find, filter_cached_channels if enabled else None,
                           access_status, cached_branding, filter_cached_channels)


def show_live_tv_guide(channels, refresh_channels=None, access_status="", peek_branding=None,
                       zap_channels=None):
    monitor = xbmc.Monitor()
    if monitor.abortRequested():
        return
    origin = guide_container()
    root = urllib.parse.urlsplit(origin[1])
    can_return = (root.scheme == "plugin" and root.netloc == addon.getAddonInfo("id")
                  and root.path in ("", "/")
                  and (not root.query or urllib.parse.parse_qs(root.query) == {"mode": ["livetv-recovery"]}))
    returning = False
    playback = None
    history = StationHistory()

    def allowed_channels():
        return zap_channels()[0] if zap_channels is not None else []

    def describe_channel(channel):
        schedules = dict(now_next_programmes(live_cache.cached_schedules(), [channel], time.time()))
        current = schedules[channel][0]
        event = current[2] if current else None
        branding = peek_branding() if peek_branding is not None else {}
        title, logo = channel_presentation(channel, event, branding, channelname, static_channel_logo)
        return playback_metadata(title, logo, event)

    def start_zap(channel, on_dispatch):
        selection = {"channel": channel, "metadata": describe_channel(channel)}
        return start_tracked(selection, on_dispatch)

    def start_tracked(selection, on_dispatch=None):
        channel = selection["channel"]
        input_trace("tune_requested", channel=channel)
        result = yield from begin_guide_playback(
            selection, owned_window=True,
            allowed=(lambda code: code in allowed_channels()) if on_dispatch else None,
            on_dispatch=on_dispatch)
        history.started(channel)
        input_trace("tune_started", channel=channel)
        return result

    def guide_playback_actions():
        return history.target(allowed_channels()), live_target(playback, xbmc)

    def open_guide_settings():
        addon.openSettings()
        if not monitor.abortRequested():
            crt_noise.start_preparation(os.path.dirname(guide_lock_path), addon)

    try:
        while not monitor.abortRequested():
            if refresh_channels is not None:
                channels, access_status = refresh_channels()
            if monitor.abortRequested():
                break
            playback = open_guide(
                channels, peek_guide_programmes, load_guide_programmes,
                channelname, addon.getAddonInfo("path"),
                lambda message: xbmc.log(
                    "[{}] {}".format(addon_name, message), xbmc.LOGWARNING
                ),
                auth.account, local_timezone,
                static_channel_logo,
                start_tracked,
                refresh_channels, access_status, rewind_observation, confirm_guide_restart, playback,
                open_guide_settings, peek_branding,
                lambda: crt_noise.startup_textures(addon, os.path.dirname(guide_lock_path)),
                timeshift_denied, catchup_eligible, peek_catchup_state, monitor,
                guide_playback_actions, lambda: addon.getSetting("guide_mini_picture") != "false"
            )
            if monitor.abortRequested():
                break
            if playback and playback.get("owned_window"):
                if playback.get("fullscreen") and xbmcgui.getCurrentWindowId() == FULLSCREEN_VIDEO_WINDOW:
                    status = "fullscreen"
                else:
                    try:
                        status, playback = open_player_window(
                            playback, allowed_channels, start_zap, addon, guide_log,
                            describe_channel,
                            lambda: crt_noise.startup_textures(addon, os.path.dirname(guide_lock_path)),
                            lambda channel: channel_schedule(live_cache, channel),
                            lambda *args: load_schedule(*args), monitor, history,
                            live_cache.cached_schedules)
                    except (RuntimeError, OSError) as error:
                        if monitor.abortRequested():
                            break
                        guide_log("Player window unavailable: {}".format(type(error).__name__))
                        if not (playback["player"].isPlayingVideo() and playback["matches"]()):
                            raise
                        playback["owned_window"] = False
                        xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
                        status = "fullscreen"
                if monitor.abortRequested():
                    break
                if status in ("guide", "stopped"):
                    remember_guide_channel(playback["channel"])
                    if status == "stopped":
                        playback = None
                    returning = True
                    continue
                if status == "fullscreen":
                    if playback.get("live"):
                        metadata = playback.get("metadata") or {}
                        launch_timeshift_overlay(playback["url"], playback["channel"], auth.account,
                                                 metadata.get("logo"),
                                                 metadata.get("title", "").partition(" — ")[0])
                    if can_return and wait_for_guide_return(origin, playback, monitor):
                        remember_guide_channel(playback["channel"])
                        returning = True
                        continue
                break
            if not (playback and can_return and wait_for_guide_return(origin, playback, monitor)):
                break
            returning = True
    except Exception as error:
        if monitor.abortRequested():
            return
        xbmc.log("[{}] Guide UI failed: {}".format(addon_name, error), xbmc.LOGERROR)
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            addon_name, "TV-Guide konnte nicht geöffnet werden",
            addon.getAddonInfo("icon"), 5000
        )
        if not returning and urllib.parse.parse_qs(root.query) != {"mode": ["livetv-recovery"]}:
            xbmc.executebuiltin('Container.Update("{}")'.format(
                build_url({"mode": "livetv-recovery"})))


def remember_guide_channel(channel):
    window = xbmcgui.Window(10000)
    key = "simplitv_t.guide.selection." + auth.account
    try:
        selection = json.loads(window.getProperty(key) or "{}")
    except (TypeError, ValueError):
        selection = {}
    if not isinstance(selection, dict):
        selection = {}
    if selection.get("channel") != channel:
        selection.update(channel=channel, programme_id="", programme_start=None)
        window.setProperty(key, json.dumps(selection))


def guide_container():
    return xbmcgui.getCurrentWindowId(), xbmc.getInfoLabel("Container.FolderPath")


def wait_for_guide_return(origin, playback, monitor):
    fullscreen_seen = playback["fullscreen"]
    matches = playback["matches"]
    deadline = time.monotonic() + 3
    while not monitor.abortRequested():
        window, folder = guide_container()
        playing = playback["player"].isPlayingVideo()
        if playing and not matches():
            return False
        if window == FULLSCREEN_VIDEO_WINDOW:
            fullscreen_seen = True
            if playing:
                deadline = time.monotonic() + 3
        elif (window, folder) != origin:
            return False
        elif fullscreen_seen and xbmcgui.getCurrentWindowDialogId() in (0, 9999):
            return True
        if time.monotonic() >= deadline:
            return False
        if monitor.waitForAbort(0.1):
            return False
    return False


def acquire_playback(codename, catchup=False):
    response = (auth.acquire(codename, data_headers, require_success=True) if catchup
                else auth.acquire(codename, data_headers))
    return select_playback(response)


def begin_guide_playback(selection, owned_window=False, allowed=None, on_dispatch=None):
    """Advance startup on the guide thread; the worker only acquires media."""
    codename = selection["channel"]
    programme = selection.get("catchup")
    request = selection.get("request")
    start = selection.get("start")
    stop = selection.get("stop")
    if start is not None and (stop is None or timeshift_denied(codename)):
        raise OutsideTimeline("Rewind is unavailable")
    completed = threading.Event()
    result = []

    def acquire():
        try:
            if programme is not None:
                if request is None or not confirm_guide_catchup(request, programme):
                    raise LiveDataError("Catch-up rights or programme data have expired")
                result.append((acquire_playback(programme["codename"], catchup=True), None))
            else:
                result.append((acquire_playback(codename), None))
        except Exception as error:
            result.append((None, error))
        finally:
            completed.set()

    threading.Thread(target=acquire, daemon=True).start()
    deadline = time.monotonic() + 60
    while not completed.is_set():
        if time.monotonic() >= deadline:
            raise TimeoutError("Playback acquisition timed out")
        yield
    media, error = result.pop()
    if error is not None:
        raise error
    if programme is not None and not confirm_guide_catchup(request, programme):
        raise LiveDataError("Catch-up rights or programme data have expired")
    if allowed is not None and not allowed(codename):
        raise LiveDataError("Live channel access is no longer confirmed")

    class GuidePlayer(xbmc.Player):
        av_started = False

        def onAVStarted(self):
            self.av_started = True

    player = GuidePlayer()
    player.request_id = uuid.uuid4().hex
    if owned_window:
        url = play(*media, codename, guide_player=player, metadata=selection.get("metadata"),
                   windowed=True)
    else:
        url = play(*media, codename, guide_player=player, metadata=selection.get("metadata"))
    if on_dispatch is not None:
        on_dispatch()
    def matches():
        try:
            if hasattr(player, "getPlayingItem"):
                return (player.getPlayingItem().getProperty(GUIDE_PLAYBACK_PROPERTY)
                        == player.request_id)
            return player.getPlayingFile().split("|", 1)[0] == url.split("|", 1)[0]
        except RuntimeError:
            return False

    deadline = time.monotonic() + 45
    target = None
    seek_from = None
    fullscreen_seen = False
    observed = False
    while time.monotonic() < deadline:
        if player.av_started and player.isPlayingVideo() and matches():
            fullscreen_seen |= xbmcgui.getCurrentWindowId() == FULLSCREEN_VIDEO_WINDOW
            try:
                ready = start is None
                duration = player.getTotalTime()
                if (programme is None and not observed and math.isfinite(duration)
                        and 1 <= duration <= MAX_REWIND_SECONDS):
                    remember_rewind(codename, media, duration)
                    observed = True
                if start is not None and target is None:
                    position = player.getTime()
                    if (math.isfinite(duration) and math.isfinite(position)
                            and duration > 0 and 0 < position <= duration
                            and duration - position <= 30):
                        now = time.time()
                        earliest = now - position
                        actual_target = max(start, earliest + 1)
                        if timeshift_denied(codename):
                            if matches():
                                player.stop()
                            raise OutsideTimeline("Rewind is unavailable")
                        seek_position = position - (now - actual_target)
                        if not 0 <= seek_position < position - 3:
                            if start < earliest and position <= 4:
                                ready = True
                            else:
                                if matches():
                                    player.stop()
                                raise OutsideTimeline("Programme is outside the reported timeline")
                        else:
                            player.seekTime(seek_position)
                            target = seek_position
                            seek_from = position
                            deadline = min(deadline, time.monotonic() + 8)
                elif start is not None:
                    position = player.getTime()
                    ready = (not xbmc.getCondVisibility("Player.Seeking")
                             and abs(position - target) <= 3 and abs(position - seek_from) > 3)
            except RuntimeError:
                ready = start is None
            if ready:
                if programme is None and not owned_window:
                    metadata = selection.get("metadata") or {}
                    launch_timeshift_overlay(url, codename, auth.account, metadata.get("logo"),
                                             metadata.get("title", "").partition(" — ")[0] or codename,
                                             banner=True)
                playback = {"player": player, "matches": matches, "fullscreen": fullscreen_seen,
                            "channel": codename, "live": programme is None}
                if owned_window:
                    playback.update(owned_window=True, channel=codename, url=url,
                                    metadata=selection.get("metadata") or {},
                                    live=programme is None)
                return playback
        yield
    if (start is not None or owned_window) and player.isPlayingVideo() and matches():
        player.stop()
    raise TimeoutError("Programme seek did not settle" if target is not None else "Playback did not start")


def restart_from_list(codename, timestamp):
    start_utc = float(timestamp)
    if not math.isfinite(start_utc) or not 0 < start_utc <= time.time():
        raise ValueError("Invalid programme start")
    monitor = xbmc.Monitor()
    page_start = datetime.datetime.fromtimestamp(
        math.floor(start_utc / 1800) * 1800, datetime.timezone.utc)
    events = load_guide_programmes(page_start, (codename,), monitor.abortRequested, None)
    event = next((event for event in events if programme_key(event)
                  and programme_key(event)[2] == start_utc
                  and replay_start(event, time.time(), rewind_observation(codename),
                                   timeshift_denied(codename)) is not None), None)
    if event is None:
        raise LiveDataError("No current restart right for programme")
    title, logo = channel_presentation(codename, event, {}, channelname, static_channel_logo)
    handoff = begin_guide_playback({
        "channel": codename, "start": start_utc, "stop": programme_key(event)[3],
        "metadata": playback_metadata(title, logo, event)
    })
    try:
        for _ in handoff:
            if monitor.waitForAbort(0.1):
                break
    finally:
        handoff.close()
   
if mode is None:
    if addon_handle < 0:
        xbmc.executebuiltin('ActivateWindow(Videos,"{}",return)'.format(base_url))
    else:
        load_live_tv()
        xbmc.executebuiltin('RunPlugin("{}")'.format(build_url({"mode": "guide-start"})))

elif mode[0] in ("livetv", "livetv-recovery", "guide-start"):
    if addon_handle >= 0:
        load_live_tv()
    elif mode[0] != "livetv-recovery":
        run_live_tv_guide(startup=mode[0] == "guide-start")

elif mode[0] == "live-access-settings" and addon_handle < 0:
    addon.openSettings()

elif mode[0] == "about" and addon_handle < 0:
    xbmcgui.Dialog().textviewer(
        addon.getLocalizedString(32005),
        "\n\n".join(addon.getLocalizedString(label) for label in (32006, 32007, 32008, 32009)),
    )

elif mode[0] == "play":
    try:
        codename = args.get("channel", [""])[0]
        if not codename or codename == "false":
            raise ValueError("Missing live channel")
        if start is not None:
            restart_from_list(codename, start[0])
        else:
            play(*acquire_playback(codename), codename)
    except LiveDataCancelled:
        pass
    except AuthError as error:
        xbmc.log("[simpliTVᵀ] " + str(error), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(addon_name, str(error), addon.getAddonInfo("icon"), 5000)
        if addon_handle >= 0:
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    except (ValueError, RuntimeError, TimeoutError) as error:
        text = GUIDE_TEXT[xbmc.getLanguage(xbmc.ISO_639_1) == "de"]
        message = "restart_bounds" if isinstance(error, OutsideTimeline) else "playback_error"
        guide_log("Playback failed: {}".format(type(error).__name__))
        xbmcgui.Dialog().notification(addon_name, text[message], addon_icon, 5000)
        if addon_handle >= 0:
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
elif addon_handle >= 0:
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False, cacheToDisc=False)

