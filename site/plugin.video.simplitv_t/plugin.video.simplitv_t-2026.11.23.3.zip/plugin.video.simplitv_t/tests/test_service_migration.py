"""Offline migration regressions, runnable with doctest or unittest discovery.

>>> test_auth_endpoints_and_override_headers()
>>> test_service_and_tenant_cache_isolation()
>>> test_background_epg_endpoints()
>>> test_channel_branding_requires_matching_catalog_identity()
>>> test_live_tv_root_opens_guide_and_recovery_does_not_redirect()
>>> test_about_settings_action_opens_localized_viewer_only_as_command()
>>> test_live_tv_failure_opens_only_the_recovery_directory()
>>> test_live_tv_handoff_ignores_a_reentrant_launch()
>>> test_guide_start_waits_for_root_and_replaces_it_with_recovery_anchor()
>>> test_back_does_not_reopen_the_guide()
>>> test_guide_starts_live_restart_and_catchup_in_addon_player()
>>> test_owned_stop_returns_to_guide_without_stale_playback()
>>> test_guide_handoff_waits_for_requested_video_not_existing_stream()
>>> test_guide_handoff_passes_metadata_through_acquisition()
>>> test_owned_zap_rechecks_rights_before_windowed_dispatch()
>>> test_zap_restores_guide_channel_without_losing_time_focus()
>>> test_rewind_rechecks_reported_timeline_and_denial()
>>> test_catchup_uses_programme_codename_without_rewind_fallback()
>>> test_guide_acquisition_failure_and_pending_cancel_never_dispatch()
>>> test_guide_return_is_limited_to_the_original_container_and_stream()
>>> test_timeshift_denial_uses_fresh_account_and_channel_data()
>>> test_live_filter_shows_only_positive_grants()
>>> test_live_access_cold_worker_publishes_catalog_grants()
>>> test_live_access_worker_failure_replaces_loading_with_error()
"""

import ast
from contextlib import contextmanager
import datetime
import hashlib
import json
import math
import os
import sys
import tempfile
import threading
import time
import types
import urllib.parse
import uuid

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
try:
    import requests
except ImportError:
    sys.modules["requests"] = types.SimpleNamespace(
        RequestException=type("RequestException", (Exception,), {})
    )
import auth_session
from channel_access import (
    ACCESS_TEXT, CACHE_KEY, CACHE_SECONDS, CHANNEL_TILE_CACHE_KEY,
    BRANDING_KEY, CATCHUP_POLICY_KEY, channel_profile_id, filter_live_channels, playable_only_enabled, load_channel_grants
)
from live_cache import (
    CHANNEL_SECONDS, LiveCache, LiveDataError, broadcast_timestamp, claim_guide_session,
    fetch_programmes
)
from guide import OutsideTimeline
from service_config import (
    API_ROOT, CHANNEL_LOGO_ROOT, FILES_ROOT, PORTAL_ROOT, TENANT_CODENAME
)


class Window:
    def __init__(self):
        self.values = {}

    def getProperty(self, key):
        return self.values.get(key, "")

    def setProperty(self, key, value):
        self.values[key] = value

    def clearProperty(self, key):
        self.values.pop(key, None)


class Response:
    status_code = 200

    def __init__(self, data):
        self.data = data

    def json(self):
        return self.data


class Http:
    RequestException = auth_session.requests.RequestException

    def __init__(self):
        self.calls = []

    def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        route = urllib.parse.urlsplit(url).path
        data = {
            "/v1/OrsUser/Authenticate": {"token": "synthetic-token"},
            "/v1/Devices/GetDevices": {"devices": [{"key": "synthetic-device"}]},
            "/v1/Player/AcquireContent": {"MediaFiles": ["synthetic-media"]},
            "/v1/EpgTile/FilterChannelTiles": {"channels": [{"tiles": [
                {"codename": "synthetic-channel", "id": "chn.43"}]}]},
            "/v1/EpgTile/FilterProgramTiles": {"programs": {"synthetic-channel": [{"id": 1}]}},
            "/v2/Tile/GetTiles": {"tiles": [{
                "start": "2026-11-17T10:00:00Z", "stop": "2026-11-17T11:00:00Z",
                "tileChannel": {"codename": "synthetic-channel"}}]},
        }
        # Any unplanned request, including device registration, fails offline.
        return Response(data[route])

    def get(self, url, **kwargs):
        return self.request("GET", url, **kwargs)

    def post(self, url, **kwargs):
        return self.request("POST", url, **kwargs)


def client(window, http):
    return auth_session.AuthSession(
        "synthetic-user", "synthetic-password", auth_session.API_HEADERS,
        window, lambda message: None, session=http)


@contextmanager
def service(api_root, tenant):
    original = auth_session.API_ROOT, auth_session.TENANT_CODENAME
    auth_session.API_ROOT, auth_session.TENANT_CODENAME = api_root, tenant
    try:
        yield
    finally:
        auth_session.API_ROOT, auth_session.TENANT_CODENAME = original


def assert_requests(calls, paths):
    assert [urllib.parse.urlsplit(url).path for _, url, _ in calls] == paths
    for _, url, options in calls:
        assert url.startswith(API_ROOT + "/")
        assert options["headers"]["X-Tenant-Codename"] == TENANT_CODENAME
        assert options["allow_redirects"] is False
        assert options["timeout"] == 15


def test_auth_endpoints_and_override_headers():
    window, http = Window(), Http()
    session = client(window, http)
    original = {"Accept": "application/json", "X-Tenant-Codename": "wrong-tenant"}
    assert session.acquire("synthetic-channel", original) == {
        "MediaFiles": ["synthetic-media"]}
    assert_requests(http.calls, [
        "/v1/OrsUser/Authenticate", "/v1/Devices/GetDevices", "/v1/Player/AcquireContent"])
    assert original["X-Tenant-Codename"] == "wrong-tenant"
    assert http.calls[-1][2]["headers"]["Accept"] == "application/json"
    assert "X-Api-Camel-Case" not in http.calls[-1][2]["headers"]
    assert http.calls[0][2]["headers"]["Referer"] == PORTAL_ROOT + "/"
    assert http.calls[0][2]["headers"]["X-Api-Camel-Case"] == "true"
    assert client(window, http).devicekey() == "synthetic-device"
    assert len(http.calls) == 3


def test_service_and_tenant_cache_isolation():
    window, http = Window(), Http()
    legacy_key = "simplitv_t.auth.session"
    legacy_account = hashlib.sha256(json.dumps(
        ["synthetic-user", "synthetic-password"]).encode("utf-8")).hexdigest()
    legacy_text = json.dumps({
        "account": legacy_account, "token": "legacy-token",
        "device": "legacy-device", "expires": time.time() + 60})
    window.setProperty(legacy_key, legacy_text)
    legacy_live = LiveCache(window, legacy_account, lambda message: None)
    legacy_live.get("channels", lambda: ["legacy-channel"], 60)
    preserved = dict(window.values)
    current = client(window, http)
    assert current._cache() == {}
    assert current.devicekey() == "synthetic-device"
    current_cache = window.getProperty(current.cache_property)
    current_live = LiveCache(window, current.account, lambda message: None)
    assert current_live.peek("channels", 60) is None
    current_live.get("channels", lambda: ["current-channel"], 60)
    assert legacy_live.peek("channels", 60) == ["legacy-channel"]
    for api_root, tenant in (
            ("https://other.invalid", TENANT_CODENAME), (API_ROOT, "other-tenant")):
        with service(api_root, tenant):
            other = client(window, http)
        assert other.cache_property != current.cache_property
        assert other.account != current.account
        assert other._cache() == {}
        assert LiveCache(window, other.account, lambda message: None).peek("channels", 60) is None
        other.invalidate()
        assert window.getProperty(current.cache_property) == current_cache
    for key, value in preserved.items():
        assert window.getProperty(key) == value
    assert client(window, http)._cache()["device"] == "synthetic-device"


def default_tree():
    with open(os.path.join(ROOT, "default.py"), encoding="utf-8-sig") as source:
        return ast.parse(source.read())


def default_namespace(http):
    namespace = dict(
        API_ROOT=API_ROOT, CHANNEL_LOGO_ROOT=CHANNEL_LOGO_ROOT,
        FILES_ROOT=FILES_ROOT, PORTAL_ROOT=PORTAL_ROOT,
        API_HEADERS=auth_session.API_HEADERS, requests=http, json=json,
        datetime=datetime, time=time, local_timezone=datetime.timezone.utc,
        broadcast_timestamp=broadcast_timestamp,
        channel_profile_id=channel_profile_id,
        token=lambda: "synthetic-token",
        xbmc=types.SimpleNamespace(executebuiltin=lambda command: None),
        xbmcplugin=types.SimpleNamespace(endOfDirectory=lambda handle: None),
        addon_handle=1, addon_icon="icon", LiveDataError=LiveDataError,
        live_cache=types.SimpleNamespace(invalidate=lambda name: None))
    tree = default_tree()
    functions = {"live_json", "load_channel_tiles", "channelname", "logomapper", "static_channel_logo"}
    assignments = {"api_headers", "data_headers", "license_headers"}
    nodes = [node for node in tree.body
             if (isinstance(node, ast.FunctionDef) and node.name in functions)
             or (isinstance(node, ast.Assign)
                 and any(isinstance(target, ast.Name) and target.id in assignments
                         for target in node.targets))]
    exec(compile(ast.Module(body=nodes, type_ignores=[]), "default.py", "exec"), namespace)
    return namespace


def test_background_epg_endpoints():
    http = Http()
    session = client(Window(), http)
    def live_json(method, url, **kwargs):
        return session._json(session._request(method, url[len(API_ROOT):], **kwargs))
    assert len(fetch_programmes(live_json, horizon=60)) == 1
    assert_requests(http.calls, ["/v1/EpgTile/FilterProgramTiles", "/v2/Tile/GetTiles"])


def load_tests(loader, tests, pattern):
    import doctest
    tests.addTests(doctest.DocTestSuite())
    return tests


def test_channel_branding_requires_matching_catalog_identity():
    from channel_access import channel_branding
    from guide import channel_presentation
    lineup = [["one", 1], ["two", 2], ["three", 3], ["four", 4]]
    tiles = [
        {"id": "chn.1", "codename": "one", "title": "Station One", "images": [
            {"role": "icon-on-dark", "url": "https://example.invalid/one.png"}]},
        {"id": "chn.2", "codename": "two", "title": "Station Two", "images": None},
        {"id": "chn.99", "codename": "three", "images": [
            {"role": "icon-on-dark", "url": "https://example.invalid/wrong.png"}]},
        {"id": "chn.4", "codename": "four", "images": [
            {"role": "icon-on-dark", "url": None},
            {"role": "icon", "url": "https://example.invalid/four.png"}]},
    ]
    branding = channel_branding(tiles, lineup)
    static = lambda channel, title: "special://static/" + channel
    assert channel_presentation("one", None, branding, str.title, static) == (
        "Station One", "https://example.invalid/one.png")
    assert channel_presentation("two", {"tileChannel": {
        "codename": "two", "logoUrlOnDark": None, "logoUrl": "special://epg/two.png"}},
        branding, str.title, static) == ("Station Two", "special://epg/two.png")
    assert channel_presentation("three", None, branding, str.title, static) == (
        "Three", "special://static/three")
    assert channel_presentation("four", None, branding, str.title, static) == (
        "Four", "https://example.invalid/four.png")


def live_tv_route(mode, handle, open_guide, access_call=lambda *_: {
        "status": "ready", "profile": [1], "free": []}, channel_tiles=None,
        localized=None):
    from guide import GUIDE_TEXT
    root = default_tree().body[-1]
    events = []

    class Item:
        def __init__(self, label):
            self.label = label
            self.properties = {}

        def setArt(self, art):
            pass

        def setProperty(self, key, value):
            self.properties[key] = value

    def get_channel_tiles():
        if isinstance(channel_tiles, Exception):
            raise channel_tiles
        return channel_tiles if channel_tiles is not None else [["one", 1]]

    namespace = dict(
        mode=mode, addon_handle=handle, build_url=urllib.parse.urlencode,
        base_url="plugin://plugin.video.simplitv_t/",
        xbmcgui=types.SimpleNamespace(
            ListItem=Item, Dialog=lambda: types.SimpleNamespace(
                notification=lambda *args: events.append(("notification", args[1])),
                textviewer=lambda *args: events.append(("textviewer", *args)))),
        xbmcplugin=types.SimpleNamespace(
            addDirectoryItem=lambda *args, **kwargs: events.append((
                "item", args + (kwargs.get("isFolder"),) if args else kwargs)),
            endOfDirectory=lambda *args, **kwargs: events.append(("end", args[0]))),
        xbmc=types.SimpleNamespace(
            LOGERROR=1, LOGWARNING=2, log=lambda *args: None,
            ISO_639_1=0, getLanguage=lambda *_: "en",
            Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False),
            executebuiltin=lambda command: events.append(("command", command))),
        simplitv=types.SimpleNamespace(getAddonInfo=lambda key: "fanart"),
        addon=types.SimpleNamespace(getAddonInfo=lambda key: "asset",
                                    getLocalizedString=(localized or {}).get,
                                    openSettings=lambda: events.append(("settings", ""))),
        addon_icon="icon", addon_name="simpliTV", auth=types.SimpleNamespace(account="test"),
        get_channel_tiles=get_channel_tiles,
        open_guide=open_guide,
        filter_live_channels=filter_live_channels, playable_only_enabled=lambda _: True,
        live_cache=types.SimpleNamespace(peek=lambda key, *args: access_call(key, *args)
                                         if key == CACHE_KEY else {}),
        CACHE_KEY=CACHE_KEY, CACHE_SECONDS=CACHE_SECONDS, BRANDING_KEY=BRANDING_KEY,
        CATCHUP_POLICY_KEY=CATCHUP_POLICY_KEY, catchup_eligible=lambda *_: False,
        peek_catchup_state=lambda: (None, None),
        CHANNEL_SECONDS=CHANNEL_SECONDS,
        ACCESS_TEXT=ACCESS_TEXT, GUIDE_TEXT=GUIDE_TEXT, time=time,
        LiveDataError=LiveDataError, AuthError=auth_session.AuthError,
        start_preparation=lambda **_: events.append(("prepare", "access")),
        guide_container=lambda: (10025, "plugin://plugin.video.simplitv_t/"),
        urllib=urllib,
        begin_guide_playback=None,
        rewind_observation=None, confirm_guide_restart=None, timeshift_denied=lambda _: False,
        peek_guide_programmes=None, load_guide_programmes=None, channelname=str,
        static_channel_logo=lambda *_: "icon",
        local_timezone=datetime.timezone.utc, traceback=types.SimpleNamespace(format_exc=str),
    )
    nodes = [node for node in default_tree().body if isinstance(node, ast.FunctionDef)
             and node.name in ("show_live_tv_guide", "load_live_tv", "add_recovery_controls")]
    namespace["run_live_tv_guide"] = lambda **kwargs: namespace["load_live_tv"]()
    from tv_behavior import StationHistory
    namespace["StationHistory"] = StationHistory
    exec(compile(ast.Module(body=nodes + [root], type_ignores=[]), "default.py", "exec"), namespace)
    return events


def test_about_settings_action_opens_localized_viewer_only_as_command():
    import xml.etree.ElementTree as ET

    root = ET.parse(os.path.join(ROOT, "resources", "settings.xml")).getroot()
    about = root.findall("category")[-1]
    assert about.get("label") == "32005"
    actions = about.findall("setting[@type='action']")
    assert actions
    labels = {
        32005: "Über", 32006: "simpliTVᵀ von Tom",
        32007: "Basiert auf simpliTV von Publish3r und sunsettrack4",
        32008: "Lizenz: GNU GPL v3 oder neuer", 32009: "Inoffizielles Add-on",
    }
    for action in actions:
        command = action.attrib["action"].replace("$ID", "plugin.video.simplitv_t")
        assert command.startswith("RunPlugin(") and command.endswith(")")
        mode = urllib.parse.parse_qs(urllib.parse.urlparse(command[10:-1]).query)["mode"]
        assert live_tv_route(mode, -1, None, localized=labels) == [
            ("textviewer", labels[32005], "\n\n".join(labels[i] for i in range(32006, 32010)))]
        assert live_tv_route(mode, 1, None, localized=labels) == [("end", 1)]


def test_live_tv_root_opens_guide_and_recovery_does_not_redirect():
    root = live_tv_route(None, 1, None)
    assert_recovery_items(root)
    assert root[-2:] == [("end", 1), ("command", 'RunPlugin("mode=guide-start")')]
    for mode in ("livetv", "livetv-recovery", "guide-start"):
        for lineup in ([["one", 1], ["two", 2]], []):
            directory = live_tv_route([mode], 1, None, channel_tiles=lineup)
            assert_recovery_items(directory, "Live TV settings" if lineup else
                                  "No channels confirmed playable — Live TV settings")
            assert directory[-1] == ("end", 1)
            assert not any(event[0] == "command" for event in directory)
    for mode in ("livetv-recovery", "menu", "epg", "aufnahmen", "add", "delete"):
        directory = live_tv_route([mode], 1, None)
        assert directory[-1] == ("end", 1)
        assert not any(event[0] == "command" for event in directory)
    command = live_tv_route(None, -1, None)
    assert command == [("command", 'ActivateWindow(Videos,"plugin://plugin.video.simplitv_t/",return)')]
    command = live_tv_route(["menu"], -1, None)
    assert command == []

    opened = []
    assert live_tv_route(["livetv"], -1, lambda channels, *_: opened.extend(channels)) == []
    assert opened == ["one"]


def assert_recovery_items(events, settings_label="Live TV settings"):
    items = [event[1] for event in events if event[0] == "item"]
    assert [(item[1], item[2].label, item[3]) for item in items] == [
        ("mode=livetv", "Programme Guide", False),
        ("mode=live-access-settings", settings_label, False),
    ]
    assert all(item[2].properties["IsPlayable"] == "false" for item in items)


def test_live_tv_failure_opens_only_the_recovery_directory():
    def broken(*args):
        raise RuntimeError("synthetic render failure")

    result = live_tv_route(["livetv"], -1, broken)
    assert result[0][0] == "notification"
    assert result[1:] == [("command", 'Container.Update("mode=livetv-recovery")')]
    assert_recovery_items(live_tv_route(["livetv-recovery"], 2, broken))
    pending = live_tv_route(["livetv-recovery"], 2, broken, lambda *_: None)
    assert pending[0] == ("prepare", "access")
    assert_recovery_items(pending, "Checking channel access… — Live TV settings")
    unavailable = live_tv_route(["livetv-recovery"], 2, broken,
                                channel_tiles=LiveDataError("Synthetic catalogue failure"))
    assert_recovery_items(unavailable, "Channel access could not be checked — Live TV settings")
    assert unavailable[-1] == ("end", 2)
    opened = []
    failed = live_tv_route(
        ["livetv"], -1, lambda channels, *args: opened.append((channels, args[10])),
        channel_tiles=LiveDataError("Synthetic catalogue failure"))
    assert failed == [("notification", "Synthetic catalogue failure")]
    assert opened == [([], "error")]


def test_live_tv_handoff_ignores_a_reentrant_launch():
    names = {"run_live_tv_guide", "show_live_tv_guide"}
    nodes = [node for node in default_tree().body
             if isinstance(node, ast.FunctionDef) and node.name in names]
    transitions = []
    playing = False

    def open_guide(channels, *args):
        nonlocal playing
        transitions.append((channels, playing))
        if channels == ["one"]:
            playing = True
            namespace["run_live_tv_guide"]()

    with tempfile.TemporaryDirectory() as folder:
        namespace = dict(
            os=os, time=time, guide_lock_path=os.path.join(folder, "guide.lock"),
            crt_noise=types.SimpleNamespace(start_preparation=lambda *_: None),
            guide_container=lambda: (10025, "plugin://plugin.video.simplitv_t/"),
            urllib=urllib,
            claim_guide_session=claim_guide_session, open_guide=open_guide,
            peek_guide_programmes=None, load_guide_programmes=None, channelname=str,
            static_channel_logo=lambda *_: None,
            begin_guide_playback=None,
            rewind_observation=None, confirm_guide_restart=None, timeshift_denied=lambda _: False,
            catchup_eligible=lambda *_: False, peek_catchup_state=lambda: (None, None),
            addon=types.SimpleNamespace(getAddonInfo=lambda _: "test", openSettings=lambda: None),
            auth=types.SimpleNamespace(account="test"), local_timezone=datetime.timezone.utc,
            LiveDataError=LiveDataError,
            xbmc=types.SimpleNamespace(
                Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False)),
        )
        current_channels = ["one"]
        namespace["load_live_tv"] = lambda: namespace["show_live_tv_guide"](current_channels)
        from tv_behavior import StationHistory
        namespace["StationHistory"] = StationHistory
        exec(compile(ast.Module(body=nodes, type_ignores=[]), "default.py", "exec"), namespace)
        namespace["run_live_tv_guide"]()
        current_channels = ["while-playing"]
        namespace["run_live_tv_guide"]()
        playing = False
        current_channels = ["after-stop"]
        namespace["run_live_tv_guide"]()
    assert transitions == [
        (["one"], False), (["while-playing"], True), (["after-stop"], False),
    ], transitions


def test_guide_start_waits_for_root_and_replaces_it_with_recovery_anchor():
    root = "plugin://plugin.video.simplitv_t/"
    anchor = root + "?mode=livetv-recovery"
    commands = []
    folders = iter(["plugin://elsewhere/", root, root, anchor])
    node = next(node for node in default_tree().body
                if isinstance(node, ast.FunctionDef) and node.name == "prepare_guide_anchor")
    namespace = dict(
        base_url=root, time=time,
        guide_container=lambda: (10025, next(folders)),
        guide_log=lambda message: commands.append(("log", message)),
        build_url=lambda query: root + "?" + urllib.parse.urlencode(query),
        xbmcgui=types.SimpleNamespace(getCurrentWindowDialogId=lambda: 0),
        xbmc=types.SimpleNamespace(
            Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False,
                                                  waitForAbort=lambda _: commands.append("wait")),
            executebuiltin=commands.append))
    from tv_behavior import StationHistory
    namespace["StationHistory"] = StationHistory
    exec(compile(ast.Module(body=[node], type_ignores=[]), "default.py", "exec"), namespace)
    assert namespace["prepare_guide_anchor"]() is True
    assert commands == ["wait", 'Container.Update("{}",replace)'.format(anchor), "wait"]


def test_back_does_not_reopen_the_guide():
    from guide import GUIDE_TEXT
    import xml.etree.ElementTree as ET
    setting = ET.parse(os.path.join(ROOT, "resources", "settings.xml")).find(
        ".//setting[@id='start_screen']")
    assert setting is None
    anchor = "plugin://test/?mode=livetv-recovery"
    node = next(node for node in default_tree().body
                if isinstance(node, ast.FunctionDef) and node.name == "show_live_tv_guide")
    for result in (None, {"fullscreen": True}):
        events = []
        namespace = dict(
            urllib=urllib, GUIDE_TEXT=GUIDE_TEXT, local_timezone=datetime.timezone.utc,
            guide_container=lambda: (10025, anchor),
            addon=types.SimpleNamespace(getAddonInfo=lambda key: "test", openSettings=lambda: None,
                                        getSetting=lambda _: "false"),
            auth=types.SimpleNamespace(account="test"),
            open_guide=lambda *args: events.append("guide") or result,
            peek_guide_programmes=None, load_guide_programmes=None, channelname=str,
            static_channel_logo=lambda *_: None, begin_guide_playback=None, rewind_observation=None,
            confirm_guide_restart=None, timeshift_denied=lambda _: False, catchup_eligible=lambda *_: False,
            peek_catchup_state=lambda: (None, None),
            wait_for_guide_return=lambda *args: events.append("playback-return") or False,
            build_url=lambda query: anchor,
            xbmc=types.SimpleNamespace(
                Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: False),
                executebuiltin=events.append))
        exec(compile(ast.Module(body=[node], type_ignores=[]), "default.py", "exec"), namespace)
        from tv_behavior import StationHistory
        namespace["StationHistory"] = StationHistory
        namespace["show_live_tv_guide"](["one"])
        assert events == (["guide", "playback-return"] if result and "fullscreen" in result
                          else ["guide"]), events


def test_owned_stop_returns_to_guide_without_stale_playback():
    for status in ("stopped", "fullscreen"):
        check_owned_return_selects_current_channel(status)
    check_owned_return_selects_current_channel("stopped", abort_on_return=True)


def test_guide_starts_live_restart_and_catchup_in_addon_player():
    node = next(node for node in default_tree().body
                if isinstance(node, ast.FunctionDef) and node.name == "show_live_tv_guide")
    from tv_behavior import StationHistory
    selections = [{"channel": "one"}, {"channel": "one", "start": 42},
                  {"channel": "one", "catchup": {"codename": "programme"}}]
    started = []

    def begin(selection, **options):
        started.append((selection, options["owned_window"]))
        yield
        return {"owned_window": True}

    def guide(*args):
        for selection in selections:
            list(args[9](selection))
        return None

    ns = dict(urllib=urllib, guide_container=lambda: (10025, "plugin://test/"),
              StationHistory=StationHistory, input_trace=lambda *_a, **_kw: None,
              addon=types.SimpleNamespace(getAddonInfo=lambda _: "test"),
              xbmc=types.SimpleNamespace(Monitor=lambda: types.SimpleNamespace(
                  abortRequested=lambda: False)), open_guide=guide,
              begin_guide_playback=begin, auth=types.SimpleNamespace(account="test"))
    ns.update(dict.fromkeys(("peek_guide_programmes", "load_guide_programmes", "channelname",
                            "local_timezone", "static_channel_logo", "rewind_observation",
                            "confirm_guide_restart", "timeshift_denied", "catchup_eligible",
                            "peek_catchup_state")))
    exec(compile(ast.Module(body=[node], type_ignores=[]), "default.py", "exec"), ns)
    ns["show_live_tv_guide"](["one"])
    assert started == [(selection, True) for selection in selections]


def check_owned_return_selects_current_channel(status, abort_on_return=False):
    anchor = "plugin://test/?mode=livetv-recovery"
    node = next(node for node in default_tree().body
                if isinstance(node, ast.FunctionDef) and node.name == "show_live_tv_guide")
    zapped = {"owned_window": True, "channel": "two", "live": True, "url": "u"}
    playback = {"owned_window": True, "channel": "one"}
    seen = []
    aborted = False

    def open_player(*args):
        nonlocal aborted
        aborted = abort_on_return
        return status, zapped

    def open_guide(*args):
        seen.append(("guide", args[14] and args[14]["channel"]))
        return playback if len(seen) == 1 else None

    def wait(origin, current, monitor):
        seen.append(("wait", current["channel"]))
        return True

    namespace = dict(
        urllib=urllib, local_timezone=datetime.timezone.utc,
        guide_container=lambda: (10025, anchor),
        addon=types.SimpleNamespace(getAddonInfo=lambda _: "test", openSettings=lambda: None,
                                    getSetting=lambda _: "true"),
        auth=types.SimpleNamespace(account="test"),
        open_guide=open_guide,
        peek_guide_programmes=None, load_guide_programmes=None, channelname=str,
        static_channel_logo=lambda *_: None, begin_guide_playback=None, rewind_observation=None,
        confirm_guide_restart=None, timeshift_denied=lambda _: False, catchup_eligible=lambda *_: False,
        peek_catchup_state=lambda: (None, None), guide_log=lambda _: None,
        open_player_window=open_player,
        launch_timeshift_overlay=lambda *_: None, wait_for_guide_return=wait,
        remember_guide_channel=lambda channel: seen.append(("channel", channel)),
        guide_lock_path="guide.lock",
        live_cache=types.SimpleNamespace(cached_schedules=lambda: ()),
        xbmc=types.SimpleNamespace(Monitor=lambda: types.SimpleNamespace(abortRequested=lambda: aborted)))
    from tv_behavior import StationHistory
    namespace["StationHistory"] = StationHistory
    exec(compile(ast.Module(body=[node], type_ignores=[]), "default.py", "exec"), namespace)
    namespace["show_live_tv_guide"](["one", "two"])
    expected = ([("guide", None), ("channel", "two"), ("guide", None)] if status == "stopped"
                else [("guide", None), ("wait", "two"), ("channel", "two"), ("guide", "two")])
    if abort_on_return:
        expected = [("guide", None)]
    assert seen == expected, (status, seen)


def guide_playback_handler(acquire):
    events = []
    players = []
    workers = []
    clock = types.SimpleNamespace(monotonic=lambda: 0, time=lambda: 1700000000)

    class Player:
        playing_id = "previous-request"
        position = 1
        duration = 0

        def __init__(self):
            players.append(self)

        def isPlayingVideo(self):
            return True

        def getPlayingItem(self):
            return types.SimpleNamespace(getProperty=lambda _: self.playing_id)

        def getTime(self):
            return self.position

        def getTotalTime(self):
            return self.duration

        def seekTime(self, seconds):
            events.append(("seek", seconds))

        def stop(self):
            events.append("stop")

    def play(url, license_server, challenge, codename, guide_player, metadata=None):
        events.append(("play", codename))
        return url

    def start_worker(target, daemon):
        return types.SimpleNamespace(start=lambda: workers.append(target))

    nodes = [node for node in default_tree().body if isinstance(node, ast.FunctionDef)
             and node.name == "begin_guide_playback"]
    namespace = dict(
        threading=types.SimpleNamespace(Event=threading.Event, Thread=start_worker),
        math=math, FULLSCREEN_VIDEO_WINDOW=12005,
        uuid=uuid, GUIDE_PLAYBACK_PROPERTY="test",
        OutsideTimeline=OutsideTimeline, remember_rewind=lambda *_: None,
        MAX_REWIND_SECONDS=48 * 3600,
        timeshift_denied=lambda _: False,
        time=clock, xbmc=types.SimpleNamespace(Player=Player, getCondVisibility=lambda _: False),
        xbmcgui=types.SimpleNamespace(getCurrentWindowId=lambda: 12005), play=play,
        acquire_playback=acquire, launch_timeshift_overlay=lambda *_, **kw: events.append("overlay"),
        auth=types.SimpleNamespace(account="test"))
    exec(compile(ast.Module(body=nodes, type_ignores=[]), "default.py", "exec"), namespace)
    return namespace["begin_guide_playback"], events, players, workers, clock


def test_guide_handoff_waits_for_requested_video_not_existing_stream():
    url = "https://example.invalid/new.mpd"
    begin, events, players, workers, _ = guide_playback_handler(
        lambda _: (url, "false", "false"))
    handoff = begin({"channel": "one", "start": 1700000000 - 4 * 3600,
                     "stop": 1700000000 - 3 * 3600})
    assert next(handoff) is None and events == []
    workers.pop()()
    assert next(handoff) is None and events == [("play", "one")]
    player = players[0]
    player.onAVStarted()  # Unrelated callback while the old video still plays.
    assert next(handoff) is None and events == [("play", "one")]
    player.playing_id = player.request_id
    player.onAVStarted()
    assert next(handoff) is None and events == [("play", "one")]
    player.duration = 18000
    player.position = 17960
    assert next(handoff) is None and events == [("play", "one")]
    player.position = 17976
    assert next(handoff) is None and events == [("play", "one"), ("seek", 3576)]
    assert next(handoff) is None and len(events) == 2  # Seek not yet applied.
    player.position = 3576
    try:
        next(handoff)
    except StopIteration as finished:
        assert finished.value["player"] is player and finished.value["fullscreen"]
    else:
        raise AssertionError("Playback handoff did not complete")
    assert events == [("play", "one"), ("seek", 3576), "overlay"]


def test_guide_handoff_passes_metadata_through_acquisition():
    url = "https://example.invalid/new.mpd"
    begin, _, players, workers, _ = guide_playback_handler(
        lambda _: (url, "false", "false"))
    metadata = {"title": "Station — Programme", "plot": "Description", "logo": "logo.png"}
    received = []

    def play(media_url, license_server, challenge, codename, guide_player, metadata=None):
        received.append(metadata)
        return media_url

    begin.__globals__["play"] = play
    handoff = begin({"channel": "one", "metadata": metadata})
    assert next(handoff) is None
    workers.pop()()
    assert next(handoff) is None
    assert received == [metadata]
    players[0].playing_id = players[0].request_id
    players[0].onAVStarted()
    try:
        next(handoff)
    except StopIteration:
        pass
    else:
        raise AssertionError("Playback handoff did not complete")


def test_owned_zap_rechecks_rights_before_windowed_dispatch():
    url = "https://example.invalid/new.mpd"
    begin, events, players, workers, _ = guide_playback_handler(
        lambda _: (url, "false", "false"))
    begin.__globals__["LiveDataError"] = LiveDataError
    grants = {"one"}
    calls = []

    def play(media_url, license_server, challenge, codename, guide_player, metadata, windowed):
        calls.append((codename, windowed))
        return media_url

    begin.__globals__["play"] = play
    handoff = begin({"channel": "one"}, owned_window=True,
                    allowed=lambda code: code in grants, on_dispatch=lambda: calls.append("dispatched"))
    next(handoff)
    workers.pop()()
    grants.clear()
    try:
        next(handoff)
    except LiveDataError:
        pass
    else:
        raise AssertionError("Expired channel grant must prevent playback")
    assert not calls and not players and not events

    grants.add("one")
    handoff = begin({"channel": "one"}, owned_window=True,
                    allowed=lambda code: code in grants, on_dispatch=lambda: calls.append("dispatched"))
    next(handoff)
    workers.pop()()
    next(handoff)
    assert calls == [("one", True), "dispatched"]
    players[0].playing_id = players[0].request_id
    players[0].onAVStarted()
    try:
        next(handoff)
    except StopIteration as finished:
        assert finished.value["owned_window"] and finished.value["channel"] == "one"
    else:
        raise AssertionError("Windowed playback handoff did not complete")
    assert "overlay" not in events


def test_zap_restores_guide_channel_without_losing_time_focus():
    window = Window()
    key = "simplitv_t.guide.selection.test"
    window.setProperty(key, json.dumps({"channel": "one", "view": 100, "anchor": 150,
                                       "programme_id": "old", "programme_start": 120}))
    node = next(node for node in default_tree().body
                if isinstance(node, ast.FunctionDef) and node.name == "remember_guide_channel")
    namespace = dict(xbmcgui=types.SimpleNamespace(Window=lambda _: window),
                     auth=types.SimpleNamespace(account="test"), json=json)
    exec(compile(ast.Module(body=[node], type_ignores=[]), "default.py", "exec"), namespace)
    namespace["remember_guide_channel"]("two")
    assert json.loads(window.getProperty(key)) == {
        "channel": "two", "view": 100, "anchor": 150,
        "programme_id": "", "programme_start": None}


def test_rewind_rechecks_reported_timeline_and_denial():
    url = "https://example.invalid/new.mpd"
    begin, events, players, workers, clock = guide_playback_handler(
        lambda _: (url, "false", "false"))
    begin.__globals__["timeshift_denied"] = lambda _: True
    handoff = begin({"channel": "one", "start": 1699999000, "stop": 1699999900})
    try:
        next(handoff)
    except OutsideTimeline:
        pass
    else:
        raise AssertionError("Denied timeshift must not acquire playback")
    assert not workers and not events
    begin.__globals__["timeshift_denied"] = lambda _: False
    handoff = begin({"channel": "one", "start": 1699999000, "stop": 1699999900})
    next(handoff)
    workers.pop()()
    next(handoff)
    player = players[-1]
    player.playing_id = player.request_id
    player.onAVStarted()
    player.duration = player.position = 600
    next(handoff)
    assert events[-1] == ("seek", 1)
    player.position = 1
    try:
        next(handoff)
    except StopIteration:
        pass
    else:
        raise AssertionError("The partial seek did not settle")

    handoff = begin({"channel": "one", "start": 1699998000, "stop": 1699999399})
    next(handoff)
    workers.pop()()
    next(handoff)
    player = players[-1]
    player.playing_id = player.request_id
    player.onAVStarted()
    player.duration = player.position = 600
    next(handoff)
    assert events[-1] == ("seek", 1)
    player.position = 1
    try:
        next(handoff)
    except StopIteration:
        pass
    else:
        raise AssertionError("The earliest available seek did not settle")

    handoff = begin({"channel": "one", "start": 1699998000, "stop": 1699999399})
    next(handoff)
    workers.pop()()
    next(handoff)
    player = players[-1]
    player.playing_id = player.request_id
    player.onAVStarted()
    player.duration = player.position = 3
    before = len(events)
    try:
        next(handoff)
    except StopIteration:
        pass
    else:
        raise AssertionError("A tiny fresh timeline should keep playing")
    assert events[before:] == ["overlay"]

    handoff = begin({"channel": "one", "start": 1699999900, "stop": 1700000100})
    next(handoff)
    workers.pop()()
    next(handoff)
    player = players[-1]
    player.playing_id = player.request_id
    player.onAVStarted()
    player.duration = player.position = 600
    next(handoff)
    assert events[-1] == ("seek", 500)
    clock.monotonic = lambda: 10
    try:
        next(handoff)
    except TimeoutError:
        pass
    else:
        raise AssertionError("An unsettled seek must not hand off")
    assert events[-1] == "stop"


def test_catchup_uses_programme_codename_without_rewind_fallback():
    calls = []

    def acquire(code, catchup=False):
        calls.append((code, catchup))
        raise auth_session.AuthError("Provider denied")

    begin, events, players, workers, _ = guide_playback_handler(acquire)
    begin.__globals__.update(confirm_guide_catchup=lambda *_: True, LiveDataError=LiveDataError)
    event = {"codename": "programme.1"}
    handoff = begin({"channel": "channel.1", "catchup": event, "request": ("page",)})
    next(handoff)
    workers.pop()()
    try:
        next(handoff)
    except auth_session.AuthError:
        pass
    else:
        raise AssertionError("Provider denial must propagate")
    assert calls == [("programme.1", True)] and not events and not players

    begin.__globals__["confirm_guide_catchup"] = lambda *_: False
    handoff = begin({"channel": "channel.1", "catchup": event, "request": ("page",)})
    next(handoff)
    workers.pop()()
    try:
        next(handoff)
    except LiveDataError:
        pass
    else:
        raise AssertionError("Expired permissions must not acquire playback")
    assert calls == [("programme.1", True)] and not events


def test_guide_return_is_limited_to_the_original_container_and_stream():
    origin = (10025, "plugin://plugin.video.simplitv_t/")
    fullscreen = (12005, "")
    elsewhere = (10025, origin[1] + "?mode=aufnahmen")
    node = next(node for node in default_tree().body
                if isinstance(node, ast.FunctionDef) and node.name == "wait_for_guide_return")
    for steps, seen, top_dialog, wanted in (
            ([(fullscreen, True, True), (origin, True, True)], False, 9999, True),
            ([(fullscreen, False, False), (origin, False, False)], True, 9999, True),
            ([(origin, False, False)], True, 9999, True),
            ([(fullscreen, True, False), (origin, True, True)], True, 9999, False),
            ([(fullscreen, True, True), (elsewhere, True, True)], True, 9999, False),
            ([(origin, True, True)], True, 12000, False),
            ([(origin, True, True)], False, 9999, False)):
        step = 0
        clock = 0

        def sleep(_):
            nonlocal step, clock
            step = min(step + 1, len(steps) - 1)
            clock += 1

        namespace = dict(
            FULLSCREEN_VIDEO_WINDOW=12005, time=types.SimpleNamespace(monotonic=lambda: clock),
            guide_container=lambda: steps[step][0],
            xbmcgui=types.SimpleNamespace(getCurrentWindowDialogId=lambda: top_dialog))
        exec(compile(ast.Module(body=[node], type_ignores=[]), "default.py", "exec"), namespace)
        playback = dict(fullscreen=seen, matches=lambda: steps[step][2],
                        player=types.SimpleNamespace(isPlayingVideo=lambda: steps[step][1]))
        monitor = types.SimpleNamespace(abortRequested=lambda: False, waitForAbort=sleep)
        assert namespace[node.name](origin, playback, monitor) is wanted, steps


def test_timeshift_denial_uses_fresh_account_and_channel_data():
    node = next(node for node in default_tree().body
                if isinstance(node, ast.FunctionDef) and node.name == "timeshift_denied")
    lineup = [["one", 1], ["two", 2]]
    access = {"status": "ready", "account_timeshift_denied": False, "timeshift_denied": [2]}
    namespace = dict(
        CHANNEL_TILE_CACHE_KEY=CHANNEL_TILE_CACHE_KEY, CHANNEL_SECONDS=CHANNEL_SECONDS,
        CACHE_KEY=CACHE_KEY, CACHE_SECONDS=CACHE_SECONDS,
        live_cache=types.SimpleNamespace(peek=lambda name, *_: lineup if name == CHANNEL_TILE_CACHE_KEY else access))
    exec(compile(ast.Module(body=[node], type_ignores=[]), "default.py", "exec"), namespace)
    denied = namespace[node.name]
    assert not denied("one") and denied("two") and not denied("missing")
    access["account_timeshift_denied"] = True
    assert denied("one")
    access.update(status="error", account_timeshift_denied=False, timeshift_denied=[])
    assert denied("one")


def test_live_filter_shows_only_positive_grants():
    switches = [types.SimpleNamespace(getSetting=lambda _, value=value: value)
                for value in ("", "true", "false")]
    assert [playable_only_enabled(addon) for addon in switches] == [True, True, False]
    profile = {"timeshiftEnabled": False, "availableChannels": [
        {"id": 1, "canPlay": False, "timeshiftEnabled": False}, {"id": 2, "canPlay": False},
        {"id": 3, "canPlay": False}, {"id": 4, "canPlay": True},
        {"id": 5, "canPlay": 0}, {"id": 6, "canPlay": False}, {"id": 6, "canPlay": True},
        {"id": 7, "canPlay": False}, {"id": 9}, {"id": 10, "canPlay": "false"},
    ]}
    calls = []

    def request(method, path, **kwargs):
        calls.append((method, path))
        if method == "GET":
            assert kwargs["params"] == {
                "platformCodename": "www", "token": "synthetic-token"}
            return profile
        payload = json.loads(kwargs["data"])
        assert payload["platformCodename"] == "www"
        assert payload["isParentalControlEnabled"] == "false"
        assert "token" not in payload
        assert payload["requestedTiles"] == [
            {"id": "chn.{}".format(i)} for i in (1, 2, 3, 5, 6, 7, 8, 9, 10)]
        return {"tiles": [
            {"id": "chn.1", "codename": "paid", "purchaseOptions": {"freeAccessType": 0, "products": [{}]}},
            {"id": "chn.2", "codename": "free", "purchaseOptions": {"freeAccessType": 1, "products": []}},
            {"id": "chn.3", "codename": "unknown", "purchaseOptions": []},
            {"id": "prg.3", "codename": "unknown", "purchaseOptions": {"freeAccessType": 0, "products": [{}]}},
            {"id": "chn.7", "codename": "different", "purchaseOptions": {"freeAccessType": 0, "products": [{}]}},
            {"id": "chn.8", "codename": "not-in-profile", "purchaseOptions": {"freeAccessType": 1, "products": []}},
            {"id": "chn.9", "codename": "different-code", "purchaseOptions": {"freeAccessType": 1, "products": []}},
        ]}

    session = types.SimpleNamespace(_request=request, _json=lambda payload: payload)
    tiles = [[code, channel_profile_id("chn.{}".format(key))] for key, code in enumerate(
        ("paid", "free", "unknown", "allowed", "numeric", "conflict", "same-id", "not-in-profile", "no-flag", "string"), 1)]
    for malformed in (1, True, "1", "prg.1", "chn.01", "chn.-1", "chn.1.extra",
                      "chn.\u0661", "chn.2147483648"):
        assert channel_profile_id(malformed) is None
    access = load_channel_grants(session, "synthetic-token", tiles)
    assert access["account_timeshift_denied"] is True and access["timeshift_denied"] == [1]
    assert filter_live_channels(tiles, access, True) == (["free", "allowed", "not-in-profile"], "partial")
    assert filter_live_channels(tiles, access, False) == ([tile[0] for tile in tiles], "")
    assert filter_live_channels(tiles, None, True) == ([], "loading")
    for status, expected in (("ready", "empty"), ("error", "error")):
        assert filter_live_channels(tiles, {"status": status, "profile": [], "free": []}, True) == ([], expected)
    assert len(calls) == 2
    profile["availableChannels"] = [{"id": 1, "canPlay": True}]
    profile["timeshiftEnabled"] = True
    calls.clear()
    assert load_channel_grants(session, "synthetic-token", [tiles[0]]) == {
        "status": "ready", "profile": [1], "free": [], "branding": {},
        "timeshift_denied": [], "account_timeshift_denied": False,
        "account_catchup_enabled": False, "catchup_agreement_missing": None,
        "catchup_channels": {"chn.1": {"canPlay": True}}}
    assert calls == [("GET", "/v1/OrsUser/GetProfile")]
    profile["timeshiftAgreementMissing"] = True
    assert load_channel_grants(session, "synthetic-token", [tiles[0]])["account_timeshift_denied"]


@contextmanager
def live_access_worker(request, lineup):
    window, messages, commands = Window(), [], []
    with tempfile.TemporaryDirectory() as folder:
        session = auth_session.AuthSession(
            "synthetic-user", "synthetic-password", auth_session.API_HEADERS,
            window, messages.append,
            session=types.SimpleNamespace(request=request, close=lambda: None),
            lock_path=os.path.join(folder, "auth.lock"))
        cache = LiveCache(window, session.account, messages.append)
        cache.get(CHANNEL_TILE_CACHE_KEY, lambda: lineup, CHANNEL_SECONDS)
        previous = {name: sys.modules.get(name) for name in ("xbmc", "xbmcaddon", "xbmcgui")}
        original_session = auth_session.kodi_session
        sys.modules.update(
            xbmc=types.SimpleNamespace(executebuiltin=commands.append),
            xbmcaddon=types.SimpleNamespace(Addon=lambda *_: types.SimpleNamespace(
                getSetting=lambda _: "true", getAddonInfo=lambda _: ROOT)),
            xbmcgui=types.SimpleNamespace())
        auth_session.kodi_session = lambda: session
        try:
            yield session, cache, messages, commands
        finally:
            auth_session.kodi_session = original_session
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module


def test_live_access_cold_worker_publishes_catalog_grants():
    ids = list(range(101, 145))
    lineup = [["station-{}".format(key), channel_profile_id("chn.{}".format(key))]
              for key in ids + [201, 202, 203]]
    expected = [code for code, _ in lineup[:44]] + ["station-202"]
    calls = []
    batches = []

    def request(method, url, **kwargs):
        calls.append((method, url))
        assert kwargs["headers"] == auth_session.API_HEADERS
        if url.endswith("/SystemBootstrap"):
            result = {"result": {"success": True},
                      "settings": {"Video.Pvr.General.AreCatchupsAvailableImmediatelyAfterBroadcast": False,
                                   "Video.Pvr.General.NpvrPublicationDelaySeconds": 5,
                                   "Video.Pvr.General.StopTimeMinutesMargin": 5}}
        elif url.endswith("/Authenticate"):
            result = {"token": "prepared-token"}
        elif url.endswith("/GetProfile"):
            assert method == "GET"
            assert kwargs["params"] == {"platformCodename": "www", "token": "prepared-token"}
            result = {"availableChannels": [
                {"id": key, "canPlay": True} for key in ids
            ] + [{"id": 201, "canPlay": False}, {"id": 202, "canPlay": False}]}
        else:
            assert method == "POST" and url.endswith("/GetTiles")
            payload = json.loads(kwargs["data"])
            keys = [int(entry["id"].split(".")[1]) for entry in payload["requestedTiles"]]
            batches.append(keys)
            assert payload == {
                "platformCodename": "www", "isParentalControlEnabled": "false",
                "requestedTiles": [{"id": "chn.{}".format(key)} for key in keys]}
            result = {"tiles": [
                {"id": "chn.{}".format(key), "codename": "station-{}".format(key),
                 "title": "Station {}".format(key), "images": [
                     {"role": "icon", "url": "https://example.invalid/icon.png"},
                     {"role": "icon-on-dark", "url": "https://example.invalid/dark.png"},
                 ],
                 "purchaseOptions": {"freeAccessType": int(key == 202),
                                     "products": [] if key == 202 else [{}]}}
                for key in keys]}
        return types.SimpleNamespace(status_code=200, json=lambda: result)

    with live_access_worker(request, lineup) as (session, cache, messages, commands):
        assert not session._cache()
        assert filter_live_channels(
            lineup, cache.peek(CACHE_KEY, CACHE_SECONDS, lineup), True) == ([], "loading")
        auth_session.start_preparation(live_access=True)
        assert commands == ['RunScript("{}",live-access)'.format(os.path.join(ROOT, "auth_session.py"))]
        auth_session.prepare(live_access=True)
        foreground = LiveCache(session.window, session.account, messages.append)
        access = foreground.peek(CACHE_KEY, CACHE_SECONDS, lineup)
        assert access is not None
        assert filter_live_channels(lineup, access, True) == (expected, "")
        assert batches == [[201, 202, 203], ids, ids + [201, 202, 203]]
        assert len(calls) == 6
        branding = foreground.peek(BRANDING_KEY, CHANNEL_SECONDS, lineup)
        assert branding["station-101"] == ["Station 101", "https://example.invalid/dark.png"]
        assert branding["station-202"] == ["Station 202", "https://example.invalid/dark.png"]
        auth_session.prepare(live_access=True)
        assert len(calls) == 6
        foreground.invalidate(CACHE_KEY)

        def guide_refresh(channels, *args):
            assert channels == [] and args[10] == "loading"
            auth_session.prepare(live_access=True)
            assert args[9]() == (expected, "")

        assert live_tv_route(
            ["livetv"], -1, guide_refresh, foreground.peek, lineup) == [("prepare", "access")]


def test_live_access_worker_failure_replaces_loading_with_error():
    lineup = [["not-confirmed", 201]]
    for authenticate_ok in (False, True):
        def request(method, url, **kwargs):
            if authenticate_ok and url.endswith("/Authenticate"):
                return types.SimpleNamespace(status_code=200, json=lambda: {"token": "prepared-token"})
            return types.SimpleNamespace(status_code=500, json=lambda: {})

        with live_access_worker(request, lineup) as (_, cache, messages, commands):
            assert filter_live_channels(
                lineup, cache.peek(CACHE_KEY, CACHE_SECONDS, lineup), True) == ([], "loading")
            auth_session.prepare(live_access=True)
            access = cache.peek(CACHE_KEY, CACHE_SECONDS, lineup)
            assert filter_live_channels(lineup, access, True) == ([], "error")
            assert filter_live_channels(lineup, access, False) == (["not-confirmed"], "")
            assert "Live channel access unavailable: simpliTV API returned HTTP 500" in messages
            recovery = live_tv_route(["livetv-recovery"], 2, None, cache.peek, lineup)
            assert recovery[1][1][2].label == (
                "Channel access could not be checked — Live TV settings")
            assert_recovery_items(recovery, "Channel access could not be checked — Live TV settings")
            assert live_tv_route(["live-access-settings"], -1, None) == [("settings", "")]


def test_guide_acquisition_failure_and_pending_cancel_never_dispatch():
    from auth_session import AuthError

    def rejected(_):
        raise AuthError("rejected")

    begin, events, players, workers, clock = guide_playback_handler(rejected)
    handoff = begin({"channel": "one"})
    next(handoff)
    workers.pop()()
    try:
        next(handoff)
    except AuthError:
        pass
    else:
        raise AssertionError("Acquisition failure was not surfaced")
    handoff = begin({"channel": "one"})
    next(handoff)
    handoff.close()
    workers.pop()()
    assert list(handoff) == [] and not events and not players

    handoff = begin({"channel": "one"})
    next(handoff)
    clock.monotonic = lambda: 60
    try:
        next(handoff)
    except TimeoutError:
        pass
    else:
        raise AssertionError("Hung acquisition did not time out")
    assert not events and not players


if __name__ == "__main__":
    import doctest
    result = doctest.testmod()
    if result.failed:
        raise SystemExit(1)
    print("PASS: {} offline migration scenarios".format(result.attempted))
