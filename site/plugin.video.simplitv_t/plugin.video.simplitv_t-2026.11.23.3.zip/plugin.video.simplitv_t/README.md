# simpliTVᵀ

A Kodi 21 (Omega) add-on for [simpliTV live TV](https://streaming.simpli.at/tv).
It opens directly into the programme guide. A simpliTV account is required;
available channels and replay depend on your entitlement.

## Setup

Install the `plugin.video.simplitv_t` folder in Kodi’s `addons` directory and
restart Kodi. Under **Settings → General** (**Einstellungen → Allgemein**),
enter your e-mail address and password. Kodi needs InputStream Adaptive with
Widevine; clear streams use InputStream Adaptive. PlayReady-only streams are
not supported.

## Watching TV

| Where | Controls |
| --- | --- |
| **Programme guide** | Left/Right moves between programmes; Up/Down moves between channels; Page Up/Down (often P+/P−) pages through the lineup. OK opens live TV or an available replay action. Menu focuses the action row, including Settings. |
| **While tuning** | Back cancels the tune. You can turn off TV static to show a black screen with the station logo instead. |
| **During playback** | Back returns to the guide without stopping the stream. **Return to stream** reopens it without retuning. Stop ends playback and returns to the guide. |

For past programmes, a **teal** badge marks provider Catch-up. An **amber** badge
marks estimated rewind in the live buffer. A rewind attempt may not land on the
scheduled start, and unavailable programmes don’t show a replay action. Until a
channel's buffer has been measured, its window is estimated at three hours;
this assumption is not saved. A shorter actual buffer starts at its earliest
available point, which may be after the selected programme.

When a channel is already playing, the guide shows its picture in the programme
details area. Sound and playback continue as before; browsing does not switch
channels. Turn the picture off in **Live TV** settings if desired.
With the mini-picture off or unavailable, the current video appears full-screen
behind a translucent guide. Without a matching stream, the guide stays opaque.

### Seeking and channel changes

The programme guide opens the **simpliTVᵀ player** for live TV and replay:

- **P+/P−** switches channels. **Up/Down** seeks ten minutes.
- **Left/Right** seeks 30 seconds per tap for the first four taps in the same
  direction, then two minutes per tap. A pause between presses or a reversal
  starts a new burst.
- **Hold Left/Right** to jump to a known programme start or end (or the live
  edge for a programme still airing). This requires Kodi to report a distinct
  long press for your input. If it doesn’t, use the programme jump commands in
  the **context menu**, which also has audio and subtitle settings.
- **Display / Fullscreen** switches to Kodi’s native OSD and controls. The
  add-on player has its own seek display, Info banner, and audio/subtitle menu,
  not the full native OSD (for example, Kodi's video settings).

The guide shows station logos; the selected row gently alternates between its
logo and name. The full-width seek strip does the same and shows a local-time ruler from
the oldest reported point to live. A thin red line marks the seek target while
seeking, then follows actual playback. Without a logo, the station name stays
visible. In the simpliTVᵀ player a badge above the marker shows local
broadcast time and live offset, e.g. `21:47 · −4:56`, or `LIVE` near the edge.
The bar stays visible while paused. Replays show
position and duration at the bottom instead. The tune and Info banner shares
that area and yields to the seek bar.
The guide fills in the rewind window in the background;
gaps mean no programme information is available for that interval. The clock
(`Broadcast time ~` / `Sendezeit ~`) in Kodi fullscreen is approximate. Normal fullscreen retains
Kodi’s native seek controls and displays the same portable overlay when enabled.

## Settings

| Tab | Settings |
| --- | --- |
| **General / Allgemein** | Account credentials; portable timeshift overlay (on); TV static while tuning (on). |
| **Live TV** | Show only playable channels (on); show the current channel in the guide (on). |
| **About / Über** | Credits and licence. |

If the guide can’t open, the recovery directory offers **Programme Guide**
and **Live TV settings**. Existing direct playable links, such as favourites
that point straight to a channel, use Kodi's standard player.

## Credits and licence

simpliTVᵀ is maintained by **Tom** and based on the original simpliTV Kodi
add-on by **Publish3r** and **sunsettrack4**. It is unofficial and licensed
under [GNU GPL v3 or later](LICENSE.txt); the full licence is in [COPYING](COPYING).

[Developer reference](docs/developer.md) — implementation details, compatibility,
caches, changes from the original add-on, and offline testing.
**TV options:** In the guide, **TV options** is available when you can return
to the last station or go live in the current stream. The add-on
player also offers these in its context menu. Stations enter the history
only once playback starts. **Go live** seeks in the current stream.
