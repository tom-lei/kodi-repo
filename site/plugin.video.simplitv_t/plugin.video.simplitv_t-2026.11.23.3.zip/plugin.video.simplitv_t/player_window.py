"""The add-on playback window and local channel navigation."""

import datetime
import os
import time

from timeshift_overlay import (FADE, PauseClock, SeekStrip, cached_strip_logo, format_duration,
                               skin_font)
from seek_schedule import SeekSchedule
from seek_timeline import LONG_BUTTON, SeekGesture, boundary_target, clamp, sane_timeline
from guide import local_startup_logo
from crt_noise import FPS as CRT_FPS, tuning_logo_size
from tv_behavior import LIVE_GAP, ProgrammeBanner, input_trace, live_target, programme_banner


def seek_status(position, duration, pending, live, wall, pause_delay=0):
    point = clamp(position if pending is None else pending, duration)
    if not live:
        return "{} / {}".format(format_duration(point), format_duration(duration))
    gap = duration - point + pause_delay
    if gap < LIVE_GAP:
        return "LIVE"
    minutes, seconds = divmod(int(gap), 60)
    delay = format_duration(gap) if minutes >= 60 else "{}:{:02d}".format(minutes, seconds)
    clock = datetime.datetime.fromtimestamp(wall - gap).strftime("%H:%M")
    return "{} · −{}".format(clock, delay)


TEXT = (
    {
        "unavailable": "No verified channel is available.",
        "switching": "Switching channel…",
        "failed": "Channel change failed.",
        "seek_unavailable": "Seeking is unavailable.",
        "audio": "Audio settings",
        "subtitles": "Subtitle settings",
        "previous": "Jump to programme start",
        "next": "Jump to programme end / live",
        "no_boundary": "No programme boundary available.",
        "last_channel": "Last channel",
        "go_live": "Go live",
        "live_edge_unreached": "Kodi did not reach the live edge.",
    },
    {
        "unavailable": "Kein bestätigter Sender verfügbar.",
        "switching": "Senderwechsel läuft…",
        "failed": "Senderwechsel fehlgeschlagen.",
        "seek_unavailable": "Spulen ist nicht verfügbar.",
        "audio": "Audioeinstellungen",
        "subtitles": "Untertiteleinstellungen",
        "previous": "Zum Sendungsanfang springen",
        "next": "Zum Sendungsende / zu Live springen",
        "no_boundary": "Keine Sendungsgrenze verfügbar.",
        "last_channel": "Letzter Sender",
        "go_live": "Zu Live",
        "live_edge_unreached": "Kodi hat den Live-Punkt nicht erreicht.",
    },
)


class GoLiveAttempt:
    """Track only the same-stream Go Live command, not ordinary seek gestures."""

    CHECK_AFTER = 6
    GIVE_UP_AFTER = 7

    def __init__(self, now):
        self.started = now
        self.retried = False

    def review(self, position, duration, now, seeking):
        elapsed = now - self.started
        # A near-edge timestamp can appear briefly before the buffer settles.
        if elapsed < self.CHECK_AFTER:
            return None
        if sane_timeline(position, duration) and not seeking:
            if duration - position < LIVE_GAP:
                return "reached"
            if not self.retried:
                self.retried = True
                self.started = now
                return "retry"
            return "warn"
        if elapsed >= self.GIVE_UP_AFTER:
            return "cancel"
        return None


class ZapController:
    def __init__(self, playback, channels, start, notify, now=time.monotonic):
        self.playback = playback
        self.channels = channels
        self.start = start
        self.notify = notify
        self.now = now
        self.desired = None
        self.deadline = 0
        self.handoff = None
        self.dispatched = False

    def request(self, direction):
        channels = self.channels()
        current = self.desired or self.playback["channel"]
        if current not in channels:
            self.notify("unavailable")
            return False
        index = channels.index(current) + direction
        if not 0 <= index < len(channels):
            return False
        return self.request_channel(channels[index])

    def request_channel(self, channel):
        if channel is None or channel == self.playback["channel"] and self.desired is None:
            return False
        self.desired = channel
        self.deadline = self.now() + 0.2
        if self.handoff is not None and not self.dispatched:
            self.handoff.close()
            self.handoff = None
        return True

    def cancel(self):
        if self.handoff is not None:
            self.handoff.close()
            self.handoff = None
        self.desired = None

    def tick(self):
        if self.handoff is None and self.desired is not None and self.now() >= self.deadline:
            if self.desired == self.playback["channel"]:
                self.desired = None
                return False
            if self.desired not in self.channels():
                self.desired = None
                self.notify("unavailable")
                return False
            self.dispatched = False
            self.handoff = self.start(self.desired, self._dispatched)
        if self.handoff is None:
            return False
        try:
            next(self.handoff)
        except StopIteration as finished:
            self.handoff = None
            self.dispatched = False
            self.playback = finished.value
            if self.desired == self.playback["channel"]:
                self.desired = None
            return True
        except (OSError, RuntimeError, ValueError, TimeoutError) as error:
            self.handoff = None
            self.dispatched = False
            self.desired = None
            self.notify("failed", error)
        return False

    def _dispatched(self):
        self.dispatched = True


def open_player_window(playback, channels, start, addon, log, describe=None, peek_crt=None,
                       peek_schedule=None, fetch_schedule=None, monitor=None,
                       history=None, cached_events=None):
    import xbmc
    import xbmcgui

    if monitor is None:
        monitor = xbmc.Monitor()
    if monitor.abortRequested():
        return "closed", playback
    german = xbmc.getLanguage(xbmc.ISO_639_1) == "de"
    text = TEXT[german]

    class PlayerWindow(xbmcgui.WindowXML):
        def __init__(self, xml_filename, script_path, default_skin, default_res):
            super().__init__(xml_filename, script_path, default_skin, default_res)
            self.controller = ZapController(playback, channels, start, self.notify)
            self.closed = False
            self.reason = "closed"
            self.back_pending = False
            self.initialized = False
            self.programme_info = None
            self.seek_until = 0
            self.strip_hidden_at = float("-inf")
            self.go_live = None
            self.pause_clock = PauseClock()
            self.gesture = SeekGesture()
            self.strip = None
            self.guide_schedule = None
            self.startup_controls = []
            self.startup_frames = None
            self.startup_frame = None
            self.startup_started = 0

        def notify(self, key, error=None):
            if error is not None:
                # Exceptions can contain signed media URLs.
                log("Player window: {}".format(type(error).__name__))
            xbmcgui.Dialog().notification("simpliTVᵀ", text[key], addon.getAddonInfo("icon"), 4000)

        def onInit(self):
            if self.closed or monitor.abortRequested():
                return
            self.initialized = True
            self.show_banner()

        def show_banner(self, message=None):
            if not self.initialized:
                return
            current = self.controller.playback
            title = current.get("metadata", {}).get("title", "")
            station = title.partition(" — ")[0] or current["channel"]
            model = (message or station, "", "", 0)
            if not message and cached_events is not None:
                try:
                    events = cached_events() if current.get("live") else ()
                    model = programme_banner(events, current["channel"], station, time.time(), german)
                except (RuntimeError, ValueError, OSError) as error:
                    log("Programme banner unavailable: {}".format(type(error).__name__))
            if self.programme_info is None:
                fonts = (skin_font(("font12", "font13", "font10")),
                         skin_font(("font36_title", "font14", "font13")),
                         skin_font(("font10", "font12", "font13")))
                self.programme_info = ProgrammeBanner(self, addon, xbmcgui, fonts[1], FADE,
                                                      bottom=True, fonts=fonts)
            self.programme_info.show(model)

        def alive(self):
            current = self.controller.playback
            try:
                return current["player"].isPlayingVideo() and current["matches"]()
            except RuntimeError:
                return False

        def ended_reason(self):
            # Native Stop can end playback before Kodi delivers onAction(13).
            try:
                replaced = self.controller.playback["player"].isPlaying()
            except RuntimeError:
                replaced = False
            return "closed" if replaced or monitor.abortRequested() else "stopped"

        def timeline(self):
            if (not self.alive() or self.controller.desired is not None
                    or not xbmc.getCondVisibility("Player.SeekEnabled")):
                raise ValueError("Seeking is unavailable")
            player = self.controller.playback["player"]
            position, duration = player.getTime(), player.getTotalTime()
            position = self.gesture.observe(position, duration, time.monotonic())
            if position is None or not sane_timeline(position, duration):
                raise ValueError("Invalid timeline")
            return player, clamp(position, duration), duration

        def schedule(self, edge, duration, now):
            if peek_schedule is None:
                return []
            if self.guide_schedule is None:
                self.guide_schedule = SeekSchedule(self.controller.playback["channel"],
                                                   peek_schedule, log, fetch_schedule)
            return self.guide_schedule.update(edge, duration, now)

        def reset_seek(self, shutdown=False):
            self.gesture = SeekGesture()
            self.go_live = None
            self.pause_clock = PauseClock()
            self.seek_until = 0
            if self.guide_schedule is not None:
                self.guide_schedule.close()
                self.guide_schedule = None
            if self.strip is not None:
                if not shutdown:
                    self.strip.close()
                self.strip = None

        def seek(self, direction, *, long=False, jump=False, seconds=None):
            try:
                _, position, duration = self.timeline()
                now = time.monotonic()
                gesture = self.gesture
                if long or jump:
                    if not self.controller.playback.get("live"):
                        return
                    pending = gesture.pending(now)
                    origin = (position if pending is None else pending) if jump else \
                        gesture.hold_origin(direction, position, now)
                    if origin is None:
                        return
                    if direction > 0 and pending is None:
                        origin = gesture.boundary_position(origin)
                    extra = self.pause_clock.update(duration, xbmc.getCondVisibility("Player.Paused"), now)
                    edge = time.time() - extra
                    target = boundary_target(self.schedule(edge, duration, now),
                                             origin, duration, edge, direction)
                    if target is None:
                        self.show_banner(text["no_boundary"])
                        return
                    if jump:
                        gesture.direction = gesture.count = 0
                    gesture.queue(target, duration, now, boundary=True)
                elif seconds is not None:
                    gesture.skip(seconds, position, duration, now)
                else:
                    gesture.tap(direction, position, duration, now)
                self.seek_until = now + 3
            except (RuntimeError, ValueError) as error:
                self.notify("seek_unavailable", error)

        def seek_live(self, player, target, now, corrective=False):
            try:
                if history is not None:
                    input_trace("go_live_seek", target=round(target, 2), corrective=corrective)
                player.seekTime(target)
            except (RuntimeError, ValueError) as error:
                self.go_live = None
                self.notify("seek_unavailable", error)
                return False
            # Keep the existing pending marker without deferring the native seek.
            gesture = SeekGesture()
            gesture.position = self.gesture.position
            gesture.position_time = self.gesture.position_time
            gesture.queue(target, target, now)
            gesture.dispatch(target, now)
            self.gesture = gesture
            self.seek_until = now + 3
            return True

        def show_startup(self):
            metadata = describe(self.controller.desired) if describe is not None else {}
            try:
                art = local_startup_logo(xbmc, metadata.get("logo"))
            except (ImportError, OSError, RuntimeError, TypeError, ValueError, AttributeError) as error:
                log("Startup logo cache unavailable: {}".format(type(error).__name__))
                art = None
            if self.startup_controls:
                self.startup_logo.setImage(art or "")
                self.startup_logo.setVisible(bool(art))
                if self.startup_frames is not None:
                    self.startup_label.setLabel(metadata.get("title", ""), shadowColor="FF101722")
                return
            width, height = self.getWidth(), self.getHeight()
            logo_width, logo_height = tuning_logo_size(width, height)
            left, top = (width - logo_width) // 2, (height - logo_height) // 2
            solid = os.path.join(addon.getAddonInfo("path"), "resources", "skins", "Default",
                                 "media", "guide-solid.png")
            textures = peek_crt() if peek_crt is not None else None
            controls = []
            if textures is None:
                controls.append(xbmcgui.ControlImage(0, 0, width, height, solid,
                                                     colorDiffuse="FF000000"))
            else:
                snow, interference = textures
                fields = [xbmcgui.ControlImage(0, 0, width, height, filename) for filename in snow]
                controls.extend(fields)
            self.startup_logo = xbmcgui.ControlImage(left, top, logo_width, logo_height,
                                                      art or "", aspectRatio=2)
            controls.append(self.startup_logo)
            if textures is not None:
                self.startup_label = xbmcgui.ControlLabel(
                    max(0, (width - 544) // 2), max(0, min(height - 30, top + logo_height + 6)),
                    min(544, width), min(30, height), metadata.get("title", ""),
                    font=skin_font(), textColor="FFFFFFFF", alignment=6)
                controls.append(self.startup_label)
                signals = [xbmcgui.ControlImage(0, max(0, top - 4), width,
                                                top + logo_height + 5 - max(0, top - 4), filename)
                           for filename in interference]
                controls.extend(signals)
                self.startup_frames = fields, signals
                self.startup_started = time.monotonic()
                self.startup_frame = None
            self.startup_controls = controls
            self.addControls(controls)
            self.startup_logo.setVisible(bool(art))
            self.animate_startup()

        def animate_startup(self):
            if self.startup_frames is None:
                return
            fields, signals = self.startup_frames
            index = int((time.monotonic() - self.startup_started) * CRT_FPS) % len(fields)
            if index != self.startup_frame:
                if self.startup_frame is None:
                    for frame in range(len(fields)):
                        fields[frame].setVisible(frame == index)
                        signals[frame].setVisible(frame == index)
                else:
                    fields[self.startup_frame].setVisible(False)
                    signals[self.startup_frame].setVisible(False)
                    fields[index].setVisible(True)
                    signals[index].setVisible(True)
                self.startup_frame = index

        def close_startup(self):
            if self.startup_controls:
                self.removeControls(self.startup_controls)
                self.startup_controls = []
                self.startup_frames = None
                self.startup_frame = None

        def onAction(self, action):
            if self.closed or monitor.abortRequested():
                return
            action_id = action.getId()
            if history is not None:
                input_trace("input", action=action_id,
                            button=getattr(action, "getButtonCode", lambda: 0)())
            if action_id in (5, 6):
                if self.controller.request(1 if action_id == 5 else -1):
                    self.reset_seek()
                    self.show_startup()
            elif action_id in (1, 2):
                self.go_live = None
                button = getattr(action, "getButtonCode", lambda: 0)()
                self.seek(-1 if action_id == 1 else 1, long=bool(button & LONG_BUTTON))
            elif action_id in (3, 4):
                self.go_live = None
                self.seek(0, seconds=600 if action_id == 3 else -600)
            elif action_id in (10, 92):
                if self.controller.dispatched:
                    self.back_pending = True
                    self.show_banner(text["switching"])
                else:
                    self.controller.cancel()
                    self.close_startup()
                    self.reason = "guide"
                    self.closed = True
            elif action_id == 13:
                # Kodi's global Stop handles the player after this window callback.
                self.controller.cancel()
                self.reason = "stopped"
                self.closed = True
            elif action_id == 11:
                self.show_banner()
            elif action_id == 117 and self.alive():
                options = [text["audio"], text["subtitles"]]
                actions = ["audio", "subtitles"]
                current = self.controller.playback
                if current.get("live"):
                    options += [text["previous"], text["next"]]
                    actions += ["previous", "next"]
                if self.controller.desired is None:
                    if history is not None and history.target(channels()) is not None:
                        options.append(text["last_channel"])
                        actions.append("last_channel")
                    if live_target(current, xbmc) is not None:
                        options.append(text["go_live"])
                        actions.append("go_live")
                choice = xbmcgui.Dialog().contextmenu(options)
                if not 0 <= choice < len(actions) or monitor.abortRequested():
                    return
                selected = actions[choice]
                if history is not None:
                    input_trace("menu", action=selected)
                if selected in ("audio", "subtitles"):
                    xbmc.executebuiltin("ActivateWindow({})".format(10124 if choice == 0 else 10159))
                elif selected in ("previous", "next"):
                    self.go_live = None
                    self.seek(-1 if choice == 2 else 1, jump=True)
                elif selected == "last_channel" and self.controller.request_channel(history.target(channels())):
                    self.reset_seek()
                    self.show_startup()
                elif selected == "go_live":
                    target = live_target(current, xbmc)
                    now = time.monotonic()
                    if target is not None and self.seek_live(current["player"], target, now):
                        self.go_live = GoLiveAttempt(now)

        def update(self):
            if not self.controller.dispatched and not self.alive():
                self.controller.cancel()
                self.reason = self.ended_reason()
                self.closed = True
                return
            changed = self.controller.tick()
            if changed:
                self.reset_seek()
                self.show_banner()
            if self.back_pending and self.controller.handoff is None:
                self.controller.desired = None
                self.reason = "guide" if self.alive() else self.ended_reason()
                self.closed = True
                return
            if self.controller.handoff is None and self.controller.desired is None:
                self.close_startup()
            else:
                self.animate_startup()
            now = time.monotonic()
            paused = xbmc.getCondVisibility("Player.Paused")
            show_seek = (paused or now < self.seek_until
                         or xbmc.getCondVisibility("Player.Seeking | Player.HasPerformedSeek(3)"))
            if self.alive() and self.controller.desired is None:
                try:
                    player = self.controller.playback["player"]
                    duration, raw_position = player.getTotalTime(), player.getTime()
                    pending_seek = self.gesture.inflight
                    position = self.gesture.observe(raw_position, duration, now)
                    if history is not None and pending_seek is not None and self.gesture.inflight is None:
                        input_trace("seek_readback", requested=round(pending_seek, 2),
                                    actual=round(position, 2) if position is not None else None)
                    if self.go_live is not None:
                        if not xbmc.getCondVisibility("Player.SeekEnabled"):
                            self.go_live = None
                        else:
                            result = self.go_live.review(raw_position, duration, now,
                                                         xbmc.getCondVisibility("Player.Seeking"))
                            if result is not None:
                                if history is not None:
                                    input_trace("go_live_result", result=result, position=round(raw_position, 2),
                                                duration=round(duration, 2))
                                if result == "retry":
                                    self.seek_live(player, duration, now, corrective=True)
                                else:
                                    self.go_live = None
                                    if result == "warn":
                                        self.notify("live_edge_unreached")
                    if position is not None and sane_timeline(position, duration):
                        target = self.gesture.dispatch(duration, now)
                        if target is not None and abs(target - position) > 1:
                            try:
                                if not xbmc.getCondVisibility("Player.SeekEnabled"):
                                    raise ValueError("Seeking is unavailable")
                                if history is not None:
                                    input_trace("seek_requested", before=round(position, 2),
                                                target=round(target, 2), duration=round(duration, 2))
                                player.seekTime(target)
                                self.seek_until = now + 3
                            except (RuntimeError, ValueError) as error:
                                self.gesture = SeekGesture()
                                self.go_live = None
                                self.notify("seek_unavailable", error)
                        elif target is not None:
                            self.gesture.inflight = None
                            self.gesture.inflight_boundary = False
                        pending = self.gesture.pending(now)
                        show_seek = show_seek or pending is not None
                        current = self.controller.playback
                        live = current.get("live")
                        pause_delay = 0
                        wall = time.time()
                        if live:
                            pause_delay = self.pause_clock.update(duration, paused, now)
                            edge = wall - pause_delay
                            rows = self.schedule(edge, duration, now)
                        if show_seek:
                            timeline = (live and peek_schedule is not None
                                        and addon.getSetting("timeshift_overlay") != "false")
                            if self.strip is None:
                                metadata = current.get("metadata") or {}
                                logo = (cached_strip_logo(xbmc, metadata.get("logo"),
                                                          addon.getAddonInfo("icon"))
                                        if timeline else None)
                                station = metadata.get("title", "").partition(" — ")[0] or current["channel"]
                                self.strip = SeekStrip(self, addon, "", logo, station,
                                                       status=True, minimal=not timeline)
                            label = seek_status(position, duration, pending, live and timeline, wall,
                                                pause_delay)
                            if timeline:
                                self.strip.update(rows, position, duration, edge, pending, status=label)
                            else:
                                self.strip.show(label)
                    else:
                        show_seek = False
                except (RuntimeError, ValueError) as error:
                    show_seek = False
                    log("Player timeline unavailable: {}".format(type(error).__name__))
            else:
                show_seek = False
            if self.strip is not None and self.strip.shown and not show_seek:
                self.strip.hide()
                self.strip_hidden_at = now
            if self.programme_info is not None:
                self.programme_info.update(not show_seek and not self.startup_controls
                                           and now - self.strip_hidden_at >= .2)

    window = PlayerWindow("simplitv-player.xml", addon.getAddonInfo("path"), "Default", "1080i")
    window_id = None
    try:
        if monitor.abortRequested():
            return "closed", playback
        previous_window = xbmcgui.getCurrentWindowId()
        window.show()
        if monitor.abortRequested():
            return "closed", playback
        window_id = xbmcgui.getCurrentWindowId()
        if window_id == previous_window:
            window_id = None
            raise RuntimeError("Player window did not become active")
        deadline = time.monotonic() + 5
        while not window.closed and not monitor.abortRequested():
            active = xbmcgui.getCurrentWindowId()
            if active != window_id:
                if active == 12005 and window.alive():
                    window.reason = "fullscreen"
                break
            if window.initialized:
                window.update()
                if window.controller.handoff is None and not window.alive():
                    if not window.closed:
                        window.reason = window.ended_reason()
                    break
            elif time.monotonic() >= deadline:
                raise RuntimeError("Player window did not initialize")
            delay = 0.02 if window.startup_frame is not None else (0.05 if window.seek_until > time.monotonic() else 0.1)
            if not window.closed and monitor.waitForAbort(delay):
                break
    finally:
        window.closed = True
        try:
            window.controller.cancel()
            window.reset_seek(shutdown=monitor.abortRequested())
            if not monitor.abortRequested():
                window.close_startup()
                if window_id is not None and xbmcgui.getCurrentWindowId() == window_id:
                    window.close()
        finally:
            window.controller.notify = None
    return ("closed" if monitor.abortRequested() else window.reason), window.controller.playback
