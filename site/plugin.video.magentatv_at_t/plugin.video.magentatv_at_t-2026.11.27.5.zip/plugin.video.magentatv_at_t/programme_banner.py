"""Now/next programme banner adapted from simpliTVᵀ (GPL-3.0-or-later).

Programme data comes only from the guide's local display cache; playback never asks
the provider for schedule data.
"""

import datetime
import os
import time

SCHEDULE_TTL = 60
# A cache read returns the 4 h guide pages overlapping [start, start + 4 h).
SCHEDULE_BEFORE = 2 * 3600


def schedule_rows(events, number):
    """Sorted (start, stop, title) rows for one channel number from cached guide events."""
    from guide import programme_key, repair_mojibake

    intervals = {}
    for event in events or ():
        key = programme_key(event)
        if key is None or key[0] != str(number) or (key[2], key[3]) in intervals:
            continue
        title = event.get("title")
        intervals[key[2], key[3]] = repair_mojibake(title).strip() if isinstance(title, str) else ""
    return [(start, stop, title) for (start, stop), title in sorted(intervals.items())]


class CachedSchedule:
    """Read programme rows for the playing channel from the guide cache, briefly memoised."""

    def __init__(self, store_for, station_for, clock=time.monotonic):
        self.store_for, self.station_for, self.clock = store_for, station_for, clock
        self.cached = {}

    def rows(self, number, around):
        station = self.station_for(number)
        if station is None or not getattr(station, "station_id", None):
            return []
        bucket = int(around // 1800)
        key = number, station.station_id, bucket
        now = self.clock()
        hit = self.cached.get(key)
        if hit is not None and now < hit[0]:
            return hit[1]
        rows = []
        try:
            store = self.store_for()
            if store is not None:
                start = datetime.datetime.fromtimestamp(bucket * 1800 - SCHEDULE_BEFORE,
                                                        datetime.timezone.utc)
                page = store.read_available_page(start, [station])
                if page is not None:
                    rows = schedule_rows(page[1], number)
        except (OSError, ValueError, TypeError, KeyError, AttributeError, OverflowError):
            rows = []
        # The banner, strip and boundary seeks may read different half-hour buckets.
        self.cached = {k: v for k, v in self.cached.items() if now < v[0] and k != key}
        while len(self.cached) >= 4:
            self.cached.pop(next(iter(self.cached)))
        self.cached[key] = now + SCHEDULE_TTL, rows
        return rows


def programme_banner(rows, station, now, german=False):
    """Return the banner model (station, programme line, next line, progress percent)."""
    current = following = None
    for row in rows:
        if row[0] <= now < row[1]:
            current = row
        elif row[0] >= now and (following is None or row[0] < following[0]):
            following = row
    if current is None or not current[2]:
        return station, "", "", 0
    start, stop, heading = current
    if following is not None and following[0] > stop + 60:
        following = None
    ends = datetime.datetime.fromtimestamp(stop).strftime("%H:%M")
    upcoming = following[2] if following is not None else ""
    return (station, "{}  ·  {} {}".format(heading, "bis" if german else "until", ends),
            ("Danach: " if german else "Next: ") + upcoming if upcoming else "",
            100 * (now - start) / (stop - start))


class ProgrammeBanner:
    def __init__(self, window, addon, xbmcgui, fonts, fade, lift=False):
        width, height = window.getWidth() or 1920, window.getHeight() or 1080
        rows = (max(23, round(height * .030)), max(28, round(height * .040)),
                max(22, round(height * .028)))
        gap = max(2, round(height * .004))
        left, wide = 0, width
        inset = min(20, max(4, width // 30))
        body = sum(rows) + 2 * gap
        top = height - body - 16
        solid = os.path.join(addon.getAddonInfo("path"), "resources", "skins", "Default",
                             "media", "guide-solid.png")
        self.background = xbmcgui.ControlImage(
            left, top, wide, body + 16, solid, colorDiffuse="FF101722")
        self.progress_width = max(1, wide - 2 * inset)
        colors = ("FFE0E7F0", "FFFFFFFF", "FFB8C6D8")
        self.labels = [xbmcgui.ControlLabel(left + inset, top + sum(rows[:i]) + i * gap + 4,
                                           self.progress_width, size, "", font=face,
                                           textColor=color, alignment=4)
                       for i, (size, face, color) in enumerate(zip(rows, fonts, colors))]
        self.track = xbmcgui.ControlImage(left + inset, top + body + 6,
                                          self.progress_width, 4, solid, colorDiffuse="FF334155")
        self.progress = xbmcgui.ControlImage(left + inset, top + body + 6,
                                             1, 4, solid, colorDiffuse="FFE20074")
        self.controls = [self.background] + self.labels + [self.track, self.progress]
        # A hide animation, or a reversible fade-in, can linger under Kodi's OSD.
        self.fade = [(event, attrs + " reversible=false" if event == "Visible" else attrs)
                     for event, attrs in fade if event != "Hidden"]
        # The banner rises natively above the skin's video controls (VideoOSD). lift is
        # their top edge as a fraction of the screen height; True means unknown controls,
        # so the banner moves to the top edge instead.
        self.raised = []
        if lift is not False and lift is not None:
            end = top + body + 16
            target = (round(height * float(lift) - max(4, height * .01))
                      if lift is not True else None)
            if target is None or target - body - 16 < height * .05:
                target = round(height * .05) + body + 16
            offset = min(0, target - end) if lift is True or float(lift) < 1 else 0
            if offset:
                self.raised = [("Conditional", "effect=slide end=0,{} time=250 tween=cubic "
                                "easing=out condition=Window.IsVisible(videoosd)".format(offset))]
        window.addControls(self.controls)
        for control in self.controls:
            control.setVisible(False)
            control.setAnimations(self.fade + self.raised)
            control.setVisibleCondition("!Window.IsVisible(fullscreeninfo)")
        self.until = 0
        self.model = ("", "", "", 0)
        self.visible = False
        self.obstructed = False
        self.osd = False

    def show(self, model, clock=time.monotonic):
        self.model = model
        for control, label in zip(self.labels, model[:3]):
            control.setLabel(label, shadowColor="FF000000")
        self.progress.setWidth(max(1, round(self.progress_width * model[3] / 100)))
        self.until = clock() + 4
        self.visible = None

    def update(self, unobstructed, osd=False, clock=time.monotonic):
        now = clock()
        if self.osd and not osd:
            # Let the banner slide back down before it expires.
            self.until = max(self.until, now + 2)
        self.osd = osd
        visible = unobstructed and ((osd and bool(self.model[0])) or now < self.until)
        obstructed = not unobstructed
        if visible == self.visible and obstructed == self.obstructed:
            return
        self.visible = visible
        if obstructed != self.obstructed:
            for control in self.controls:
                control.setAnimations(self.raised if obstructed else self.fade + self.raised)
            self.obstructed = obstructed
        self.background.setVisible(visible)
        for control, text in zip(self.labels, self.model[:3]):
            control.setVisible(visible and bool(text))
        self.track.setVisible(visible and bool(self.model[1]))
        self.progress.setVisible(visible and self.model[3] > 0)

    def hide(self):
        self.until = 0
        self.model = ("", "", "", 0)
        self.update(True)

    def close(self, window):
        try:
            window.removeControls(self.controls)
        except RuntimeError:
            pass
