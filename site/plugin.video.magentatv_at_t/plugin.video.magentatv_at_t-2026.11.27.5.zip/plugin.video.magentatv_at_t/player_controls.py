"""Owned live-player controls adapted from simpliTVᵀ (GPL-3.0-or-later)."""

import datetime
import os
import threading
import time
import weakref

import crt_noise
from channel_numbers import SETTINGS_SHORTCUT, ChannelNumber, number_channel, number_status, numbered
from seek_strip import FADE, SeekStrip, skin_font
from seek_timeline import LONG_BUTTON, LiveClock, SeekGesture, boundary_target, clamp, sane_timeline
from tuning_screen import TuningScreen
from player_context import choose
from programme_banner import ProgrammeBanner, programme_banner
from skin_osd import banner_lift, video_osd_layout


GERMAN = {
    "Seeking is unavailable.": "Spulen ist nicht verfügbar.",
    "The player timeline is unavailable.": "Die Wiedergabezeitleiste ist nicht verfügbar.",
    "The seek could not be completed.": "Spulen konnte nicht abgeschlossen werden.",
    "No programme boundary is available.": "Keine Sendungsgrenze verfügbar.",
}
JUMP = "jump"
# Remote and keyboard aliases: channel up/down (184/185) and step/big-step seeks (20-23).
ALIASES = {184: 5, 185: 6, 20: 2, 21: 1, 22: 3, 23: 4}
ACTIONS = frozenset((1, 2, 3, 4, 5, 6, 7, 10, 11, 13, 24, 92, 117)) | frozenset(range(58, 68))
NUMBER_HINT_SECONDS = 2


class PlayerControls:
    """Keep local input separate from provider and player lifecycle operations."""

    def __init__(self, player, owns_player, channel, channels, seek_enabled,
                 notify, clock=time.monotonic, show_timeline=None, schedule=None, wall=None,
                 paused=None):
        self.player = player
        self.owns_player = owns_player
        self.channel = channel
        self.channels = tuple(channels)
        self.numbers = {number: number for number in self.channels}
        self.number = ChannelNumber(self.numbers)
        self.rejected = None
        self.seek_enabled = seek_enabled
        self.notify = notify
        self.clock = clock
        self.show_timeline = show_timeline or (lambda: False)
        # schedule(wall time) -> cached (start, stop, title) rows; None outside live playback.
        self.schedule = schedule
        self.wall = wall or (lambda: time.time())
        self.paused = paused or (lambda: False)
        self.live_clock = LiveClock()
        # dash_video.LiveWindow of the current tune; None withholds programme mapping.
        self.live_window = None
        self.mapped = None
        self.gesture = SeekGesture()
        self.lock = threading.Lock()
        self.actions = []
        self.seek_until = 0

    def action(self, action, button=0):
        action = ALIASES.get(action, action)
        if action in ACTIONS:
            held = type(button) is int and bool(button & LONG_BUTTON) and action in (1, 2)
            with self.lock:
                self.actions.append((action, held))

    def jump(self, direction):
        """Queue a seek to the previous programme start or the current programme's end."""
        with self.lock:
            self.actions.append((2 if direction > 0 else 1, JUMP))

    def set_channels(self, channels):
        self.channels = tuple(channels)
        self.numbers.clear()
        self.numbers.update({number: number for number in self.channels})

    def reset_seek(self):
        self.gesture = SeekGesture()
        self.seek_until = 0

    def update(self, switching=False):
        with self.lock:
            actions, self.actions = self.actions, []
        if not switching and not self.owns_player():
            self.reset_seek()
            self.number.clear()
            return None, None
        if not switching:
            # Sample every tick so a pause is timed from when it starts.
            self.sample()
        now = self.clock()
        switch = None
        ui_action = None
        confirm = False
        for action, held in actions:
            if switching and action not in (5, 6, 7, 24) and not 58 <= action <= 67:
                continue
            if action in (10, 92):
                self.reset_seek()
                self.number.clear()
                return "guide", None
            if action == 13:
                self.reset_seek()
                self.number.clear()
                return "stop", None
            if 58 <= action <= 67:
                self.number.press(action, now)
                continue
            if action in (7, 24) and self.number.digits:
                confirm = True
                continue
            if not switching and action in (7, 24, 11, 117):
                if switch is None:
                    ui_action = {7: "osd", 24: "osd", 11: "info", 117: "context"}[action]
                continue
            if action in (5, 6):
                try:
                    index = self.channels.index(switch if switch is not None else self.channel)
                    index += 1 if action == 5 else -1
                except ValueError:
                    continue
                if 0 <= index < len(self.channels):
                    switch = self.channels[index]
                continue
            if switching:
                continue
            if switch is not None:
                continue
            if not self.seek_enabled():
                self.notify("Seeking is unavailable.")
                continue
            try:
                position, duration = self.player.getTime(), self.player.getTotalTime()
                if not sane_timeline(position, duration):
                    self.notify("The player timeline is unavailable.")
                    continue
                if action in (3, 4):
                    self.gesture.skip(600 if action == 3 else -600, position, duration, now)
                elif held and self.schedule is not None:
                    if not self._boundary(-1 if action == 1 else 1, position, duration, now,
                                          held == JUMP):
                        continue
                else:
                    self.gesture.tap(-1 if action == 1 else 1, position, duration, now)
                self.seek_until = now + 3
            except (RuntimeError, TypeError, ValueError):
                self.notify("The player timeline is unavailable.")
                continue
        taken = self.number.take(now, confirm)
        if taken == SETTINGS_SHORTCUT:
            self.reset_seek()
            return "settings", None
        if taken is not None:
            channel, reason = number_channel(taken, self.numbers, self.channels)
            if reason:
                self.rejected = taken
            else:
                switch = channel
        if switch is not None:
            self.reset_seek()
            return switch, None
        if switching:
            return None, None
        if ui_action is not None:
            return ui_action, None
        if not self.seek_enabled():
            self.reset_seek()
            return None, None
        if now >= self.seek_until and self.gesture.pending(now) is None and not self.show_timeline():
            return None, None
        try:
            raw, duration = self.player.getTime(), self.player.getTotalTime()
            if not sane_timeline(raw, duration):
                self.reset_seek()
                self.notify("The player timeline is unavailable.")
                return None, None
            position = self.gesture.observe(raw, duration, now)
            if position is None:
                return None, None
            target = self.gesture.dispatch(duration, now)
            if target is not None and abs(target - position) > 1:
                try:
                    self.player.seekTime(target)
                except (RuntimeError, TypeError, ValueError):
                    self.gesture = SeekGesture()
                    self.notify("The seek could not be completed.")
                    return None, None
                if self.schedule is not None:
                    self.live_clock.seek(target - raw, self.paused())
            if now < self.seek_until or self.gesture.pending(now) is not None or self.show_timeline():
                return None, (position, duration, self.gesture.pending(now))
        except (RuntimeError, TypeError, ValueError):
            self.gesture = SeekGesture()
            self.seek_until = 0
            self.notify("The player timeline is unavailable.")
        return None, None

    def sample(self):
        """Feed Kodi's raw position to the live clock; returns the playhead wall time or None."""
        self.mapped = None
        if self.schedule is None:
            return None
        try:
            position, duration = self.player.getTime(), self.player.getTotalTime()
            if not sane_timeline(position, duration):
                return None
            window = self.live_window
            if window is None or abs(duration - window.depth) > LiveClock.TOLERANCE:
                # Without the provider's window, the broadcast time on screen is unknown.
                self.live_clock.failed = True
                return None
            playhead = self.live_clock.observe(position, duration, self.paused(),
                                               self.wall() - window.lag)
        except (RuntimeError, TypeError, ValueError):
            return None
        if playhead is not None:
            self.mapped = playhead - position
        return playhead

    def playhead(self, position):
        """Wall time at a position on the current player clock, from this tick's sample."""
        return None if self.mapped is None else self.mapped + position

    def _boundary(self, direction, position, duration, now, jump):
        gesture = self.gesture
        pending = gesture.pending(now)
        origin = ((position if pending is None else pending) if jump
                  else gesture.hold_origin(direction, position, now))
        if origin is None:
            return True  # Kodi repeats a held key; one boundary per hold.
        if direction > 0 and pending is None:
            origin = gesture.boundary_position(origin)
        playhead = self.playhead(position)
        if playhead is None:
            self.notify("No programme boundary is available.")
            return False
        # The live edge in wall time; while paused it is held back by the pause length.
        edge = playhead + duration - position
        target = boundary_target(self.schedule(edge - duration + clamp(origin, duration)),
                                 origin, duration, edge, direction)
        if target is None:
            self.notify("No programme boundary is available.")
            return False
        if jump:
            gesture.direction = gesture.count = 0
        gesture.queue(target, duration, now, boundary=True)
        return True


def _duration(seconds):
    seconds = max(0, int(seconds))
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)
    return "{}:{:02d}:{:02d}".format(hours, minutes, seconds) if hours else "{}:{:02d}".format(minutes, seconds)


# Kodi InputStream Adaptive plays 16 s behind the manifest edge, which itself lags
# the wall clock by a few seconds; nearer than this counts as live.
LIVE_GAP = 30


def seek_status(position, duration, pending, playhead, wall):
    """Strip status: "pos / dur", or for mapped live playback "LIVE" / "HH:MM · −m:ss"."""
    point = clamp(position if pending is None else pending, duration)
    if playhead is None:
        return "{} / {}".format(_duration(point), _duration(duration))
    shown = playhead + point - position
    gap = wall - shown
    if gap < LIVE_GAP:
        return "LIVE"
    return "{} · −{}".format(datetime.datetime.fromtimestamp(shown).strftime("%H:%M"), _duration(gap))


class OwnedPlayerWindow:
    def __init__(self, player, owns_player, channel, channels, addon, profile, last_channel=None,
                 is_replay=False, logo_for=None, schedule_for=None, live_window=None):
        import xbmc
        import xbmcgui

        self.xbmc = xbmc
        self.xbmcgui = xbmcgui
        self.addon = addon
        self.profile = profile
        self.logo_for = logo_for or (lambda _: None)
        # schedule_for(channel, wall time) -> cached rows; enables the programme banner.
        self.schedule_for = schedule_for
        self.banner = None
        self.banner_due = False
        self.closed = False
        self.window_id = None
        self.between_channels = False
        self.cancel_switch = threading.Event()
        self.switch_stopped = threading.Event()
        self.switch_worker = None
        self.switch_error = None
        self.starting_player = None
        self.bind(player, owns_player, channel, channels, last_channel, is_replay, live_window)
        owner_ref = weakref.ref(self)

        class Window(xbmcgui.WindowXML):
            def onAction(self, action):
                owner = owner_ref()
                if owner is not None and not owner.closed:
                    if owner.between_channels and action.getId() in (10, 13, 92):
                        owner.cancel_switch.set()
                    else:
                        button = getattr(action, "getButtonCode", None)
                        owner.controls.action(action.getId(), button() if button else 0)

        self.window = Window("magenta-player.xml", addon.getAddonInfo("path"), "Default", "1080i")

    def bind(self, player, owns_player, channel, channels, last_channel, is_replay=False,
             live_window=None):
        self._stop_switch_worker()
        if self.switch_error is not None:
            raise RuntimeError("The channel-switch controls failed.") from self.switch_error
        desired = getattr(self, "desired", None)
        xbmc, xbmcgui, addon = self.xbmc, self.xbmcgui, self.addon
        def notify(message):
            if xbmc.getLanguage(xbmc.ISO_639_1) == "de":
                message = GERMAN[message]
            xbmcgui.Dialog().notification("Magenta TV ATᵀ", message, addon.getAddonInfo("icon"), 4000)

        if not hasattr(self, "controls"):
            self.controls = PlayerControls(
                player, owns_player, channel, [number for number, _ in channels],
                lambda: xbmc.getCondVisibility("Player.SeekEnabled"), notify,
                show_timeline=lambda: addon.getSetting("timeshift_overlay") != "false"
                    and xbmc.getCondVisibility("Player.Seeking | Player.HasPerformedSeek(3) | Player.Paused"),
                paused=lambda: xbmc.getCondVisibility("Player.Paused"),
            )
            self.strip = None
            self.full_strip = None
            self.tuning = None
            self.hint = None
            self.hint_text = None
        else:
            # Keep the same input queue: callbacks can arrive even during this AV handoff.
            self.controls.player = player
            self.controls.owns_player = owns_player
            self.controls.set_channels([number for number, _ in channels])
            self.controls.reset_seek()
        self.controls.live_clock.reset()
        self.controls.live_window = live_window
        self.controls.mapped = None
        self.controls.channel = desired if desired is not None else channel
        self.channel = channel
        self.names = dict(channels)
        self.last_channel = last_channel if last_channel in self.names and last_channel != channel else None
        self.is_replay = is_replay
        # Replay has its own stream clock; programme boundaries apply only to the live timeshift.
        schedule_for = self.schedule_for
        self.controls.schedule = (None if is_replay or schedule_for is None
                                  else lambda around: schedule_for(self.channel, around))
        self.banner_due = schedule_for is not None
        self.desired = desired if desired != channel else None
        if self.desired is None:
            self._cancel_tuning()
        self.hint_until = 0
        self.number_entry = False
        self.between_channels = False

    def begin_switch(self, channel):
        self.cancel_switch.clear()
        self.between_channels = True
        self.starting_player = None
        self.dismissed_startup = False
        self.desired = channel
        self.controls.channel = channel
        self.controls.reset_seek()
        self._show_tuning()
        self._hide_hint()
        if self.banner is not None:
            self.banner.hide()
        self._close_strips()
        self.switch_stopped.clear()
        self.switch_error = None
        self.switch_worker = threading.Thread(target=self._switch_updates,
                                              name="magenta-tuning", daemon=True)
        self.switch_worker.start()

    def _show_tuning(self):
        if not crt_noise.enabled(self.addon):
            return
        if self.tuning is None:
            self.tuning = TuningScreen(
                self.window, self.addon,
                crt_noise.startup_textures(self.addon, self.profile), self._title(self.desired))
        else:
            self.tuning.set_title(self._title(self.desired))
        self.tuning.set_logo(self.logo_for(self.desired))
        self.tuning.animate()

    def _switch_updates(self):
        # Only UI/input run here; the playback owner remains the sole lease/session caller.
        try:
            while not self.switch_stopped.is_set() and not self.closed and not self.cancel_switch.is_set():
                if self.starting_player is not None and not self.dismissed_startup:
                    self._dismiss_native_start()
                selected, _ = self.controls.update(switching=True)
                if type(selected) is int:
                    self.desired = selected
                    self.controls.channel = selected
                    self._show_tuning()
                self._update_hint()
                if self.tuning is not None:
                    self.tuning.set_logo(self.logo_for(self.desired))
                    self.tuning.animate()
                self.switch_stopped.wait(0.04)
        except (RuntimeError, TypeError, ValueError) as error:
            self.switch_error = error

    def _stop_switch_worker(self):
        self.switch_stopped.set()
        if self.switch_worker is not None:
            self.switch_worker.join()
            self.switch_worker = None

    def expect_native_start(self, player):
        # Only arm for our direct play submission on an unobstructed retained window.
        if (self.xbmcgui.getCurrentWindowId() == self.window_id
                and self.xbmcgui.getCurrentWindowDialogId() in (0, 9999)):
            self.starting_player = player

    def _dismiss_native_start(self):
        player = self.starting_player
        if (self.xbmcgui.getCurrentWindowId() != self.window_id
                or self.xbmcgui.getCurrentWindowDialogId() != 10138):
            return
        # Kodi's startup dialog swallows channel keys before isPlayingVideo() is true.
        if not player.isPlaying() or player._playing_direct():
            self.xbmc.executebuiltin("Dialog.Close(busydialog,true)")
            self.dismissed_startup = True

    def waiting_for_channel(self, owns_new_stream):
        if self.switch_error is not None:
            raise RuntimeError("The channel-switch controls failed.") from self.switch_error
        if self.cancel_switch.is_set() and owns_new_stream():
            return False
        # Omega opens its own cancellable busy dialog while a non-PVR stream starts.
        # Dismiss only on this retained window, after Kodi is playing the exact new URL.
        if (self.starting_player is None and not self.dismissed_startup
                and self.xbmcgui.getCurrentWindowId() == self.window_id
                and self.xbmcgui.getCurrentWindowDialogId() == 10138 and owns_new_stream()):
            self.xbmc.executebuiltin("Dialog.Close(busydialog,true)")
            self.dismissed_startup = True
        return True

    def show(self):
        previous = self.xbmcgui.getCurrentWindowId()
        if self.window_id is not None:
            if previous != self.window_id:
                raise RuntimeError("The player controls are no longer active.")
            return
        self.window.show()
        self.window_id = self.xbmcgui.getCurrentWindowId()
        if self.window_id == previous:
            self.close()
            raise RuntimeError("The player controls could not be opened.")
        crt_noise.start_preparation(self.profile, self.addon)

    def update(self):
        if (self.closed or self.xbmcgui.getCurrentWindowId() != self.window_id
                or not self.controls.owns_player()):
            self.controls.reset_seek()
            self._cancel_tuning()
            self._hide_hint()
            if self.banner is not None:
                self.banner.update(False)
            return None
        switch = self._update()
        if self.banner is not None:
            strip = any(getattr(s, "shown", False) is True for s in (self.strip, self.full_strip)
                        if s is not None)
            self.banner.update(self.desired is None and self.hint is None and not strip,
                               osd=self.xbmc.getCondVisibility("Window.IsVisible(videoosd)"))
        return switch

    def _update(self):
        switch, timeline = self.controls.update()
        if switch is None and self.desired is not None:
            switch = self.desired
        self._update_hint()
        if switch in ("stop", "guide", "settings"):
            self._cancel_tuning()
            self._hide_hint()
            return switch
        if switch is None and self.banner_due and self.desired is None:
            self.banner_due = False
            self._show_banner()
        if switch in ("osd", "info", "context"):
            if self.desired is not None:
                return None
            self._hide_strips()
            if switch == "osd":
                if self.schedule_for is not None:
                    # Open the stock controls with current programme info above them.
                    self._show_banner()
                    self.banner.update(True, osd=True)
                self.xbmc.executebuiltin("ActivateWindow(videoosd)")
            elif switch == "info":
                if self.schedule_for is not None:
                    self._show_banner()
                else:
                    self.controls.seek_until = self.controls.clock() + 3
                    self.xbmcgui.Dialog().notification(
                        "Magenta TV ATᵀ", self._title(self.channel), self.addon.getAddonInfo("icon"), 4000)
            else:
                return "context"
            return None
        if switch is not None:
            if switch == self.channel:
                self._cancel_tuning()
                switch = None
            else:
                self.desired = switch
                self.controls.channel = switch
                self._show_tuning()
                return switch
        if self.xbmc.getCondVisibility("Window.IsVisible(videoosd)"):
            self._hide_strips()
        elif timeline is not None:
            position, duration, pending = timeline
            playhead = self.controls.playhead(position)
            status = seek_status(position, duration, pending, playhead, self.controls.wall())
            rows = None
            if playhead is not None:
                edge = playhead + duration - position
                rows = self.controls.schedule(edge)
            if rows:
                self._show_full_strip(rows, position, duration, edge, pending, status)
            else:
                if self.full_strip is not None:
                    self.full_strip.hide()
                if self.strip is None:
                    self.strip = SeekStrip(self.window, self.addon, station=self._title(self.channel),
                                           status=True, minimal=True)
                self.strip.set_logo(self.logo_for(self.channel))
                self.strip.show_progress(position, duration, pending, status)
        else:
            self._hide_strips()
        return switch

    def _show_full_strip(self, rows, position, duration, edge, pending, status):
        logo = self.logo_for(self.channel)
        if self.full_strip is not None and self.full_logo != logo:
            self.full_strip.close()
            self.full_strip = None
        if self.full_strip is None:
            self.full_strip = SeekStrip(self.window, self.addon, logo=logo,
                                        station=self._title(self.channel), status=True)
            self.full_logo = logo
        if self.strip is not None:
            self.strip.hide()
        self.full_strip.update(rows, position, duration, edge, pending, status)

    def _hide_strips(self):
        for strip in (self.strip, self.full_strip):
            if strip is not None:
                strip.hide()

    def _close_strips(self):
        for strip in (self.strip, self.full_strip):
            if strip is not None:
                strip.close()
        self.strip = self.full_strip = None

    def _show_banner(self):
        station = self._title(self.channel)
        model = (station, "", "", 0)
        if not self.is_replay:
            try:
                wall = self.controls.wall()
                # Timeshifted viewing describes the programme on screen, not the live one.
                position, duration = self.controls.player.getTime(), self.controls.player.getTotalTime()
                sane = sane_timeline(position, duration)
                playhead = self.controls.sample() if sane else None
                if playhead is None and self.controls.live_clock.failed:
                    # Without a reliable clock, any programme shown could be the wrong one.
                    raise ValueError("live clock unavailable")
                behind = (wall - playhead if playhead is not None
                          else duration - position if sane else 0)
                watched = wall - (behind if behind >= 30 else 0)
                model = programme_banner(self.schedule_for(self.channel, watched), station,
                                         watched, self._german())
            except (RuntimeError, TypeError, ValueError, OSError) as error:
                self.xbmc.log("[Magenta TV AT] Programme banner unavailable: {}".format(
                    type(error).__name__), self.xbmc.LOGWARNING)
        if self.banner is None:
            fonts = (skin_font(("font12", "font13", "font10")),
                     skin_font(("font36_title", "font14", "font13")),
                     skin_font(("font10", "font12", "font13")))
            self.banner = ProgrammeBanner(self.window, self.addon, self.xbmcgui, fonts, FADE,
                                          lift=banner_lift(video_osd_layout()))
        self.banner.show(model)

    def context_menu(self, should_close, shutdown):
        if self.closed or should_close() or not self.controls.owns_player():
            return None
        german = self.xbmc.getLanguage(self.xbmc.ISO_639_1) == "de"
        options = [("Audio" if not german else "Ton", "audio"),
                   ("Subtitles" if not german else "Untertitel", "subtitles")]
        if self.controls.schedule is not None:
            options += [("Jump to programme start" if not german else "Zum Sendungsanfang springen",
                         "previous"),
                        ("Jump to programme end / live" if not german
                         else "Zum Sendungsende / zu Live springen", "next")]
        if self.last_channel is not None:
            options.append(("Last channel" if not german else "Letzter Sender", "last"))
        target = self._live_target()
        if target is not None:
            options.append(("Go live" if not german else "Live", "live"))
        choice = choose([label for label, _ in options], self.addon, should_close, shutdown,
                        self.controls.player.stop)
        if (not isinstance(choice, int) or not 0 <= choice < len(options)
                or self.closed or should_close() or not self.controls.owns_player()):
            return None
        action = options[choice][1]
        if action in ("audio", "subtitles"):
            self.xbmc.executebuiltin("ActivateWindow({})".format(10124 if action == "audio" else 10159))
        elif action == "last":
            return self.last_channel
        elif action in ("previous", "next"):
            self.controls.jump(1 if action == "next" else -1)
        elif action == "live":
            target = self._live_target()
            if target is not None:
                try:
                    self.controls.player.seekTime(target)
                except (RuntimeError, TypeError, ValueError):
                    self.controls.notify("The seek could not be completed.")
        return None

    def _live_target(self):
        if (self.is_replay or not self.controls.owns_player() or not self.controls.seek_enabled()
                or self.xbmc.getCondVisibility("Player.Seeking")):
            return None
        try:
            position, duration = self.controls.player.getTime(), self.controls.player.getTotalTime()
            if sane_timeline(position, duration) and duration - position >= 12:
                return duration
        except (RuntimeError, TypeError, ValueError):
            return None

    def _title(self, channel):
        return numbered(channel, self.names.get(channel, ""))

    def _german(self):
        return self.xbmc.getLanguage(self.xbmc.ISO_639_1) == "de"

    def _update_hint(self):
        """Show typed digits like a TV; keep a rejected number visible briefly."""
        controls = self.controls
        now = time.monotonic()
        digits = controls.number.digits
        rejected, controls.rejected = controls.rejected, None
        self.number_entry = bool(digits)
        if digits:
            text = number_status(digits, controls.numbers, controls.channels, self.names.get,
                                 self._german(), controls.number.is_settings())
        elif rejected is not None:
            text = number_status(str(rejected), controls.numbers, controls.channels, self.names.get,
                                 self._german(), final=True)
            self.hint_until = now + NUMBER_HINT_SECONDS
        elif now < self.hint_until:
            return
        else:
            self._hide_hint()
            return
        if text == self.hint_text:
            return
        if self.hint is None:
            width = self.window.getWidth() or 1920
            height = self.window.getHeight() or 1080
            scale = height / 1080
            panel_width, panel_height = int(760 * scale), int(64 * scale)
            left, top = width - panel_width - int(48 * scale), int(40 * scale)
            solid = os.path.join(self.addon.getAddonInfo("path"), "resources", "skins", "Default",
                                 "media", "guide-solid.png")
            background = self.xbmcgui.ControlImage(left, top, panel_width, panel_height, solid,
                                                   colorDiffuse="D0101722")
            label = self.xbmcgui.ControlLabel(left + int(20 * scale), top, panel_width - int(40 * scale),
                                              panel_height, "", font=skin_font(), textColor="FFFFFFFF",
                                              alignment=1 | 4)
            self.window.addControls([background, label])
            self.hint = (background, label)
        self.hint[1].setLabel(text)
        self.hint_text = text

    def _hide_hint(self):
        self.number_entry = False
        self.hint_until = 0
        if self.hint is not None:
            hint, self.hint, self.hint_text = self.hint, None, None
            try:
                self.window.removeControls(list(hint))
            except RuntimeError:
                pass

    def update_channels(self, channels):
        """Apply a refreshed lineup; keep the playing channel and report if it is gone."""
        channels = list(channels)
        title = self._title(self.channel)
        self.names = dict(channels)
        self.controls.set_channels([number for number, _ in channels])
        if self.last_channel not in self.names:
            self.last_channel = None
        if self.channel in self.names:
            return True
        german = self._german()
        message = ("Der zuvor gewählte Sender {} ist ausgeblendet oder nicht mehr vorhanden."
                   if german else "The previously selected channel {} is hidden or no longer available.")
        self.xbmcgui.Dialog().notification("Magenta TV ATᵀ", message.format(title),
                                           self.addon.getAddonInfo("icon"), 6000)
        return False

    def _cancel_tuning(self):
        self._stop_switch_worker()
        if self.tuning is not None:
            self.tuning.close()
            self.tuning = None
        self.controls.channel = self.channel
        self.desired = None

    def close(self, aborted=False):
        if self.closed:
            return
        self.closed = True
        self._stop_switch_worker()
        if aborted:
            return
        self._cancel_tuning()
        self._hide_hint()
        if self.banner is not None:
            self.banner.close(self.window)
            self.banner = None
        self._close_strips()
        self.window.close()
