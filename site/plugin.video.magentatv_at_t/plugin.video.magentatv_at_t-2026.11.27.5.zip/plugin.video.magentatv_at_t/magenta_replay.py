"""Match an authenticated Replay offer to one broadcast, not just its title."""

from dataclasses import dataclass
from urllib.parse import unquote

from magenta_guide_data import CODE, schedule_timestamp
from magenta_playback import PlaybackError
from magenta_experiment import valid_manifest_url
from seek_timeline import PROGRAMME_START_TOLERANCE


PADDING_LIMIT = 3 * 3600


@dataclass(frozen=True)
class Airing:
    number: int
    station: str
    programme: str
    start: int
    stop: int

    def __post_init__(self):
        if (type(self.number) is not int or not 0 <= self.number <= 999999
                or not all(isinstance(s, str) and CODE.fullmatch(s) and s not in (".", "..")
                           for s in (self.station, self.programme))
                or type(self.start) is not int or type(self.stop) is not int
                or not 0 <= self.start < self.stop <= 253402300799):
            raise PlaybackError("Invalid Replay airing.")

    def query(self):
        return {"channel": self.number, "station": self.station, "replay": self.programme,
                "start": self.start, "stop": self.stop}


@dataclass(frozen=True)
class ReplayOffer:
    airing: Airing
    start_utc: str
    end_utc: str
    expires: float


def opted_in(response):
    groups = response.get("groups")
    if not isinstance(groups, list):
        raise PlaybackError("The provider did not confirm Replay consent.")
    matches = []
    for group in groups:
        entries = group.get("consents") if isinstance(group, dict) else None
        if not isinstance(entries, list) or not all(isinstance(e, dict) for e in entries):
            raise PlaybackError("The provider did not confirm Replay consent.")
        matches.extend(e for e in entries if e.get("code", e.get("consent_code")) == "catchup-opt-in")
    return len(matches) == 1 and matches[0].get("pre_checked") is True


def replay_offer(response, airing, now):
    """Return the exact provider interval to hand back, never a calculated media URL."""
    if any(response.get(key, False) is not False for key in ("is_geo_blocked", "is_device_not_compatible")):
        return None
    actions = response.get("actions")
    if not isinstance(actions, dict):
        raise PlaybackError("The provider did not return programme actions.")
    rows = actions.get("catchup_schedules", [])
    if not isinstance(rows, list):
        raise PlaybackError("The provider returned invalid Replay schedules.")
    matches = []
    for row in rows:
        if not isinstance(row, dict):
            raise PlaybackError("The provider returned an invalid Replay offer.")
        if (row.get("program_id") != airing.programme or str(row.get("station_id")) != airing.station
                or str(row.get("channel_number")) != str(airing.number)):
            continue
        try:
            start, stop, first, last = (schedule_timestamp(row[key]) for key in (
                "start_utc", "end_utc", "catchup_start_utc", "catchup_end_utc"))
        except (KeyError, TypeError, ValueError, OverflowError, OSError):
            raise PlaybackError("The provider returned an invalid Replay interval.") from None
        if (start, stop) == (airing.start, airing.stop):
            matches.append((row, first, last))
    if len(matches) != 1:
        return None
    row, first, last = matches[0]
    if (now < airing.start or not first <= now < last or row.get("is_blackout") is not False
            or row.get("is_restricted") is not False or row.get("allowed_platforms") != []
            or row.get("entitlements") != [] or row.get("adult", False) is not False):
        return None
    return ReplayOffer(airing, row["start_utc"], row["end_utc"], last)


def replay_media_id(info, airing):
    catalog, playback = info.get("catalogInfoResponse"), info.get("playBackInfoResponse")
    if not isinstance(catalog, dict) or not isinstance(playback, dict):
        raise PlaybackError("The provider did not return Replay playback information.")
    denied = ("is_geo_blocked", "is_device_not_compatible", "is_blackout", "is_restricted")
    if (catalog.get("is_subscribe") is not True or catalog.get("is_catchup_enabled") is not True
            or any(catalog.get(key) is not False for key in denied)
            or catalog.get("is_adult") is not False or catalog.get("allowed_platforms")):
        raise PlaybackError("Replay is not explicitly permitted for this airing.")
    try:
        matches = (playback["type"] == "catchup" and str(playback["station_id"]) == airing.station
                   and playback["program_id"] == airing.programme
                   and schedule_timestamp(playback["start_time"]) == airing.start
                   and schedule_timestamp(playback["end_time"]) == airing.stop)
        items = playback["service_items"]
        if not matches or not isinstance(items, list) or len(items) != 1:
            raise ValueError
        media_id = items[0]["media_id"]
        if not isinstance(media_id, str) or not media_id.strip() or media_id != items[0]["timeshift_media_id"]:
            raise ValueError
    except (KeyError, IndexError, TypeError, ValueError, OverflowError, OSError):
        raise PlaybackError("The provider did not identify a verified Replay media item.") from None
    return media_id


def _padding_seconds(value):
    if isinstance(value, str) and value.isascii() and value.isdigit() and len(value) <= 6:
        value = int(value)
    if type(value) is int and 0 <= value <= PADDING_LIMIT:
        return value
    raise ValueError


def replay_padding(info):
    """Return explicit padding in seconds at both ends, or None if either is unknown."""
    try:
        rights = info["catalogInfoResponse"]["entitlements"]
        return tuple(_padding_seconds(rights[key]) for key in ("padding_start", "padding_end"))
    except (KeyError, TypeError, ValueError):
        return None


def replay_duration_matches(padding, airing, total):
    before, after = padding
    expected = airing.stop - airing.start + before + after
    return abs(total - expected) <= PROGRAMME_START_TOLERANCE


def replay_start_offset(padding, airing, total):
    """Return (seconds, None) for the scheduled start on the padded manifest, or (None, reason).

    The portal draws the programme start at padding_start seconds into the
    catch-up stream, so stream time 0 is the scheduled start minus that padding.
    The player's total duration must agree with the padded airing.
    """
    before, after = padding
    expected = airing.stop - airing.start + before + after
    if not replay_duration_matches(padding, airing, total):
        return None, "manifest duration %d s does not match provider padding (expected %d s)" % (
            round(total), expected)
    if before >= total - PROGRAMME_START_TOLERANCE:
        return None, "start outside manifest"
    return before, None


def replay_stream(media):
    video = media.get("video")
    if isinstance(video, dict):
        url, pid = video.get("video_src"), video.get("pid")
        if (valid_manifest_url(url) and not any(c in unquote(url) for c in "{}|\\\r\n")
                and not any(ord(c) < 33 for c in url)
                and isinstance(pid, str) and pid.strip() and pid == pid.strip()):
            return url, pid
    raise PlaybackError("The provider did not supply a supported Replay manifest and release ID.")
