"""Match DASH video sizes to public CENC key IDs, without changing the MPD."""

import calendar
import collections
import re
import uuid
import xml.etree.ElementTree as ET

from magenta_experiment import valid_manifest_url


_DASH = "{urn:mpeg:dash:schema:mpd:2011}"
_KID = "{urn:mpeg:cenc:2013}default_KID"
_MAX_MPD = 2 * 1024 * 1024


def _kid(element):
    kids = {uuid.UUID(cp.attrib[_KID]) for cp in element.findall(_DASH + "ContentProtection")
            if _KID in cp.attrib}
    if len(kids) > 1 or any(kid.int == 0 for kid in kids):
        raise ValueError
    return next(iter(kids)).bytes if kids else None


def video_ladder(data):
    """Return (pixels or None, KID) for each video representation in a single period."""
    if not data or len(data) > _MAX_MPD or b"\0" in data or b"<!DOCTYPE" in data:
        return ()
    try:
        root = ET.fromstring(data)
        periods = root.findall(_DASH + "Period")
        if root.tag != _DASH + "MPD" or len(periods) != 1:
            return ()
        ladder = []
        for group in periods[0].findall(_DASH + "AdaptationSet"):
            group_kid = None
            for rep in group.findall(_DASH + "Representation"):
                kind = (group.get("contentType") or rep.get("mimeType")
                        or group.get("mimeType", "")).partition("/")[0]
                if kind in ("audio", "image", "text"):
                    continue
                if kind != "video":
                    return ()
                if group_kid is None:
                    group_kid = _kid(group)
                kid = _kid(rep) or group_kid
                width = rep.get("width", group.get("width"))
                height = rep.get("height", group.get("height"))
                dimensions = [int(value) for value in (width, height) if value is not None]
                if kid is None or any(value <= 0 for value in dimensions):
                    return ()
                pixels = dimensions[0] * dimensions[1] if len(dimensions) == 2 else None
                if pixels is not None and pixels > 2147483647:
                    return ()
                ladder.append((pixels, kid))
        return tuple(ladder)
    except (ET.ParseError, ValueError, LookupError):
        return ()


LiveWindow = collections.namedtuple("LiveWindow", "lag depth")
# Sampled Magenta live MPDs end 3.8-4.1 s behind the wall clock; far more means the
# timeline is not wall-clock based (or the device clock is wrong).
MAX_LIVE_LAG = 60
_INSTANT = re.compile(r"(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d(?:\.\d+)?)(Z|[+-]\d\d:\d\d)?")
_SPAN = re.compile(r"PT?(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?")


def _instant(value):
    match = _INSTANT.fullmatch(value or "")
    if not match or not match.group(7):
        raise ValueError
    year, month, day, hour, minute = (int(part) for part in match.groups()[:5])
    seconds = calendar.timegm((year, month, day, hour, minute, 0)) + float(match.group(6))
    zone = match.group(7)
    if zone != "Z":
        offset = int(zone[1:3]) * 3600 + int(zone[4:6]) * 60
        seconds -= offset if zone[0] == "+" else -offset
    return seconds


def _span(value):
    match = _SPAN.fullmatch(value or "")
    if not match or not any(match.groups()):
        raise ValueError
    days, hours, minutes, seconds = (float(part or 0) for part in match.groups())
    return ((days * 24 + hours) * 60 + minutes) * 60 + seconds


def live_window(data, wall):
    """Return the live window of a wall-clock-timed dynamic MPD, else None.

    InputStream Adaptive reports positions from the first segment of its window, so
    ``wall - lag - (depth - position)`` is the broadcast time on screen. ``lag`` is how
    far the newest segment ends behind ``wall`` when this MPD was read.
    """
    if not data or len(data) > _MAX_MPD or b"\0" in data or b"<!DOCTYPE" in data:
        return None
    try:
        root = ET.fromstring(data)
        periods = root.findall(_DASH + "Period")
        if root.tag != _DASH + "MPD" or root.get("type") != "dynamic" or len(periods) != 1:
            return None
        origin = _instant(root.get("availabilityStartTime"))
        depth = _span(root.get("timeShiftBufferDepth"))
        origin += _span(periods[0].get("start")) if periods[0].get("start") else 0
        for group in periods[0].findall(_DASH + "AdaptationSet"):
            rep = group.find(_DASH + "Representation")
            kind = group.get("contentType") or group.get("mimeType", "") or (
                rep.get("mimeType", "") if rep is not None else "")
            if not kind.startswith("video"):
                continue
            template = group.find(_DASH + "SegmentTemplate")
            if template is None and rep is not None:
                template = rep.find(_DASH + "SegmentTemplate")
            timeline = template.find(_DASH + "SegmentTimeline") if template is not None else None
            if timeline is None:
                return None
            scale = int(template.get("timescale", "1"))
            offset = int(template.get("presentationTimeOffset", "0"))
            first = t = None
            for segment in timeline.findall(_DASH + "S"):
                if segment.get("t") is not None:
                    t = int(segment.get("t"))
                if t is None:
                    return None
                if first is None:
                    first = t
                t += int(segment.get("d")) * (int(segment.get("r", "0")) + 1)
            if first is None or scale <= 0:
                return None
            start, end = (origin + (point - offset) / scale for point in (first, t))
            lag = wall - end
            if not (0 < depth and 0 < end - start <= depth + 60 and 0 <= lag <= MAX_LIVE_LAG):
                return None
            return LiveWindow(lag, end - start)
        return None
    except (ET.ParseError, ValueError, TypeError, OverflowError):
        return None


def load_video_ladder(url, open_file, log):
    """Read the provider's MPD once using Kodi VFS (including its proxy settings)."""
    return load_manifest(url, open_file, log, None)[0]


def load_manifest(url, open_file, log, wall_clock):
    """Read the MPD once; return (video ladder, LiveWindow or None)."""
    ladder, window = (), None
    if valid_manifest_url(url) and "|" not in url and "\\" not in url:
        try:
            stream = open_file(url + "|connection-timeout=5")
            try:
                data = stream.readBytes(_MAX_MPD + 1)
            finally:
                stream.close()
            ladder = video_ladder(data)
            if wall_clock is not None:
                window = live_window(data, wall_clock())
        except (OSError, RuntimeError):
            pass
    if not ladder:
        log("licence video limit: DASH video key mapping unavailable; no inferred limit")
    return ladder, window


def licensed_pixel_limit(ladder, content_kids):
    """Bound by known licensed sizes, without guessing the size of a missing tier."""
    available = [pixels for pixels, kid in ladder if kid in content_kids]
    missing = [pixels for pixels, kid in ladder if kid not in content_kids]
    if not available or None in available or not missing:
        return None
    ceiling = max(available)
    return ceiling if all(pixels is None or pixels > ceiling for pixels in missing) else None
