"""Prevent this add-on from acquiring two live leases simultaneously."""

import os
import time

from magenta_playback import PlaybackError


class PlaybackGuard:
    def __init__(self, path, on_busy=None, timeout=0, aborted=None):
        self.path = path
        self.file = None
        self.on_busy = on_busy
        self.timeout = timeout
        self.aborted = aborted or (lambda: False)

    def __enter__(self):
        try:
            self.file = open(self.path, "a+b")
        except OSError:
            raise PlaybackError("The add-on playback guard is unavailable.") from None
        deadline = time.monotonic() + self.timeout
        requested = False
        try:
            while True:
                try:
                    self._lock()
                    break
                except OSError:
                    if self.aborted():
                        raise PlaybackError("Playback was cancelled.") from None
                    if not requested and self.on_busy:
                        self.on_busy()
                        requested = True
                    if time.monotonic() >= deadline:
                        raise PlaybackError(
                            "Another Magenta playback is still stopping. Please try again."
                        ) from None
                    time.sleep(0.2)
        except BaseException:
            self.file.close()
            self.file = None
            raise
        return self

    def _lock(self):
        if os.name == "nt":
            import msvcrt
            self.file.seek(0, os.SEEK_END)
            if self.file.tell() == 0:
                self.file.write(b"\0")
                self.file.flush()
            self.file.seek(0)
            msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

    def __exit__(self, exc_type, exc_value, traceback):
        if self.file is not None:
            self.file.close()
            self.file = None


def request_switch(path):
    try:
        with open(path, "w", encoding="ascii") as file:
            file.write("stop")
    except OSError:
        raise PlaybackError("Could not request the current channel to stop.") from None


def clear_switch(path):
    try:
        if os.path.exists(path):
            os.unlink(path)
    except OSError:
        raise PlaybackError("Could not clear the channel-switch request.") from None


class SwitchingMonitor:
    def __init__(self, monitor, path, cancelled=None):
        self.monitor = monitor
        self.path = path
        self.cancelled = cancelled

    def abortRequested(self):
        return (self.monitor.abortRequested() or os.path.exists(self.path)
                or (self.cancelled is not None and self.cancelled.is_set()))

    def waitForAbort(self, timeout):
        return self.monitor.waitForAbort(timeout)


def application_aborted(monitor):
    if isinstance(monitor, SwitchingMonitor):
        return monitor.monitor.abortRequested()
    return monitor.abortRequested()
