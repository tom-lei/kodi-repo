"""Validate the subscribed live channels shown by the add-on."""

from magenta_experiment import _channel_number
from magenta_playback import PlaybackError


def subscribed_channels(response):
    channels = response.get("channels") if isinstance(response, dict) else None
    if not isinstance(channels, list):
        raise PlaybackError("Subscribed channels are unavailable.")
    result = []
    numbers = set()
    for channel in channels:
        if not isinstance(channel, dict):
            raise PlaybackError("The provider returned an invalid subscribed channel.")
        number = _channel_number(channel.get("channel_number"))
        title = channel.get("title")
        if number is None or not isinstance(title, str) or not title.strip():
            raise PlaybackError("The provider returned an invalid subscribed channel.")
        if number in numbers:
            raise PlaybackError("The provider returned duplicate channel numbers.")
        numbers.add(number)
        result.append((number, title.strip()))
    return sorted(result)


def require_subscribed(response, number):
    if number not in {channel[0] for channel in subscribed_channels(response)}:
        raise PlaybackError("This channel is not subscribed.")
