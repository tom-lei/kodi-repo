"""Cancellable, add-on-owned playback options."""

import os

from magenta_playback import PlaybackError


def choose(options, addon, should_close, shutdown, stop):
    import xbmc
    import xbmcgui

    class ContextDialog(xbmcgui.WindowXMLDialog):
        def __init__(self, *args):
            super().__init__(*args)
            self.closed = False
            self.choice = None
            self.buttons = []
            self.error = False

        def onInit(self):
            if self.closed or should_close():
                self.close()
                return
            try:
                self._build()
            except (RuntimeError, TypeError, ValueError):
                self.error = True
                self.close()

        def _build(self):
            width, height = self.getWidth(), self.getHeight()
            row = max(40, height // 18)
            wide = max(200, width // 3)
            left = (width - wide) // 2
            top = max(0, (height - row * len(options)) // 2)
            solid = os.path.join(addon.getAddonInfo("path"), "resources", "skins", "Default",
                                 "media", "guide-solid.png")
            background = xbmcgui.ControlImage(left, top, wide, row * len(options), solid,
                                               colorDiffuse="FF101722")
            self.buttons = [
                xbmcgui.ControlButton(left, top + index * row, wide, row, label,
                                      font="font13", textColor="0xFFF1F5F9",
                                      focusedColor="0xFF80D6FF", focusTexture="",
                                      noFocusTexture="", alignment=4, textOffsetX=16)
                for index, label in enumerate(options)
            ]
            self.addControls([background] + self.buttons)
            for index, button in enumerate(self.buttons):
                button.controlUp(self.buttons[(index - 1) % len(self.buttons)])
                button.controlDown(self.buttons[(index + 1) % len(self.buttons)])
            self.setFocus(self.buttons[0])

        def onClick(self, control_id):
            if self.closed or should_close():
                self.close()
                return
            for index, button in enumerate(self.buttons):
                if button.getId() == control_id:
                    self.choice = index
                    self.close()
                    break

        def onAction(self, action):
            action_id = action.getId()
            if action_id == 13:
                if not should_close():
                    try:
                        stop()
                    except RuntimeError:
                        self.error = True
                self.close()
            elif action_id in (10, 92):
                self.close()

        def close(self):
            if self.closed:
                return
            self.closed = True
            if not shutdown():
                try:
                    super().close()
                except RuntimeError:
                    self.error = True

        def onDeinit(self):
            self.closed = True

    if should_close():
        return None
    dialog = ContextDialog("magenta-context.xml", addon.getAddonInfo("path"), "Default", "1080i")
    try:
        dialog.show()
        while not dialog.closed and not should_close():
            xbmc.sleep(50)
    finally:
        dialog.close()
    if dialog.error:
        raise PlaybackError("The player options could not be opened or closed.")
    return None if should_close() else dialog.choice
