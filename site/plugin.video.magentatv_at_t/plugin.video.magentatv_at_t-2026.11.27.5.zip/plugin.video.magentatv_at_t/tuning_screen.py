"""CRT channel-change screen adapted from simpliTVᵀ (GPL-3.0-or-later)."""

import os
import threading
import time

import crt_noise
from crt_noise import FPS, tuning_logo_size
from seek_strip import skin_font


class TuningScreen:
    def __init__(self, window, addon, textures, title, clock=time.monotonic):
        import xbmcgui

        self.window = window
        self.clock = clock
        self.started = clock()
        self.frame = None
        self.logo = None
        self.logo_path = None
        width, height = window.getWidth(), window.getHeight()
        solid = os.path.join(addon.getAddonInfo("path"), "resources", "skins", "Default",
                             "media", "guide-solid.png")
        self.frames = []
        if textures:
            self.frames = [xbmcgui.ControlImage(0, 0, width, height, path)
                           for path in textures[0]]
            background = self.frames
        else:
            background = [xbmcgui.ControlImage(0, 0, width, height, solid,
                                                colorDiffuse="FF101722")]
        self.label = xbmcgui.ControlLabel(
            0, max(0, height // 2 - 20), width, 40, title,
            font=skin_font(), textColor="FFFFFFFF", alignment=6,
        )
        self.controls = background + [self.label]
        self.window.addControls(self.controls)
        self.animate()

    def set_title(self, title):
        self.label.setLabel(title)

    def set_logo(self, path):
        if self.logo_path == path:
            return
        import xbmcgui
        from guide import guide_logo_texture
        width, height = self.window.getWidth(), self.window.getHeight()
        w, h = tuning_logo_size(width, height)
        top = max(0, (height - h - 45) // 2)
        if path:
            texture = guide_logo_texture(path, w, h)
            if self.logo is None:
                self.logo = xbmcgui.ControlImage((width - w) // 2, top, w, h, texture, aspectRatio=2)
                self.window.addControl(self.logo)
                self.controls.append(self.logo)
            else:
                self.logo.setImage(texture)
            self.logo.setVisible(True)
        elif self.logo is not None:
            self.logo.setVisible(False)
        self.label.setPosition(0, top + h + 5 if path else max(0, height // 2 - 20))
        self.logo_path = path

    def animate(self):
        if not self.frames:
            return
        frame = int((self.clock() - self.started) * FPS) % len(self.frames)
        if frame == self.frame:
            return
        if self.frame is None:
            for index, control in enumerate(self.frames):
                control.setVisible(index == frame)
        else:
            self.frames[self.frame].setVisible(False)
            self.frames[frame].setVisible(True)
        self.frame = frame

    def close(self):
        self.window.removeControls(self.controls)


class StartupScreen:
    def __init__(self, addon, profile, title, log, cancelled, presentation=None):
        import xbmcgui

        class Window(xbmcgui.WindowXMLDialog):
            def onAction(self, action):
                if action.getId() in (10, 13, 92):
                    cancelled.set()

        self.window = Window("startup.xml", addon.getAddonInfo("path"), "Default", "1080i")
        self.window.show()
        self.stopped = threading.Event()
        self.worker = None
        self.tuning = None
        self.log = log
        self.presentation = presentation
        self.title = title
        try:
            textures = crt_noise.startup_textures(addon, profile)
            self.tuning = TuningScreen(self.window, addon, textures, title)
            if textures or presentation is not None:
                self.worker = threading.Thread(target=self._animate, name="magenta-startup", daemon=True)
                self.worker.start()
            if not textures:
                crt_noise.start_preparation(profile, addon)
        except Exception:
            self.window.close()
            raise

    def _animate(self):
        try:
            while not self.stopped.wait(1 / FPS):
                self.tuning.animate()
                if self.presentation is not None:
                    title, logo = self.presentation()
                    if title != self.title:
                        self.tuning.set_title(title)
                        self.title = title
                    self.tuning.set_logo(logo)
        except (RuntimeError, ValueError) as error:
            self.log("Startup animation failed: {}".format(type(error).__name__))

    def close(self):
        self.stopped.set()
        if self.worker is not None:
            self.worker.join()
        try:
            try:
                self.tuning.close()
            except RuntimeError as error:
                self.log("Startup screen cleanup failed: {}".format(type(error).__name__))
        finally:
            self.window.close()
