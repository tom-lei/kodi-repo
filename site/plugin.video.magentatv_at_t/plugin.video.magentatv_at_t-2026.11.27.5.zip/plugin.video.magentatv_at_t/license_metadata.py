"""Describe Widevine licence responses for diagnostics without exposing key material.

Only key IDs, enum-like levels, protection requirements, resolution constraints
and policy numbers are reported. Key, IV, key-control, session-key,
signature, client-token, licence-ID and URL fields are never decoded or logged.
"""

_MESSAGE_TYPES = {
    1: "LICENSE_REQUEST", 2: "LICENSE", 3: "ERROR_RESPONSE", 4: "SERVICE_CERTIFICATE_REQUEST",
    5: "SERVICE_CERTIFICATE", 6: "SUB_LICENSE", 7: "CAS_LICENSE_REQUEST", 8: "CAS_LICENSE",
    9: "EXTERNAL_LICENSE_REQUEST", 10: "EXTERNAL_LICENSE",
}
_LICENSE_TYPES = {1: "STREAMING", 2: "OFFLINE", 3: "AUTOMATIC"}
_KEY_TYPES = {1: "SIGNING", 2: "CONTENT", 3: "KEY_CONTROL", 4: "OPERATOR_SESSION",
              5: "ENTITLEMENT", 6: "OEM_CONTENT"}
_SECURITY_LEVELS = {1: "SW_SECURE_CRYPTO", 2: "SW_SECURE_DECODE", 3: "HW_SECURE_CRYPTO",
                    4: "HW_SECURE_DECODE", 5: "HW_SECURE_ALL"}
_HDCP = {0: "HDCP_NONE", 1: "HDCP_V1", 2: "HDCP_V2", 3: "HDCP_V2_1", 4: "HDCP_V2_2",
         5: "HDCP_V2_3", 0xff: "HDCP_NO_DIGITAL_OUTPUT"}
_CGMS = {0: "COPY_FREE", 2: "COPY_ONCE", 3: "COPY_NEVER", 42: "CGMS_NONE"}
_PLATFORM_VERIFICATION = {
    0: "PLATFORM_UNVERIFIED", 1: "PLATFORM_TAMPERED", 2: "PLATFORM_SOFTWARE_VERIFIED",
    3: "PLATFORM_HARDWARE_VERIFIED", 4: "PLATFORM_NO_VERIFICATION",
    5: "PLATFORM_SECURE_STORAGE_SOFTWARE_VERIFIED",
}
# Policy fields reported by number; renewal_server_url (8) is only noted as present.
_POLICY_FLAGS = {1: "can_play", 2: "can_persist", 3: "can_renew", 11: "renew_with_usage",
                 12: "always_include_client_id", 14: "soft_enforce_playback_duration",
                 15: "soft_enforce_rental_duration"}
_POLICY_SECONDS = {4: "rental_duration", 5: "playback_duration", 6: "license_duration",
                   7: "renewal_recovery_duration", 9: "renewal_delay", 10: "renewal_retry_interval",
                   13: "play_start_grace_period"}


class _Malformed(ValueError):
    pass


def _varint(data, position):
    value = shift = 0
    while True:
        if position >= len(data) or shift > 63:
            raise _Malformed
        byte = data[position]
        position += 1
        value |= (byte & 0x7f) << shift
        if not byte & 0x80:
            return value, position
        shift += 7


def _fields(data):
    """Yield (field number, wire type, value) for one protobuf message."""
    position = 0
    while position < len(data):
        tag, position = _varint(data, position)
        number, wire = tag >> 3, tag & 7
        if number == 0:
            raise _Malformed
        if wire == 0:
            value, position = _varint(data, position)
        elif wire in (1, 5):
            end = position + (8 if wire == 1 else 4)
            if end > len(data):
                raise _Malformed
            value, position = data[position:end], end
        elif wire == 2:
            length, position = _varint(data, position)
            end = position + length
            if end > len(data):
                raise _Malformed
            value, position = data[position:end], end
        else:
            raise _Malformed
        yield number, wire, value


def _name(names, value):
    return names.get(value, "UNKNOWN({})".format(value))


def _protection(data):
    parts = []
    for number, wire, value in _fields(data):
        if number == 1 and wire == 0:
            parts.append("hdcp=" + _name(_HDCP, value))
        elif number == 2 and wire == 0:
            parts.append("cgms=" + _name(_CGMS, value))
        elif number == 4 and wire == 0:
            parts.append("disable_analog_output=" + ("true" if value else "false"))
        elif number == 5 and wire == 0:
            parts.append("disable_digital_output=" + ("true" if value else "false"))
    return ",".join(parts) or "none"


def _resolution(data):
    minimum = maximum = None
    protection = "none"
    for number, wire, value in _fields(data):
        if number == 1 and wire == 0:
            minimum = value
        elif number == 2 and wire == 0:
            maximum = value
        elif number == 3 and wire == 2:
            protection = _protection(value)
    return "{}-{}px:{}".format("" if minimum is None else minimum,
                               "" if maximum is None else maximum, protection)


def _key(data):
    kid = key_type = level = None
    required = requested = "absent"
    constraints = []
    for number, wire, value in _fields(data):
        # Fields 2 (IV), 3 (key) and 8 (key control) are deliberately never read.
        if number == 1 and wire == 2:
            if len(value) == 16:
                kid = value
        elif number == 4 and wire == 0:
            key_type = _name(_KEY_TYPES, value)
        elif number == 5 and wire == 0:
            level = _name(_SECURITY_LEVELS, value)
        elif number == 6 and wire == 2:
            required = _protection(value)
        elif number == 7 and wire == 2:
            requested = _protection(value)
        elif number == 10 and wire == 2:
            constraints.append(_resolution(value))
    line = ("licence key: kid={} type={} level={} required_protection={} "
            "requested_protection={} video_resolution_constraints={}").format(
        kid.hex() if kid is not None else "none", key_type or "unset", level or "unset",
        required, requested, ";".join(constraints) or "none")
    return line, kid if key_type == "CONTENT" else None


def _policy(data):
    parts = []
    for number, wire, value in _fields(data):
        if number in _POLICY_FLAGS and wire == 0:
            parts.append("{}={}".format(_POLICY_FLAGS[number], "true" if value else "false"))
        elif number in _POLICY_SECONDS and wire == 0:
            parts.append("{}={}s".format(_POLICY_SECONDS[number], value))
        elif number == 8 and wire == 2:
            parts.append("renewal_server_url=present")
    return "licence policy: " + (" ".join(parts) or "none")


def _license(data):
    summary = []
    keys = []
    content_kids = set()
    policy = "licence policy: absent"
    for number, wire, value in _fields(data):
        # Field 1 (licence ID) holds request and session identifiers; only its type is reported.
        if number == 1 and wire == 2:
            for id_number, id_wire, id_value in _fields(value):
                if id_number == 4 and id_wire == 0:
                    summary.append("type=" + _name(_LICENSE_TYPES, id_value))
        elif number == 2 and wire == 2:
            policy = _policy(value)
        elif number == 3 and wire == 2:
            line, kid = _key(value)
            keys.append(line)
            if kid is not None:
                content_kids.add(kid)
        elif number == 5 and wire == 0:
            summary.append("remote_attestation_verified=" + ("true" if value else "false"))
        elif number == 7 and wire == 0:
            scheme = value.to_bytes(4, "big").decode("ascii", "replace") if value < 1 << 32 else ""
            summary.append("protection_scheme=" + (scheme if scheme.isalnum() else str(value)))
        elif number == 10 and wire == 0:
            summary.append("platform_verification=" + _name(_PLATFORM_VERIFICATION, value))
    summary.append("keys={}".format(len(keys)))
    return ["licence: " + " ".join(summary), policy] + keys, content_kids


def inspect_license(data):
    """Return diagnostic lines and CONTENT key IDs, never the key material."""
    try:
        message_type = body = None
        for number, wire, value in _fields(bytes(data)):
            # Fields 3 (signature) and 4 (session key) are deliberately never read.
            if number == 1 and wire == 0:
                message_type = value
            elif number == 2 and wire == 2:
                body = value
        if message_type != 2:
            return ["licence message type: " + (
                "absent" if message_type is None else _name(_MESSAGE_TYPES, message_type))], set()
        if body is None:
            return ["licence message type: LICENSE without a licence body"], set()
        return _license(body)
    except (_Malformed, TypeError, ValueError, OverflowError):
        return ["licence metadata unreadable"], set()
