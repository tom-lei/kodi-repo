"""Seek strip adapted from simpliTVᵀ (GPL-3.0-or-later)."""

import datetime
import math
import os
import uuid
import xml.etree.ElementTree as ET

from seek_timeline import clamp, strip_cells

STRIP_PROPERTY = "magentatv_at_t.seekstrip"
TILE_COLOR = "FF30485D"
TILE_ACTIVE_COLOR = "FF3B7593"
FADE = [("Visible", "effect=fade start=0 end=100 time=200"),
        ("Hidden", "effect=fade start=100 end=0 time=200")]


def skin_font(preferred=("font13", "font12", "font20", "font10")):
    import xbmc
    import xbmcaddon

    root = xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo("path")
    for folder in ("xml", "1080i", "720p"):
        path = os.path.join(root, folder, "Font.xml")
        if not os.path.isfile(path):
            continue
        try:
            fonts = [node.text for node in ET.parse(path).findall(".//font/name")]
        except (OSError, ET.ParseError) as error:
            xbmc.log("[Magenta TV AT] Cannot read skin fonts: {}".format(type(error).__name__),
                     xbmc.LOGWARNING)
            break
        for candidate in preferred:
            if candidate in fonts:
                return candidate
        if fonts:
            return fonts[0]
    xbmc.log("[Magenta TV AT] Using default overlay font for this skin", xbmc.LOGWARNING)
    return "font13"


def ruler_ticks(duration, edge, width, spacing):
    oldest = edge - duration
    step = next((seconds for seconds in (60, 120, 300, 600, 900, 1800, 3600, 7200, 14400, 28800)
                 if seconds * width >= spacing * duration), 86400)
    first = math.ceil(oldest / step) * step
    return [(round((stamp - oldest) * width / duration),
             datetime.datetime.fromtimestamp(stamp).strftime("%H:%M"))
            for stamp in range(first, math.floor(edge) + 1, step)]


class SeekStrip:
    """Non-focusable guide tiles with one marker for the current seek position."""

    def __init__(self, window, addon, condition="", logo=None, station="", *,
                 status=False, minimal=False):
        import xbmcgui
        from magenta_logo_layout import logo_box
        from guide import TIMELINE_MARKER_COLOR, TIMELINE_MARKER_WIDTH, guide_logo_texture

        self.window = window
        width, height = window.getWidth(), window.getHeight()
        self.height = height
        self.active = None
        self.left = max(1, int(width * 0.10))
        self.width = max(1, width - self.left)
        self.row = max(24, round(height * .036)) if status and not minimal else max(24, int(height * .0296))
        self.top = height - self.row * 2
        self.tile_y = self.top + self.row
        self.layout = self.ticks = None
        self.marker_x = None
        self.marker_width = min(self.width, TIMELINE_MARKER_WIDTH)
        self.shown = False
        self.owner = uuid.uuid4().hex
        solid = os.path.join(addon.getAddonInfo("path"), "resources", "skins", "Default",
                             "media", "guide-solid.png")
        font = skin_font()
        tile_font = skin_font(("font27", "font12", "font13") if status and not minimal
                              else ("font10", "font12", "font13"))

        def image(x, y, w, h, color):
            return xbmcgui.ControlImage(x, y, w, h, solid, colorDiffuse=color)

        def label(x, y, w, title, alignment, color="FFFFFFFF", size=font):
            return xbmcgui.ControlLabel(x, y, w, self.row, title, font=size,
                                         textColor=color, alignment=alignment)

        status_y = height - self.row if minimal else self.top - self.row
        self.status_y = status_y
        self.status = label(12, status_y, max(1, width - 24), "", 6) if status or minimal else None
        self.status_badge = None
        self.status_text = None
        if minimal:
            self.track_x = max(8, width // 10)
            self.track_width = max(1, width - 2 * self.track_x)
            track_y = min(height - 4, status_y + self.row - 7)
            self.track = image(self.track_x, track_y, self.track_width, 4, "FF607080")
            self.progress = image(self.track_x, track_y, 1, 4, "FFE20074")
            self.progress_marker = image(self.track_x, track_y - 3, 5, 10, "FFFFFFFF")
            w, h = logo_box(max(1, self.track_x - 8), self.row * 2 - 8)
            panel_height = max(h, self.row) if station else self.row
            self.controls = [image(0, height - panel_height, width, panel_height, "FF101722"), self.track,
                             self.progress, self.progress_marker, self.status]
            self.logo = None
            if station:
                self.logo_size = w, h
                x, y = (self.track_x - w) // 2, height - (panel_height + h) // 2
                self.logo = xbmcgui.ControlImage(x, y, w, h, "", aspectRatio=2)
                self.station_label = label(0, height - (panel_height + self.row) // 2,
                                           self.track_x, station, 6)
                self.controls.extend((self.logo, self.station_label))
            self._attach(condition)
            self.logo_path = None
            self.set_logo(logo)
            return
        background_top = status_y if status else self.top
        if status:
            self.status_badge = image(0, status_y + 3, 1, self.row - 6, "FF30485D")
            self.status_width = min(max(1, width - 12), max(180, round(width * .115)))
            self.status_bounds = None
        self.background = image(0, background_top, width, height - background_top, "FF101722")
        branding = image(0, self.top, self.left, self.row * 2, "FF202C3A")
        station_logo = None
        if logo:
            w, h = logo_box(max(1, self.left - 16), self.row * 2 - 8)
            station_logo = xbmcgui.ControlImage((self.left - w) // 2, height - self.row - h // 2,
                                               w, h, guide_logo_texture(logo, w, h), aspectRatio=2)
        station_name = label(4, height - self.row - self.row // 2,
                             max(1, self.left - 8), station, 6)
        self.tiles = [(image(self.left, self.tile_y, 1, self.row, TILE_COLOR),
                       label(self.left, self.tile_y, 1, "", 4, size=tile_font)) for _ in range(24)]
        self.tick_width = max(50, int(width * 0.055))
        self.ruler_y = self.top if status else self.top - 2
        self.ruler = [(image(self.left, self.tile_y - 5, 2, 5, "FF8B9AAF"),
                       label(self.left, self.ruler_y, self.tick_width, "", 6, "FFB8C6D8"))
                      for _ in range(min(32, self.width // self.tick_width + 1))]
        self.marker = image(self.left, self.top, self.marker_width, self.row * 2, TIMELINE_MARKER_COLOR)
        self.controls = [self.background, branding, station_name]
        if self.status is not None:
            self.controls += [self.status_badge, self.status]
        if station_logo is not None:
            self.controls.append(station_logo)
        self.controls += [control for pair in self.tiles + self.ruler for control in pair]
        self.controls.append(self.marker)
        self._attach(condition, station_logo, station_name)
        for tile in self.tiles + self.ruler:
            for control in tile:
                control.setVisible(False)

    def _attach(self, condition, station_logo=None, station_name=None):
        from guide import branding_fade

        self.window.addControls(self.controls)
        show = "String.IsEqual(Window.Property({}),{})".format(STRIP_PROPERTY, self.owner)
        for control in self.controls:
            animations = FADE
            if station_logo is not None and control in (station_logo, station_name):
                animations = FADE + branding_fade(control is station_logo, show)
            control.setAnimations(animations)
            control.setVisibleCondition("{} + [{}]".format(show, condition) if condition else show)

    def show(self, status=None):
        if self.status is not None and status != self.status_text:
            self.status.setLabel(status or "")
            self.status_text = status
        if not self.shown:
            self.window.setProperty(STRIP_PROPERTY, self.owner)
            self.shown = True

    def set_logo(self, path):
        if self.logo is None:
            return
        if self.logo_path != path:
            from guide import guide_logo_texture
            self.logo.setImage(guide_logo_texture(path, *self.logo_size) if path else "")
            self.logo_path = path
        self.logo.setVisible(bool(path))
        self.station_label.setVisible(not path)

    def show_progress(self, position, duration, pending, status):
        point = position if pending is None else pending
        x = round(clamp(point, duration) / duration * self.track_width)
        self.progress.setWidth(max(1, x))
        self.progress_marker.setPosition(self.track_x + min(self.track_width - 1, x), self.status_y + self.row - 10)
        self.show(status)

    def update(self, rows, position, duration, edge, pending, status=None):
        from guide import fit_event_label

        labelled = [(start, stop, (datetime.datetime.fromtimestamp(start).strftime("%H:%M"), title))
                    for start, stop, title in rows]
        cells = strip_cells(labelled, duration, edge, self.width)
        if len(cells) > len(self.tiles):
            cells = sorted(sorted(cells, key=lambda cell: cell[1], reverse=True)[:len(self.tiles)])
        if cells != self.layout:
            previous = self.layout or ()
            for index, (tile, label) in enumerate(self.tiles):
                cell = cells[index] if index < len(cells) else None
                old = previous[index] if index < len(previous) else None
                if cell == old:
                    continue
                text = ""
                if cell is not None:
                    x, width, (start_text, title) = cell
                    tile.setPosition(self.left + x, self.tile_y)
                    tile.setWidth(max(1, width - 1))
                    text = fit_event_label(start_text, title, width, self.height)
                    if text:
                        label.setPosition(self.left + x + 3, self.tile_y)
                        label.setWidth(width - 6)
                        label.setLabel(text)
                if (old is None) != (cell is None):
                    tile.setVisible(cell is not None)
                label.setVisible(bool(text))
            self.layout = cells
            relaid = True
        else:
            relaid = False
        ticks = ruler_ticks(duration, edge, self.width, self.tick_width * 1.5)
        if ticks != self.ticks:
            for index, (tick, label) in enumerate(self.ruler):
                if index < len(ticks):
                    x, title = ticks[index]
                    tick.setPosition(self.left + min(self.width - 2, x), self.tile_y - 5)
                    label_x = max(0, min(self.width - self.tick_width, x - self.tick_width // 2))
                    label.setPosition(self.left + label_x, self.ruler_y)
                    label.setLabel(title)
                tick.setVisible(index < len(ticks))
                label.setVisible(index < len(ticks))
            self.ticks = ticks
        point = position if pending is None else pending
        x = self.left + min(self.width - self.marker_width,
                            round(clamp(point, duration) / duration * self.width))
        if x != self.marker_x:
            self.marker.setPosition(x, self.top)
            self.marker_x = x
        offset = x - self.left
        active = next((index for index, (left, width, _) in enumerate(self.layout or ())
                       if left <= offset < left + width), None)
        if active != self.active or (relaid and active is not None):
            for index in {self.active, active} - {None}:
                self.tiles[index][0].setColorDiffuse(TILE_ACTIVE_COLOR if index == active else TILE_COLOR)
            self.active = active
        if self.status_badge is not None:
            width = min(78, self.status_width) if status == "LIVE" else self.status_width
            inset = min(6, (self.left + self.width - width) // 2)
            left = max(inset, min(self.left + self.width - width - inset,
                                  x + self.marker_width // 2 - width // 2))
            if (left, width) != self.status_bounds:
                self.status_badge.setPosition(left, self.status_y + 3)
                self.status_badge.setWidth(width)
                self.status.setPosition(left, self.status_y)
                self.status.setWidth(width)
                self.status_bounds = left, width
        self.show(status)

    def hide(self):
        if self.shown:
            if self.window.getProperty(STRIP_PROPERTY) == self.owner:
                self.window.clearProperty(STRIP_PROPERTY)
            self.shown = False

    def close(self):
        self.hide()
        self.window.removeControls(self.controls)
