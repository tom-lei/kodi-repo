"""Connect Magenta programme data to the adapted simpliTVᵀ guide."""

import datetime
import threading
import time
from collections import OrderedDict

from guide_support import LiveDataCancelled, LiveDataError
from magenta_guide_data import UTC, display_image_url, fetch_schedules
from magenta_guide_store import EPG_RETENTION, EPG_SECONDS
from magenta_playback import PlaybackError
from provider_error import ProviderError


PAGE_HOURS = 4
MAX_CACHED_PAGES = 16
MAX_DETAILS = 64
MAX_REPLAY = 128
REPLAY_SECONDS = 5 * 60


class ReplayCache:
    """Cache availability only; playback independently rechecks provider rights."""

    def __init__(self, backend, store=None, clock=time.time):
        self.backend, self.store, self.clock = backend, store, clock
        self.entries = OrderedDict()
        self.pending = OrderedDict()
        self.seen = set()
        self.lock = threading.Lock()
        self.worker = None
        self.closed = False

    def _remember(self, airing, value, until):
        self.entries[airing] = (value, until)
        self.entries.move_to_end(airing)
        while len(self.entries) > MAX_REPLAY:
            self.entries.popitem(last=False)

    def peek(self, airing):
        with self.lock:
            entry = self.entries.get(airing)
            if entry is not None and self.clock() < entry[1]:
                self.entries.move_to_end(airing)
                return entry
            self.entries.pop(airing, None)
            if self.store is not None and not self.closed and airing not in self.seen:
                self.seen.add(airing)
                if len(self.seen) > MAX_REPLAY:
                    self.seen.clear()
                    self.seen.add(airing)
                self.pending[airing] = None
                if len(self.pending) > MAX_REPLAY:
                    self.pending.popitem(last=False)
                if self.worker is None:
                    self.worker = threading.Thread(target=self._read_disk, name="magenta-replay-disk", daemon=True)
                    self.worker.start()
            return None

    def _read_disk(self):
        while True:
            with self.lock:
                if self.closed or not self.pending:
                    self.worker = None
                    return
                airing, _ = self.pending.popitem(last=False)
            try:
                value = self.store.read_replay(airing)
            except (OSError, ValueError, TypeError, RuntimeError) as error:
                self.store.log("Could not read cached Replay availability: {}".format(type(error).__name__))
                continue
            if value is not None:
                offer, until = value
                with self.lock:
                    if not self.closed and airing not in self.entries:
                        self._remember(airing, offer, min(until, offer.expires) if offer else until)

    def load(self, airing, cancelled):
        with self.lock:
            entry = self.entries.get(airing)
            if entry is not None and self.clock() < entry[1]:
                return entry[0]
        cached = self.store.read_replay(airing) if self.store is not None else None
        if cached is not None:
            value, until = cached
        else:
            value = self.backend.replay_offer(airing, cancelled)
            if cancelled():
                return None
            until = self.clock() + REPLAY_SECONDS
            if self.store is not None:
                self.store.write_replay(airing, value)
        with self.lock:
            self._remember(airing, value, min(until, value.expires) if value is not None else until)
        return value

    def close(self):
        with self.lock:
            self.closed = True
            self.pending.clear()
            worker = self.worker
        if worker is not None:
            worker.join()


class WindowObservations:
    """Read the last observed per-station buffer off the guide's UI thread."""

    def __init__(self, store, station_for):
        self.store, self.station_for = store, station_for
        self.entries = {}
        self.pending = OrderedDict()
        self.seen = set()
        self.lock = threading.Lock()
        self.worker = None
        self.closed = False
        self.revision = 0

    def peek(self, channel):
        with self.lock:
            station = self.station_for(channel)
            if not self.store or not station or not station.station_id or self.closed:
                return None
            identity = (station.number, station.station_id)
            if identity not in self.seen:
                self.seen.add(identity)
                self.pending[identity] = channel
                if self.worker is None:
                    self.worker = threading.Thread(target=self._read_disk, name="magenta-window-disk", daemon=True)
                    self.worker.start()
            return self.entries.get(identity)

    def _read_disk(self):
        while True:
            with self.lock:
                if self.closed or not self.pending:
                    self.worker = None
                    return
                identity, _ = self.pending.popitem(last=False)
            try:
                value = self.store.read_window(*identity)
            except (OSError, ValueError, TypeError, RuntimeError) as error:
                self.store.log("Could not read cached live window: {}".format(type(error).__name__))
                continue
            if value is not None:
                with self.lock:
                    if not self.closed:
                        self.entries[identity] = value
                        self.revision += 1

    def close(self):
        with self.lock:
            self.closed = True
            self.pending.clear()
            worker = self.worker
        if worker is not None:
            worker.join()


class ProgrammeDetails:
    def __init__(self, api, store=None):
        self.api = api
        self.store = store
        self.entries = OrderedDict()
        self.lock = threading.Lock()
        self.pending = OrderedDict()
        self.disk_seen = OrderedDict()
        self.disk_worker = None
        self.closed = False

    def peek(self, program_id):
        with self.lock:
            if program_id in self.entries:
                self.entries.move_to_end(program_id)
                return self.entries[program_id]
            if self.store is not None and not self.closed and program_id not in self.disk_seen:
                self.disk_seen[program_id] = None
                if len(self.disk_seen) > MAX_DETAILS:
                    self.disk_seen.popitem(last=False)
                self.pending[program_id] = None
                if len(self.pending) > MAX_DETAILS:
                    self.pending.popitem(last=False)
                if self.disk_worker is None:
                    self.disk_worker = threading.Thread(target=self._read_disk, name="magenta-details-disk",
                                                        daemon=True)
                    self.disk_worker.start()
            return None

    def _read_disk(self):
        while True:
            with self.lock:
                if self.closed or not self.pending:
                    self.disk_worker = None
                    return
                program_id, _ = self.pending.popitem(last=False)
            try:
                value = self.store.read_details(program_id)
            except (OSError, ValueError, TypeError, RuntimeError) as error:
                self.store.log("Could not read cached programme details: {}".format(type(error).__name__))
                continue
            if value is not None:
                with self.lock:
                    if not self.closed and program_id not in self.entries:
                        self._remember(program_id, value)

    def close(self):
        with self.lock:
            self.closed = True
            self.pending.clear()
            worker = self.disk_worker
        if worker is not None:
            worker.join()

    def _remember(self, program_id, value):
        self.entries[program_id] = value
        self.entries.move_to_end(program_id)
        while len(self.entries) > MAX_DETAILS:
            self.entries.popitem(last=False)

    def load(self, program_id):
        with self.lock:
            cached = self.entries.get(program_id)
        if cached is not None:
            return cached
        cached = self.store.read_details(program_id) if self.store else None
        if cached is not None:
            with self.lock:
                self._remember(program_id, cached)
            return cached
        response = self.api.program_details(program_id)
        details = response.get("details")
        description = details.get("description") if isinstance(details, dict) else None
        value = {"description": description.strip()[:8192] if isinstance(description, str) else "",
                 "artwork": display_image_url(response.get("poster_image_url"))}
        with self.lock:
            self._remember(program_id, value)
        if self.store:
            self.store.write_details(program_id, value)
        return value


def guide_events(programmes):
    events = []
    for item in programmes:
        event = {
            "id": item.program_id,
            "title": item.title,
            "start": datetime.datetime.fromtimestamp(item.start, UTC).isoformat(),
            "stop": datetime.datetime.fromtimestamp(item.stop, UTC).isoformat(),
            "tileChannel": {"codename": str(item.channel)},
        }
        if item.catchup is not None:
            event["is_catchup_enabled"] = item.catchup
        if item.start_over is not None:
            event["has_start_over"] = item.start_over
        events.append(event)
    return tuple(events)


class GuideCache:
    def __init__(self, api, channels, store=None, clock=time.time):
        self.api = api
        self.channels = {str(channel.number): channel for channel in channels}
        self.pages = OrderedDict()
        self.created = {}
        self.partial = set()
        self.store = store
        self.clock = clock
        self.lock = threading.RLock()
        self.revision = 0

    def update_channels(self, channels):
        updated = {str(channel.number): channel for channel in channels}
        with self.lock:
            if list(updated.items()) == list(self.channels.items()):
                return False
            self.channels = updated
            self.revision += 1
            self.pages.clear()
            self.created.clear()
            self.partial.clear()
            return True

    def peek(self, start, channels):
        key = (start, tuple(channels))
        with self.lock:
            stamp = self.created.get(key)
            if stamp is not None and not 0 <= self.clock() - stamp < EPG_RETENTION:
                self.pages.pop(key, None)
                self.created.pop(key, None)
                self.partial.discard(key)
            if key in self.pages:
                return self.pages[key]
            if self.store is not None:
                try:
                    selected = [self.channels[channel] for channel in channels]
                except KeyError:
                    return None
                entry = self.store.read_page(start, selected)
                if entry is None:
                    entry = self.store.read_available_page(start, selected)
                    if entry is not None:
                        self.partial.add(key)
                if entry is not None:
                    self._remember(key, entry[1], entry[0])
                    return entry[1]
            return None

    def _remember(self, key, events, created):
        self.pages[key] = events
        self.created[key] = created
        self.pages.move_to_end(key)
        while len(self.pages) > MAX_CACHED_PAGES:
            old, _ = self.pages.popitem(last=False)
            self.created.pop(old, None)
            self.partial.discard(old)

    def needs_refresh(self, start, channels):
        key = (start, tuple(channels))
        self.peek(start, channels)
        with self.lock:
            stamp = self.created.get(key)
            return (key in self.partial or stamp is None
                    or not 0 <= self.clock() - stamp < EPG_SECONDS)

    def load(self, start, channels, cancelled, publish):
        key = (start, tuple(channels))
        if cancelled():
            raise LiveDataCancelled()
        with self.lock:
            previous = self.peek(start, channels)
            if not self.needs_refresh(start, channels):
                return previous
            created = self.clock()
            revision = self.revision
            try:
                selected = [self.channels[channel] for channel in channels]
            except KeyError:
                raise LiveDataError("The selected guide channel is unavailable.") from None

        def request_cancelled():
            if cancelled():
                return True
            with self.lock:
                return revision != self.revision

        try:
            programmes, invalid = fetch_schedules(
                self.api, start, start + datetime.timedelta(hours=PAGE_HOURS),
                selected, request_cancelled,
            )
        except PlaybackError as error:
            if request_cancelled():
                raise LiveDataCancelled() from None
            raise LiveDataError(ProviderError.from_exception(error) or str(error)) from None
        events = guide_events(programmes)
        if request_cancelled():
            raise LiveDataCancelled()
        invalid += sum(channel.station_id is None for channel in selected)
        with self.lock:
            if revision != self.revision:
                raise LiveDataCancelled()
            if invalid:
                if previous is None:
                    publish(events)
                raise LiveDataError("The programme guide is incomplete.")
            self._remember(key, events, created)
            self.partial.discard(key)
            if self.store is not None:
                self.store.write_page(start, selected, events, created)
        return events
