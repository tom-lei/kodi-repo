"""Adapt Magenta's channel feed and UTC schedule blocks for the guide."""

import datetime
import re
from dataclasses import dataclass
from typing import Optional
from urllib.parse import parse_qsl, urlsplit

from channel_catalog import subscribed_channels
from magenta_experiment import _channel_number, _first
from magenta_playback import PlaybackError


UTC = datetime.timezone.utc
BLOCK_SECONDS = 3 * 60 * 60
MAX_WINDOW_SECONDS = 48 * 60 * 60
CODE = re.compile(r"[A-Za-z0-9_.-]{1,128}")


def display_image_url(value):
    if not isinstance(value, str) or not value or len(value) > 2048:
        return None
    try:
        parts = urlsplit(value)
        if (parts.scheme != "https" or parts.hostname != "tv-at-prod.yo-digital.com"
                or parts.port not in (None, 443)
                or parts.username is not None or parts.password is not None
                or parts.fragment or "\\" in value
                or any(ord(char) < 33 for char in value)):
            return None
        # Python before 3.11, including Kodi 21's Windows build, rejects "" under strict parsing.
        query = (parse_qsl(parts.query, keep_blank_values=True, strict_parsing=True)
                 if parts.query else [])
        if (len(query) > 2 or len({key for key, _ in query}) != len(query)
                or any(key not in ("w", "h") or not val.isascii() or not val.isdigit()
                       or not 1 <= int(val) <= 8192 for key, val in query)):
            return None
    except ValueError:
        return None
    return value


@dataclass(frozen=True)
class GuideChannel:
    number: int
    title: str
    station_id: Optional[str] = None
    logo: Optional[str] = None


@dataclass(frozen=True)
class Programme:
    channel: int
    start: int
    stop: int
    title: str
    program_id: str
    # The station's own Replay and start-over marks for this airing; None when absent.
    catchup: Optional[bool] = None
    start_over: Optional[bool] = None


def _flag(value):
    return value if isinstance(value, bool) else None


def _merge_flag(first, second):
    if first is None or first == second:
        return second
    return first if second is None else False


def guide_channels(subscriptions, feed):
    channels = feed.get("channels") if isinstance(feed, dict) else None
    if not isinstance(channels, list):
        raise PlaybackError("The provider channel feed is unavailable.")
    wanted = subscribed_channels(subscriptions)
    numbers = {number for number, _ in wanted}
    stations = {}
    for channel in channels:
        if not isinstance(channel, dict):
            raise PlaybackError("The provider returned an invalid channel feed.")
        number = _channel_number(_first(channel, "channel_number", "channelNumber"))
        if number not in numbers:
            continue
        if number in stations:
            raise PlaybackError("The provider returned duplicate feed channel numbers.")
        station = _first(channel, "station_id", "stationId")
        stations[number] = (station.strip() if isinstance(station, str) and station.strip() else None,
                            display_image_url(channel.get("channel_logo")))
    return [GuideChannel(number, title, *(stations.get(number) or (None, None))) for number, title in wanted]


def schedule_blocks(start, stop):
    if (not isinstance(start, datetime.datetime) or not isinstance(stop, datetime.datetime)
            or start.utcoffset() is None or stop.utcoffset() is None):
        raise PlaybackError("The programme guide window must include a time zone.")
    start, stop = start.astimezone(UTC), stop.astimezone(UTC)
    if stop <= start or (stop - start).total_seconds() > MAX_WINDOW_SECONDS:
        raise PlaybackError("The programme guide window is invalid.")
    cursor = start.replace(hour=(start.hour // 3) * 3, minute=0, second=0, microsecond=0)
    result = []
    while cursor < stop:
        result.append((cursor.strftime("%Y-%m-%d"), cursor.hour))
        cursor += datetime.timedelta(seconds=BLOCK_SECONDS)
    return result


def schedule_timestamp(value):
    if not isinstance(value, str):
        raise ValueError
    value = value.replace("Z", "+00:00")
    # Kodi's Python 3.8 accepts three/six fractional digits, not Magenta's two.
    value = re.sub(r"\.(\d{1,6})(?=[+-]\d{2}:\d{2}$)",
                   lambda match: "." + match.group(1).ljust(6, "0"), value)
    parsed = datetime.datetime.fromisoformat(value)
    if parsed.utcoffset() is None:
        raise ValueError
    return parsed.timestamp()


def parse_schedules(blocks, channels):
    by_station = {}
    for channel in channels:
        if channel.station_id is not None:
            by_station.setdefault(channel.station_id, []).append(channel.number)
    events = {}
    invalid = 0
    for block in blocks:
        station_map = block.get("channels") if isinstance(block, dict) else None
        if not isinstance(station_map, dict):
            raise PlaybackError("The provider returned an invalid programme schedule.")
        for station, numbers in by_station.items():
            items = station_map.get(station, [])
            if not isinstance(items, list):
                raise PlaybackError("The provider returned an invalid programme schedule.")
            for item in items:
                try:
                    start = int(schedule_timestamp(item["start_time"]))
                    stop = int(schedule_timestamp(item["end_time"]))
                    if stop <= start:
                        raise ValueError
                    title = item.get("description") or item.get("title") or ""
                    program_id = item.get("program_id") or ""
                    if isinstance(program_id, int) and not isinstance(program_id, bool):
                        program_id = str(program_id)
                    if not isinstance(title, str) or not isinstance(program_id, str):
                        raise ValueError
                    entitlements = item.get("entitlements")
                    catchup = _flag(item.get("is_catchup_enabled"))
                    start_over = _flag(entitlements.get("hasStartOver")
                                       if isinstance(entitlements, dict) else None)
                except (KeyError, TypeError, ValueError, OverflowError, OSError):
                    invalid += 1
                    continue
                # Programme IDs repeat across simulcast stations with different
                # flags, so the flags always come from this station's record.
                for number in numbers:
                    key = (number, start, stop, title.strip(), program_id)
                    known = events.get(key)
                    flags = (catchup, start_over) if known is None else (
                        _merge_flag(known.catchup, catchup),
                        _merge_flag(known.start_over, start_over))
                    events[key] = Programme(*key, *flags)
    return sorted(events.values(), key=lambda event: (event.channel, event.start, event.stop)), invalid


def fetch_schedules(api, start, stop, channels, cancelled):
    blocks = []
    for date, offset in schedule_blocks(start, stop):
        if cancelled():
            raise PlaybackError("Programme guide loading was cancelled.")
        blocks.append(api.schedules(date, offset))
    if cancelled():
        raise PlaybackError("Programme guide loading was cancelled.")
    return parse_schedules(blocks, channels)
