"""Use only the separate Magenta add-on's Kodi settings for credentials."""

import uuid


ADDON_ID = "plugin.video.magentatv_at_t"


class CredentialsCancelled(Exception):
    pass


class CredentialsIncomplete(Exception):
    pass


class CredentialSettingsError(Exception):
    pass


def device_id(settings):
    try:
        value = settings.getSettingString("device_id")
        if not value:
            value = str(uuid.uuid4())
            if not settings.setSettingString("device_id", value):
                raise CredentialSettingsError()
        return str(uuid.UUID(value))
    except (RuntimeError, TypeError, ValueError, AttributeError):
        raise CredentialSettingsError() from None


def load_or_prompt(settings, prompt, aborted):
    try:
        username = settings.getSettingString("username")
        password = settings.getSettingString("password")
    except (RuntimeError, TypeError, ValueError):
        raise CredentialSettingsError() from None
    if not isinstance(username, str) or not isinstance(password, str):
        raise CredentialSettingsError()

    username_changed = not username or not username.strip()
    password_changed = username_changed or not password
    if username_changed:
        username = prompt("Magenta account", hidden=False)
        if username is None or aborted():
            raise CredentialsCancelled()
        if not username.strip():
            raise CredentialsIncomplete()
    if password_changed:
        password = prompt("Magenta password", hidden=True)
        if password is None or aborted():
            raise CredentialsCancelled()
        if not password:
            raise CredentialsIncomplete()
    if aborted():
        raise CredentialsCancelled()

    try:
        if username_changed and not settings.setSettingString("username", username):
            raise CredentialSettingsError()
        if password_changed and not settings.setSettingString("password", password):
            raise CredentialSettingsError()
    except (RuntimeError, TypeError, ValueError):
        raise CredentialSettingsError() from None
    return username, password
