"""Provider-independent helpers adapted from simpliTVᵀ (GPL-3.0-or-later)."""

import datetime


ACCESS_TEXT = (
    {"loading": "Checking channels…", "error": "Channels are unavailable",
     "partial": "Channel information is incomplete", "empty": "No subscribed channels",
     "settings": "Settings", "hint": "Check your account settings."},
    {"loading": "Sender werden geprüft…", "error": "Sender sind nicht verfügbar",
     "partial": "Senderinformationen sind unvollständig", "empty": "Keine abonnierten Sender",
     "settings": "Einstellungen", "hint": "Kontoeinstellungen prüfen."},
)


class LiveDataError(RuntimeError):
    pass


class LiveDataCancelled(RuntimeError):
    pass


def broadcast_timestamp(value):
    try:
        parsed = datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.utcoffset() is None:
            raise ValueError
        return parsed.timestamp()
    except (AttributeError, TypeError, ValueError, OverflowError, OSError):
        raise LiveDataError("Invalid programme timestamp") from None


def format_duration(seconds):
    seconds = max(0, int(seconds))
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)
    return "{:02d}:{:02d}:{:02d}".format(hours, minutes, seconds)
