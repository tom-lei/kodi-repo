"""Disposable-profile service entry point, not connected to the shipped add-on."""

import json
import os
import threading
import time
import uuid
import ctypes

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from credential_settings import (
    ADDON_ID, CredentialSettingsError, CredentialsCancelled, CredentialsIncomplete,
    load_or_prompt,
)
from dash_video import load_video_ladder
from magenta_auth import AuthError, client_platform, open_session
from magenta_experiment import (
    Bff, compare_live_inputs, select_feed_channel, widevine_query_config,
)
from license_probe import LicenseProbe
from magenta_playback import (
    CleanupUnconfirmed, ConcurrencyLease, LockedPlayback,
    PlaybackError, entitled_live_media, lock_transport, player_seconds, player_stream_events,
)


# "media" (default) plays /media video_src and video.pid. "feed" is an explicit
# opt-in that plays /epg/channel video_src_dash with pid_dash, following Ultimate
# Backend. Both sources still take, renew and release the normal /media lock.
LIVE_INPUT_SOURCE = "media"

_events = []
_events_lock = threading.Lock()
_profile_path = xbmcvfs.translatePath("special://profile/")
_status_path = os.path.join(_profile_path, "magenta-test-status.json")
_observation_ack = os.path.join(_profile_path, "magenta-observation-ack")


def report(event):
    with _events_lock:
        _events.append(event)
        with open(_status_path, "w", encoding="utf-8") as file:
            json.dump(_events, file)


def keyboard(heading, hidden=False):
    monitor = xbmc.Monitor()
    done = threading.Event()

    def wait_for_dialog():
        while not done.is_set() and not monitor.abortRequested():
            if xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
                report("password dialog ready" if hidden else "account dialog ready")
                return
            done.wait(0.1)

    watcher = threading.Thread(target=wait_for_dialog, daemon=True)
    watcher.start()
    dialog = xbmc.Keyboard("", heading, hidden)
    try:
        dialog.doModal()
        return dialog.getText() if dialog.isConfirmed() else None
    finally:
        done.set()
        watcher.join(timeout=1)


def choose_channel(subscriptions):
    channels = subscriptions.get("channels")
    if not isinstance(channels, list):
        raise PlaybackError("Subscribed channels are unavailable.")
    for channel in channels:
        if (isinstance(channel, dict) and isinstance(channel.get("title"), str)
                and channel["title"].casefold().replace(" ", "") in ("orf1", "orf1hd")
                and isinstance(channel.get("channel_number"), int)
                and not isinstance(channel["channel_number"], bool)):
            return channel["channel_number"]
    raise PlaybackError("The subscribed ORF 1 channel was not found.")


def make_player():
    class ObservedPlayer(xbmc.Player):
        def __init__(self):
            super().__init__()
            self.stop_reason = None
            self.stopping = False

        def onPlayBackStarted(self):
            report("Kodi playback started callback")

        def onAVStarted(self):
            report("Kodi AV started callback")

        def onPlayBackError(self):
            if not self.stopping:
                self.stop_reason = "Kodi playback error callback"

        def onPlayBackStopped(self):
            if not self.stopping:
                self.stop_reason = "Kodi playback stopped callback"

        def onPlayBackEnded(self):
            if not self.stopping:
                self.stop_reason = "Kodi playback ended callback"

        def stop(self):
            self.stopping = True
            super().stop()

    return ObservedPlayer()


def kodi_is_foreground():
    try:
        user32 = ctypes.windll.user32
        user32.GetForegroundWindow.restype = ctypes.c_void_p
        user32.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        process_id = ctypes.c_ulong()
        window = user32.GetForegroundWindow()
        if not window:
            return None
        user32.GetWindowThreadProcessId(window, ctypes.byref(process_id))
        return process_id.value == os.getpid()
    except (AttributeError, OSError):
        return None


def _yes_no(value):
    return "unavailable" if value is None else "yes" if value else "no"


def _jsonrpc(method, params=None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        request["params"] = params
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except (RuntimeError, TypeError, ValueError):
        return None
    return response.get("result") if isinstance(response, dict) else None


def jsonrpc_player_properties():
    players = _jsonrpc("Player.GetActivePlayers")
    if not isinstance(players, list):
        return None
    for active in players:
        if isinstance(active, dict) and active.get("type") == "video" and isinstance(active.get("playerid"), int):
            return _jsonrpc("Player.GetProperties", {
                "playerid": active["playerid"],
                "properties": ["time", "speed", "currentvideostream", "currentaudiostream"],
            })
    return None


def play_one(session, monitor):
    def check_abort():
        if monitor.abortRequested():
            raise PlaybackError("The test was cancelled.")

    if LIVE_INPUT_SOURCE not in ("media", "feed"):
        raise PlaybackError("Unknown live input source.")
    report("live input source: " + LIVE_INPUT_SOURCE)
    bff = Bff(session)
    check_abort()
    bff.user_account()
    check_abort()
    number = choose_channel(bff.subscriptions())
    report("subscribed channel found")
    check_abort()
    info = bff.playinfo(number)
    media_id = entitled_live_media(info)
    playback = info["playBackInfoResponse"]
    if playback.get("type") != "live":
        raise PlaybackError("The provider did not return a live channel.")
    report("playinfo rights accepted")
    check_abort()
    feed_inputs = None
    if LIVE_INPUT_SOURCE == "feed":
        feed_inputs = select_feed_channel(bff.channel_feed(), number)
        report("feed channel inputs accepted")
        check_abort()
    report("requesting media; lock outcome may be unknown if interrupted")
    media = bff.media(media_id, playback["type"])
    lock = media.get("lock")
    if not isinstance(lock, dict):
        report("lock release unconfirmed")
        raise PlaybackError("The media response did not contain a releasable lock.")
    lease = ConcurrencyLease(lock, session.device_id, session.constants["NATCO_KEY"], lock_transport)
    player = make_player()
    probe = None
    try:
        with LockedPlayback(player, lease):
            lease._url("unlock")
            lease.start_renewal()
            video = media.get("video")
            if feed_inputs is None:
                if not isinstance(video, dict):
                    raise PlaybackError("The media response did not contain a video.")
                url = video.get("video_src")
                release_pid = video.get("pid")
            else:
                url, release_pid = feed_inputs
                pid_match, host_match, path_match = compare_live_inputs(url, release_pid, video)
                report("feed PID matches media PID: " + _yes_no(pid_match))
                report("feed manifest host matches media: " + _yes_no(host_match))
                report("feed manifest path matches media: " + _yes_no(path_match))
            if not isinstance(url, str) or not url.startswith("https://"):
                raise PlaybackError("The media response did not contain a usable HTTPS stream.")
            drm = widevine_query_config(session.access_token, release_pid)
            check_abort()

            def cleanup_before_failure_reaches_kodi():
                report("early cleanup after licence failure")
                try:
                    lease.release()
                    report("unlock response received")
                except CleanupUnconfirmed as error:
                    report("cleanup unconfirmed: " + str(error))
                try:
                    session.close()
                    report("logout HTTP success")
                except AuthError:
                    report("logout unconfirmed")

            ladder = load_video_ladder(url, xbmcvfs.File,
                                       lambda msg: xbmc.log("[Magenta TV AT] " + msg, xbmc.LOGINFO))
            probe = LicenseProbe(drm, report, on_failure=cleanup_before_failure_reaches_kodi,
                                 video_ladder=ladder)
            drm = probe.__enter__()
            item = xbmcgui.ListItem(path=url, offscreen=True)
            item.setMimeType("application/dash+xml")
            item.setContentLookup(False)
            item.setProperty("inputstream", "inputstream.adaptive")
            item.setProperty("inputstream.adaptive.drm_legacy", drm)
            report("starting player")
            started_at = time.monotonic()
            player.play(url, item)
            started = False
            first_time = None
            video_observed = False
            audio_observed = False
            fullscreen_requested = False
            fullscreen_observed = False
            window_check_reported = False
            ready_at = None
            observation_deadline = None
            next_rpc_check = 0
            rpc_first_time = None
            rpc_reported = set()
            rpc_unavailable_reported = False
            while not monitor.abortRequested() and time.monotonic() - started_at < 150:
                if probe.in_flight:
                    # Avoid Kodi player calls while ISA waits for the licence relay.
                    time.sleep(0.2)
                    continue
                if player.stop_reason:
                    report(player.stop_reason)
                    break
                if probe.failed:
                    report("licence denied or redirected")
                    break
                if lease.renew_if_due():
                    report("renewal response received")
                now = time.monotonic()
                if ready_at is not None and observation_deadline is None:
                    if os.path.isfile(_observation_ack):
                        observation_deadline = min(now + 90, started_at + 150)
                        report("observation window started")
                    elif now - ready_at >= 30:
                        report("observation acknowledgement timed out")
                        break
                if observation_deadline is not None and now >= observation_deadline:
                    report("observation time expired")
                    break
                if player.isPlayingVideo():
                    if not started:
                        started = True
                        report("Kodi video player started")
                    if not fullscreen_requested:
                        xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
                        fullscreen_requested = True
                    if not fullscreen_observed and xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
                        fullscreen_observed = True
                        foreground = kodi_is_foreground()
                        report("Kodi fullscreen active")
                        report("Kodi foreground" if foreground is True else
                               "Kodi not foreground" if foreground is False else
                               "Kodi foreground unverified")
                        report("playback ready for observation")
                        ready_at = time.monotonic()
                        xbmcgui.Dialog().notification(
                            "Magenta TV AT", "Please watch and listen now", time=10000
                        )
                    try:
                        current = player.getTime()
                        if first_time is None:
                            first_time = current
                        elif current > first_time + 2 and not video_observed:
                            video_observed = True
                            report("player clock advanced")
                        if player.getAvailableAudioStreams() and not audio_observed:
                            audio_observed = True
                            report("Kodi reports an audio stream")
                    except RuntimeError:
                        pass
                elif not started and time.monotonic() - started_at >= 30:
                    raise PlaybackError("Kodi did not start the video player.")
                if started and not fullscreen_observed and not window_check_reported and (
                        time.monotonic() - started_at >= 10):
                    window_check_reported = True
                    report("Kodi fullscreen unconfirmed")
                if started and not fullscreen_observed and time.monotonic() - started_at >= 30:
                    report("Kodi fullscreen timed out")
                    break
                if started and now >= next_rpc_check:
                    next_rpc_check = now + 2
                    properties = jsonrpc_player_properties()
                    if properties is None:
                        if not rpc_unavailable_reported:
                            rpc_unavailable_reported = True
                            report("JSON-RPC player properties unavailable")
                    else:
                        for event in player_stream_events(properties):
                            if event not in rpc_reported:
                                rpc_reported.add(event)
                                report(event)
                        seconds = player_seconds(properties)
                        if seconds is not None:
                            if rpc_first_time is None:
                                rpc_first_time = seconds
                            elif seconds > rpc_first_time + 2 and "time" not in rpc_reported:
                                rpc_reported.add("time")
                                report("JSON-RPC time advanced")
                monitor.waitForAbort(0.5)
            else:
                report("Kodi shutdown requested" if monitor.abortRequested()
                       else "diagnostic time limit reached")
    finally:
        try:
            report("unlock response received" if lease.unlock_response_received
                   else "lock release unconfirmed")
        finally:
            if probe is not None:
                probe.__exit__(None, None, None)


def run():
    monitor = xbmc.Monitor()
    report("service started")
    try:
        settings = xbmcaddon.Addon(ADDON_ID)
        username, password = load_or_prompt(settings, keyboard, monitor.abortRequested)
    except CredentialsCancelled:
        report("cancelled before sign-in")
        return
    except CredentialsIncomplete:
        report("credentials incomplete")
        xbmcgui.Dialog().ok("Magenta TV AT", "Account and password are required.")
        return
    except (CredentialSettingsError, RuntimeError):
        report("credential settings unavailable")
        xbmcgui.Dialog().ok(
            "Magenta TV AT", "Could not read or save the Magenta add-on settings."
        )
        return
    session = None
    try:
        session = open_session(username, password, str(uuid.uuid4()),
                               client_platform(xbmc.getCondVisibility))
        username = password = None
        report("sign-in succeeded")
        play_one(session, monitor)
    except CleanupUnconfirmed as error:
        report("cleanup unconfirmed: " + str(error))
    except AuthError as error:
        report("stopped: " + str(error))
        xbmcgui.Dialog().ok(
            "Magenta TV AT",
            "Sign-in failed. Check the account and password in the add-on settings.",
        )
    except PlaybackError as error:
        report("stopped: " + str(error))
    except Exception as error:
        report("unexpected error: " + type(error).__name__)
        raise
    finally:
        username = password = None
        if session is not None and not getattr(session, "_closed", False):
            try:
                session.close()
                report("logout HTTP success")
            except AuthError:
                report("logout unconfirmed")
        report("service finished")


if __name__ == "__main__":
    try:
        run()
    finally:
        xbmc.executebuiltin("Quit")
