"""Extract classified diagnostics without copying free text from Kodi logs."""

import re
import sys


_LEVEL = re.compile(r"\b(error|warning)(?:\s+<[^>\r\n]+>)?\s*:", re.IGNORECASE)
_CATEGORIES = (
    ("inputstream.adaptive", re.compile(r"\binputstream[._ ]adaptive\b", re.I)),
    ("Widevine", re.compile(r"\bwidevine\b", re.I)),
    ("CDM", re.compile(r"\b(?:cdm|content decryption module)\b", re.I)),
    ("decrypter", re.compile(r"\b(?:decrypt(?:er|ion)?|drm)\b", re.I)),
    ("VideoPlayer", re.compile(r"\bvideoplayer\b", re.I)),
    ("demux", re.compile(r"\bdemux(?:er|ing)?\b", re.I)),
    ("codec", re.compile(r"\b(?:codec|decoder|decoding)\b", re.I)),
    ("manifest", re.compile(r"\b(?:manifest|mpd)\b", re.I)),
    ("stream selection", re.compile(r"\b(?:stream|representation|adaptation set)\b", re.I)),
)
_DETAILS = (
    ("initialization failed", re.compile(r"\b(?:failed to initiali[sz]e|initiali[sz]ation failed|could not initiali[sz]e)\b", re.I)),
    ("creation failed", re.compile(r"\b(?:failed to create|could not create|creation failed)\b", re.I)),
    ("open failed", re.compile(r"\b(?:failed to open|could not open|unable to open|open failed)\b", re.I)),
    ("download failed", re.compile(r"\b(?:failed to download|download failed|could not download)\b", re.I)),
    ("parse failed", re.compile(r"\b(?:failed to parse|parse failed|parsing failed|could not parse)\b", re.I)),
    ("not found", re.compile(r"\b(?:not found|could not find|unable to find)\b", re.I)),
    ("not supported", re.compile(r"\b(?:not supported|unsupported)\b", re.I)),
    ("licence request failed", re.compile(r"\b(?:licen[cs]e|key)\b.{0,80}\b(?:failed|error|denied)\b", re.I)),
    ("decryption failed", re.compile(r"\b(?:decrypt(?:ion)? failed|failed to decrypt|decrypter failed)\b", re.I)),
    ("licence server returned failure", re.compile(r"\blicense server returned failure\b", re.I)),
    ("licence update returned no keys", re.compile(r"\blicense update not successful \(no keys\)", re.I)),
    ("CDM returned no key", re.compile(r'\breturned cdm status "kNoKey"', re.I)),
    ("licence response could not be read", re.compile(r"\bcould not read full sessionmessage response\b", re.I)),
    ("unsupported licence request template", re.compile(r"\bunsupported license request template\b", re.I)),
    ("Widevine library could not be loaded", re.compile(r"\bunable to load widevine shared library\b", re.I)),
)
_LICENCE = re.compile(r"\b(?:licen[cs]e|widevine)\b", re.I)
_STATUS = re.compile(r"\b(?:http(?: status| response| error)?|status(?: code)?|response code)\s*[:= ]\s*([1-5][0-9]{2})\b", re.I)
_URL = re.compile(r"\b[a-z][a-z0-9+.-]*://[^\s\"'<>]+", re.I)


def extract_lines(lines):
    """Return fixed labels and, when explicit, a licence HTTP status only."""
    extracted = []
    for line in lines:
        line = _URL.sub(" ", line)
        level = _LEVEL.search(line)
        if not level:
            continue
        categories = [name for name, pattern in _CATEGORIES if pattern.search(line)]
        if not categories:
            continue
        details = [name for name, pattern in _DETAILS if pattern.search(line)]
        status = _STATUS.search(line) if _LICENCE.search(line) else None
        record = level.group(1).upper() + ": " + ", ".join(categories)
        if details:
            record += " | " + ", ".join(details)
        if status:
            record += " | licence HTTP " + status.group(1)
        extracted.append(record)
    return extracted


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: native_log_extract.py input.log output.txt")
    with open(sys.argv[1], encoding="utf-8-sig", errors="replace") as source:
        records = extract_lines(source)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        destination.write("\n".join(records) + ("\n" if records else ""))
