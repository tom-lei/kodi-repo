"""Number-key entry for Magenta's provider channel numbers, shared by the guide and the player."""

SETTINGS_SHORTCUT = "settings"


def _valid(number):
    return type(number) is int and number >= 0


class ChannelNumber:
    """Collect remote digits (Kodi REMOTE_0..9 = action ids 58..67) like a TV.

    numbers maps channel code -> provider channel number. Pass the caller's dict so
    a lineup refresh also updates the digit limit and the 000 shortcut.
    """

    TIMEOUT = 1.5

    def __init__(self, numbers=None):
        self.numbers = numbers if numbers is not None else {}
        self.digits = ""
        self.until = 0.0
        self.truncated = False

    def width(self):
        values = [number for number in self.numbers.values() if _valid(number)]
        return max(3, len(str(max(values)))) if values else 3

    def press(self, action_id, now):
        if not 58 <= action_id <= 67:
            return None
        if now >= self.until:
            self.digits = ""
            self.truncated = False
        width = self.width()
        self.truncated |= len(self.digits) >= width
        self.digits = (self.digits + str(action_id - 58))[-width:]
        self.until = now + self.TIMEOUT
        return self.digits

    def is_settings(self):
        # A real provider channel 0 takes precedence over the shortcut.
        return (self.digits == "000" and not self.truncated
                and not any(number == 0 and _valid(number) for number in self.numbers.values()))

    def take(self, now, confirm=False):
        if not self.digits or not confirm and now < self.until:
            return None
        number = SETTINGS_SHORTCUT if self.is_settings() else int(self.digits)
        self.clear()
        return number

    def clear(self):
        self.digits = ""
        self.truncated = False


def number_text(number):
    return str(number) if _valid(number) else ""


def numbered(number, title):
    prefix = number_text(number)
    title = title or ""
    if not prefix or title.startswith(prefix + "  "):
        return title
    return "{}  {}".format(prefix, title) if title else prefix


def number_channel(number, numbers, visible):
    """Return (code, "") for a visible channel, (code, "hidden") or (None, "unknown")."""
    matches = [code for code, value in numbers.items() if _valid(value) and value == number]
    if not matches:
        return None, "unknown"
    channel = next((code for code in matches if code in visible), None)
    return (channel, "") if channel is not None else (matches[0], "hidden")


def number_status(digits, numbers, visible, channel_name, german=False, settings_shortcut=False,
                  final=False):
    """Describe typed digits; final drops the entry cursor once the number was taken."""
    typed = digits if final else digits + "_"
    if settings_shortcut:
        return "{}  →  {}".format(typed, "Einstellungen" if german else "Settings")
    number = int(digits)
    channel, reason = number_channel(number, numbers, visible)
    if reason == "unknown":
        return "{}  →  {} {}".format(typed, number, "nicht belegt" if german else "not assigned")
    title = channel_name(channel) or channel
    suffix = " (ausgeblendet)" if german else " (hidden)"
    return "{}  →  {} {}{}".format(typed, number, title, suffix if reason else "")
