"""Bounded, dependency-free alpha cropping for catalogue PNG logos."""

import struct
import time
import zlib

RULE_VERSION = 1
MAX_BYTES = 8 * 1024 * 1024
MAX_DIMENSION = 4096
MAX_DECODED = 64 * 1024 * 1024
MAX_PROCESS_SECONDS = 10
ALPHA_THRESHOLD = 8
SIGNATURE = b"\x89PNG\r\n\x1a\n"


class UnsupportedPNG(ValueError):
    """Leave other formats, bit depths and interlaced PNGs to Kodi."""


def _chunk(kind, data):
    return (struct.pack(">I", len(data)) + kind + data
            + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff))


def _paeth(a, b, c):
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    return a if pa <= pb and pa <= pc else b if pb <= pc else c


def _rows(raw, width, height, channels, deadline):
    stride = width * channels
    previous = bytearray(stride)
    for y in range(height):
        if y % 16 == 0 and time.monotonic() >= deadline:
            raise ValueError("Logo processing time limit exceeded")
        offset = y * (stride + 1)
        kind = raw[offset]
        row = bytearray(raw[offset + 1:offset + stride + 1])
        if kind == 1:
            for x in range(channels, stride):
                row[x] = (row[x] + row[x - channels]) & 255
        elif kind == 2:
            row = bytearray((value + above) & 255 for value, above in zip(row, previous))
        elif kind in (3, 4):
            for x in range(stride):
                left = row[x - channels] if x >= channels else 0
                above_left = previous[x - channels] if x >= channels else 0
                predictor = ((left + previous[x]) // 2 if kind == 3 else
                             _paeth(left, previous[x], above_left))
                row[x] = (row[x] + predictor) & 255
        elif kind != 0:
            raise ValueError("Invalid PNG filter")
        yield row
        previous = row


def _crop(data, deadline):
    """Crop alpha >= 8 bounds; preserve all colour and alpha inside the bounds.

    Output is an 8-bit RGBA PNG. Unsupported encodings must use the caller's
    ordinary Kodi image fitting, not a guessed crop or background colour.
    """
    if len(data) > MAX_BYTES:
        raise ValueError("Logo exceeds size limit")
    if not data.startswith(SIGNATURE):
        raise UnsupportedPNG("Not a PNG")
    offset, header, palette, transparency = 8, None, None, None
    compressed = bytearray()
    ended = False
    while offset < len(data):
        if offset + 12 > len(data):
            raise ValueError("Truncated PNG chunk")
        length, kind = struct.unpack_from(">I4s", data, offset)
        end = offset + length + 12
        if end > len(data):
            raise ValueError("Truncated PNG chunk")
        payload = data[offset + 8:end - 4]
        if zlib.crc32(kind + payload) & 0xffffffff != struct.unpack_from(">I", data, end - 4)[0]:
            raise ValueError("Invalid PNG checksum")
        if header is None and kind != b"IHDR":
            raise ValueError("Missing PNG header")
        if kind == b"IHDR":
            if header is not None or length != 13:
                raise ValueError("Invalid PNG header")
            header = struct.unpack(">IIBBBBB", payload)
        elif kind == b"PLTE":
            palette = payload
        elif kind == b"tRNS":
            transparency = payload
        elif kind == b"IDAT":
            compressed.extend(payload)
        elif kind == b"IEND":
            if length:
                raise ValueError("Invalid PNG end")
            ended = True
            break
        elif not kind[0] & 32:
            raise UnsupportedPNG("Unknown critical PNG chunk")
        offset = end
    if not ended or header is None:
        raise ValueError("Incomplete PNG")
    width, height, depth, colour, compression, filtering, interlace = header
    if not 0 < width <= MAX_DIMENSION or not 0 < height <= MAX_DIMENSION:
        raise ValueError("Logo dimensions exceed limit")
    if compression or filtering or interlace or depth != 8 or colour not in (0, 2, 3, 4, 6):
        raise UnsupportedPNG("Unsupported PNG encoding")
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[colour]
    expected = height * (width * channels + 1)
    if max(expected, height * (width * 4 + 1)) > MAX_DECODED:
        raise ValueError("Decoded logo exceeds size limit")
    decoder = zlib.decompressobj()
    try:
        raw = decoder.decompress(bytes(compressed), expected + 1)
    except zlib.error:
        raise ValueError("Invalid compressed PNG") from None
    if len(raw) != expected or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
        raise ValueError("Invalid PNG pixel size")
    if colour == 3 and (not palette or len(palette) % 3 or len(palette) > 768):
        raise ValueError("Invalid PNG palette")
    transparent_pixel = None
    if transparency is not None:
        if colour in (0, 2):
            if len(transparency) != channels * 2:
                raise ValueError("Invalid PNG transparency")
            values = struct.unpack(">" + "H" * channels, transparency)
            transparent_pixel = bytes(values) if all(value <= 255 for value in values) else None
        elif colour != 3 or len(transparency) > len(palette) // 3:
            raise ValueError("Invalid PNG transparency")
    rows = []
    left, top, right, bottom = width, height, 0, 0
    for y, row in enumerate(_rows(raw, width, height, channels, deadline)):
        if colour == 6:
            rgba = row
        else:
            rgba = bytearray(width * 4)
            for x in range(width):
                pixel = row[x * channels:(x + 1) * channels]
                if colour == 3:
                    index = pixel[0]
                    if index >= len(palette) // 3:
                        raise ValueError("Invalid PNG palette index")
                    rgb = palette[index * 3:index * 3 + 3]
                    alpha = transparency[index] if transparency and index < len(transparency) else 255
                else:
                    rgb = pixel[:3] if colour == 2 else pixel[:1] * 3
                    alpha = pixel[1] if colour == 4 else 0 if pixel == transparent_pixel else 255
                rgba[x * 4:x * 4 + 4] = bytes(rgb) + bytes((alpha,))
        alpha = rgba[3::4]
        visible = [x for x, value in enumerate(alpha) if value >= ALPHA_THRESHOLD]
        if visible:
            left, right = min(left, visible[0]), max(right, visible[-1] + 1)
            top, bottom = min(top, y), y + 1
        rows.append(rgba)
    if right <= left:
        raise ValueError("Logo has no visible pixels")
    return (width, height, right - left, bottom - top), [
        bytes(row[left * 4:right * 4]) for row in rows[top:bottom]]


def _encode(width, height, rows):
    return (SIGNATURE
            + _chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
            + _chunk(b"IDAT", zlib.compress(b"".join(b"\0" + row for row in rows)))
            + _chunk(b"IEND", b""))


def trim_png(data):
    (_, _, w, h), rows = _crop(data, time.monotonic() + MAX_PROCESS_SECONDS)
    return _encode(w, h, rows)


def prepare_logo(data, guide_frame):
    """Return a lossless alpha crop and a bounded high-resolution guide cell."""
    deadline = time.monotonic() + MAX_PROCESS_SECONDS
    geometry, rows = _crop(data, deadline)
    if guide_frame is None:
        image = _encode(geometry[2], geometry[3], rows)
        return image, image
    cell, target = guide_frame(geometry)
    if (len(cell) != 2 or len(target) != 2
            or any(not isinstance(value, int) or value <= 0 or value > MAX_DIMENSION // 4
                   for value in cell)
            or any(not isinstance(value, (int, float)) or not 0 < value <= cell[i]
                   for i, value in enumerate(target))):
        raise ValueError("Invalid guide logo dimensions")
    density = 4
    width, height = (value * density for value in cell)
    art_width, art_height = (max(1, round(value * density)) for value in target)
    if width > MAX_DIMENSION or height > MAX_DIMENSION or width * height * 4 > MAX_DECODED:
        raise ValueError("Guide logo exceeds size limit")
    source_width, source_height = geometry[2:]
    x_offsets = [(x * source_width // art_width) * 4 for x in range(art_width)]
    empty = bytes(width * 4)
    left = (width - art_width) // 2
    top = (height - art_height) // 2

    def canvas_rows():
        for y in range(height):
            if y % 16 == 0 and time.monotonic() >= deadline:
                raise ValueError("Logo processing time limit exceeded")
            if top <= y < top + art_height:
                row = rows[(y - top) * source_height // art_height]
                art = b"".join(row[offset:offset + 4] for offset in x_offsets)
                yield bytes(left * 4) + art + bytes((width - left - art_width) * 4)
            else:
                yield empty

    crop = _encode(source_width, source_height, rows)
    return crop, _encode(width, height, canvas_rows())
