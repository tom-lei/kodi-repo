"""Safe details from Magenta HTTP errors, shared by authentication, playback and the guide."""

from dataclasses import dataclass
from http.client import HTTPException
import json
from typing import Optional


_MAX_BODY = 8192
_CODE_KEYS = ("code", "errorCode", "error_code", "responseCode")
_EXPLANATIONS = {
    2805: 32103, 2810: 32104, 2816: 32105,
    2818: 32106, 2819: 32106, 2826: 32106, 2827: 32106,
    2820: 32107, 2821: 32107, 2824: 32108, 2838: 32102,
    2839: 32109, 2840: 32110, 2861: 32111,
    2868: 32112, 2869: 32112, 2870: 32113,
}


def provider_code(value):
    if isinstance(value, str) and 1 <= len(value) <= 4 and value.isascii() and value.isdigit():
        return int(value)
    return value if type(value) is int and 0 <= value <= 9999 else None


@dataclass(frozen=True)
class ProviderError:
    status: int
    code: Optional[int] = None

    def __str__(self):
        # Non-UI callers (including diagnostic logs) get numbers only.
        if self.code is None:
            return "The provider returned HTTP {}.".format(self.status)
        return "Magenta error {} (HTTP {}).".format(self.code, self.status)

    @property
    def explained(self):
        return self.code in _EXPLANATIONS

    def localized(self, localize):
        if self.code is None:
            return localize(32100).format(status=self.status)
        label = localize(32101).format(code=self.code, status=self.status)
        explanation = _EXPLANATIONS.get(self.code)
        return label + " " + localize(explanation) if explanation else label

    @classmethod
    def from_exception(cls, error):
        return error.args[0] if error.args and isinstance(error.args[0], cls) else None

    @classmethod
    def from_http(cls, error):
        fallback = cls(error.code)
        content_type = (error.headers.get("Content-Type", "") if error.headers else "")
        mime = content_type.partition(";")[0].strip().lower()
        kind, _, subtype = mime.partition("/")
        if mime != "application/json" and not (
                kind == "application" and len(subtype) > 5 and subtype.endswith("+json")):
            return fallback
        try:
            data = error.read(_MAX_BODY + 1)
            if len(data) > _MAX_BODY:
                return fallback
            body = json.loads(data.decode("utf-8"))
        except (ValueError, RecursionError, OSError, HTTPException):
            return fallback
        if not isinstance(body, dict):
            return fallback
        errors = body.get("errors")
        first = errors[0] if isinstance(errors, list) and errors else None
        for key in _CODE_KEYS:
            for entry in (body, body.get("error"), first):
                if isinstance(entry, dict):
                    code = provider_code(entry.get(key))
                    if code is not None:
                        return cls(error.code, code)
        return fallback
