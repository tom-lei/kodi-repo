"""Play one entitled live channel or programme Replay while owning its lease."""

import threading
import time
from dataclasses import dataclass

from channel_catalog import subscribed_channels
from dash_video import load_manifest
from license_probe import LicenseProbe
from magenta_auth import AuthError
from magenta_experiment import Bff, select_feed_channel, widevine_query_config
from magenta_guide_data import guide_channels
from magenta_replay import (
    Airing, opted_in, replay_media_id, replay_offer, replay_padding, replay_start_offset, replay_stream,
)
from magenta_playback import (
    CleanupUnconfirmed, ConcurrencyLease, LockedPlayback, PlaybackError, entitled_live_media, lock_transport,
)
from magenta_switch import LiveInputs, TuneTiming, read_inputs
from playback_guard import application_aborted
from provider_error import ProviderError
from seek_timeline import PROGRAMME_START_TOLERANCE, sane_timeline


REPLAY_TIMELINE_WAIT = 10


@dataclass(frozen=True)
class StartOver:
    """Restart a current programme from its scheduled start in the live timeshift."""
    number: int
    start: int

    def __post_init__(self):
        if (type(self.number) is not int or not 0 <= self.number <= 999999
                or type(self.start) is not int or not 0 <= self.start <= 253402300799):
            raise PlaybackError("Invalid restart selection.")

    def query(self):
        return {"channel": self.number, "start_over": self.start}


def position_start_over(player, start, now, timed_out, report):
    """Seek the live timeshift to the scheduled start; return (done, failure key)."""
    try:
        position, total = float(player.getTime()), float(player.getTotalTime())
    except (RuntimeError, TypeError, ValueError, OverflowError):
        position = total = float("nan")
    if not sane_timeline(position, total):
        if timed_out:
            report("not applied: live buffer unavailable")
            return True, "start_over_failed"
        return False, None
    # Kodi's live edge is the end of the timeshift window, as for "Go live".
    target = total - (now - start)
    if now < start or target < 0:
        report("not applied: start is %d s before live, buffer %d s" % (now - start, total))
        return True, "start_over_missed"
    try:
        player.seekTime(target)
    except (RuntimeError, TypeError, ValueError):
        report("not applied: seek failed")
        return True, "start_over_failed"
    report("applied: %d s before live" % (now - start))
    return True, None


def position_replay(player, airing, padding, timed_out, report):
    """Seek once from stream time 0 to the scheduled start; return False to retry later."""
    if padding is None:
        report("start offset not applied: provider padding unavailable")
        return True
    try:
        position, total = float(player.getTime()), float(player.getTotalTime())
    except (RuntimeError, TypeError, ValueError, OverflowError):
        position = total = float("nan")
    if not sane_timeline(position, total):
        if timed_out:
            report("start offset not applied: player duration unavailable")
        return timed_out
    offset, reason = replay_start_offset(padding, airing, total)
    if reason is None and position > PROGRAMME_START_TOLERANCE:
        reason = "player did not start at the beginning"
    if reason is not None:
        report("start offset not applied: " + reason)
        return True
    if offset:
        try:
            player.seekTime(offset)
        except (RuntimeError, TypeError, ValueError):
            report("start offset not applied: seek failed")
            return True
    report("start offset applied: %d s" % offset)
    return True


def owned_guide(lease, show, player, owns, monitor, probe, interval=0.5):
    """Keep the provider lease renewed while the modal guide owns the UI."""
    stopped = threading.Event()
    errors = []

    def renew():
        while not stopped.wait(interval):
            if probe.in_flight or probe.failed:
                continue
            try:
                lease.renew_if_due()
            except PlaybackError as error:
                errors.append(error)
                return

    worker = threading.Thread(target=renew, name="magenta-guide-renewal", daemon=True)
    worker.start()
    try:
        result = show(player, owns, lambda: bool(errors) or player.finished or probe.failed
                      or monitor.abortRequested() or not owns())
    finally:
        stopped.set()
        worker.join()
    while errors and probe.in_flight and not monitor.abortRequested():
        monitor.waitForAbort(0.1)
    if errors and not probe.failed and not monitor.abortRequested():
        raise errors[0]
    return result


class OwnedStop:
    def __init__(self, player, url, plugin_url=None):
        self.player = player
        self.urls = {url}
        if plugin_url:
            self.urls.add(plugin_url)

    def matches(self):
        try:
            return self.player.isPlayingVideo() and self.player.getPlayingFile() in self.urls
        except RuntimeError:
            return False

    def stop(self):
        try:
            if self.player.isPlaying():
                if self.player.getPlayingFile() in self.urls:
                    self.player.stop()
                elif not self.player.finished:
                    raise PlaybackError("Kodi could not confirm ownership of the active player.")
        except RuntimeError:
            raise PlaybackError("Kodi could not confirm the player stopped.") from None


def live_inputs(bff, number, cache, timing):
    account = cache.get("account")
    if account is None:
        account = timing.measure("account", bff.user_account)
        if isinstance(account, dict):
            fields = {k: account[k] for k in (
                "channelMap_id", "user_id", "account_type", "is_recording_enabled", "rightsGroup_ids",
                "release_slot", "account_id") if k in account}
            settings = account.get("managed_settings")
            if isinstance(settings, dict) and "TVSOA-setting-VodEnabled" in settings:
                fields["managed_settings"] = {"TVSOA-setting-VodEnabled": settings["TVSOA-setting-VodEnabled"]}
            cache.put("account", fields)
    else:
        bff.account = account
    lineup, feed, media_id = cache.get("lineup"), cache.get("feed"), cache.get(number)
    calls = []
    if lineup is None:
        calls.append(("subscriptions", bff.subscriptions))
    if feed is None:
        calls.append(("feed", bff.channel_feed))
    if media_id is None:
        calls.append(("playinfo", lambda: bff.playinfo(number)))
    data = read_inputs(calls, timing)
    if lineup is None:
        channels = subscribed_channels(data["subscriptions"])
        subscriptions = {"channels": [{"channel_number": n, "title": title} for n, title in channels]}
        cache.put("lineup", (channels, subscriptions))
    else:
        channels, subscriptions = lineup
    if number not in dict(channels):
        raise PlaybackError("This channel is not subscribed.")
    if media_id is None:
        info = data["playinfo"]
        media_id = entitled_live_media(info)
        if info["playBackInfoResponse"].get("type") != "live":
            raise PlaybackError("The provider did not return a live channel.")
        cache.put(number, media_id, 300)
    if feed is None:
        feed = data["feed"]
        if isinstance(feed, dict) and isinstance(feed.get("channels"), list):
            fields = ("channel_number", "channelNumber", "station_id", "stationId", "channel_logo",
                      "video_src_dash", "videoDashUrl", "pid_dash", "pidDash")
            feed = {"channels": [{k: row[k] for k in fields if k in row} if isinstance(row, dict)
                                 else row for row in feed["channels"]]}
            cache.put("feed", feed)
    url, release_pid = select_feed_channel(feed, number)
    return channels, subscriptions, feed, media_id, url, release_pid


def play_channel(session, number, player, monitor, resolve, make_item,
                 clock=time.monotonic, report=None, plugin_url=None, make_controls=None,
                 show_owned_guide=None, replay=None, start_over=None, open_settings=None,
                 notify=None, wall_clock=time.time, license_log=None, open_manifest=None,
                 prepare_artwork=None, cache=None, renew_session=None, timing=None,
                 persist_live_window=False, waiting_for_channel=None):
    report = report or (lambda event: None)
    notify = notify or (lambda key: None)
    if start_over is not None and (replay is not None or type(start_over) is not int
                                   or not 0 <= start_over <= wall_clock()):
        raise PlaybackError("Invalid restart selection.")
    timing = timing or TuneTiming()
    cache = cache if cache is not None else LiveInputs()
    if replay is None:
        while True:
            bff = Bff(session)
            try:
                channels, subscriptions, feed, media_id, url, release_pid = live_inputs(
                    bff, number, cache, timing)
                break
            except PlaybackError as error:
                cache.clear()
                details = ProviderError.from_exception(error)
                if (renew_session is None or monitor.abortRequested()
                        or (details and details.status in (403, 409, 429))):
                    raise
                session = renew_session()
                renew_session = None
        title = dict(channels)[number]
    else:
        bff = Bff(session)
        bff.user_account()
        subscriptions = bff.subscriptions()
        channels = subscribed_channels(subscriptions)
        if number not in dict(channels):
            raise PlaybackError("This channel is not subscribed.")
        if not isinstance(replay, Airing) or replay.number != number:
            raise PlaybackError("The Replay airing does not match the subscribed station.")
        feed = bff.channel_feed()
        if not any(c.number == number and c.station_id == replay.station
                   for c in guide_channels(subscriptions, feed)):
            raise PlaybackError("The Replay airing does not match the subscribed station.")
        if not opted_in(bff.replay_consents()):
            raise PlaybackError("Replay consent was not confirmed.")
        offer = replay_offer(bff.program_actions(replay.programme), replay, time.time())
        if offer is None:
            raise PlaybackError("Magenta did not offer Replay for this airing.")
        report("airing offer confirmed")
        info = bff.catchup_playinfo(replay.programme, replay.station, offer.start_utc, offer.end_utc)
        media_id = replay_media_id(info, replay)
        padding = replay_padding(info)
        report("catchup playinfo accepted")
        title = info["catalogInfoResponse"].get("title") or dict(channels)[number]
    if monitor.abortRequested():
        raise PlaybackError("Playback was cancelled.")
    if prepare_artwork is not None:
        prepare_artwork(subscriptions, feed)
    # The retry above must never enclose /media, the licence relay or a lease operation.
    try:
        media = timing.measure("media", bff.media, media_id, "live" if replay is None else "catchup")
    except PlaybackError:
        cache.clear()
        raise
    lock = media.get("lock")
    if not isinstance(lock, dict):
        cache.clear()
        raise CleanupUnconfirmed("The provider did not return a releasable lock.")
    lease = ConcurrencyLease(lock, session.device_id, session.constants["NATCO_KEY"], lock_transport)
    if replay is not None:
        try:
            url, release_pid = replay_stream(media)
        except PlaybackError:
            lease.release()
            raise
    probe = None
    controls = None
    next_channel = None
    cleanup_errors = []
    try:
        owned = OwnedStop(player, url, plugin_url)
        with LockedPlayback(owned, lease):
            report("lease acquired")
            lease._url("unlock")
            lease.start_renewal()
            drm = widevine_query_config(session.access_token, release_pid)

            def cleanup_before_denial():
                try:
                    lease.release()
                except CleanupUnconfirmed:
                    cleanup_errors.append("The provider did not confirm stream release.")
                try:
                    session.close()
                except AuthError:
                    cleanup_errors.append("The provider did not confirm sign-out.")

            ladder, window = (load_manifest(url, open_manifest, license_log or report,
                                            wall_clock if replay is None else None)
                              if open_manifest else ((), None))
            probe = LicenseProbe(drm, lambda event: None, on_failure=cleanup_before_denial,
                                 license_log=license_log, video_ladder=ladder)
            local_drm = probe.__enter__()
            item = make_item(url, local_drm, title)
            if monitor.abortRequested():
                raise PlaybackError("Playback was cancelled.")
            resolve(item)
            timing.mark("resolved")
            if replay is not None:
                report("Replay handed to Kodi")
            av_reported = False
            positioned = replay is None and start_over is None
            start = clock()
            while not monitor.abortRequested():
                if probe.in_flight:
                    time.sleep(0.02 if waiting_for_channel is not None else 0.2)
                    continue
                if probe.failed:
                    message = "The Widevine licence request failed."
                    if isinstance(probe.proxy_error, str):
                        message += " " + probe.proxy_error
                    if probe.failure_cleanup_error is True:
                        message += " Provider cleanup did not complete."
                    if cleanup_errors:
                        message += " " + " ".join(cleanup_errors)
                    raise PlaybackError(message)
                if waiting_for_channel is not None and controls is None:
                    try:
                        if not waiting_for_channel(owned.matches):
                            break
                    except RuntimeError:
                        raise PlaybackError("The channel-switch controls failed.") from None
                if player.finished:
                    if player.failed:
                        raise PlaybackError("Kodi could not play this channel.")
                    break
                if (replay is not None or start_over is not None) and not av_reported \
                        and player.started and owned.matches():
                    report("Replay AV started" if replay is not None else "AV started")
                    av_reported = True
                    av_started = clock()
                if not positioned and av_reported and owned.matches():
                    timed_out = clock() - av_started >= REPLAY_TIMELINE_WAIT
                    if replay is not None:
                        positioned = position_replay(player, replay, padding, timed_out, report)
                    else:
                        positioned, failure = position_start_over(
                            player, start_over, wall_clock(), timed_out, report)
                        if failure is not None:
                            notify(failure)
                if not player.started and clock() - start >= 30:
                    raise PlaybackError("Kodi did not start the video player.")
                if (make_controls is not None and controls is None and positioned
                        and player.started and owned.matches()):
                    try:
                        controls = make_controls(player, owned.matches, number,
                                                 channels, window)
                        controls.show()
                    except RuntimeError:
                        raise PlaybackError("The player controls could not be opened.") from None
                if controls is not None:
                    try:
                        next_channel = controls.update()
                    except RuntimeError:
                        raise PlaybackError("The player controls failed.") from None
                    if next_channel is not None:
                        if next_channel == "settings":
                            next_channel = None
                            if open_settings is None:
                                continue
                            changed = owned_guide(
                                lease, lambda player, owns, should_close: open_settings(),
                                player, owned.matches, monitor, probe)
                            if changed is True and not probe.failed and not monitor.abortRequested():
                                cache.clear()
                                try:
                                    channels = subscribed_channels(bff.subscriptions())
                                except (AuthError, PlaybackError, KeyError, TypeError, ValueError):
                                    report("lineup refresh after settings failed")
                                else:
                                    controls.update_channels(channels)
                            continue
                        if next_channel == "context":
                            next_channel = owned_guide(
                                lease, lambda player, owns, should_close: controls.context_menu(
                                    should_close, lambda: application_aborted(monitor)),
                                player, owned.matches, monitor, probe)
                            if probe.failed or next_channel is None:
                                continue
                        if next_channel == "guide" and show_owned_guide is not None:
                            next_channel = owned_guide(
                                lease, show_owned_guide, player, owned.matches, monitor, probe)
                            if probe.failed:
                                continue
                            if (next_channel in (None, "return")
                                    or (replay is None and next_channel in (str(number), number))):
                                next_channel = None
                                continue
                            if isinstance(next_channel, str) and next_channel.isascii() and next_channel.isdigit():
                                next_channel = int(next_channel)
                        if next_channel == "stop":
                            next_channel = None
                            break
                        next_number = (next_channel.number if isinstance(next_channel, (Airing, StartOver))
                                       else next_channel)
                        if (next_channel != "guide" and
                                (next_number not in {channel[0] for channel in channels}
                                 or (next_channel == number and replay is None))):
                            raise PlaybackError("The player selected an invalid channel.")
                        timing.mark("switch selected")
                        if persist_live_window and type(next_channel) is int:
                            try:
                                controls.begin_switch(next_channel)
                            except RuntimeError:
                                raise PlaybackError("The channel-switch controls failed.") from None
                        break
                if lease.renew_if_due():
                    report("lease renewed")
                if controls is None:
                    delay = 0.02 if waiting_for_channel is not None else 0.5
                else:
                    delay = 0.04 if controls.tuning or getattr(controls, "number_entry", False) is True else 0.1
                monitor.waitForAbort(delay)
    finally:
        try:
            if controls is not None and not persist_live_window:
                try:
                    controls.close(aborted=application_aborted(monitor))
                except RuntimeError:
                    raise PlaybackError("The player controls could not be closed.") from None
        finally:
            try:
                if lease.unlock_response_received:
                    timing.mark("lease released")
                    report("lease released")
            finally:
                if probe is not None:
                    probe.__exit__(None, None, None)
    return next_channel
