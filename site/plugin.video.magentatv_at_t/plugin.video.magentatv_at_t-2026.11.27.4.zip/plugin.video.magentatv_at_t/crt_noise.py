"""CRT textures adapted from simpliTVᵀ (GPL-3.0-or-later)."""

import os
from contextlib import contextmanager
from pathlib import Path


FRAMES = 48
FPS = 25
WIDTH, HEIGHT, OVERLAY_HEIGHT = 384, 216, 44
CACHE_VERSION = 3  # Bump when the frame recipe or on-disk format changes.
FRAME_NAMES = tuple(
    "{}-{:02d}.png".format(prefix, index)
    for prefix in ("snow", "signal") for index in range(FRAMES)
)


def tuning_logo_size(width, height):
    """Fit the double-size logo while reserving room for the tuning labels."""
    scale = min(1.0, width / 560, max(1, height - 108) / 208)
    return max(1, int(448 * scale)), max(1, int(208 * scale))


def _directory(profile):
    return Path(profile) / "crt-cache" / "v{}".format(CACHE_VERSION)


def cached_textures(profile):
    directory = _directory(profile)
    try:
        with (directory / "sizes").open("rb") as handle:
            manifest = handle.read(1024)
        sizes = tuple(map(int, manifest.split()))
        if len(sizes) == len(FRAME_NAMES) and all(
                size > 0 and (directory / name).stat().st_size == size
                for name, size in zip(FRAME_NAMES, sizes)):
            paths = tuple(str(directory / name) for name in FRAME_NAMES)
            return paths[:FRAMES], paths[FRAMES:]
    except (OSError, ValueError):
        pass
    return None


def enabled(addon):
    return addon.getSetting("tv_static") != "false"


def startup_textures(addon, profile):
    return cached_textures(profile) if enabled(addon) else None


def start_preparation(profile, addon=None):
    if addon is not None and not enabled(addon):
        return
    if cached_textures(profile) is None:
        import xbmc

        xbmc.executebuiltin('RunScript("{}")'.format(os.path.abspath(__file__)))


@contextmanager
def _cache_guard(path):
    with open(path, "a+b") as handle:
        if os.name == "nt":
            import msvcrt
            handle.seek(0, os.SEEK_END)
            if handle.tell() == 0:
                handle.write(b"\0")
                handle.flush()
            handle.seek(0)
            acquire = lambda: msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            acquire = lambda: fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            acquire()
        except OSError:
            yield False
        else:
            yield True


def prepare_cache(profile, cancelled):
    import shutil

    directory = _directory(profile)
    directory.parent.mkdir(parents=True, exist_ok=True)
    staging = directory.with_suffix(".pending")
    with _cache_guard(str(directory.parent / "generation.lock")) as claimed:
        if not claimed or cancelled() or cached_textures(profile) is not None:
            return
        if staging.exists():
            shutil.rmtree(staging)
        try:
            if not generate(staging, cancelled) or cancelled():
                return
            sizes = ((staging / name).stat().st_size for name in FRAME_NAMES)
            (staging / "sizes").write_text(" ".join(map(str, sizes)), encoding="ascii")
            if cancelled():
                return
            if directory.exists():
                shutil.rmtree(directory)
            staging.rename(directory)
        finally:
            if staging.exists():
                shutil.rmtree(staging)


def _chunk(kind, data):
    import struct
    import zlib

    return (struct.pack(">I", len(data)) + kind + data
            + struct.pack(">I", zlib.crc32(kind + data)))


def _png(path, rows, palette, alpha=None):
    import struct
    import zlib

    width, height = len(rows[0]), len(rows)
    packed = b"".join(b"\0" + row for row in rows)
    data = b"\x89PNG\r\n\x1a\n" + _chunk(b"IHDR", struct.pack(
        ">IIBBBBB", width, height, 8, 3, 0, 0, 0))
    data += _chunk(b"PLTE", bytes(c for color in palette for c in color))
    if alpha:
        data += _chunk(b"tRNS", bytes(alpha))
    path.write_bytes(data + _chunk(b"IDAT", zlib.compress(packed, 3)) + _chunk(b"IEND", b""))


def generate(directory, cancelled):
    import math
    import random
    from statistics import NormalDist

    directory.mkdir(exist_ok=True)
    fields = random.Random(20261119), random.Random(20261120)
    normal = NormalDist()
    gaussian = bytes(round(128 + 36 * normal.inv_cdf((i + 0.5) / 256))
                     for i in range(256))
    gamma = bytes(round(255 * min(1, max(0, 0.70 + (i - 512) * 0.24
                                         / (36 * math.sqrt(6)))) ** 2.3)
                  for i in range(1021))
    vignette = [round(8 * ((2 * x / (WIDTH - 1)) - 1) ** 2) for x in range(WIDTH)]
    palette = [(i, i, i) for i in range(256)]
    alpha = [round(18 + 94 * abs(i - 128) / 128) for i in range(256)]
    previous = None
    for frame in range(FRAMES):
        rows = []
        for y in range(HEIGHT):
            if y % 16 == 0 and cancelled():
                return False
            rng = fields[y % 2]
            salt = rng.getrandbits(16)
            jitter = (salt & 3) - 1
            noise = rng.getrandbits((WIDTH + 5) * 8).to_bytes(WIDTH + 5, "little").translate(gaussian)
            start = jitter + 1
            phase = y / HEIGHT - frame / FRAMES
            hum = round(10 * ((1 + math.cos(math.tau * phase)) / 2) ** 5 - 2)
            level = hum - (5 if y % 2 != frame % 2 else 0) - round(6 * (2 * y / HEIGHT - 1) ** 2)
            # A three-tap luma filter acts along each line, never across fields.
            row = [gamma[a + 2 * b + c] for a, b, c in zip(
                noise[start:start + WIDTH], noise[start + 1:start + WIDTH + 1],
                noise[start + 2:start + WIDTH + 2])]
            if salt < 2500:
                x = max(0, min(WIDTH - 10, rng.randrange(WIDTH) + jitter))
                length = 3 + salt % 7
                row[x:x + length] = [255] * length
            past = previous[y] if previous is not None else row
            rows.append(bytes(max(0, min(255, ((7 * value + old + 4) >> 3) + level - dark))
                              for value, old, dark in zip(row, past, vignette)))
        previous = rows
        top = (HEIGHT - OVERLAY_HEIGHT) // 2
        _png(directory / "snow-{:02d}.png".format(frame), rows, palette)
        _png(directory / "signal-{:02d}.png".format(frame),
             rows[top:top + OVERLAY_HEIGHT], palette, alpha)
    return True


if __name__ == "__main__":
    import xbmc
    import xbmcaddon
    import xbmcvfs
    addon = xbmcaddon.Addon("plugin.video.magentatv_at_t")
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    monitor = xbmc.Monitor()
    try:
        prepare_cache(profile, lambda: monitor.abortRequested() or not enabled(addon))
    except OSError as error:
        xbmc.log("[Magenta TV AT] CRT cache unavailable: " + type(error).__name__, xbmc.LOGWARNING)
