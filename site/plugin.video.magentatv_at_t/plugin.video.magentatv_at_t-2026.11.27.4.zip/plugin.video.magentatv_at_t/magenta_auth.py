"""Website-style sign-in that identifies the client as Kodi on its real operating system."""

import base64
import hashlib
import hmac
import json
import secrets
import time
import uuid
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request

from kodi_http import ProxySettingsError, open_provider
from provider_error import ProviderError


SITE = "https://tv.magenta.at/"
LOGIN_HOST = "gateway-at-proxy.tv.yo-digital.com"
_CREDENTIAL_KEY = secrets.token_bytes(32)
SWITCH_SECONDS = 20
JS_WHITESPACE = (
    "\t\n\v\f\r \xa0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006"
    "\u2007\u2008\u2009\u200a\u2028\u2029\u202f\u205f\u3000\ufeff"
)
# Kodi's platform conditions, most specific first: Android and webOS also report Linux.
PLATFORMS = (
    ("System.Platform.Windows", "Windows"),
    ("System.Platform.Android", "Android"),
    ("System.Platform.WebOS", "webOS"),
    ("System.Platform.Linux", "Linux"),
    ("System.Platform.TVOS", "tvOS"),
    ("System.Platform.IOS", "iOS"),
    ("System.Platform.OSX", "macOS"),
)


class AuthError(Exception):
    pass


def client_platform(condition):
    """Name the operating system from Kodi's own conditions, e.g. xbmc.getCondVisibility."""
    for name, platform in PLATFORMS:
        if condition(name):
            return platform
    return "Unknown"


def _json_after(text, marker):
    position = text.find(marker)
    if position < 0:
        raise AuthError("Website configuration is unavailable.")
    content = text[position + len(marker):].lstrip()
    try:
        return json.JSONDecoder().raw_decode(content)[0]
    except ValueError:
        raise AuthError("Website configuration could not be decoded.") from None


def bootstrap(html):
    constants = _json_after(html, "window.APP_CONSTANTS =")
    state = html.find("window.INITIAL_STATE =")
    if state < 0:
        raise AuthError("Website configuration is unavailable.")
    cms = _json_after(html[state:], '"cmsConfiguration":')
    try:
        auth = cms["data"]["modules"]["auth"]
        login = auth["methods"]["login"]
        stream_limit = cms["data"]["modules"]["tvplatform"]["cts"]["concurrency"]["streamLimitKey"]
        base = constants["NATIVE_LOGIN_BASE_URL"]
        parts = urlsplit(base)
        if (parts.scheme != "https" or parts.hostname != LOGIN_HOST
                or parts.port not in (None, 443) or parts.path.rstrip("/") != "/at-idm/P"
                or parts.username or parts.password or parts.query or parts.fragment):
            raise AuthError("The website returned an unexpected login endpoint.")
        if not login["enableUsernamePassword"]:
            raise AuthError("Website password login is not enabled.")
        return constants, auth["rsaPublicKey"], stream_limit, login
    except (KeyError, TypeError, ValueError):
        raise AuthError("Website login configuration is incomplete.") from None


def wrap_password(password, public_key):
    from Cryptodome.Cipher import PKCS1_OAEP
    from Cryptodome.Hash import SHA1
    from Cryptodome.PublicKey import RSA

    if not isinstance(public_key, str) or not public_key:
        raise AuthError("The website did not provide a public login key.")
    try:
        der = base64.b64decode("".join(public_key.split()), validate=True)
        key = RSA.import_key(der)
        if key.has_private() or not 2048 <= key.size_in_bits() <= 8192:
            raise ValueError("Invalid public login key")
        # PyCryptodome uses MGF1 with this hash and an empty label by default.
        encrypted = PKCS1_OAEP.new(key, hashAlgo=SHA1).encrypt(password.encode("utf-8"))
        return base64.b64encode(encrypted).decode("ascii")
    except (ValueError, TypeError, IndexError, OSError):
        raise AuthError("Password encryption could not be performed.") from None


def _read(request):
    return _read_with_status(request)[1]


def _read_with_status(request, limit=None):
    try:
        with open_provider(request) as response:
            data = response.read(limit + 1) if limit is not None else response.read()
            if limit is not None and len(data) > limit:
                raise AuthError("The provider response exceeded the size limit.")
            return response.status, data
    except ProxySettingsError as exc:
        raise AuthError(str(exc)) from None
    except HTTPError as exc:
        with exc:
            details = ProviderError.from_http(exc)
        raise AuthError(details) from None
    except (URLError, OSError):
        raise AuthError("The provider could not be reached.") from None


def _headers(constants, device_id, session_id, user_agent, authenticated, flow, step, *, device_name):
    tracking_id = str(uuid.uuid4())
    call_time = str(int(time.time() * 1000))
    transaction = hashlib.sha256(
        (tracking_id + session_id + device_id + call_time).encode("utf-8")
    ).hexdigest()[:32]
    return {
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json",
        "Device-Id": device_id,
        "app_key": constants["CMS_CONFIGURATION_API_KEY"],
        "app_version": constants["APP_VERSION"],
        "X-User-Agent": user_agent,
        "Device-Name": device_name,
        "tenant": "tv",
        "X-Call-Type": constants["AUTH_USER_HEADER" if authenticated else "GUEST_USER_HEADER"],
        "requestId": str(uuid.uuid4()),
        "x-request-tracking-id": tracking_id,
        "x-request-session-id": session_id,
        "x-call-time": call_time,
        "x-txn-id": transaction,
        "x-tv-flow": flow,
        "x-tv-step": step,
        "Pragma": "akamai-x-cache-on,akamai-x-check-cacheable,akamai-x-get-cache-key",
    }


class Session:
    """Keep the experimental session in memory and explicitly log out."""

    def __init__(self, constants, device_id, session_id, user_agent, response, device_name):
        self.constants = constants
        self.device_id = device_id
        self.session_id = session_id
        self.user_agent = user_agent
        self.device_name = device_name
        self.access_token = response.get("accessToken")
        self.refresh_token = response.get("refreshToken")
        self.device_limit = bool(response.get("deviceLimitExceed"))
        self.multiple_accounts = bool(response.get("tvAccountIds"))
        self._closed = False
        self._logout_failure = None
        self._created = time.monotonic()
        self._credentials = None

    @staticmethod
    def _tag(username, password):
        data = json.dumps([username, password], separators=(",", ":")).encode("utf-8")
        return hmac.digest(_CREDENTIAL_KEY, data, "sha256")

    def bind_credentials(self, username, password):
        self._credentials = self._tag(username, password)

    def can_continue(self, username, password, device, selected, *, now=None, tick=None):
        """Eligibility only, never authorization: /media and the licence are always fresh."""
        if (self._closed or self.device_limit or self.multiple_accounts or not self.refresh_token
                or self.device_id != device or self._credentials is None or selected is None):
            return False
        tick = time.monotonic() if tick is None else tick
        if not (0 <= tick - selected <= SWITCH_SECONDS and 0 <= tick - self._created <= 1200):
            return False
        try:
            _, payload, _ = self.access_token.split(".")
            claims = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
            expiry = claims["exp"]
        except (AttributeError, KeyError, TypeError, ValueError, RecursionError):
            return False
        now = time.time() if now is None else now
        return (type(expiry) in (int, float) and now + 300 <= expiry <= 253402300799
                and hmac.compare_digest(self._credentials, self._tag(username, password)))

    def close(self):
        if self._closed:
            if self._logout_failure is not None:
                raise AuthError(self._logout_failure)
            return
        self._closed = True
        self._credentials = None
        refresh = self.refresh_token
        authenticated = bool(self.access_token and not self.device_limit and not self.multiple_accounts)
        self.refresh_token = None
        self.access_token = None
        if not refresh:
            return
        flow = "DEVICE_LIMIT_EXCEEDED" if self.device_limit else "ACCOUNT_LOGOUT"
        headers = _headers(self.constants, self.device_id, self.session_id,
                           self.user_agent, authenticated, flow, "LOGOUT",
                           device_name=self.device_name)
        headers["refresh_token"] = refresh
        logout = Request(self.constants["NATIVE_LOGIN_BASE_URL"].rstrip("/") + "/onboarding/logout",
                         b"{}", headers, method="POST")
        try:
            _read(logout)
        except AuthError as error:
            details = ProviderError.from_exception(error)
            if details is None and str(error) == "The provider could not be reached.":
                details = "The provider could not be reached."
            self._logout_failure = ("Sign-out was not confirmed: " + str(details) if details is not None
                                    else "Sign-out was not confirmed.")
            raise AuthError(self._logout_failure) from None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()


def open_session(username, password, device_id, platform="Windows"):
    try:
        device_id = str(uuid.UUID(device_id))
    except (ValueError, TypeError, AttributeError):
        raise AuthError("A persistent device ID is required.") from None
    try:
        html = _read(Request(SITE, headers={"User-Agent": "Kodi Magenta TV AT proof of concept"})).decode("utf-8")
    except AuthError as error:
        if ProviderError.from_exception(error):
            raise
        raise AuthError("Website bootstrap: " + str(error)) from None
    constants, key, stream_limit, login = bootstrap(html)
    session_id = str(uuid.uuid4())
    encrypted = wrap_password(password, key)
    version = constants["APP_VERSION"]
    # Identify the client as WEB as explicitly authorized; the OS remains accurate.
    # On Windows these values stay exactly as verified with the provider.
    user_agent = "web|web|{}-Kodi|{}|1".format(platform, version)
    device_name = platform + " - Kodi"
    device = {
        "id": device_id, "model": "WEB", "os": platform,
        "deviceName": "WEB", "manageDevice": False, "deviceType": "WEB",
        "deviceOS": platform, "deviceModel": user_agent,
        "deviceManufacturer": platform + " Kodi",
        "concurrencyLimitParam": stream_limit,
        "broadcastingStreamLimitationApplies": False,
    }
    payload = {
        "appVersion": version, "channel": {"id": "Tv"},
        "natco": constants["COUNTRY_CODE"], "type": "telekom",
        "forceRegister": False, "context": "login", "device": device,
        "telekomLogin": {"username": username.lstrip(JS_WHITESPACE), "password": encrypted},
    }
    headers = _headers(constants, device_id, session_id, user_agent, False,
                       "USERNAME_PASSWORD_LOGIN", "GET_ACCESS_TOKEN", device_name=device_name)
    if login.get("enableMultipleSubscription"):
        headers["X-Multi-Account-Enabled"] = "true"
    url = constants["NATIVE_LOGIN_BASE_URL"].rstrip("/") + "/onboarding/login"
    request = Request(url, json.dumps(payload).encode("utf-8"), headers, method="POST")
    try:
        response = json.loads(_read(request).decode("utf-8"))
    except AuthError as error:
        if ProviderError.from_exception(error):
            raise
        raise AuthError("Sign-in request: " + str(error)) from None
    except (UnicodeError, ValueError):
        raise AuthError("The provider returned an invalid login response.") from None
    if not isinstance(response, dict):
        raise AuthError("The provider returned an invalid login response.")
    session = Session(constants, device_id, session_id, user_agent, response, device_name)
    try:
        if session.device_limit:
            raise AuthError("The provider reported a device limit.")
        if session.multiple_accounts:
            raise AuthError("The provider requires account selection, which is not yet supported.")
        if not session.access_token or not session.refresh_token:
            raise AuthError("The provider did not return a usable sign-in session.")
    except AuthError:
        session.close()
        raise
    session.bind_credentials(username, password)
    return session


def sign_in(username, password, device_id, platform="Windows"):
    with open_session(username, password, device_id, platform):
        pass
