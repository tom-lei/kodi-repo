"""Programme guide adapted from simpliTVᵀ (GPL-3.0-or-later)."""

import datetime
import html
import json
import math
import os
import re
import threading
import textwrap
import time
import urllib.parse
from guide_support import (
    ACCESS_TEXT, LiveDataCancelled, LiveDataError, broadcast_timestamp, format_duration,
)
from channel_numbers import (SETTINGS_SHORTCUT, ChannelNumber, number_channel, number_status,
                             number_text, numbered)
from crt_noise import FPS as CRT_FPS, tuning_logo_size
from magenta_logo_layout import logo_box
from magenta_playback import PlaybackError
from provider_error import ProviderError

TIMELINE_MARKER_COLOR = "80E45D5D"
TIMELINE_MARKER_WIDTH = 2
GUIDE_SEPARATOR_COLOR = "0xFF404E5E"
GUIDE_REFRESH_RETRY_SECONDS = 5 * 60
GUIDE_ADDON_ID = "plugin.video.magentatv_at_t"
# guide.xml's onunload resolves this Home property into its NotifyAll message.
GUIDE_INSTANCE_PROPERTY = "magentatv_at_t.guide.instance"
GUIDE_UNLOADED = "Other.guide_unloaded."
ADDON_CHECK_SECONDS = 2.0
# Kodi exposes no "texture is on screen" signal to Python, so a logo that replaces
# a station name is added nearly transparent for this long before it is revealed.
LOGO_WARM_SECONDS = 0.3
LOGO_WARM_COLOR = "0x01FFFFFF"  # diffuse alpha 0 would read as "no colour" (opaque)


def guide_exit_monitor(xbmc, token):
    """Return a Monitor that learns when Kodi itself removed this guide window.

    Python dialogs get no callback when Kodi closes them (e.g. Dialog.Close), so
    guide.xml announces its unload. Notifications arrive during Monitor waits and,
    unlike visibility queries, take no GUI lock.
    """
    class GuideExitMonitor(xbmc.Monitor):
        unloaded = False

        def onNotification(self, sender, method, data):
            if sender == GUIDE_ADDON_ID and method == GUIDE_UNLOADED + token:
                self.unloaded = True

    return GuideExitMonitor()


def guide_logo_texture(logo, width, height):
    """Have Kodi's texture cache store a Lanczos-downscaled copy for the guide slot.

    Provider logos are up to 1920x1080 and Kodi draws them without mipmaps, so
    showing them at row size aliases badly. Slot sizes are bucketed to keep the
    number of cached variants small across window sizes.
    """
    if not isinstance(logo, str) or not logo or logo.startswith("image://"):
        return logo
    width = max(32, -(-int(width) // 32) * 32)
    height = max(16, -(-int(height) // 16) * 16)
    return "image://{}/transform?width={}&height={}&scaling_algorithm=lanczos".format(
        urllib.parse.quote(logo, safe=""), width, height)


def fit_event_label(start_text, title, width, screen_height):
    """Leave cells too narrow for their start time blank instead of a '..' stub."""
    # Measured font12 "14:15" is ~5.5% of the height at 720p and ~5% at 1080p;
    # overestimate with slack so Kodi never elides the time itself to "14:…".
    glyph = screen_height / 80
    room = width - 16
    time_width = len(start_text) * glyph + 4
    if room >= time_width + 4 * glyph:
        return start_text + "  " + title
    if room >= time_width:
        return start_text
    return ""


def branding_fade(logo, condition="true"):
    start, end = (100, 0) if logo else (0, 100)
    return [("Conditional", "effect=fade start={} end={} delay=1300 time=2500 "
             "pulse=true reversible=false condition={}".format(start, end, condition))]


# guide.xml's clipped logo/name carousel; Kodi clips list containers but not
# Python-added controls, so the slide lives in XML for the 1080i grid geometry.
BRANDING_SLIDE_IDS = (110, 111, 112)
BRANDING_SLIDE_CELL = (176, 53)
BRANDING_SLIDE_PROPERTY = "magentatv_at_t.guide.branding"
TINY_CELL_WIDTH = 36
GUIDE_AXIS_HEIGHT = 30
# An odd box height centres the glyphs both at 1080 and at scaled 720.
GUIDE_TICK_HEIGHT = 19
GUIDE_TICK_TOP = (GUIDE_AXIS_HEIGHT - GUIDE_TICK_HEIGHT + 1) // 2
GUIDE_TICK_FONT = "font12"
GUIDE_NUMBER_COLUMN = 44
GUIDE_CELL_TRIM = 16


def guide_tile_gaps(width, height):
    return max(1, round(width / 960)), max(1, round(height / 600))


GUIDE_PAST_SECONDS = 7 * 24 * 60 * 60
GUIDE_FUTURE_SECONDS = 21 * 60 * 60
TIMELINE_SECONDS = 4 * 60 * 60
TIMELINE_STEP_SECONDS = 30 * 60
# Sampled Magenta live manifests advertise a two-hour timeshift (PT2H). The depth per
# station is not published, so the player still checks the stream's real window.
START_OVER_SECONDS = 2 * 60 * 60
# Kodi 21's ActionIDs.h; these are actions, not remote keycodes.
ACTION_CHANNEL_UP = 184
ACTION_CHANNEL_DOWN = 185
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6

GUIDE_TEXT = (
    {
        "live": "Live TV", "loading": "Loading programme details…",
        "more": "Loading more programmes…", "incomplete": "Programme guide incomplete",
        "error": "Programme data unavailable",
        "programme": "Programme",
        "empty": "No programme information is available for this time.",
        "watch": "Watch live", "restart": "Try rewind", "unavailable": "Replay unavailable",
        "catchup": "Restart with Replay", "guide_date": "Guide date",
        "navigate": "←/→ Programmes  ↑/↓ Channels  PgUp/PgDn Pages", "actions": "OK Play  Menu  000 Settings  Back Close",
        "not_playable": "This programme cannot be played.",
        "past_unavailable": "No verified Replay offer for this airing.",
        "checking_replay": "Checking Replay…",
        "replay_error": "Replay availability could not be checked.",
        "starting": "Starting playback…", "playback_error": "Playback could not start.",
        "startup_cancel": "Back to cancel",
        "return_stream": "Return to stream",
        "tv_actions": "TV options",
        "last_channel": "Last channel",
        "go_live": "Go live",
        "guide": "Programme Guide", "settings": "Settings",
        "rewind_live": "Live rewind: depth not confirmed for this station (sampled streams: 2 h)",
        "rewind_observed": "Live rewind: last reported ~{} ({})",
        "replay_offered": "Replay: offered for this airing",
        "replay_checking": "Replay: checking this airing…",
        "replay_unchecked": "Replay: availability could not be checked",
        "replay_none": "Replay: no offer for this airing",
        "replay_not_offered": "Replay: not offered by Magenta for this airing",
        "replay_marked": "Replay: marked available in Magenta's guide",
        "replay_flagged": "Replay: marked available, checking this airing…",
        "start_over": "Restart (live buffer)",
        "start_over_live": "Restart from the start via the live buffer",
        "start_over_outside": "Start is beyond the live buffer (sampled streams: 2 h)",
        "start_over_none": "Restart: not offered for this airing",
        "start_over_missed": "The programme start is no longer in the live buffer. Playing live.",
        "start_over_failed": "Restart was not possible. Playing live.",
        "not_aired": "Not aired yet: no Replay or rewind",
        "restart_bounds": "Could not place the programme start on the reported stream timeline.",
        "refresh_rights": "Refreshing programme data. Try restarting again shortly.",
    },
    {
        "live": "Live TV", "loading": "Programmdetails werden geladen…",
        "more": "Weitere Sendungen werden geladen…", "incomplete": "TV-Guide unvollständig",
        "error": "Programmdaten nicht verfügbar",
        "programme": "Sendung",
        "empty": "Für diese Zeit sind keine Programmdaten verfügbar.",
        "watch": "Live ansehen", "restart": "Zurückspulen versuchen", "unavailable": "Replay nicht verfügbar",
        "catchup": "Mit Replay starten", "guide_date": "Programmtag",
        "navigate": "←/→ Sendungen  ↑/↓ Sender  Bild↑/↓ Seiten", "actions": "OK Abspielen  Menü  000 Einstellungen  Zurück Schließen",
        "not_playable": "Diese Sendung kann nicht abgespielt werden.",
        "past_unavailable": "Kein bestätigtes Replay-Angebot für diese Ausstrahlung.",
        "checking_replay": "Replay wird geprüft…",
        "replay_error": "Replay-Verfügbarkeit konnte nicht geprüft werden.",
        "starting": "Wiedergabe startet…", "playback_error": "Wiedergabe konnte nicht gestartet werden.",
        "startup_cancel": "Zurück zum Abbrechen",
        "return_stream": "Zurück zum Stream",
        "tv_actions": "TV-Optionen",
        "last_channel": "Letzter Sender",
        "go_live": "Zu Live",
        "guide": "Programmübersicht", "settings": "Einstellungen",
        "rewind_live": "Live-Zurückspulen: Tiefe für diesen Sender nicht bestätigt (Stichproben: 2 Std.)",
        "rewind_observed": "Live-Zurückspulen: zuletzt gemeldet ~{} ({})",
        "replay_offered": "Replay: für diese Ausstrahlung angeboten",
        "replay_checking": "Replay: Ausstrahlung wird geprüft…",
        "replay_unchecked": "Replay: Verfügbarkeit konnte nicht geprüft werden",
        "replay_none": "Replay: kein Angebot für diese Ausstrahlung",
        "replay_not_offered": "Replay: von Magenta für diese Ausstrahlung nicht angeboten",
        "replay_marked": "Replay: im Magenta-Programm als verfügbar markiert",
        "replay_flagged": "Replay: als verfügbar markiert, Ausstrahlung wird geprüft…",
        "start_over": "Neu starten (Live-Puffer)",
        "start_over_live": "Neustart ab Beginn über den Live-Puffer",
        "start_over_outside": "Beginn liegt außerhalb des Live-Puffers (Stichproben: 2 Std.)",
        "start_over_none": "Neustart: für diese Ausstrahlung nicht angeboten",
        "start_over_missed": "Der Sendungsbeginn ist nicht mehr im Live-Puffer. Live-Wiedergabe.",
        "start_over_failed": "Neustart war nicht möglich. Live-Wiedergabe.",
        "not_aired": "Noch nicht ausgestrahlt: kein Replay oder Zurückspulen",
        "restart_bounds": "Der Sendungsbeginn ließ sich nicht auf der gemeldeten Zeitleiste bestimmen.",
        "refresh_rights": "Programmdaten werden aktualisiert. Bitte erneut versuchen.",
    },
)


def guide_window(now=None):
    now = time.time() if now is None else float(now)
    if not math.isfinite(now):
        raise LiveDataError("Invalid guide time")
    start = datetime.datetime.fromtimestamp(
        now - GUIDE_PAST_SECONDS, datetime.timezone.utc)
    end = datetime.datetime.fromtimestamp(
        now + GUIDE_FUTURE_SECONDS, datetime.timezone.utc)
    return start, end


def programme_key(programme):
    if not isinstance(programme, dict):
        return None
    channel_data = programme.get("tileChannel")
    if not isinstance(channel_data, dict):
        return None
    channel = channel_data.get("codename")
    if not isinstance(channel, str):
        return None
    try:
        start = broadcast_timestamp(programme["start"])
        stop = broadcast_timestamp(programme["stop"])
    except (KeyError, LiveDataError):
        return None
    if stop <= start:
        return None
    return channel, str(programme.get("id", "")), start, stop


def replay_flag(programme):
    """Magenta's per-station guide flag for this airing: True, False or None (unknown)."""
    flag = programme.get("is_catchup_enabled") if isinstance(programme, dict) else None
    return flag if isinstance(flag, bool) else None


def replay_capable(programme, now):
    """Like the portal's "Replay verfügbar" mark: started and flagged for this station."""
    key = programme_key(programme)
    return key is not None and key[2] <= now and replay_flag(programme) is True


def start_over_state(programme, now, window=START_OVER_SECONDS):
    """Restart a running programme in the live timeshift, as Magenta's portal does."""
    key = programme_key(programme)
    if key is None or not key[2] <= now < key[3]:
        return None
    flag = programme.get("has_start_over")
    if not isinstance(flag, bool):
        return None
    if not flag:
        return "none"
    return "available" if now - key[2] <= window else "outside"


def available_actions(programme, now=None, rewind=None, timeshift_denied=False, catchup=False):
    now = time.time() if now is None else float(now)
    key = programme_key(programme)
    if key is None:
        return ()
    start, stop = key[2], key[3]
    live = ("watch_live",) if start <= now < stop else ()
    start_over = ("start_over",) if start_over_state(programme, now) == "available" else ()
    return live + start_over + (("catchup",) if catchup is True and start <= now else ())


def event_badge(programme, actions, now):
    """Badge an airing at its start: live-buffer restart, or Magenta's Replay mark."""
    key = programme_key(programme)
    if key is None:
        return None
    if "start_over" in actions:
        return "start_over", key[2]
    if "catchup" in actions or replay_capable(programme, now):
        return "catchup", key[2]
    return None


def replay_start(programme, now, rewind=None, timeshift_denied=False):
    """A live buffer is not a verified programme restart."""
    return None


def replay_badge_x(target, view_start, view_end, scale, timeline_x):
    if target is None or not view_start <= target[1] < view_end:
        return None
    return int(timeline_x + (target[1] - view_start) * scale)


UTF8_CONTINUATION = ("[\u0080-\u00bf\u0152\u0153\u0160\u0161\u0178"
                     "\u017d\u017e\u0192\u02c6\u02dc\u2013-\u2026\u2030\u2039\u203a\u20ac\u2122]")
MOJIBAKE = re.compile(
    "[\u00c2-\u00df]" + UTF8_CONTINUATION
    + "|[\u00e0-\u00ef]" + UTF8_CONTINUATION + "{2}"
    + "|[\u00f0-\u00f4]" + UTF8_CONTINUATION + "{3}"
)


def repair_mojibake(value):
    if not isinstance(value, str):
        return value

    def decode_sequence(match):
        sequence = match.group()
        raw = bytearray((ord(sequence[0]),))
        for char in sequence[1:]:
            # Latin-1 control characters are already the original byte values.
            if ord(char) <= 0xBF:
                raw.append(ord(char))
            else:
                raw.extend(char.encode("cp1252"))
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            return sequence

    return MOJIBAKE.sub(decode_sequence, value)


def description_text(value):
    value = html.unescape(repair_mojibake(value))
    value = re.sub(r"(?i)<(?:br\s*/?|/p|/div)>", "\n", value)
    value = re.sub(r"<[^>]*>", "", value)
    return "\n".join(" ".join(line.split()) for line in value.splitlines()).strip()


def synopsis_lines(value, width, count):
    lines = []
    for paragraph in description_text(value).splitlines():
        # font12 averages ~12.4 px per character; wrap early so Kodi never clips a word.
        lines.extend(textwrap.wrap(paragraph, width=max(12, int(width // 13))) or [""])
    if len(lines) > count and count:
        lines[count - 1] = lines[count - 1].rstrip(" .") + "…"
    return lines[:count]


class OutsideTimeline(ValueError):
    pass


def channel_programmes(programmes, channel):
    matching = []
    for programme in programmes or ():
        key = programme_key(programme)
        if key is not None and key[0] == channel:
            matching.append((key[2], key[3], programme))
    matching.sort(key=lambda item: (item[0], item[1]))
    return [item[2] for item in matching]


def nearest_programme(programmes, channel, target_time):
    events = channel_programmes(programmes, channel)
    if not events:
        return None
    for event in events:
        key = programme_key(event)
        if key[2] <= target_time < key[3]:
            return event
    return min(
        events,
        key=lambda event: min(
            abs(programme_key(event)[2] - target_time),
            abs(programme_key(event)[3] - target_time)
        )
    )


def adjacent_programme(programmes, channel, selected, direction):
    if direction not in (-1, 1):
        raise ValueError("direction must be -1 or 1")
    events = channel_programmes(programmes, channel)
    if not events:
        return None
    selected_key = programme_key(selected) if selected is not None else None
    if selected_key is None:
        return events[0] if direction > 0 else events[-1]
    for index, event in enumerate(events):
        if programme_key(event) == selected_key:
            next_index = index + direction
            return events[next_index] if 0 <= next_index < len(events) else None
    target = selected_key[2]
    return nearest_programme(events, channel, target)


def channel_direction_for_action(action_id, move_up, move_down,
                                 channel_up=None, channel_down=None):
    if move_up is not None and action_id == move_up:
        return -1
    if move_down is not None and action_id == move_down:
        return 1
    if channel_up is not None and action_id == channel_up:
        return 1
    if channel_down is not None and action_id == channel_down:
        return -1
    return None


def _format_time(timestamp, timezone):
    return datetime.datetime.fromtimestamp(timestamp, timezone).strftime("%H:%M")


def local_startup_logo(logo):
    """Only a local artwork file may be handed to the tuning window."""
    if not logo:
        return None
    import xbmcvfs

    if logo.startswith("special://") or (os.path.isabs(logo) and not logo.startswith(("\\\\", "//"))):
        path = xbmcvfs.translatePath(logo)
        if os.path.isabs(path) and not path.startswith(("\\\\", "//")) and os.path.isfile(path):
            return logo
        return None
    return None


def channel_presentation(channel, event, branding, channel_name, fallback_logo=None):
    title, logo = branding.get(channel, (None, None))
    tile = event.get("tileChannel") if event else None
    if isinstance(tile, dict) and tile.get("codename") == channel:
        if not title and isinstance(tile.get("title"), str) and tile["title"].strip():
            title = tile["title"]
        if not logo:
            dark_logo = tile.get("logoUrlOnDark")
            if isinstance(dark_logo, str) and dark_logo.strip():
                logo = dark_logo
    title = title or channel_name(channel)
    if not logo and fallback_logo:
        logo = fallback_logo(channel, title)
    return title, logo


def playback_metadata(channel_title, logo, event):
    title = event.get("title") if isinstance(event, dict) else None
    title = repair_mojibake(title).strip() if isinstance(title, str) else ""
    description = event.get("description") if isinstance(event, dict) else None
    return {
        "title": "{} — {}".format(channel_title, title) if title else channel_title,
        "plot": description_text(description) if isinstance(description, str) else "",
        "logo": logo,
    }


def open_guide(channels, peek_programmes, load_programmes, channel_name,
               addon_path, log, account_key, timezone, channel_logo=None,
               start_playback=None, refresh_channels=None, access_status="",
               rewind_observation=None, confirm_restart=None, owned_playback=None,
               open_settings=None, peek_branding=None, peek_crt=None, timeshift_denied=None,
               monitor=None, playback_actions=None,
               mini_picture=None, report_view=None, needs_refresh=None, should_close=None,
               peek_details=None, load_details=None, lookup_replay=None, channel_numbers=None,
               playback_error=None, localize=None, addon_enabled=None, artwork=None):
    import xbmc
    import xbmcgui

    if monitor is None:
        monitor = xbmc.Monitor()
    if monitor.abortRequested():
        return None
    window = xbmcgui.Window(10000)
    german = xbmc.getLanguage(xbmc.ISO_639_1) == "de"
    text = GUIDE_TEXT[german]
    access_text = ACCESS_TEXT[german]
    # Shared with the caller so a lineup refresh also updates the provider numbers.
    numbers = channel_numbers if channel_numbers is not None else {}
    selection_property = "magentatv_at_t.guide.selection." + account_key
    solid_texture = os.path.join(
        addon_path, "resources", "skins", "Default", "media", "guide-solid.png")
    badge_texture = os.path.join(os.path.dirname(solid_texture), "guide-rewind.png")
    catchup_texture = os.path.join(os.path.dirname(solid_texture), "guide-catchup.png")

    class GuideDialog(xbmcgui.WindowXMLDialog):
        def __init__(self, xml_filename, script_path, default_skin, default_res):
            super().__init__(xml_filename, script_path, default_skin, default_res)
            self.channels = list(channels)
            self.access_status = access_status
            self.check_channels_after = time.monotonic() + 1
            self.programmes = []
            self.events_by_channel = {}
            self.loading = False
            self.error = ""
            self.timezone = timezone
            self.channel_name = channel_name
            self.channel_logo = channel_logo
            self.branding = peek_branding() if peek_branding is not None else {}
            self.art_revision = None
            self.log = log
            self.cancel = threading.Event()
            self.closed = False
            self.pending = None
            self.pending_lock = threading.Lock()
            self.request = None
            self.request_cached = None
            self.worker_request = None
            self.worker_thread = None
            self.details_key = None
            self.details_after = 0
            self.details_worker = None
            self.details_pending = None
            self.details_value = None
            self.details_error = None
            self.replay_offer = None
            self.replay_error = False
            self.replay_checked = False
            self.catchup_requested = None
            self.details_lock = threading.Lock()
            self.fetch_after = 0
            self.auto_refresh_after = 0
            self.slots = {}
            self.image_colors = {}
            self.control_labels = {}
            self.button_enabled = {}
            self.footer_mode = False
            self.focus_requested = None
            self.event_controls = {}
            self.restart_controls = {}
            self.rewind_data = {}
            self.action_controls = {}
            self.selected_channel = 0
            self.channel_number = ChannelNumber(numbers)
            self.number_shown = False
            self.first_channel = 0
            self.selected_programme = None
            self.restore_key = None
            self.detail_label = None
            self.start_button = None
            self.visible_count = 1
            self.rendered_minute = None
            self.marker_layer = 0
            self.animated_branding = None
            self.branding_slide = None
            self.slide_items = None
            self.slide_state = None
            self.slide_waiting_for_logo = False
            self.slide_reveal_at = None
            self.name_rows = {}
            self.logo_warm = {}
            self.logo_warm_due = None
            self.ui_error = None
            self.initialized = False
            self.result = None
            self.reported_view = None
            self.handoff = None
            self.startup = None
            self.startup_clock = 0
            self.startup_frame = None
            self.startup_textures = None
            self.can_return = False
            self.mini_active = False
            self.fullscreen_video = False
            now = time.time()
            self.anchor = now
            self.view_start = self._snap(now - 90 * 60)
            self.first_view = self._snap(now - GUIDE_PAST_SECONDS)
            self.last_view = self._snap(now + GUIDE_FUTURE_SECONDS - TIMELINE_SECONDS)
            self._restore_selection()

        def _snap(self, timestamp):
            return math.floor(timestamp / TIMELINE_STEP_SECONDS) * TIMELINE_STEP_SECONDS

        def _restore_selection(self):
            try:
                state = json.loads(window.getProperty(selection_property) or "{}")
                channel = state.get("channel")
                if channel in self.channels:
                    self.selected_channel = self.channels.index(channel)
                    self.restore_key = (state.get("programme_id"), state.get("programme_start"))
                    saved_view = state.get("view")
                    saved_anchor = state.get("anchor")
                    if (isinstance(saved_view, (int, float))
                            and self.first_view <= saved_view <= self.last_view):
                        self.view_start = self._snap(saved_view)
                    if (isinstance(saved_anchor, (int, float))
                            and self.view_start <= saved_anchor
                            < self.view_start + TIMELINE_SECONDS):
                        self.anchor = saved_anchor
            except (AttributeError, TypeError, ValueError):
                return

        def _save_selection(self):
            channel = (self.channels[self.selected_channel]
                       if self.channels and self.selected_channel < len(self.channels) else "")
            selected = programme_key(self.selected_programme) if self.selected_programme else None
            window.setProperty(selection_property, json.dumps({
                "channel": channel,
                "view": self.view_start,
                "anchor": self.anchor,
                "programme_start": selected[2] if selected else None,
                "programme_id": selected[1] if selected else ""
            }))

        def onInit(self):
            if self.closed or monitor.abortRequested():
                return
            try:
                self.width = self.getWidth() or 1280
                self.height = self.getHeight() or 720
                self.video_large = self.getControl(100)
                self.video_small = self.getControl(102)
                self.video_large.setVisible(False)
                self.video_small.setVisible(False)
                try:
                    self.branding_slide = tuple([
                        self.getControl(control_id) for control_id in BRANDING_SLIDE_IDS])
                except RuntimeError:
                    self.branding_slide = None
                grid_height = (self.height - self._footer_height() - self._grid_gap()
                               - self._row_basis_top())
                self.visible_count = max(1, min(12, grid_height // 48))
                self._ensure_selected_channel_visible()
                self._request_view(immediate=True)
                self._render()
                self.initialized = not self.closed
            except Exception as error:
                self._fail_ui("initialization", error)

        def _resolve_selection(self):
            candidates = self._visible_events(self.channels[self.selected_channel]) if self.channels else []
            key = programme_key(self.selected_programme)
            self.selected_programme = next(
                (event for event in candidates if programme_key(event) == key), None)
            if self.selected_programme is None and self.restore_key is not None:
                self.selected_programme = next(
                    (event for event in candidates if programme_key(event)[1:3] == self.restore_key),
                    None)
                if self.selected_programme is not None or not self.loading:
                    self.restore_key = None
            if self.selected_programme is None:
                # A partially loaded row must not pull the time cursor to a different slot.
                self.selected_programme = next(
                    (event for event in candidates
                     if programme_key(event)[2] <= self.anchor < programme_key(event)[3]),
                    None)

        def _visible_events(self, channel):
            return [event for event in self.events_by_channel.get(channel, ())
                    if self._event_is_visible(event, self.view_start,
                                              self.view_start + TIMELINE_SECONDS)]

        def _set_programmes(self, programmes):
            self.programmes = programmes
            self.events_by_channel = {}
            for event in programmes:
                key = programme_key(event)
                if key is not None:
                    self.events_by_channel.setdefault(key[0], []).append((key[2:4], event))
            for channel, events in self.events_by_channel.items():
                self.events_by_channel[channel] = [
                    event for _, event in sorted(events, key=lambda value: value[0])]

        def _request_view(self, immediate=False):
            channels = tuple(self.channels[self.first_channel:self.first_channel + self.visible_count])
            key = (datetime.datetime.fromtimestamp(self.view_start, datetime.timezone.utc), channels)
            if not channels or (self.request is not None and key == self.request[0]):
                return
            self.request = (key, object())
            self.auto_refresh_after = 0
            cached = peek_programmes(*key)
            self.request_cached = list(cached) if cached is not None else None
            self._set_programmes(self.request_cached if cached is not None else [
                event for channel in channels for event in self._visible_events(channel)
            ])
            self.loading = (cached is None or
                            (needs_refresh is not None and needs_refresh(*key)))
            self.error = ""
            self.fetch_after = time.monotonic() + (0 if immediate else 0.15)
            self._resolve_selection()

        def _start_worker(self):
            if (monitor.abortRequested() or not self.loading or self.worker_request is not None
                    or time.monotonic() < self.fetch_after):
                return
            request = self.worker_request = self.request
            cached = self.request_cached

            def cancelled():
                return self.cancel.is_set() or self.request is not request

            def queue_result(programmes, loading, error=""):
                with self.pending_lock:
                    if not self.cancel.is_set():
                        self.pending = (request, programmes, loading, error)

            def worker():
                latest = None

                def publish(programmes):
                    nonlocal latest
                    latest = programmes
                    queue_result(latest, True)

                try:
                    result = load_programmes(*request[0], cancelled, publish)
                    queue_result(result, False)
                except LiveDataCancelled:
                    queue_result(cached if cached is not None else latest, False,
                                 "Programme guide fetch cancelled")
                except Exception as error:
                    message = ProviderError.from_exception(error)
                    if message is None:
                        message = (str(error) if isinstance(error, LiveDataError) else
                                   "Unexpected programme guide fetch failure ({})".format(type(error).__name__))
                    if not cancelled():
                        self.log("Programme guide: " + str(message))
                    queue_result(cached if cached is not None else latest, False, message)

            self.worker_thread = threading.Thread(target=worker, name="magenta-guide", daemon=True)
            self.worker_thread.start()

        def _apply_number(self, confirm=False):
            """Select a visible channel by its unfiltered lineup number."""
            number = self.channel_number.take(time.monotonic(), confirm)
            if number is None:
                if not self.channel_number.digits and self.number_shown:
                    self._render()
                return False
            if number == SETTINGS_SHORTCUT:
                self._activate("settings")
                if not self.closed:
                    self._render()
                return True
            channel, reason = number_channel(number, numbers, self.channels)
            if not reason:
                self._move_channel(self.channels.index(channel) - self.selected_channel)
            self._render()
            return True

        def _apply_pending(self):
            if monitor.abortRequested():
                return
            self._apply_number()
            if self.closed:
                return
            self._update_details()
            if artwork is not None and self.art_revision != artwork.revision:
                self.art_revision = artwork.revision
                self._render()
            if self.slide_waiting_for_logo and self.slide_state is not None:
                # Keep the already painted name until Kodi finishes its first
                # native scroll (220 ms) into the newly populated logo item.
                if self.branding_slide[2].getSelectedPosition() != 1:
                    self.slide_reveal_at = None
                elif self.slide_reveal_at is None:
                    self.slide_reveal_at = time.monotonic() + 0.22
                elif time.monotonic() >= self.slide_reveal_at:
                    self.slide_waiting_for_logo = False
                    self.slide_reveal_at = None
                    self._render()
            if self.logo_warm_due is not None and time.monotonic() >= self.logo_warm_due:
                self._render()
            if peek_branding is not None and time.monotonic() >= self.check_channels_after:
                updated_branding = peek_branding()
                if updated_branding is not None and updated_branding != self.branding:
                    self.branding = updated_branding
                    self._render()
                if refresh_channels is None:
                    self.check_channels_after = time.monotonic() + 1
            if refresh_channels is not None and time.monotonic() >= self.check_channels_after:
                updated, status = refresh_channels()
                self.check_channels_after = time.monotonic() + 1
                status_changed = status != self.access_status
                self.access_status = status
                if updated != self.channels:
                    old_index = self.selected_channel
                    selected = self.channels[old_index] if self.channels else None
                    if self.channels and not updated:
                        self._save_selection()
                    self.channels = list(updated)
                    if selected is None and self.channels:
                        self._restore_selection()
                    elif selected in self.channels:
                        self.selected_channel = self.channels.index(selected)
                    else:
                        self.selected_channel = max(0, min(old_index, len(self.channels) - 1))
                        self.selected_programme = None
                        self.restore_key = None
                    self._ensure_selected_channel_visible()
                    if self.channels:
                        self._request_view()
                    else:
                        self.request = None
                        self.loading = False
                        self._set_programmes([])
                    self._render()
                elif status_changed:
                    self._render()
            with self.pending_lock:
                pending, self.pending = self.pending, None
            if pending is not None and not self.closed:
                request, result, loading, error = pending
                if not loading:
                    self.worker_request = None
                if request is self.request:
                    data = list(result) if result is not None else self.programmes
                    if (data, loading, error) != (self.programmes, self.loading, self.error):
                        if data != self.programmes:
                            self._set_programmes(data)
                        self.loading, self.error = loading, error
                        if error and not loading:
                            self.auto_refresh_after = time.monotonic() + GUIDE_REFRESH_RETRY_SECONDS
                        self._resolve_selection()
                        self._render()
                        if error and not self.closed and not monitor.abortRequested():
                            # Invalidate the idle screen while Kodi applies queued label updates.
                            self.slots["status"][1].setAnimations([
                                ("Conditional", "effect=fade start=90 end=100 time=1000 condition=true")])
            if not self.closed:
                playing = self._owned_playing()
                if (self.can_return != playing
                        or self.mini_active != self._mini_picture_active(playing)):
                    self._render()
                if self.rendered_minute != int(time.time() // 60):
                    if (self.request is not None and not self.loading
                            and time.monotonic() >= self.auto_refresh_after):
                        key = self.request[0]
                        if ((confirm_restart is not None and peek_programmes(*key) is None)
                                or (needs_refresh is not None and needs_refresh(*key))):
                            self._refresh_view()
                    self._render()
                self._start_worker()

        def _refresh_view(self):
            self.request = (self.request[0], object())
            cached = peek_programmes(*self.request[0])
            self.request_cached = list(cached) if cached is not None else None
            self.loading = True
            self.fetch_after = time.monotonic()

        def _control(self, key, spec, create):
            self.used_slots.add(key)
            previous = self.slots.get(key)
            if previous is not None:
                last_spec, control = previous
                if last_spec == spec:
                    return control
                self.retired.append(control)
                self.image_colors.pop(key, None)
                self.control_labels.pop(key, None)
                self.button_enabled.pop(key, None)
            control = create()
            self.slots[key] = (spec, control)
            self.additions.append(control)
            return control

        def _place_branding_slide(self, branding):
            if self.branding_slide is None or branding == self.slide_state:
                return
            group, background, carousel = self.branding_slide
            self.slide_state = branding
            self.slide_reveal_at = None
            if branding is None:
                # Parked rather than hidden: a hidden list restarts its autoscroll
                # clock and would slide immediately when it comes back.
                group.setPosition(-4000, 0)
                return
            title, texture, x, y, color = branding
            group.setPosition(x, y)
            background.setColorDiffuse(color)
            if self.slide_items is None:
                # If art arrived after the name was drawn, keep the name on
                # screen while Kodi loads the new cropped texture.
                name, logo = xbmcgui.ListItem(title), xbmcgui.ListItem("")
                logo.setArt({"thumb": texture})
                carousel.addItems([name, logo])
                carousel.selectItem(0 if self.initialized else 1)
                self.slide_items = (name, logo)
                self.slide_waiting_for_logo = self.initialized
                self.setProperty(BRANDING_SLIDE_PROPERTY, "true")
            else:
                name, logo = self.slide_items
                if name.getLabel() != title:
                    name.setLabel(title)
                if logo.getArt("thumb") != texture:
                    logo.setArt({"thumb": texture})

        def _image(self, key, x, y, width, height, color, filename=solid_texture, aspect=0):
            geometry = (int(x), int(y), int(width), int(height))
            control = self._control(key, (geometry, filename, aspect), lambda:
                xbmcgui.ControlImage(*geometry, filename, aspectRatio=aspect, colorDiffuse=color))
            if self.image_colors.get(key) != color:
                if key in self.image_colors:
                    control.setColorDiffuse(color)
                self.image_colors[key] = color
            return control

        def _label(self, key, x, y, width, height, text, size, color, alignment=0, shadow="",
                   movable=False):
            geometry = (int(x), int(y), int(width), int(height))
            previous = self.slots.get(key) if movable else None
            if previous is not None and previous[0][1:] == (size, color, alignment, shadow) \
                    and previous[0][0] != geometry:
                # Move in place so status changes don't rebuild the header's draw order.
                previous[1].setPosition(geometry[0], geometry[1])
                previous[1].setWidth(geometry[2])
                self.slots[key] = ((geometry, size, color, alignment, shadow), previous[1])
            control = self._control(key, (geometry, size, color, alignment, shadow), lambda:
                xbmcgui.ControlLabel(*geometry, text, font=size, textColor=color, alignment=alignment))
            if self.control_labels.get(key) != text:
                if shadow:
                    control.setLabel(text, shadowColor=shadow)
                elif key in self.control_labels:
                    control.setLabel(text)
                self.control_labels[key] = text
            return control

        def _synopsis(self, x, y, width, height, value):
            line_height = 28
            for index, line in enumerate(synopsis_lines(value, width, max(0, int(height // line_height)))):
                self._label(("synopsis", index), x, y + index * line_height,
                            width, line_height, line, "font12", "0xFFB8C6D8")

        def _button(self, key, x, y, width, height, text, enabled=True, size="font13",
                    texture="", focused_texture=None, center_y=False):
            geometry = (int(x), int(y), int(width), int(height))
            focus = texture if focused_texture is None else focused_texture
            alignment = 6 if texture else (4 if center_y else 0)
            control = self._control(key, (geometry, size, texture, focus, alignment), lambda: xbmcgui.ControlButton(
                *geometry, text, font=size,
                textColor="0xFFF1F5F9", focusedColor="0xFF80D6FF",
                disabledColor="0xFF7B8492", shadowColor="0x80000000",
                focusTexture=focus, noFocusTexture=texture,
                alignment=alignment,
                textOffsetX=0 if texture else 8, textOffsetY=0 if alignment & 4 else 2
            ))
            if self.control_labels.get(key) != text:
                if key in self.control_labels:
                    control.setLabel(text)
                self.control_labels[key] = text
            if self.button_enabled.get(key) != enabled:
                self.enable_updates.append((control, enabled))
                self.button_enabled[key] = enabled
            return control

        def _fail_ui(self, phase, error):
            self.ui_error = error
            self.result = None
            if not monitor.abortRequested():
                self.log("Guide {} failed: {}".format(phase, type(error).__name__))
            self.close()

        def _event_title(self, event):
            title = event.get("title")
            return repair_mojibake(title) if isinstance(title, str) and title else text["programme"]

        def _header_height(self):
            return max(50, int(self.height * 0.06))

        def _row_basis_top(self):
            # Row size and count are measured from the former, taller header.
            return max(58, int(self.height * 0.085)) + 44

        def _footer_height(self):
            return max(220, int(self.height * 0.25))

        def _grid_gap(self):
            return max(24, int(self.height * 0.035))

        def _render_startup(self):
            title, _, art = self.startup
            width, height = self.width, self.height
            logo_width, logo_height = tuning_logo_size(width, height)
            if self.startup_textures is None:
                self._image("startup-black", 0, 0, width, height, "0xFF000000")
                top = (height - logo_height) // 2
                if art:
                    self._image("startup-logo", (width - logo_width) // 2, top,
                                logo_width, logo_height, "0xFFFFFFFF", art, 2)
                label_width = max(1, min(544, width - 16))
                self._label("startup-station", (width - label_width) // 2,
                            min(height - 35, top + logo_height + 6), label_width, 35,
                            title, "font14", "0xFFF6FAFF", 6, "FF101722")
                return
            static_textures, interference_textures = self.startup_textures
            for frame, texture in enumerate(static_textures):
                key = "startup-static" if frame == 0 else ("startup-static", frame)
                self._image(key, 0, 0, width, height, "0xFFFFFFFF", texture)
            content_height = logo_height + 100 if art else 100
            center = max(0, (height - content_height) // 2)
            label_width = max(1, min(544, width - 16))
            left = (width - label_width) // 2
            if art:
                self._image("startup-logo", (width - logo_width) // 2, center,
                            logo_width, logo_height, "0xEADBE8EF", art, 2)
            station_top = center + (logo_height + 5 if art else 0)
            self._label("startup-station", left, station_top, label_width, 35,
                        title, "font14", "0xFFF6FAFF", 6, "FF101722")
            signal_top = max(0, center - 3)
            for frame, texture in enumerate(interference_textures):
                key = ("startup-interference", art) if frame == 0 else ("startup-interference", art, frame)
                self._image(key, 0, signal_top, width, min(height, station_top) - signal_top,
                            "0xFFFFFFFF", texture)
            self._label("startup-status", left, station_top + 38,
                        label_width, 30, text["starting"], "font13", "0xFFFFFFFF", 6, "FF101722")
            self._label("startup-cancel", left, station_top + 69, label_width, 24,
                        text["startup_cancel"], "font10", "0xFFF2F7FC", 6, "FF101722")
            self.startup_frame = None

        def _animate_startup(self):
            if self.startup is None or self.startup_textures is None:
                return
            count = len(self.startup_textures[0])
            frame = int(max(0, time.monotonic() - self.startup_clock) * CRT_FPS) % count
            if self.startup_frame != frame:
                art = self.startup[2]
                def set_frame(index, visible):
                    field = "startup-static" if index == 0 else ("startup-static", index)
                    snow = ("startup-interference", art) if index == 0 else ("startup-interference", art, index)
                    self.slots[field][1].setVisible(visible)
                    self.slots[snow][1].setVisible(visible)
                if self.startup_frame is None:
                    for index in range(count):
                        set_frame(index, index == frame)
                else:
                    set_frame(frame, True)
                    set_frame(self.startup_frame, False)
                self.startup_frame = frame

        def _owned_playing(self):
            if owned_playback is None:
                return False
            try:
                return owned_playback["player"].isPlayingVideo() and owned_playback["matches"]()
            except RuntimeError:
                return False

        def _mini_picture_active(self, playing=None):
            if playing is None:
                playing = self._owned_playing()
            return (self._video_size() is not None
                    and self.startup is None and mini_picture is not None
                    and mini_picture() and playing)

        def _video_size(self):
            # Kodi exposes the XML groups to Python, but not their video controls.
            pad = max(18, int(self.width * 0.02))
            available_height = self._footer_height() - 94
            for width, height in ((312, 176), (216, 121)):
                if (self.height >= 360 and available_height >= height
                        and self.width - pad * 2 - width - 36 >= 180):
                    return width, height
            return None

        def _return_to_stream(self, activate=True):
            if self._owned_playing() and not self.closed and self.startup is None:
                self._save_selection()
                self.result = dict(owned_playback, fullscreen=not activate)
                self.close()
                if activate and not owned_playback.get("owned_window"):
                    if self._owned_playing():
                        xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
                    else:
                        self.result = None
            elif activate:
                self._render()

        def _update_details(self):
            if peek_details is None or load_details is None:
                return
            selected = programme_key(self.selected_programme)
            program_id = selected[1] if selected else ""
            if (not isinstance(program_id, str) or program_id in (".", "..")
                    or not re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", program_id)):
                program_id = ""
            if selected != self.details_key:
                self.details_key = selected
                if self.catchup_requested != selected:
                    self.catchup_requested = None
                self.details_after = time.monotonic() + 0.35
                self.details_value = peek_details(program_id) if program_id else None
                self.details_error = None
                self.replay_offer = None
                self.replay_error = False
                self.replay_checked = False
                self._render()
            with self.details_lock:
                pending, self.details_pending = self.details_pending, None
            if pending is not None:
                key, value, offer, failed, detail_error = pending
                if key == self.details_key and not self.closed:
                    if value is not None:
                        self.details_value = value
                    self.replay_offer = offer
                    self.replay_error = failed
                    self.details_error = detail_error
                    self.replay_checked = True
                    self._render()
                    if self.catchup_requested == key and not self.closed:
                        self.catchup_requested = None
                        if "catchup" in self._actions(self.selected_programme):
                            self._activate("catchup")
                        else:
                            status = self._replay_status(self.selected_programme, time.time())
                            xbmcgui.Dialog().notification(
                                "Magenta TV ATᵀ",
                                text["past_unavailable" if status == "unavailable" else status],
                                time=3000)
            if self.details_worker is not None and not self.details_worker.is_alive():
                self.details_worker.join()
                self.details_worker = None
            check_replay = (lookup_replay is not None and selected and selected[2] <= time.time()
                            and replay_flag(self.selected_programme) is not False)
            if (not program_id or (self.details_value is not None and not check_replay) or self.details_worker is not None
                    or time.monotonic() < self.details_after):
                return
            key = selected
            need_details = self.details_value is None
            self.details_after = time.monotonic() + 300

            def cancelled():
                return self.cancel.is_set() or self.details_key != key

            def worker():
                value, offer, failed = None, None, False
                detail_error = None
                try:
                    if need_details:
                        value = load_details(program_id)
                except Exception as error:
                    detail_error = ProviderError.from_exception(error)
                    self.log("Programme details unavailable: {}".format(type(error).__name__))
                if check_replay and not cancelled():
                    try:
                        offer = lookup_replay(key, cancelled)
                    except (LiveDataError, PlaybackError, OSError, RuntimeError, ValueError) as error:
                        self.log("Replay availability check failed: {}".format(type(error).__name__))
                        failed = ProviderError.from_exception(error) or True
                with self.details_lock:
                    if not self.cancel.is_set():
                        self.details_pending = (key, value, offer, failed, detail_error)

            self.details_worker = threading.Thread(target=worker, name="magenta-details", daemon=True)
            self.details_worker.start()

        def _channel_presentation(self, channel, events, now):
            current = next(
                (event for event in events
                 if programme_key(event)[2] <= now < programme_key(event)[3]),
                None
            )
            event = current or nearest_programme(self.events_by_channel.get(channel, ()), channel, now)
            title, source = channel_presentation(channel, event, self.branding, self.channel_name,
                                                self.channel_logo)
            if artwork is not None:
                source = artwork.get(source)
            elif isinstance(source, str) and source.startswith(("http://", "https://")):
                source = None
            return title, source

        def _event_is_visible(self, event, start, end):
            key = programme_key(event)
            return key is not None and key[2] < end and key[3] > start

        def _replay(self, event, now):
            key = programme_key(event)
            if key is None:
                return None
            rewind, denied = self._rewind_data(key[0])
            return replay_start(event, now, rewind, denied)

        def _rewind_data(self, channel):
            if channel not in self.rewind_data:
                self.rewind_data[channel] = (
                    rewind_observation(channel) if rewind_observation else None,
                    timeshift_denied(channel) if timeshift_denied else False)
            return self.rewind_data[channel]

        def _actions(self, event, now=None):
            now = time.time() if now is None else now
            key = programme_key(event)
            if key is None:
                return ()
            rewind, denied = self._rewind_data(key[0])
            return available_actions(event, now, rewind, denied,
                                     key == self.details_key and self.replay_offer is not None
                                     and now < self.replay_offer.expires)

        def _replay_status(self, event, now):
            key = programme_key(event)
            # Magenta's guide flag is per station; a cleared flag has no Replay offer.
            if (lookup_replay is not None and key and key[1] and key[2] <= now
                    and replay_flag(event) is not False):
                if self.details_key != key or not self.replay_checked:
                    if re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", key[1]) and key[1] not in (".", ".."):
                        return "checking_replay"
                elif self.replay_error:
                    return "replay_error"
            return "unavailable"

        def _availability(self, event, now):
            """One truthful line for the selected airing: Replay, then the live buffer."""
            key = programme_key(event)
            if key is None:
                return text["rewind_live"]
            if key[2] > now:
                return text["not_aired"]
            flag = replay_flag(event)
            status = self._replay_status(event, now)
            if (key == self.details_key and self.replay_offer is not None
                    and now < self.replay_offer.expires):
                line = text["replay_offered"]
            elif flag is False:
                line = text["replay_not_offered"]
            elif status == "checking_replay":
                line = text["replay_flagged" if flag else "replay_checking"]
            elif status == "replay_error":
                line = text["replay_unchecked"]
            elif lookup_replay is not None and key == self.details_key and self.replay_checked:
                line = text["replay_none"]
            else:
                line = text["replay_marked" if flag else "replay_unchecked"]
            if not key[2] <= now < key[3]:
                return line
            state = start_over_state(event, now)
            if state is not None:
                return line + "  ·  " + text["start_over_" + {"available": "live"}.get(state, state)]
            rewind = self._rewind_data(key[0])[0]
            if rewind and rewind.get("seconds") is not None:
                return line + "  ·  " + text["rewind_observed"].format(
                    format_duration(rewind["seconds"]), rewind["format"])
            return line + "  ·  " + text["rewind_live"]

        def _render(self):
            if self.closed or monitor.abortRequested():
                return
            try:
                self._render_controls()
                if report_view is not None and not self.closed and not monitor.abortRequested():
                    view = (
                        sum(bool(event.get("title", "").strip())
                            for _, event in self.event_controls.values()),
                        self.loading, bool(self.error),
                    )
                    if view != self.reported_view:
                        report_view(*view)
                        self.reported_view = view
            except Exception as error:
                self._fail_ui("render", error)

        def _focus_id(self):
            try:
                return self.getFocusId()
            except RuntimeError:
                return None

        def _focus(self, control):
            target = control.getId()
            if target == self._focus_id() and self.focus_requested in (None, target):
                self.focus_requested = None
            elif target != self.focus_requested:
                self.focus_requested = target
                self.setFocus(control)

        def _render_controls(self):
            if self.closed:
                return
            focused = self._focus_id()
            focused_restart = self.restart_controls.get(self.focus_requested or focused)
            self.used_slots = set()
            self.retired = []
            self.additions = []
            self.enable_updates = []
            self.text_updates = []
            self.rewind_data = {}
            event_buttons = []
            restart_buttons = []
            badge_overlays = []

            width, height = self.width, self.height
            pad = max(18, int(width * 0.02))
            number_column = GUIDE_NUMBER_COLUMN if numbers else 0
            cell_trim = GUIDE_CELL_TRIM if number_column else 0
            left = max(124, int(width * 0.12)) + number_column - cell_trim
            timeline_x = left + 18
            timeline_width = max(100, width - timeline_x - pad)
            grid_right = timeline_x + timeline_width
            footer_height = self._footer_height()
            header_height = self._header_height()
            axis_height = GUIDE_AXIS_HEIGHT
            grid_top = header_height + axis_height
            grid_bottom = height - footer_height - self._grid_gap()
            row_count = self.visible_count
            # Rows keep their size; space freed by the compact header goes to the details.
            row_height = max(36, int((grid_bottom - self._row_basis_top()) / row_count))
            # Tiles are separated by one thin line of window background, nothing stacked.
            gap_x, gap_y = guide_tile_gaps(width, height)
            tile_height = row_height - gap_y
            window_end = self.view_start + TIMELINE_SECONDS
            scale = timeline_width / TIMELINE_SECONDS
            now = time.time()
            self.rendered_minute = int(now // 60)
            local_now = datetime.datetime.fromtimestamp(now, self.timezone)

            # The details panel shares the last row's gap line; the rounding remainder
            # goes to the details instead of an empty band.
            footer_y = min(height - footer_height, grid_top + row_height * row_count)
            footer_height = height - footer_y
            video_size = self._video_size()
            video_width, video_height = video_size or (0, 0)
            video_x = width - pad - 12 - video_width
            video_y = footer_y + 8
            video_fits = video_size is not None
            self.can_return = self._owned_playing()
            self.mini_active = self._mini_picture_active(self.can_return)
            self.fullscreen_video = bool(self.can_return and not self.mini_active
                                         and self.startup is None)

            def surface(color, alpha):
                return "0x" + alpha + color[4:] if self.fullscreen_video else color

            # Keep footer controls in the same draw order when the preview changes.
            if video_fits:
                self.video = self.video_large if video_width == 312 else self.video_small
                self.video.setPosition(video_x, video_y)
            self._image("header", 0, 0, width, header_height, surface("0xFF202C3A", "D4"))
            # Measured with Estuary's NotoSans: the title needs ~0.21 W; the German help
            # (~0.57 W, or ~0.32 W for the actions alone) must fit up to the status.
            help_x = width * 0.24
            self._label("title", pad, (header_height - 34) // 2, width * 0.235 - pad, 34, "Magenta TV ATᵀ  |  " + text["live"], "font14",
                        "0xFFF1F5F9")
            date_format = "%d.%m.%Y, %H:%M" if german else "%d %b %Y, %H:%M"
            access_key = "error" if isinstance(self.access_status, ProviderError) else self.access_status
            status = (text["starting"] if self.startup is not None else
                      access_text[access_key] if access_key else
                      text["more" if self.programmes else "loading"] if self.loading else
                      text["incomplete" if self.programmes else "error"] if self.error else
                      local_now.strftime(date_format))
            self.number_shown = bool(self.channel_number.digits)
            if self.number_shown:
                status = number_status(
                    self.channel_number.digits, numbers, self.channels,
                    lambda code: self._channel_presentation(
                        code, self.events_by_channel.get(code, ()), now)[0], german,
                    self.channel_number.is_settings())
            # Key help sits in the header's empty middle, freeing a details line.
            # Longer status messages keep only the action keys beside them.
            quiet = status == local_now.strftime(date_format)
            # Help and status share the header row without overlapping.
            status_x = width * (0.84 if quiet else 0.585)
            self._label("help", help_x, (header_height - 26) // 2, status_x - pad - help_x, 26,
                        text["navigate"] + "   " + text["actions"] if quiet else text["actions"],
                        "font10", "0xFF9AAABD", 4, movable=True)
            # Right edge = the grid's right edge (timeline_x + timeline_width).
            self._label("status", status_x, (header_height - 26) // 2, width - pad - status_x, 26,
                        status, "font13", "0xFFB8C6D8", alignment=1, movable=True)

            self._image("axis", 0, header_height, width, axis_height,
                        "0xD4202C3A" if self.fullscreen_video else "0x00202C3A")
            first_tick = math.ceil(self.view_start / 3600) * 3600
            tick = first_tick
            while tick <= window_end:
                x = int(timeline_x + (tick - self.view_start) * scale)
                self._label(("tick", tick), min(x + 4, width - pad - 70),
                            header_height + GUIDE_TICK_TOP, 70, GUIDE_TICK_HEIGHT,
                            _format_time(tick, self.timezone), GUIDE_TICK_FONT, "0xFF9AAABD", 4)
                tick += 3600

            channel_window = self.channels[
                self.first_channel:self.first_channel + row_count
            ]
            animated_branding = None
            slide_branding = None
            revealed_names = set()
            warming_rows = {}
            named_rows = {}
            now_monotonic = time.monotonic()
            label_width = left - pad - 16 - number_column + cell_trim
            column_right = pad + 8 + number_column + label_width
            slide = (self.branding_slide
                     if (label_width, row_height) == BRANDING_SLIDE_CELL else None)
            for row, channel in enumerate(channel_window):
                y = grid_top + row * row_height
                events = self._visible_events(channel)
                channel_title, channel_logo_url = self._channel_presentation(
                    channel, events, now
                )
                channel_selected = self.first_channel + row == self.selected_channel
                row_color = ("0xFF325063" if channel_selected else
                             "0xFF202A37" if row % 2 == 0 else "0xFF1B2430")
                has_logo = (isinstance(channel_logo_url, str) and channel_logo_url.strip()
                            and os.path.normcase(os.path.normpath(channel_logo_url))
                            != os.path.normcase(os.path.join(addon_path, "icon.png")))
                slide_row = slide is not None and has_logo and channel_selected
                hold_name = slide_row and (self.slide_waiting_for_logo
                                           or (self.slide_items is None and self.initialized))
                channel_right = timeline_x - gap_x
                if slide is None:
                    self._image(("row", row), pad, y, channel_right - pad, tile_height,
                                surface(row_color, "60"))
                else:
                    # The XML carousel sits below Python controls, so this row's
                    # channel cell stays see-through while the carousel is on it.
                    # Kodi reads diffuse 0 as "none" (opaque white): keep RGB, drop alpha.
                    if number_column:
                        self._image(("row-number", row), pad, y, number_column, tile_height,
                                    surface(row_color, "60"))
                    self._image(("row-column", row), pad + number_column, y,
                                column_right - pad - number_column, tile_height,
                                "0x00" + row_color[4:] if slide_row and not hold_name
                                else surface(row_color, "60"))
                    self._image(("row", row), column_right, y, channel_right - column_right,
                                tile_height, surface(row_color, "60"))
                label_height = 24
                label_y = y + (tile_height - label_height) // 2
                if number_column:
                    self._label(("number", row), pad - 4, label_y, number_column + 12, label_height,
                                number_text(numbers.get(channel)), "font10",
                                "0xFFF1F5F9" if channel_selected else "0xFF8B9AAF", alignment=6)
                logo = None
                warming = False
                if has_logo:
                    logo_width, logo_height = logo_box(label_width, row_height - 8)
                    logo_x = pad + 8 + number_column + (label_width - logo_width) // 2
                    logo_y = y + (tile_height - logo_height) // 2
                    logo_texture = guide_logo_texture(channel_logo_url, logo_width, logo_height)
                    if slide_row:
                        slide_branding = (channel_title, logo_texture, pad + number_column, y,
                                          surface(row_color, "60"))
                    else:
                        warm = self.logo_warm.get(row)
                        if warm is None or warm[:2] != (channel, logo_texture):
                            warm = None
                            if not channel_selected and self.name_rows.get(row) == channel:
                                # The name is on screen: let Kodi load the texture invisibly,
                                # then swap in place instead of removing the name and waiting.
                                warm = (channel, logo_texture, now_monotonic + LOGO_WARM_SECONDS)
                        warming = (warm is not None and not channel_selected
                                   and now_monotonic < warm[2])
                        if warming:
                            warming_rows[row] = warm
                        elif warm is not None:
                            revealed_names.add(("channel", row))
                        logo = self._image(("logo", row), logo_x, logo_y,
                                           logo_width, logo_height,
                                           LOGO_WARM_COLOR if warming else "0xFFFFFFFF",
                                           logo_texture, 2)
                if hold_name or (not slide_row and (logo is None or channel_selected or warming)):
                    name = self._label(("channel", row), pad + 8 + number_column, label_y, label_width, label_height,
                                       channel_title, "font10", "0xFFE0E7EF", alignment=6)
                    if logo is not None and not warming:
                        animated_branding = (channel, logo, name)
                    if not slide_row and (logo is None or warming):
                        named_rows[row] = channel
                cursor = timeline_x

                def fill_hole(left, right):
                    # Holes in the provider data are quiet tiles, never dark broken cells.
                    if right - left >= 1:
                        self._image(("gap-fill", channel, left), left, y, right - left,
                                    tile_height, surface("0xFF303944", "80"))

                for event in events:
                    key = programme_key(event)
                    start, stop = key[2], key[3]
                    x1 = max(timeline_x, int(timeline_x + (start - self.view_start) * scale))
                    x2 = min(grid_right, int(timeline_x + (stop - self.view_start) * scale))
                    if x1 - cursor > gap_x:
                        fill_hole(cursor, x1 - gap_x)
                    cursor = max(cursor, x2)
                    event_width = max(1, x2 - x1 - (gap_x if x2 < grid_right else 0))
                    key_id = key
                    is_selected = programme_key(self.selected_programme) == key_id
                    actions = self._actions(event, now)
                    # Slivers stay selectable at their real times without truncated text.
                    tiny = event_width < TINY_CELL_WIDTH
                    if is_selected:
                        color = "0xFF3B7593"
                    elif tiny:
                        color = "0xFF282F38"
                    elif "watch_live" in actions:
                        color = "0xFF31566E"
                    elif "start_from_beginning" in actions or "catchup" in actions:
                        color = "0xFF35465B"
                    else:
                        color = "0xFF303944"
                    self._image(("event-fill", key), x1, y, event_width, tile_height,
                                surface(color, "80"))
                    label = _format_time(start, self.timezone) + "  " + self._event_title(event)
                    # Replay marks follow Magenta's per-station flag; playback stays verified.
                    badge = event_badge(event, actions, now)
                    badge_size = 24
                    badge_x = replay_badge_x(badge, self.view_start, window_end, scale, timeline_x)
                    body_width = max(1, event_width)
                    if tiny and not is_selected:
                        label = ""
                    elif not is_selected:
                        # The selected cell keeps its full title for Kodi's focus scrolling.
                        label = fit_event_label(_format_time(start, self.timezone),
                                                self._event_title(event), body_width, height)
                    button = self._button(
                        ("event", key), x1, y,
                        body_width, tile_height, label,
                        size="font12", center_y=True
                    )
                    event_buttons.append((button, key_id, event))
                    if badge_x is not None:
                        texture = catchup_texture if badge[0] == "catchup" else badge_texture
                        badge_overlays.append((key, key_id, event, badge_x, y - badge_size // 2,
                                               badge_size, texture, badge[0]))

                if grid_right - cursor > gap_x:
                    fill_hole(cursor, grid_right)

            current_x = int(timeline_x + (self.rendered_minute * 60 - self.view_start) * scale)
            timeline_right = timeline_x + timeline_width
            if channel_window and timeline_x <= current_x <= timeline_right:
                # Append the line above any newly added cells in Kodi's draw order.
                if self.additions:
                    self.marker_layer += 1
                line_left = max(timeline_x, min(current_x - 1, timeline_right - TIMELINE_MARKER_WIDTH))
                self._image(("now-line", self.marker_layer), line_left, grid_top,
                            TIMELINE_MARKER_WIDTH, row_height * len(channel_window) - gap_y,
                            "0x" + TIMELINE_MARKER_COLOR)

            # Recreate old overlays when new row controls would otherwise cover them.
            if self.additions:
                for slot in [key for key in self.slots
                             if isinstance(key, tuple) and key[0] == "event-restart"]:
                    self.retired.append(self.slots.pop(slot)[1])
                    self.control_labels.pop(slot, None)
                    self.button_enabled.pop(slot, None)

            # Draw badges after the rows so their raised halves remain visible.
            for key, key_id, event, badge_x, badge_y, size, texture, action in badge_overlays:
                restart = self._button(
                    ("event-restart", key), badge_x - 2, badge_y - 2, size + 4, size + 4, "",
                    size="font10", texture=texture,
                    focused_texture=texture.replace(".png", "-focus.png"))
                restart_buttons.append((restart, key_id, event, action))

            if video_fits:
                footer_color = surface("0xFF202C3A", "D4")
                self._image("footer-top", pad, footer_y, width - pad * 2, 8, footer_color)
                self._image("footer-left", pad, video_y, video_x - pad, video_height, footer_color)
                self._image("footer-right", video_x + video_width, video_y,
                            width - pad - video_x - video_width, video_height, footer_color)
                self._image("footer-bottom", pad, video_y + video_height, width - pad * 2,
                            height - 4 - video_y - video_height, footer_color)
                self._image("footer-video", video_x, video_y, video_width, video_height,
                            "0x00202C3A" if self.mini_active else footer_color)
            else:
                self._image("footer", pad, footer_y, width - pad * 2, footer_height - 4,
                            surface("0xFF202C3A", "D4"))
            channel = self.channels[self.selected_channel] if self.channels else ""
            selected = self.selected_programme
            same_airing = programme_key(selected) == self.details_key
            selected_details = self.details_value if same_airing else None
            synopsis = ""
            if selected is not None:
                key = programme_key(selected)
                period = "{}–{}".format(
                    _format_time(key[2], self.timezone),
                    _format_time(key[3], self.timezone)
                )
                detail = "{}   {}".format(period, self._event_title(selected))
                description = selected.get("description", "")
                if isinstance(description, str):
                    synopsis = description.strip()
                if selected_details and selected_details.get("description"):
                    synopsis = selected_details["description"]
            else:
                if access_key and not self.channels:
                    detail = access_text[access_key]
                    synopsis = access_text["hint"]
                else:
                    detail = text["loading" if self.loading else "empty"]
            for problem in (self.replay_error if same_airing else None,
                            self.details_error if same_airing else None,
                            self.error, self.access_status):
                if isinstance(problem, ProviderError):
                    synopsis = problem.localized(localize) if localize else str(problem)
                    break
            detail_width = width - pad * 2 - 24
            info_width = video_x - pad - 24 if self.mini_active else detail_width
            button_y = height - 56
            artwork = selected_details.get("artwork") if selected_details else None
            if artwork:
                artwork_height = max(1, min(video_height or 150, button_y - video_y - 4))
                artwork_width = min(180, max(1, width // 8))
                artwork_x = (video_x - 12 - artwork_width if self.mini_active
                             else width - pad - 12 - artwork_width)
                self._image("programme-artwork", artwork_x, video_y, artwork_width,
                            artwork_height, "0xFFFFFFFF", artwork, 2)
                info_width = max(1, artwork_x - pad - 24)
            self.detail_label = self._label(
                "detail", pad + 12, footer_y + 8, info_width, 38,
                detail, "font14", "0xFFE7EDF5")

            if channel:
                status = (self._availability(selected, now) if selected is not None
                          else text["rewind_live"])
                self._label("rewind", pad + 12, footer_y + 49, info_width, 23,
                            status, "font10", "0xFF9AAABD")
            synopsis_y = footer_y + (77 if channel else 51)
            self._synopsis(pad + 12, synopsis_y, info_width, button_y - synopsis_y - 5, synopsis)
            last, edge = playback_actions() if playback_actions is not None and not self.startup else (None, None)
            has_tv_actions = last in self.channels or edge is not None
            actions = self._actions(selected, now) if selected is not None else ()
            # Portal behaviour: a running programme restarts in the live buffer;
            # a past airing needs Magenta's verified Replay offer.
            start_action = next((name for name in ("start_over", "catchup", "start_from_beginning")
                                 if name in actions), "catchup")
            can_start = start_action in actions
            start_text = text[start_action if can_start and start_action != "start_from_beginning"
                              else "restart" if can_start else self._replay_status(selected, now)]

            def button_width(label):
                # Grouped buttons sized to their text, not quarter-screen slots.
                return max(int(width * 0.09), min(int(width * 0.2), len(label) * 12 + 40))

            watch_width = button_width(text["watch"])
            restart_width = button_width(start_text)
            return_width = button_width(text["return_stream"])
            settings_width = button_width(text["settings"])
            watch = self._button(
                "watch", pad + 12, button_y, watch_width, 40, text["watch"], enabled=bool(channel),
                size="font12")
            start_button = self._button(
                "restart", pad + 24 + watch_width, button_y, restart_width, 40,
                start_text, enabled=can_start, size="font12"
            )
            self.watch_button, self.start_button, self.can_start = watch, start_button, can_start
            return_button = (self._button(
                "return-stream", pad + 36 + watch_width + restart_width, button_y,
                return_width, 40, text["return_stream"], size="font12") if self.can_return else None)
            self.return_button = return_button
            settings_x = pad + 36 + watch_width + restart_width + (return_width + 12 if return_button else 0)
            settings_button = self._button(
                "settings", settings_x,
                button_y, settings_width, 40, text["settings"], size="font12")
            self.settings_button = settings_button
            tv_button = self.tv_button = (self._button(
                "tv-options", settings_x + settings_width + 12, button_y,
                button_width(text["tv_actions"]), 40, text["tv_actions"], size="font12")
                if has_tv_actions else None)
            guide_day = datetime.datetime.fromtimestamp(self.anchor, self.timezone)
            date_text = "{}: {}".format(text["guide_date"], guide_day.strftime("%d.%m."))
            date_x = (settings_x + settings_width + 12
                      + (button_width(text["tv_actions"]) + 12 if has_tv_actions else 0))
            date_button = self.date_button = self._button(
                "guide-date", date_x, button_y, button_width(date_text), 40, date_text,
                enabled=bool(channel), size="font12")
            self._image("accent", 0, 0, width, 2, "0xFF4A9BC5")
            if self.startup is not None:
                self._render_startup()
            self.name_rows = named_rows
            self.logo_warm = warming_rows
            self.logo_warm_due = min((warm[2] for warm in warming_rows.values()), default=None)
            for key in self.slots.keys() - self.used_slots:
                control = self.slots.pop(key)[1]
                if key in revealed_names and not monitor.abortRequested():
                    # The opaque logo is already in place; hiding is immediate, unlike removal.
                    control.setVisible(False)
                self.retired.append(control)
                self.image_colors.pop(key, None)
                self.control_labels.pop(key, None)
                self.button_enabled.pop(key, None)
            branding_changed = self.animated_branding != animated_branding
            if branding_changed and self.animated_branding is not None and not monitor.abortRequested():
                self.animated_branding[1].setAnimations([])
            if self.retired:
                if monitor.abortRequested():
                    return
                self.removeControls(self.retired)
            if self.additions:
                if monitor.abortRequested():
                    return
                self.addControls(self.additions)
            self.video_large.setVisible(self.mini_active and video_size == (312, 176))
            self.video_small.setVisible(self.mini_active and video_size == (216, 121))
            self.setProperty("magentatv_at_t.guide.video", "true" if self.mini_active else "")
            self.setProperty("magentatv_at_t.guide.fullscreen", "true" if self.fullscreen_video else "")
            if monitor.abortRequested():
                return
            if branding_changed:
                self.animated_branding = animated_branding
                if animated_branding is not None:
                    _, logo, name = animated_branding
                    logo.setAnimations(branding_fade(True))
                    name.setAnimations(branding_fade(False))
            self._place_branding_slide(slide_branding)
            self._animate_startup()
            for control, enabled in self.enable_updates:
                control.setEnabled(enabled)
            for control, value in self.text_updates:
                control.setText(value)
            self.event_controls = {
                button.getId(): (key, event) for button, key, event in event_buttons
            }
            self.restart_controls = {
                button.getId(): (key, event) for button, key, event, _ in restart_buttons
            }
            self.action_controls = {
                watch.getId(): "watch_live", start_button.getId(): start_action,
                settings_button.getId(): "settings", date_button.getId(): "guide_date",
            }
            self.action_controls.update((button.getId(), action) for button, _, _, action in restart_buttons)
            if return_button is not None:
                self.action_controls[return_button.getId()] = "return_to_stream"
            if tv_button is not None:
                self.action_controls[tv_button.getId()] = "tv_options"

            effective_focus = self.focus_requested or focused
            if self.footer_mode:
                footer = [button for button in (watch if channel else None,
                                               start_button if can_start else None, return_button,
                                               settings_button, tv_button, date_button if channel else None)
                          if button is not None]
                target = next((button for button in footer if button.getId() == effective_focus),
                              footer[0] if footer else watch)
            else:
                selected_key = programme_key(selected)
                target = next((button for button, key, _, _ in restart_buttons
                               if key == selected_key and
                               (button.getId() == effective_focus or
                                focused_restart is not None and focused_restart[0] == key)), None)
                if target is None:
                    primary = [button for button, key, _ in event_buttons if key == selected_key]
                    empty_target = date_button if window_end <= now else watch
                    target = next((button for button in primary if button.getId() == effective_focus),
                                  primary[0] if primary else empty_target)
            if not channel:
                self.footer_mode = True
                available_footer = {settings_button.getId()}
                if return_button:
                    available_footer.add(return_button.getId())
                if effective_focus not in available_footer:
                    target = return_button or settings_button
            self._focus(target)

        def _select_event(self, event):
            self.restore_key = None
            self.selected_programme = event
            key = programme_key(event) if event else None
            if key is not None:
                if key[0] in self.channels:
                    self.selected_channel = self.channels.index(key[0])
                self.anchor = (max(key[2], self.view_start)
                               + min(key[3], self.view_start + TIMELINE_SECONDS)) / 2
            self._save_selection()
            self._render()

        def _ensure_selected_channel_visible(self):
            self.first_channel = min(
                self.selected_channel // self.visible_count * self.visible_count,
                max(0, len(self.channels) - self.visible_count))

        def _move_channel(self, direction):
            if not self.channels:
                return
            self.footer_mode = False
            target = min(
                max(0, self.selected_channel + direction), len(self.channels) - 1)
            if target != self.selected_channel:
                self.restore_key = None
                self.selected_programme = None
            self.selected_channel = target
            self._ensure_selected_channel_visible()
            self._request_view()
            self._resolve_selection()
            self._save_selection()
            self._render()

        def _move_page(self, direction):
            page = self.first_channel + direction * self.visible_count
            if not 0 <= page < len(self.channels):
                self._move_channel(0)
                return
            offset = self.selected_channel - self.first_channel
            target = min(page + offset, len(self.channels) - 1)
            self._move_channel(target - self.selected_channel)

        def _move_programme(self, direction):
            if not self.channels:
                return
            channel = self.channels[self.selected_channel]
            events = self._visible_events(channel)
            if self.selected_programme is not None:
                event = adjacent_programme(events, channel, self.selected_programme, direction)
            elif direction > 0:
                event = next((e for e in events if programme_key(e)[2] >= self.anchor), None)
            else:
                event = next((e for e in reversed(events) if programme_key(e)[3] <= self.anchor), None)
            if event is not None:
                self._select_event(event)
                return
            # Move by a full viewport at its edge, keeping all request keys aligned.
            target = min(max(self.view_start + direction * TIMELINE_SECONDS,
                             self.first_view), self.last_view)
            if target == self.view_start:
                return
            boundary = self.view_start + (TIMELINE_SECONDS if direction > 0 else -1)
            self.view_start = target
            self.anchor = min(max(boundary, target), target + TIMELINE_SECONDS - 1)
            self.restore_key = None
            self.selected_programme = None
            self._request_view()
            self._save_selection()
            self._render()

        def _choose_date(self):
            current = datetime.datetime.fromtimestamp(self.anchor, self.timezone)
            first = datetime.datetime.fromtimestamp(self.first_view, self.timezone).date()
            end = self.last_view + TIMELINE_SECONDS - 1
            last = datetime.datetime.fromtimestamp(end, self.timezone).date()
            days = [last - datetime.timedelta(days=i) for i in range((last - first).days + 1)]
            choice = xbmcgui.Dialog().select(text["guide_date"], [d.strftime("%d.%m.%Y") for d in days],
                                             preselect=days.index(current.date()))
            if not 0 <= choice < len(days) or monitor.abortRequested():
                return
            day = days[choice]
            at = current.replace(year=day.year, month=day.month, day=day.day).timestamp()
            target = min(max(at, self.first_view), end)
            self.view_start = min(max(self._snap(target - 90 * 60), self.first_view), self.last_view)
            self.anchor = target
            self.restore_key = self.selected_programme = None
            self.footer_mode = False
            self._request_view()
            self._resolve_selection()
            self._save_selection()
            self._render()

        def onFocus(self, control_id):
            if monitor.abortRequested():
                return
            if self.closed or self.handoff is not None or control_id != self._focus_id():
                return
            if self.focus_requested is not None:
                if control_id != self.focus_requested:
                    return
                self.focus_requested = None
            value = self.event_controls.get(control_id) or self.restart_controls.get(control_id)
            if value is not None:
                key, event = value
                if key != programme_key(self.selected_programme):
                    self.footer_mode = False
                    self._select_event(event)

        def onClick(self, control_id):
            if self.closed or self.handoff is not None or monitor.abortRequested():
                return
            if self._apply_number(confirm=True):
                return
            restart = control_id in self.restart_controls
            value = self.restart_controls.get(control_id) if restart else self.event_controls.get(control_id)
            if value is not None:
                requested = self.action_controls.get(control_id)
                self.footer_mode = False
                self._select_event(value[1])
                if self.closed:
                    return
                if restart:
                    self._activate(requested)
                    return
                actions = self._actions(self.selected_programme)
                if actions:
                    self._activate(actions[0])
                else:
                    message = "not_playable"
                    now = time.time()
                    if value[0][3] <= now:
                        message = self._replay_status(value[1], now)
                        if message == "unavailable":
                            message = "past_unavailable"
                    if message == "replay_error" and isinstance(self.replay_error, ProviderError):
                        reason = self.replay_error.localized(localize) if localize else str(self.replay_error)
                        xbmcgui.Dialog().ok("Magenta TV ATᵀ", reason)
                    else:
                        xbmcgui.Dialog().notification("Magenta TV ATᵀ", text[message], time=3000)
                return

            self._activate(self.action_controls.get(control_id))

        def _activate(self, action_name):
            if action_name == "guide_date" and self.channels and not self.closed and self.startup is None:
                self._choose_date()
                return
            if action_name == "settings" and not self.closed and self.startup is None:
                if self.channels:
                    self._save_selection()
                if open_settings is not None and open_settings():
                    self.result = "settings_changed"
                    self.close()
                return
            if action_name == "return_to_stream" and not self.closed and self.startup is None:
                self._return_to_stream()
                return
            if action_name == "tv_options" and not self.closed and self.startup is None:
                last, edge = playback_actions()
                options = []
                if last in self.channels:
                    options.append((text["last_channel"], last))
                if edge is not None:
                    options.append((text["go_live"], None))
                if not options:
                    self._render()
                    return
                choice = xbmcgui.Dialog().contextmenu([label for label, _ in options])
                if not 0 <= choice < len(options) or monitor.abortRequested():
                    return
                channel = options[choice][1]
                fresh_last, fresh_edge = playback_actions()
                if channel is None:
                    if fresh_edge is not None and self._owned_playing():
                        try:
                            owned_playback["player"].seekTime(fresh_edge)
                        except RuntimeError as error:
                            self.log("Go Live seek failed: {}".format(type(error).__name__))
                        else:
                            self._return_to_stream()
                    return
                if channel == fresh_last and channel in self.channels:
                    self.selected_channel = self.channels.index(channel)
                    self._ensure_selected_channel_visible()
                    self._resolve_selection()
                    self._activate("watch_live")
                return
            channel = self.channels[self.selected_channel] if self.channels else ""
            if not channel or self.closed or self.startup is not None:
                return
            if action_name == "watch_live":
                self.result = {"channel": channel}
            elif action_name == "start_over" and self.selected_programme:
                if "start_over" not in self._actions(self.selected_programme):
                    xbmcgui.Dialog().notification(
                        "Magenta TV ATᵀ", self._availability(self.selected_programme, time.time()),
                        time=3000)
                    return
                self.result = {"channel": channel,
                               "start_over": int(programme_key(self.selected_programme)[2])}
            elif action_name == "catchup" and self.selected_programme:
                if "catchup" not in self._actions(self.selected_programme):
                    status = self._replay_status(self.selected_programme, time.time())
                    if status == "checking_replay":
                        # A Replay mark is only the guide flag; start once the offer is verified.
                        self.catchup_requested = programme_key(self.selected_programme)
                    xbmcgui.Dialog().notification(
                        "Magenta TV ATᵀ", text["unavailable" if status == "unavailable" else status],
                        time=3000)
                    return
                self.result = {"channel": channel, "catchup": self.replay_offer.airing}
            elif action_name == "start_from_beginning" and self.selected_programme:
                replay = self._replay(self.selected_programme, time.time())
                if replay is None:
                    return
                if (confirm_restart is not None
                        and not confirm_restart(self.request[0], self.selected_programme)):
                    if not self.loading:
                        self._refresh_view()
                    xbmcgui.Dialog().notification("Magenta TV ATᵀ", text["refresh_rights"], time=3000)
                    return
                self.result = {
                    "channel": channel,
                    "start": programme_key(self.selected_programme)[2],
                    "stop": programme_key(self.selected_programme)[3]
                }
            else:
                return
            self._save_selection()
            if start_playback is None:
                self.close()
            else:
                selection = self.result
                self.result = None
                now = time.time()
                title, logo = self._channel_presentation(channel, self._visible_events(channel), now)
                event = self.selected_programme
                if action_name == "watch_live":
                    event = next((candidate for candidate in self.events_by_channel.get(channel, ())
                                  if programme_key(candidate)[2] <= now < programme_key(candidate)[3]), None)
                selection["metadata"] = playback_metadata(title, logo, event)
                self.startup = (numbered(numbers.get(channel), title), logo, None)
                self.startup_textures = peek_crt() if peek_crt is not None else None
                self.startup_clock = time.monotonic()
                self._render()
                if not self.closed:
                    self.handoff = start_playback(selection)

        def _advance_handoff(self):
            try:
                next(self.handoff)
                title, logo, art = self.startup
                if logo:
                    try:
                        art = local_startup_logo(logo)
                    except (ImportError, OSError, RuntimeError, TypeError, ValueError, AttributeError) as error:
                        self.log("Startup logo cache unavailable: {}".format(type(error).__name__))
                    self.startup = (title, None, art)
                    if art:
                        self._render()
            except StopIteration as finished:
                self.result = finished.value
                self.close()
            except Exception as error:
                # Playback exceptions can contain signed media URLs.
                self.log("Guide playback failed: {}".format(type(error).__name__))
                self.handoff = None
                self.startup = None
                self.startup_textures = None
                self._render()
                handled = playback_error(error) if playback_error is not None else None
                if handled == "settings_changed":
                    self.result = handled
                    self.close()
                    return
                if handled:
                    return
                message = "restart_bounds" if isinstance(error, OutsideTimeline) else "playback_error"
                xbmcgui.Dialog().notification("Magenta TV ATᵀ", text[message], time=5000)

        def onAction(self, action):
            if self.closed or monitor.abortRequested():
                return
            try:
                self._handle_action(action.getId())
            except Exception as error:
                self._fail_ui("action", error)

        def _handle_action(self, action_id):
            channel_direction = channel_direction_for_action(
                action_id,
                getattr(xbmcgui, "ACTION_MOVE_UP", 3),
                getattr(xbmcgui, "ACTION_MOVE_DOWN", 4),
                getattr(xbmcgui, "ACTION_CHANNEL_UP", ACTION_CHANNEL_UP),
                getattr(xbmcgui, "ACTION_CHANNEL_DOWN", ACTION_CHANNEL_DOWN)
            )
            if action_id == getattr(xbmcgui, "ACTION_STOP", 13):
                if self._owned_playing():
                    owned_playback["player"].stop()
                    self._render()
            elif action_id in (
                    getattr(xbmcgui, "ACTION_PREVIOUS_MENU", 10),
                    getattr(xbmcgui, "ACTION_NAV_BACK", 92)):
                self.close()
            elif self.handoff is not None:
                return
            elif action_id == getattr(xbmcgui, "ACTION_SHOW_GUI", 18):
                self._activate("return_to_stream")
            elif self.channel_number.press(action_id, time.monotonic()) is not None:
                # Like PVR: show the digits, tune on OK or after ChannelNumber.TIMEOUT.
                self._render()
            elif action_id == getattr(xbmcgui, "ACTION_SHOW_INFO", 11):
                selected = self.selected_programme
                if selected is not None:
                    key = programme_key(selected)
                    heading = "{}–{}  {}".format(_format_time(key[2], self.timezone),
                                                  _format_time(key[3], self.timezone),
                                                  self._event_title(selected))
                    description = selected.get("description")
                    xbmcgui.Dialog().textviewer(
                        heading, description_text(description) if isinstance(description, str)
                        else "")
            elif action_id == getattr(xbmcgui, "ACTION_MOUSE_RIGHT_CLICK", 101):
                value = (self.event_controls.get(self._focus_id())
                         or self.restart_controls.get(self._focus_id()))
                if value is not None:
                    self._select_event(value[1])
                    actions = self._actions(value[1])
                    labels = {"watch_live": text["watch"], "start_over": text["start_over"],
                              "catchup": text["catchup"], "start_from_beginning": text["restart"]}
                    if len(actions) >= 2:
                        choice = xbmcgui.Dialog().contextmenu([labels[name] for name in actions])
                        if 0 <= choice < len(actions):
                            self._activate(actions[choice])
            elif action_id == getattr(xbmcgui, "ACTION_CONTEXT_MENU", 117):
                self.footer_mode = True
                actions = self._actions(self.selected_programme)
                self._focus(self.return_button if self.can_return else
                            self.start_button if actions and "watch_live" not in actions else
                            self.watch_button if self.channels else self.settings_button)
            elif action_id in (ACTION_PAGE_UP, ACTION_PAGE_DOWN):
                if self.channels:
                    self._move_page(-1 if action_id == ACTION_PAGE_UP else 1)
            elif channel_direction is not None:
                if self.channels:
                    if (self.footer_mode and action_id in (
                            getattr(xbmcgui, "ACTION_MOVE_UP", 3),
                            getattr(xbmcgui, "ACTION_MOVE_DOWN", 4))):
                        self.footer_mode = False
                        self._render()
                    elif (action_id == getattr(xbmcgui, "ACTION_MOVE_DOWN", 4)
                            and not self.footer_mode
                            and self.selected_channel == len(self.channels) - 1):
                        self.footer_mode = True
                        self._focus(self.settings_button)
                    else:
                        self._move_channel(channel_direction)
            elif action_id in (1, 2):
                if self.footer_mode:
                    footer = [button for button in (
                        self.watch_button if self.channels else None,
                        self.start_button if self.can_start else None, self.return_button,
                        self.settings_button, self.tv_button, self.date_button if self.channels else None)
                              if button is not None]
                    ids = [button.getId() for button in footer]
                    focus = self.focus_requested or self._focus_id()
                    index = ids.index(focus) if focus in ids else 0
                    if footer:
                        self._focus(footer[max(0, min(len(footer) - 1, index + (-1 if action_id == 1 else 1)))])
                else:
                    self._move_programme(-1 if action_id == 1 else 1)

        def close(self):
            if self.handoff is not None:
                self.handoff.close()
                self.handoff = None
            self.startup = None
            if self.closed:
                return
            self.closed = True
            self.cancel.set()
            with self.pending_lock:
                self.pending = None
            # Kodi owns window teardown on application shutdown.
            from playback_guard import application_aborted
            if not application_aborted(monitor):
                super().close()

        def onDeinit(self):
            self.closed = True
            self.cancel.set()

    if monitor.abortRequested():
        return None
    dialog = GuideDialog("guide.xml", addon_path, "Default", "1080i")
    token = os.urandom(8).hex()
    window.setProperty(GUIDE_INSTANCE_PROPERTY, token)
    exit_monitor = guide_exit_monitor(xbmc, token)
    addon_check_at = time.monotonic() + ADDON_CHECK_SECONDS
    try:
        if monitor.abortRequested():
            return None
        dialog.show()
        if monitor.abortRequested():
            return None
        init_deadline = time.monotonic() + 5
        # Monitor waits dispatch onInit/onDeinit. Polling Window.IsVisible can
        # block on Kodi's GUI during a Stop-to-guide return followed by Quit.
        while not dialog.closed and not monitor.abortRequested():
            if should_close is not None and should_close():
                dialog.close()
                break
            # Kodi handles Tab/Fullscreen before dispatching actions to Python dialogs.
            if (dialog.handoff is None and dialog._owned_playing()
                    and xbmcgui.getCurrentWindowId() == 12005):
                dialog._return_to_stream(activate=False)
                break
            # A playback handoff may legitimately take the guide down for fullscreen video.
            if dialog.handoff is None and exit_monitor.unloaded:
                log("Kodi closed the guide window; ending the guide.")
                dialog.close()
                break
            if addon_enabled is not None and time.monotonic() >= addon_check_at:
                addon_check_at = time.monotonic() + ADDON_CHECK_SECONDS
                if not addon_enabled():
                    log("The add-on was disabled or removed; ending the guide.")
                    dialog.close()
                    break
            if dialog.initialized:
                if dialog.handoff is not None:
                    dialog._animate_startup()
                    dialog._advance_handoff()
                elif not dialog.closed:
                    dialog._apply_pending()
            elif time.monotonic() >= init_deadline:
                raise RuntimeError("Guide initialization callback did not run")
            delay = 0.02 if dialog.startup_frame is not None else (0.04 if dialog.handoff is not None else 0.1)
            if not dialog.closed and monitor.waitForAbort(delay):
                break
    except Exception as error:
        if monitor.abortRequested():
            return None
        dialog._fail_ui("modal", error)
        raise RuntimeError("Guide dialog could not be opened") from error
    finally:
        dialog.close()
        if dialog.worker_thread is not None:
            dialog.worker_thread.join(timeout=25)
            if dialog.worker_thread.is_alive():
                raise RuntimeError("Programme guide worker did not stop.")
        if dialog.details_worker is not None:
            dialog.details_worker.join(timeout=25)
            if dialog.details_worker.is_alive():
                raise RuntimeError("Programme details worker did not stop.")
    if monitor.abortRequested():
        return None
    if dialog.ui_error is not None:
        raise RuntimeError("Guide rendering failed") from dialog.ui_error
    return dialog.result
