"""Magenta TV AT guide logo bounds, measured from its own clients."""


LOGO_CELL = (100, 45)


def logo_box(width, height):
    """Keep the official-client box centred while shrinking for narrow layouts."""
    box_width, box_height = LOGO_CELL
    scale = min(1.0, max(1, width) / box_width, max(1, height) / box_height)
    return max(1, round(box_width * scale)), max(1, round(box_height * scale))
