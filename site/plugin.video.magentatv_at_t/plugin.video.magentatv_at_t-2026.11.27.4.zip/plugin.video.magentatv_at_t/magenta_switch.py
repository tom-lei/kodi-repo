"""Private, in-invocation switch inputs and credential-free timings."""

from concurrent.futures import ThreadPoolExecutor
from time import monotonic


class TuneTiming:
    def __init__(self, log=None, start=None):
        self.log = log
        self.start = monotonic() if start is None else start
        self.selected = None

    def mark(self, label):
        stamp = monotonic()
        if label == "switch selected":
            self.selected = stamp
        if self.log:
            self.log("{} at {} ms".format(label, round((stamp - self.start) * 1000)))

    def measure(self, label, call, *args):
        start = monotonic()
        try:
            return call(*args)
        finally:
            if self.log:
                self.log("{} {} ms".format(label, round((monotonic() - start) * 1000)))


class LiveInputs:
    """Owned by exactly one signed-in invocation; nothing here is serialized."""
    def __init__(self, clock=monotonic):
        self.clock = clock
        self.entries = {}

    def clear(self):
        self.entries.clear()

    def get(self, key):
        entry = self.entries.get(key)
        if entry is not None and self.clock() < entry[0]:
            return entry[1]
        self.entries.pop(key, None)
        return None

    def put(self, key, value, seconds=600):
        self.entries[key] = (self.clock() + seconds, value)


def read_inputs(calls, timing):
    if len(calls) < 2:
        return {name: timing.measure(name, read) for name, read in calls}
    # Join every worker (also on error) before the owner can close/replace its session.
    with ThreadPoolExecutor(max_workers=len(calls), thread_name_prefix="magenta-read") as pool:
        pending = [(name, pool.submit(timing.measure, name, read)) for name, read in calls]
        return {name: future.result() for name, future in pending}
