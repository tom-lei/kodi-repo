"""Website-derived API helpers for an isolated, manually run Kodi experiment."""

import base64
import json
import re
from urllib.parse import quote, urlencode, urlsplit
from urllib.request import Request

from magenta_auth import AuthError, _headers, _read
from magenta_playback import PlaybackError
from provider_error import ProviderError


_BROWSER_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)


class Bff:
    def __init__(self, session):
        self.session = session
        self.account = None
        try:
            base = session.constants["BFF_BASE_URL"]
            parts = urlsplit(base)
            if (parts.scheme != "https" or parts.hostname != "tv-at-prod.yo-digital.com"
                    or parts.port not in (None, 443) or parts.username is not None
                    or parts.password is not None or parts.path.rstrip("/") != "/at-bifrost"
                    or parts.query or parts.fragment):
                raise ValueError
            self.base = base.rstrip("/")
        except (KeyError, TypeError, ValueError):
            raise PlaybackError("The website returned an unexpected API endpoint.") from None

    def get(self, route, params, step, density="xhdpi", flow="PLAYER"):
        constants = self.session.constants
        params = dict(params, app_language=constants["LANGUAGE_CODE"],
                      natco_code=constants["COUNTRY_CODE"])
        headers = _headers(constants, self.session.device_id, self.session.session_id,
                           self.session.user_agent, True, flow, step,
                           device_name=self.session.device_name)
        if step is None:
            del headers["x-tv-step"]
        headers["bff_token"] = self.session.access_token
        headers["Device-Density"] = density
        if self.account is not None:
            account = self.account
            if account.get("channelMap_id"):
                headers["X-Channel-Map-Id"] = account["channelMap_id"]
            if account.get("user_id"):
                headers["x-user-id"] = account["user_id"]
            names = {
                "account_type": "accountType", "user_id": "userId",
                "is_recording_enabled": "recordingEnabledDVR",
                "channelMap_id": "channelMapId", "rightsGroup_ids": "rightsGroupIds",
                "release_slot": "releaseSlot", "account_id": "accountId",
            }
            details = {target: account[source] for source, target in names.items()
                       if source in account}
            settings = account.get("managed_settings")
            vod = settings.get("TVSOA-setting-VodEnabled") if isinstance(settings, dict) else None
            if vod:
                details["vodEnabled"] = vod
            headers["x-account-details"] = json.dumps(details, separators=(",", ":"))
        request = Request(self.base + route + "?" + urlencode(params), headers=headers)
        try:
            result = json.loads(_read(request).decode("utf-8"))
        except AuthError as error:
            raise PlaybackError(ProviderError.from_exception(error)
                                or "The provider API request failed: " + str(error)) from None
        except (UnicodeError, ValueError):
            raise PlaybackError("The provider API request failed or returned invalid data.") from None
        if not isinstance(result, dict):
            raise PlaybackError("The provider API returned an invalid response.")
        return result

    def user_account(self):
        self.account = self.get("/user/account", {"fresh_login": "true"}, "GET_USER_ACCOUNT")
        return self.account

    def subscriptions(self):
        return self.get("/epg/channel/subscriptions", {}, "EPG_SUBSCRIPTIONS")

    def playinfo(self, channel_number):
        c = self.session.constants
        return self.get("/player/playinfo/channel", {
            "natco_key": c["NATCO_KEY"], "device_type": c["DEVICE_TYPE"],
            "channel_number": channel_number,
        }, "LIVE_PLAYBACK")

    def channel_feed(self):
        """Fetch the public channel list as Ultimate Backend's magentaeu provider does.

        Ultimate uses guest headers; this harness has no guest start-up flow, so it
        reuses the signed-in session's headers instead of adding another session.
        """
        return self.get("/epg/channel", {
            "channelMap_id": "", "includeVirtualChannels": "false",
            "includeSyntheticChannels": "false",
            "natco_key": self.session.constants["NATCO_KEY"],
        }, None, flow="START_UP")

    def schedules(self, date, hour_offset):
        return self.get("/epg/channel/schedules", {
            "natco_key": self.session.constants["NATCO_KEY"], "date": date,
            "hour_offset": hour_offset, "hour_range": 3, "channelMap_id": "",
            "filler": "true", "includeSyntheticChannels": "false",
        }, "EPG_SCHEDULES", flow="EPG")

    def _program_path(self, program_id):
        if (not isinstance(program_id, str) or program_id in (".", "..")
                or not re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", program_id)):
            raise PlaybackError("The programme identifier is invalid.")
        return "/details/program/" + quote(program_id, safe="")

    def program_details(self, program_id):
        return self.get(self._program_path(program_id), {
            "natco_key": self.session.constants["NATCO_KEY"],
            "interacted_with_nPVR": "false",
        }, "PROGRAM_METADATA", density="xxxhdpi", flow="SINGLE_PROGRAM_DETAIL")

    def program_actions(self, program_id):
        return self.get(self._program_path(program_id) + "/actions/v2", {
            "natco_key": self.session.constants["NATCO_KEY"],
            "interacted_with_nPVR": "false",
        }, "PROGRAM_WATCH_ACTION", flow="SINGLE_PROGRAM_DETAIL")

    def replay_consents(self):
        return self.get("/consents", {
            "natco_key": self.session.constants["NATCO_KEY"],
            "device_type": self.session.constants["DEVICE_TYPE"],
        }, "GET_CATCHUP_CONSENTS", flow="SINGLE_PROGRAM_DETAIL")

    def catchup_playinfo(self, program_id, station_id, start_time, end_time):
        return self.get("/player/playinfo/catchup", {
            "natco_key": self.session.constants["NATCO_KEY"],
            "device_type": self.session.constants["DEVICE_TYPE"], "program_id": program_id,
            "station_id": station_id, "start_time": start_time, "end_time": end_time,
        }, "CATCHUP_PLAYBACK")

    def media(self, media_id, content_type):
        c = self.session.constants
        return self.get("/media", {
            "client_id": self.session.device_id, "media_id": media_id,
            "natco_key": c["NATCO_KEY"], "src_format": "MPEG-DASH",
            "content_type": content_type,
        }, "MEDIA_CALL")


def _first(entry, *names):
    for name in names:
        value = entry.get(name)
        if value not in (None, ""):
            return value
    return None


def _channel_number(value):
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.isdigit() and value.isascii():
        return int(value)
    return None


def valid_manifest_url(url):
    try:
        parts = urlsplit(url)
        return (isinstance(url, str) and parts.scheme == "https" and bool(parts.hostname)
                and parts.port in (None, 443) and parts.username is None
                and parts.password is None and not parts.fragment
                and parts.path.lower().endswith(".mpd"))
    except (AttributeError, TypeError, ValueError):
        return False


def select_feed_channel(feed, channel_number):
    """Return (manifest URL, release PID) for exactly one feed channel, else fail closed."""
    wanted = _channel_number(channel_number)
    channels = feed.get("channels") if isinstance(feed, dict) else None
    if wanted is None or not isinstance(channels, list):
        raise PlaybackError("The channel list was invalid.")
    matches = [entry for entry in channels if isinstance(entry, dict) and _channel_number(
        _first(entry, "channel_number", "channelNumber")) == wanted]
    if len(matches) != 1:
        raise PlaybackError("The channel list did not contain exactly one requested channel.")
    manifest = _first(matches[0], "video_src_dash", "videoDashUrl")
    release_pid = _first(matches[0], "pid_dash", "pidDash")
    if not valid_manifest_url(manifest):
        raise PlaybackError("The channel list did not contain a usable DASH manifest.")
    if not isinstance(release_pid, str) or not release_pid.strip() or release_pid != release_pid.strip():
        raise PlaybackError("The channel list did not contain a usable release ID.")
    return manifest, release_pid


def compare_live_inputs(feed_manifest, feed_pid, media_video):
    """Compare feed and /media inputs, returning booleans only (None if unavailable)."""
    if not isinstance(media_video, dict):
        return None, None, None
    media_pid = media_video.get("pid")
    media_url = media_video.get("video_src")
    pid_match = feed_pid == media_pid if isinstance(media_pid, str) and media_pid else None
    try:
        if not isinstance(media_url, str):
            raise ValueError
        feed_parts, media_parts = urlsplit(feed_manifest), urlsplit(media_url)
        if media_parts.scheme != "https":
            raise ValueError
        host_match = feed_parts.hostname == media_parts.hostname
        path_match = feed_parts.path == media_parts.path
    except (AttributeError, TypeError, ValueError):
        host_match = path_match = None
    return pid_match, host_match, path_match


def _widevine_claims(access_token, release_pid):
    try:
        payload = access_token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        claims = json.loads(base64.urlsafe_b64decode(payload).decode("utf-8"))
        persona = claims["dc_cts_personaToken"]
        account = claims["dc_cts_accountId"]
        if not all(isinstance(item, str) and item for item in (persona, account, release_pid)):
            raise ValueError
    except (AttributeError, IndexError, KeyError, TypeError, UnicodeError, ValueError):
        raise PlaybackError("The sign-in session lacks the website's Widevine authorization.") from None
    return persona, account


def widevine_config(access_token, release_pid):
    """Build the public web player's Widevine configuration without exposing it."""
    persona, account = _widevine_claims(access_token, release_pid)
    basic = base64.b64encode(
        ("http://access.auth.theplatform.com/data/Account/" + account + ":" + persona)
        .encode("utf-8")
    ).decode("ascii")
    url = ("https://widevine.entitlement.theplatform.eu/wv/web/ModularDrm/"
           "getRawWidevineLicense?" + urlencode({
               "schema": "1.0", "form": "json", "releasePid": release_pid,
           }))
    headers = urlencode({"Authorization": "Basic " + basic, "Content-Type": "application/json"})
    return "com.widevine.alpha|" + url + "|" + headers


def widevine_query_config(access_token, release_pid):
    """Build the alternative request for the isolated loopback diagnostic."""
    persona, account = _widevine_claims(access_token, release_pid)
    url = ("https://widevine.entitlement.theplatform.eu/wv/web/ModularDrm/"
           "getRawWidevineLicense?" + urlencode({
               "schema": "1.0", "releasePid": release_pid,
               "token": persona,
               "account": "http://access.auth.theplatform.com/data/Account/" + account,
           }, quote_via=quote))
    headers = urlencode({
        "User-Agent": _BROWSER_USER_AGENT,
        "Content-Type": "application/octet-stream",
        "Origin": "https://tv.magenta.at",
        "Referer": "https://tv.magenta.at/",
    })
    return "com.widevine.alpha|" + url + "|" + headers
