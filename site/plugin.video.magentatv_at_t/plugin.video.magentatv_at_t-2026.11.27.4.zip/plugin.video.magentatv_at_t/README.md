# Magenta TV ATᵀ

An independent, unofficial Kodi add-on for Magenta TV Austria. It uses its own
settings and profile; it does not modify simpliTVᵀ or its data.

Versions follow simpliTVᵀ's date convention: `YYYY.MM.DD` (zero-padded,
without `.0`) for the first version that day, then `.1`, `.2`, and so on for
further Magenta versions that day. Magenta's daily counter is independent of
simpliTV's. See [changelog.txt](changelog.txt) for changes, including historical
version `0.1.0`.

The add-on entry point contains an **experimental** live channel directory and
playback path for Kodi on Windows and Linux, including LibreELEC on a Raspberry
Pi (see [Platforms](#platforms-and-device-identity)). In an isolated Kodi 21.3
test on Windows, the add-on played
ORF 1 with picture and sound confirmed. A subsequent isolated guide-first test
confirmed channel selection, lease renewal/release, sign-out and natural Kodi
exit with code 0 after relay shutdown hardening. A guide-only follow-up exposed
and fixed timestamp parsing on Kodi's Python runtime; visible programme titles
and start/end times are now verified, with no active video during inspection.
An isolated controls test verified video/audio streams, an advancing player
clock, backward seeking, channel switching with sequential leases, and returning
to the populated guide. The CRT transition and basic seek strip were also
visually inspected in synthetic, no-video Kodi fixtures; no protected-video
screenshots were taken. Programme-aligned seeking and the live seek strip have
since been connected for live playback; their timeline source and verification
limits are described below.

Shutdown remains an experimental limitation: two earlier controls runs stalled
on Quit after lease release and sign-out, requiring termination of the disposable
Kodi process. After improving owned-window lifetime handling, a full controls run
and three immediate-Quit variants exited naturally with code 0. The earlier
intermittent stall's cause is not established; these successes do not prove it
cannot recur.

## Live playback

The add-on needs InputStream Adaptive, InputStream Helper and Kodi's
`script.module.pycryptodome`, `script.module.urllib3` and `script.module.pysocks`
dependencies. Sign-in password encryption uses PyCryptodome; no external
OpenSSL executable or PATH changes are needed. Kodi 21 Omega bundles
`script.module.pycryptodome` as a system add-on; it is not downloaded from
the Kodi add-on mirror.
It reads Magenta's website configuration and uses the
user's Magenta account to request the subscribed channel list. For playback,
it checks channel rights, uses the DASH manifest and release ID from the
channel feed, requests the normal `/media` concurrency lease, renews it during
playback and releases it on stop. A local licence relay keeps the
credential-bearing licence URL out of Kodi; successful licence bytes are
forwarded unchanged. When Kodi's HTTP proxy is enabled, sign-in, guide and
playback API calls, lease updates, sign-out and upstream licence requests use
that proxy, including its credentials if set. Operating-system bypass lists
do not override it. HTTPS and SOCKS proxies are also supported; HTTPS proxies
and destinations must present trusted certificates with matching hostnames.
Python's platform trust may differ from Kodi's certificate bundle. Proxy errors
do not fall back to a direct connection. With Kodi's proxy off, the existing OS
proxy behaviour for API calls and direct upstream licence requests is unchanged.
Channel logos use the same
proxy-aware transport as sign-in. Programme posters, DASH and media segments use
Kodi's own network stack. Kodi 21.3 on Windows also exports its
HTTP proxy to libcurl. While the relay is running, the add-on exempts only
`127.0.0.1` from that process-level proxy so the player sends its challenge
to the local listener, not the proxy. The relay restores the previous exclusion
on shutdown unless another component changed it; no Kodi or system settings
are saved. The relay's request to the provider still uses Kodi's proxy.
For diagnosis, the relay writes only licence metadata to
Kodi's log at info level, prefixed `[Magenta TV AT] licence`: the licence type,
policy durations and flags, and for each key its key ID, key type, security
level, required and requested output protection and video
resolution constraints. Key bytes, IVs, key control blocks, signatures, session
keys, licence identifiers, tokens and the raw licence are never decoded or
logged.

### Platforms and device identity

The add-on no longer refuses to run outside Windows. Windows was verified as
described above. On a Raspberry Pi 3B+ (LibreELEC 12.2.1, Kodi 21.3,
InputStream Adaptive 21.5.25.1, Widevine 4.10.2662.3), the previous version
with its Windows check bypassed signed in and showed the guide, and live
playback, channel switching, Replay and returning to the guide worked when
protected video was limited to 720p or 480p. With the Linux identity and no
cap, the licence for Magenta HD on this Pi still omitted its 1080p key; Kodi
selected 1080p and showed no picture. With version `2026.11.26.1` and the
default chooser, the same channel played at 1280×720/50 for 45 seconds using
the Pi's hardware decoder, with no missing-key errors. ORF 1 HD offered
720p50 and played; its manifest had no 1080p stream. The Windows comparison
on Magenta HD stopped with provider error 2838 (HTTP 403) before a licence
was returned, so its 1080p key availability was not verified.

The add-on compares the video key IDs and sizes advertised in the DASH manifest
with the content key IDs in the licence. If only higher resolutions lack keys,
the relay sends `X-Limit-Video` with the pixel count of the largest licensed
video size. For example, a licensed 1280×720 stream and an unlicensed
1920×1080 stream give `max=921600`. Only the licensed streams need known
dimensions: the ceiling is still 921600 if the unlicensed stream omits its
size. There is no platform or model check. The relay adds no limit when all
video keys are present or the mapping is unclear;
an existing provider limit is never raised. InputStream Adaptive 21.5.25
applies this header before choosing a stream, unless **Ignore HDCP status**
is enabled. Key presence does not guarantee that a decoder or display supports
that size. A manually selected limit for protected video remains available.

Other Raspberry Pi systems may not use the same Widevine CDM. InputStream
Helper installs Google's Linux arm64 CDM, the same version line as Windows, on
64-bit (`aarch64`) images such as those for a Pi 4 or 5. Only 32-bit (`armv7`)
images, as on this Pi 3B+, receive the frozen ChromeOS CDM 4.10.2662.3. Only the
32-bit Pi 3B+ was tested.

The add-on names the operating system from Kodi's own platform conditions
(Windows, Android, webOS, Linux, tvOS, iOS or macOS, otherwise `Unknown`; LibreELEC
reports Linux). On Windows, the sign-in values are unchanged. Elsewhere,
`<OS>` replaces `Windows` in the same fields: the `X-User-Agent` header and
device model `web|web|<OS>-Kodi|<app version>|1`, the `Device-Name` header
`<OS> - Kodi`, device `os` and `deviceOS` `<OS>`, and device manufacturer
`<OS> Kodi`. The device model name and type remain `WEB`, and
`manageDevice` remains false. The licence request keeps its fixed browser user
agent. Magenta may list a non-Windows Kodi as a new device in the account's
device list; how Magenta uses these values otherwise is not known.

When a provider request fails, Kodi shows the HTTP status and, if supplied,
the numeric Magenta error code. **2838** means Magenta does not permit the
current IP address. Turn off any VPN or proxy, or retry on your permitted
Magenta connection in Austria. A 403 without that code does not identify
the cause. For known codes, Kodi explains the reason in English or German
(for example, **2810** means all simultaneous streams are in use; **2839**
means Replay requires a package upgrade). Unknown codes show the code and
HTTP status only. The add-on never displays the provider's raw error text.

The add-on opens the guide over a menu with guide and Settings entries. The
guide caches subscribed channels and schedule data in its own profile for
reuse, refreshing them in the background. **Guide date** (remote: **Menu**
then move right to **Guide date**) jumps directly to a day in the past week.
Only the visible four-hour page is loaded. A past listing is not a playback
offer; selecting it does not tune the live channel or seek. **Watch live**
remains a separate channel action. When playback started from the guide stops
or ends, the guide reopens on the channel you watched. Replay and live-buffer
restart return to the played airing; Watch live returns to the current listing.
Back closes the guide. Playback opened directly does not reopen it. A guide
that reopened after playback also ends when Kodi dismisses it, when Kodi shuts
down, or when the add-on is disabled or uninstalled. On LibreELEC with Kodi
21.3, `Dialog.Close(all,true)` dismissed the guide and its threads ended.
`ActivateWindow(Home)` alone left the guide visible and responsive; Back
then closed it. A stream still starting from the guide completes its handoff first.

### Channel numbers and the Settings shortcut

The guide and player show Magenta's own channel numbers from the subscribed
lineup, with gaps where the account has no channel; they are not renumbered by
list position. Type a number with the remote's digit keys: the pending digits
and their target appear as a hint (for example `12_  →  12 ORF III`), and the
channel switches on **OK** or after 1.5 seconds. An unassigned number shows
`3_  →  3 not assigned` and does nothing else; a channel that is not visible is
marked as hidden and is not tuned.

Typing exactly `000` shows `000_  →  Settings` and opens the add-on settings
on **OK** or after the timeout; `0` and `00` do not. If Magenta assigns a real
channel 0, that channel wins and the shortcut is unavailable. The guide's
Settings button and the add-on menu still open Settings. After Settings the
channel list is refreshed and the current channel stays selected by its
provider number, not its position; a playing stream keeps running. If that
channel is no longer in the list, a notification names it. A changed account
takes effect from the next channel start, not on the stream already playing.

**Remember last channel** (General settings, on by default) preselects the
last watched channel per account on the next guide start. Turning it off
deletes the stored channel.

### Programme Replay and live rewind

Magenta [advertises seven-day Replay on TV S, M and L](https://www.magenta.at/tv/tv).
It is not seven days of live rewind or a guarantee for every airing. On
25 November 2026 the signed-in [Austrian portal](https://tv.magenta.at/)
offered W24 HD's *ÖsterreichBlick - Die Woche* (10:00–10:30 CET) and opened
`/player/catchup` for that airing. Its first `/at-bifrost/media` request returned
HTTP 403, provider error **2838** (IP address not permitted); no media started.
A later normal retry returned HTTP 200, with advancing video time and decoded
frames in the browser. This verifies Replay for that airing in the portal.
A fresh signed-in selection confirmed `/details/program/{id}/actions/v2`,
`/player/playinfo/catchup`, and `/media` with `content_type=catchup`, all
HTTP 200. `/player/playinfo/program` is VOD. Neither a guide flag nor a
catch-up ID proves entitlement.
The supplied Android package (2.1.063.05) contains a catch-up activation
layout; that resource is not evidence of an account's consent or rights.

The Replay path checks the signed-in account's existing consent and matches
one unrestricted `catchup_schedules` row by programme, station, channel and
both broadcast times, inside that row's availability window. It rechecks
at playback, not just when drawing the guide. It does not activate Replay,
buy access or substitute a live stream or seek if any step fails.

In the guide, select the past airing and wait for **Checking Replay…** to
finish. Press **OK** on an offered past airing, or choose **Restart with
Replay** in the footer. For a current airing, **OK** still means **Watch
live**; the separate restart action appears only with a verified offer. A
failed availability check or a missing offer leaves restart disabled. The
existing live-buffer controls are not used to choose a programme start.

On the W24 sample the portal requested the exact HTTPS DASH URL returned by
`/media.video.video_src`. The add-on passes the supplied manifest unchanged
and the accompanying `video.pid` to its existing Widevine/lease flow.
It rejects ambiguous media IDs, unknown platform or trickplay restrictions
and unusable manifests. It does not construct Replay URLs from the live feed.
A disposable Kodi run played that W24 airing natively, including pause, seek
and lease release. Kodi's provider-error paths have **synthetic coverage only**.

The signed-in portal reported `padding_start="30"` and `padding_end="420"`
for that W24 airing. Its video lasted 2252.16 seconds, 2.16 seconds longer
than the padded 30-minute slot. The portal started at the 30-second mark;
the original Kodi run started at zero and showed a total of 37:32.

The add-on reads both paddings from the selected airing's Replay playinfo
(`catalogInfoResponse.entitlements`). A missing or null value
means unknown, not zero: Kodi skips the automatic seek and logs
`start offset not applied: provider padding unavailable`. With explicit padding,
it seeks once to `padding_start` after A/V starts and before opening the controls, provided that:
- Kodi's duration matches the scheduled length plus both paddings, within
  12 seconds.
- Playback is still within 12 seconds of the beginning.

Otherwise it stays where Kodi started. It never estimates the offset from the
guide, and padding remains reachable by manual seeking. The scheduled start
can differ from the broadcaster's actual start. The positioning has offline
coverage only.

To check it natively, select W24 HD, **Guide date → 25.11.2026**, then the
10:00–10:30 airing while its offer is valid. On success there is no Replay
confirmation dialog. Normal add-on log messages use the prefix
`[Magenta TV AT] Replay: ` with `airing offer confirmed`, `catchup playinfo
accepted`, `lease acquired`, `Replay handed to Kodi`, `Replay AV started`,
then `start offset applied: N s` (N is `padding_start`) and, after Stop,
`lease released`; `lease renewed` is expected only if due. The positioning step
may instead log `start offset not applied:` with one of these reasons:
- `provider padding unavailable`
- `manifest duration … s does not match provider padding (expected … s)`
- `start outside manifest`
- `player did not start at the beginning`
- `player duration unavailable` (no Kodi timeline within 10 seconds)
- `seek failed`

In those cases playback continues from Kodi's position. The handoff message
is not proof of playback. If Magenta withdraws the offer before acquisition,
the dialog reads `Magenta did not offer Replay for this airing.` Provider HTTP
errors stop startup rather than opening Watch live.
Do not share full Kodi logs or stream URLs.

**Live rewind is separate.** ORF 1, ORF 2 Wien HD and W24 HD each advertised
`PT2H` in a sampled live manifest. The guide exposed capability flags, not
a numeric live-buffer duration for every station. The three-hour UTC blocks
used to fetch schedules are not rewind windows. Neither two nor three hours
is assumed for an unplayed channel.

**Guide marks.** Magenta's schedule feed (`/epg/channel/schedules`) carries
`is_catchup_enabled` and `entitlements.hasStartOver` for each programme of each
station. In a signed-in sample of 320 stations, 135 had the flag on every
programme, 170 on none, and 15 excluded individual films, series or sports.
The add-on keys these flags by station, because programme IDs repeat across
simulcast stations with different flags. Like the portal's *Replay verfügbar*
mark, a started programme whose flag is true shows a Replay badge at its start,
whether or not it is selected; a false flag or a future programme never shows
one. The flag is display information only: **Restart with Replay** is still
enabled only after the selected airing's `actions/v2` offer and catch-up
playinfo are confirmed, and fails closed otherwise. A single status line for
the selected programme states the result, for example `Replay: not offered by
Magenta for this airing` or `Replay: marked available, checking this airing…`.

**Restarting a running programme.** For the current programme on a station
with `hasStartOver`, **Restart (live buffer)** starts the live stream and seeks
its timeshift back to the scheduled start, as the portal's *Neu starten* does
(padding is ignored). It is offered only when the start lies within the
sampled two-hour live window; otherwise the status line says
`Start is beyond the live buffer` or `Restart: not offered for this airing`.
If Kodi's reported timeline no longer contains the start, or reports no
timeline within 10 seconds, playback continues live with a notification. A past
programme is never restarted from the live buffer; it needs a verified Replay
offer.

Guide display metadata is cached per account in the add-on profile's
`guide-cache` directory, independently of authentication and playback rights.
Channel lists are fresh for 15 minutes and programme pages for 5 minutes;
retained snapshots can be displayed during a background refresh or outage
for up to 7 days and 48 hours respectively. Cached subscription information
does not authorize playback. Cached display data includes channel names, station
identifiers, public logo and artwork URLs, programme titles, times and
descriptions, not complete provider responses,
credentials, tokens, manifests or licence URLs. Fixed slots bound the cache
to 8 channel lists and 64 programme pages, at most 256 KiB each; expired and
unreadable entries are pruned. Episode descriptions and public programme artwork
are loaded only for the settled selection, asynchronously, and cached in up to
64 account-scoped detail slots for 48 hours. Verified public Magenta image URLs
may include numeric width and height parameters; signed URLs and other hosts
are not cached or displayed. Cache corruption or an unwritable cache must
not prevent loading live guide data.

Back opens the guide over the existing stream without releasing its lease;
lease renewal continues until returning to the stream, stopping or switching
channels. The guide can show a mini-picture, and its TV options include the
last subscribed channel and Kodi's seekable timeline edge. Switches release
the old lease before requesting another.
The channel source is subscribed-only, so there is no separate setting to hide
unplayable channels.

For successive live channels selected in the player, one plug-in invocation can
keep the login under its existing playback guard. The old player must stop and
its lease must be released before the next tune. Reuse requires the same
account, password and device ID, at most 20 seconds since selection, a session
no older than 20 minutes and a readable token with at least five minutes left.
Stop and errors sign out. For live-to-live switches the existing full-size
player window stays open while the previous player stops. Kodi opens the new
stream inside that window, including when a fresh login is needed. In that
case the add-on signs out, clears the cached inputs and signs in again under
the same guard. An unconfirmed stop, release or sign-out does not start a
successor. Replay and restart keep their existing paths.

Channel Up/Down starts switching immediately, with no fixed animation delay.
When **TV Static** is enabled, the tuning screen covers the actual stop, lease
release and new stream startup until Kodi reports AV start. Further channel keys
during that handoff update the desired channel without starting another player
or lease request in parallel. After the in-flight tune finishes, only the last
selected target is dispatched; selecting the channel now playing does nothing.

No session, token or switch cache is exported to a file, URL or Kodi window
property. The login stays in its owning interpreter; this is not a security
boundary against code running inside Kodi itself. Only pre-lock inputs are
reused: account headers, subscribed lineup and channel-feed fields for ten
minutes and validated live media IDs for five. Independent reads run in
parallel. A failed pre-lock read on a reused session can cause **one** fresh
sign-in and read; HTTP 403, 409 and 429 are not retried. Every channel requests
its own `/media` lease and licence. A `/media` failure drops the inputs and
never triggers another attempt. Kodi info-level `Timing channel` lines contain
only stage names, channel numbers and durations. For reused tunes these times
start when the controls accept the switch, without a static pre-delay; AV
start is the Kodi callback, not the point at which a URL is resolved.

In a disposable Windows Kodi 21.3, four alternating channel 11/12 switches
averaged **7.777 s** on the final logo baseline (`f9eeba9`) and **4.160 s** on
the single-owner candidate (`05f96be`), from the same Page Up/Down commands to
native `onAVStarted`. All four reached 720p video with audio and an advancing
clock. Cold starts were separate (8.250 s and 6.469 s); forcing one ineligible
switch in the test copy took 8.438 s via a new login. The four reused switches
needed no new login, but each got and released its own lease. Both builds
briefly returned to Home during the transition. These are four Windows pairs,
not a guarantee for another network, channel or device; the earlier HTTP 403
attempts never reached AV start and are not switch times.

The owned player offers Kodi's video OSD, Info, audio/subtitle selection,
last-channel and seekable-edge actions, and ten-minute seeks. The seek strip
uses only Kodi's reported player timeline and is shown for seeking or pause
when that timeline is valid; it is hidden behind the video OSD. The General
settings can disable automatic display without disabling explicit Info or seek
feedback. Go live seeks
to the reported timeline edge, which is not independently verified as the
provider's actual live position. Station titles come from the subscribed
channel list and add-on artwork is used as a fallback. The guide uses the channel feed's station logo
and individual programme details when available, with station text and empty
details as fallbacks.

Live playback also shows a now/next programme banner (as in simpliTVᵀ) after
tuning, on **Info**, and above Kodi's video OSD when **OK** opens it; it rises
above the skin's seek bar using the skin's own `VideoOSD.xml` geometry, or moves
to the top when that cannot be read. Holding **Left**/**Right** (Kodi's long-press
key code) seeks to the previous programme start or the current programme's end,
and the context menu offers the same jumps. Programme data comes only from the
guide's local display cache, so after a fresh install or for a channel not yet
shown in the guide the banner shows only the station and a long press reports
that no boundary is available; playback never fetches a schedule. While seeking
or paused, live playback fills the seek strip with the cached programme tiles
and shows a status of `LIVE` (within 30 seconds of the wall clock) or the
playhead's time and offset, for example `00:22 · −17:05`; without cached rows it
shows the plain position/duration strip. Programme times are mapped to Kodi's
timeline from the provider's live MPD, read once per tune together with the video
ladder: it is a dynamic manifest whose segment timeline counts wall-clock seconds,
so its newest segment end and window length give how far the stream trails the
clock (about 4 seconds in samples) and the window InputStream Adaptive positions
from. A tune whose manifest is not a single-period dynamic timeline, trails the
clock by more than a minute, or whose window does not match Kodi's duration within
five seconds gets no programme mapping at all. On Windows Kodi 21.3 the
position freezes while paused and is rebased on the current window after resume;
a seek made while paused is applied on the paused coordinates and then reported
on the current window. A live clock holds the paused playhead from raw player
samples and moves it by each seek dispatched while paused, because that rebase
can cancel a tap's step (a 30-second tap after 30 seconds paused barely moves
the reported position). If the resume rebase is not seen within six seconds, a
pause began between samples, or a seek lands before a resume was confirmed, the
mapping is treated as unreliable for that playback: the banner shows only the
station, the strip loses its programme tiles and long presses report that no
boundary is available. Kodi's position is about 16 seconds behind the window end
(the inputstream live delay), so the offset near live includes that delay plus the
manifest lag; InputStream Adaptive exposes no absolute stream time, so the
mapping rests on the manifest timeline rather than a frame-level check. Replay
has its own stream clock and keeps the plain station notification and
ten-minute/tap seeks; the seek strip is not programme-labelled.

The Magenta TV AT web EPG (`EPG.f54efed3.js`, bundled component
`styles__EPGChannelStyled`) limits station logos to 53×26 CSS px, vertically
centred in an 85 px channel row inside an 84 px channel rail. Its image component
uses `object-fit: contain`. Mapped proportionally to this guide's 176×45 logical
cell, the EPG logo box is about 111×14 px; the Android EPG's `channel_list_item`
uses a centred `FIT_CENTER` image up to 51×32 dp. To stay close to the visible
wide-logo scale while retaining room for tall/square marks in Kodi's much shorter
row, Magenta uses a 100×45 px `contain` box, centred within the existing cell.
The same bounds are used by the sliding logo and player strip; the tuning screen
uses the uncapped crop in its larger box. Original PNG detail is retained and
Kodi's `image://transform` creates Lanczos-downscaled variants for the guide.
A background worker stores local textures in the add-on profile (256 entries, 64 MiB),
checks HTTP validators after 24 hours, and retains cached art when offline.
JPEG, GIF, WebP and PNGs that cannot be trimmed keep their original aspect fit.
The station name is shown if no local art is available; oversized downloads
(over 8 MiB) are not retried through Kodi's texture downloader.

An isolated Windows test received licence HTTP 422 `ACCESS_DENIED` with
Widevine 4.10.2934.0, and played successfully after installing Google's
unmodified 4.10.3112.0. When playback starts, InputStream Helper's standard
check runs first and can offer to install a missing CDM or prompt to update it.
On Windows the add-on then requires Widevine 4.10.3112.0 or newer, the version
verified with Magenta, before signing in. If the installed version is older, it
offers to update through InputStream Helper; accepting changes Kodi's shared
CDM. A declined or unsuccessful update, or a version that cannot be read, stops
playback with an explanation, while the guide and Settings still open. The add-on
shows the update offer and these explanations in Kodi's language (German or
English, with English as the fallback). To update
manually, use InputStream Helper's "(Re)install Widevine CDM library..."
setting. This requirement comes from Magenta observations only: it is not a
general minimum Widevine version, and a newer version is not guaranteed to work.
On other systems only InputStream Helper's standard check applies.

The add-on stores the Magenta account, password and an add-on-specific device
ID in Kodi's per-user add-on settings. The password field is masked in the UI,
but Kodi stores its value in plaintext. Change or remove the credentials in the
add-on settings. Without credentials, opening the guide or a channel explains
this and opens Settings. After changed credentials are saved, the add-on signs
in once to check them and signs out again; a failure keeps the saved values and
offers **Open settings** or **Later**. Sign-in failures that need account
changes offer the same Settings shortcut; provider explanations such as **2838**
(IP address not permitted) are shown without it. **Sign out / switch account**
clears the saved account and password locally; the device ID and the
account-scoped guide caches remain. Signing in may consume a provider device
slot; device-limit recovery is not implemented.

Do not share Kodi debug logs: Kodi may record manifest URLs or other sensitive
request details. A temporary file or profile deletion does not guarantee
physical erasure on an SSD. Playback and sign-out depend on the provider's
current API and rights; a provider response to unlock or logout does not
independently prove server-side release or invalidation.

## Credits and licence

The add-on is based on simpliTVᵀ, maintained by Tom, itself based on the
simpliTV Kodi add-on by Publish3r and sunsettrack4. It is licensed under the
[GNU GPL version 3 or later](LICENSE.txt).

The Magenta channel-list, programme-schedule and query-authorization licence-request approach
follows [Ultimate Backend (`script.service.ultimate`)](https://github.com/nirvana-7777/script.service.ultimate)
by Nirvana (GPL-3.0), as of commit
`7c7665d3a528adabc3dbc15ee31c31eac1656f33`. The corresponding code was written
independently, using its `magentaeu/epg_manager.py` as the schedule reference;
Ultimate Backend's authors do not endorse this add-on.

## Synthetic native playback regression

`tests/kodi_service/reliability_playback.py` exercises a locally generated,
unprotected video through the real playback loop, owned controls and guide. It
replaces the provider, lease, licence relay and add-on settings with fakes; it
does not exercise the plugin-to-guide routing or real service playback.

For an isolated test, copy a Kodi installation to a disposable directory and
use `kodi.exe -p`. Copy this add-on's Python files, `addon.xml` and `resources`
to `portable_data\addons\plugin.video.magentatv_at_t`. Create
`portable_data\addons\service.magenta_reliability_playback`, copying
`tests\kodi_service\reliability_playback.py` there and
`reliability_playback_addon.xml` as its `addon.xml`. Generate the video with
`python tests\kodi_service\make_reliability_clip.py <portable-profile>\fixture.avi`.
Write `<portable-profile>\fixture.json` as `{"mode":"pending"}` or
`{"mode":"populated"}`; add `"input":"seek_back"` to test an immediately
cancelled queued seek. The profile is `portable_data\userdata`.

Kodi may initially install the synthetic service disabled. If so, stop the
disposable Kodi process and enable only `service.magenta_reliability_playback`
in that profile's Addons database before starting it again. Capture the owned
process's natural exit code and verify the resulting `fixture-events.jsonl`:
`python tests\kodi_service\verify_reliability_events.py <events> pending 0`
or use `populated` and the actual exit code; append `--seek-back` for that
variant. A missing event, fixture error, nonzero exit or timeout is not a pass.
Use a fresh event file per run and remove the disposable profile afterward.
