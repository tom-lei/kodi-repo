"""CRT channel-change screen adapted from simpliTVᵀ (GPL-3.0-or-later)."""

import os
import time

from crt_noise import FPS, tuning_logo_size
from seek_strip import skin_font


class TuningScreen:
    def __init__(self, window, addon, textures, title, clock=time.monotonic):
        import xbmcgui

        self.window = window
        self.clock = clock
        self.started = clock()
        self.frame = None
        self.logo = None
        self.logo_path = None
        width, height = window.getWidth(), window.getHeight()
        solid = os.path.join(addon.getAddonInfo("path"), "resources", "skins", "Default",
                             "media", "guide-solid.png")
        self.frames = []
        if textures:
            self.frames = [xbmcgui.ControlImage(0, 0, width, height, path)
                           for path in textures[0]]
            background = self.frames
        else:
            background = [xbmcgui.ControlImage(0, 0, width, height, solid,
                                                colorDiffuse="FF101722")]
        self.label = xbmcgui.ControlLabel(
            0, max(0, height // 2 - 20), width, 40, title,
            font=skin_font(), textColor="FFFFFFFF", alignment=6,
        )
        self.controls = background + [self.label]
        self.window.addControls(self.controls)
        self.animate()

    def set_title(self, title):
        self.label.setLabel(title)

    def set_logo(self, path):
        if self.logo_path == path:
            return
        import xbmcgui
        from guide import guide_logo_texture
        width, height = self.window.getWidth(), self.window.getHeight()
        w, h = tuning_logo_size(width, height)
        top = max(0, (height - h - 45) // 2)
        if path:
            texture = guide_logo_texture(path, w, h)
            if self.logo is None:
                self.logo = xbmcgui.ControlImage((width - w) // 2, top, w, h, texture, aspectRatio=2)
                self.window.addControl(self.logo)
                self.controls.append(self.logo)
            else:
                self.logo.setImage(texture)
            self.logo.setVisible(True)
        elif self.logo is not None:
            self.logo.setVisible(False)
        self.label.setPosition(0, top + h + 5 if path else max(0, height // 2 - 20))
        self.logo_path = path

    def animate(self):
        if not self.frames:
            return
        frame = int((self.clock() - self.started) * FPS) % len(self.frames)
        if frame == self.frame:
            return
        if self.frame is None:
            for index, control in enumerate(self.frames):
                control.setVisible(index == frame)
        else:
            self.frames[self.frame].setVisible(False)
            self.frames[frame].setVisible(True)
        self.frame = frame

    def close(self):
        self.window.removeControls(self.controls)
