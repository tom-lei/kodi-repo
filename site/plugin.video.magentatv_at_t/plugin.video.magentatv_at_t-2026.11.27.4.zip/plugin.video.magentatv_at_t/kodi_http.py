"""Open provider requests using the current Kodi proxy, never OS bypass rules."""

import base64
import ipaddress
import json
import os
import re
import ssl
from contextlib import contextmanager
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, ProxyHandler, build_opener

import urllib3


_PROXY_SCHEMES = {1: "socks4", 2: "socks4a", 3: "socks5", 4: "socks5h", 5: "https"}


class ProxySettingsError(Exception):
    """Safe to show: messages never include setting values."""


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class _KodiProxy(ProxyHandler):
    def __init__(self, endpoint, username, password):
        super().__init__({"http": endpoint, "https": endpoint})
        self.authorization = None
        if username or password:
            self.authorization = "Basic " + base64.b64encode(
                (username + ":" + password).encode("utf-8")).decode("ascii")

    def proxy_open(self, request, endpoint, scheme):
        # ProxyHandler.proxy_open consults OS bypass rules (including NO_PROXY=*).
        # For HTTPS, urllib sends Proxy-Authorization on CONNECT only.
        request.set_proxy(endpoint, "http")
        if self.authorization is not None:
            request.add_unredirected_header("Proxy-Authorization", self.authorization)


def _settings(rpc, names):
    calls = [{"jsonrpc": "2.0", "id": i, "method": "Settings.GetSettingValue",
              "params": {"setting": "network." + name}} for i, name in enumerate(names)]
    try:
        answers = json.loads(rpc(json.dumps(calls)))
        values = {answer["id"]: answer["result"]["value"] for answer in answers}
        return [values[i] for i in range(len(names))]
    except (KeyError, TypeError, ValueError, RuntimeError):
        raise ProxySettingsError("Could not read Kodi's proxy settings; connection blocked.") from None


def _proxy_enabled(rpc):
    enabled, = _settings(rpc, ("usehttpproxy",))
    if type(enabled) is not bool:
        raise ProxySettingsError("Invalid Kodi proxy setting; connection blocked.")
    return enabled


def _process_env(name):
    # os.environ is a snapshot belonging to one Kodi Python interpreter.
    if os.name == "nt":
        from winreg import ExpandEnvironmentStrings
        reference = "%" + name + "%"
        value = ExpandEnvironmentStrings(reference)
        return None if value == reference else value
    from ctypes import CDLL, c_char_p
    getenv = CDLL(None).getenv
    getenv.argtypes = (c_char_p,)
    getenv.restype = c_char_p
    value = getenv(name.encode("ascii"))
    return os.fsdecode(value) if value is not None else None


@contextmanager
def local_relay_route():
    import xbmc

    if not _proxy_enabled(xbmc.executeJSONRPC):
        yield
        return
    # Kodi skips its explicit proxy for loopback, but libcurl also reads the
    # process environment. Exempt only the listener's literal IPv4 address.
    key = "no_proxy"
    try:
        previous = _process_env(key)
        effective = previous or _process_env("NO_PROXY") or ""
        if effective == "*" or "127.0.0.1" in (entry.strip() for entry in effective.split(",")):
            applied = None
        else:
            applied = effective + ",127.0.0.1" if effective else "127.0.0.1"
            os.putenv(key, applied)
            if _process_env(key) != applied:
                raise ProxySettingsError("Could not keep the Kodi licence request on loopback; playback blocked.")
    except (ImportError, OSError, ValueError):
        raise ProxySettingsError("Could not keep the Kodi licence request on loopback; playback blocked.") from None
    try:
        yield
    finally:
        # PlaybackGuard serializes Magenta players. Never overwrite a later
        # change by a different component in the same Kodi process.
        try:
            if applied is not None and _process_env(key) == applied:
                if previous is None and os.name != "nt":
                    os.unsetenv(key)
                else:
                    # Kodi Omega embeds Python 3.8 on Windows: no os.unsetenv.
                    os.putenv(key, previous or "")
        except (OSError, ValueError):
            raise ProxySettingsError("Could not restore the Kodi loopback proxy exclusion.") from None


def _proxy_handler(rpc, direct_when_off):
    if not _proxy_enabled(rpc):
        # Preserve the previous transports while Kodi's proxy is explicitly off.
        return ProxyHandler({}) if direct_when_off else ProxyHandler()
    kind, host, port, username, password = _settings(rpc, (
        "httpproxytype", "httpproxyserver", "httpproxyport", "httpproxyusername", "httpproxypassword"))
    if type(kind) is not int or kind not in (0, 1, 2, 3, 4, 5):
        raise ProxySettingsError("Invalid Kodi proxy type; connection blocked.")
    if (not isinstance(host, str) or not host or type(port) is not int or not 1 <= port <= 65535
            or not isinstance(username, str) or not isinstance(password, str)):
        raise ProxySettingsError("Invalid Kodi proxy configuration; connection blocked.")
    if ":" in host:
        try:
            address = host[1:-1] if host.startswith("[") and host.endswith("]") else host
            host = "[{}]".format(ipaddress.IPv6Address(address))
        except ValueError:
            raise ProxySettingsError("Invalid Kodi proxy host; connection blocked.") from None
    elif not re.fullmatch(r"[a-zA-Z0-9._-]+", host):
        raise ProxySettingsError("Invalid Kodi proxy host; connection blocked.")
    if kind == 0:
        return _KodiProxy("{}:{}".format(host, port), username, password)
    context = ssl.create_default_context()
    scheme = _PROXY_SCHEMES[kind]
    proxy_url = "{}://{}:{}".format(scheme, host, port)
    if kind != 5:
        from urllib3.contrib.socks import SOCKSProxyManager

        return SOCKSProxyManager(proxy_url, username=username or None,
                                 password=password or None, ssl_context=context)
    try:
        headers = urllib3.make_headers(proxy_basic_auth=username + ":" + password) if (
            username or password) else None
    except (UnicodeError, ValueError):
        raise ProxySettingsError("Invalid Kodi proxy credentials; connection blocked.") from None
    return urllib3.ProxyManager(proxy_url, proxy_headers=headers, ssl_context=context,
                               proxy_ssl_context=ssl.create_default_context())


class _Response:
    def __init__(self, response, manager):
        self._response = response
        self._manager = manager
        self.code = self.status = response.status
        self.headers = response.headers

    def read(self, size=None):
        try:
            return self._response.read(size)
        except urllib3.exceptions.HTTPError as error:
            raise OSError("The HTTP response could not be read") from error

    def read1(self, size):
        try:
            return self._response.read1(size)
        except urllib3.exceptions.HTTPError as error:
            raise OSError("The HTTP response could not be read") from error

    def close(self):
        try:
            self._response.close()
        finally:
            self._manager.clear()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()


def open_provider(request, *, direct_when_off=False, timeout=20):
    import xbmc

    proxy = _proxy_handler(xbmc.executeJSONRPC, direct_when_off)
    if isinstance(proxy, ProxyHandler):
        return build_opener(proxy, _NoRedirect()).open(request, timeout=timeout)
    try:
        response = proxy.request(
            request.get_method(), request.full_url, body=request.data,
            headers=dict(request.header_items()), timeout=timeout, retries=False,
            redirect=False, preload_content=False)
    except (urllib3.exceptions.HTTPError, OSError) as error:
        proxy.clear()
        raise URLError("The HTTP transport failed") from error
    result = _Response(response, proxy)
    if not 200 <= response.status < 300:
        raise HTTPError(request.full_url, response.status, response.reason,
                        response.headers, result)
    return result
