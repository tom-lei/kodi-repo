"""Bounded, account-scoped display metadata; never persist provider responses."""

import datetime
import hashlib
import json
import math
import os
import re
import time
from contextlib import contextmanager

from magenta_guide_data import CODE, GuideChannel, UTC, display_image_url


VERSION = 1
CHANNEL_SECONDS = 15 * 60
EPG_SECONDS = 5 * 60
CHANNEL_RETENTION = 7 * 24 * 60 * 60
EPG_RETENTION = 48 * 60 * 60
LAST_RETENTION = 365 * 24 * 60 * 60
PAGE_SECONDS = 4 * 60 * 60
MAX_FILE_BYTES = 256 * 1024
MAX_CHANNELS = 1024
MAX_PROGRAMMES = 2000
SLOTS = {"channels": 8, "epg": 64, "details": 64, "last": 8}
RETENTION = {"channels": CHANNEL_RETENTION, "last": LAST_RETENTION}
URL_TEXT = re.compile(r"\S*(?:://|www\.)\S+", re.IGNORECASE)


class _ExpiredEntry(ValueError):
    pass


def _digest(value):
    return hashlib.sha256(json.dumps(value, separators=(",", ":"),
                                     ensure_ascii=True).encode("ascii")).hexdigest()


def _stamp(value):
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
        raise ValueError("Invalid cache timestamp")
    return value


def _text(value, limit):
    if not isinstance(value, str):
        raise ValueError("Invalid cache text")
    return URL_TEXT.sub("", value).strip()[:limit]


def _channels(values):
    if not isinstance(values, (list, tuple)) or len(values) > MAX_CHANNELS:
        raise ValueError("Invalid cached channels")
    result, numbers = [], set()
    for value in values:
        number, title, station = value["number"], value["title"], value["station_id"]
        if type(number) is not int or not 0 <= number <= 999999 or number in numbers:
            raise ValueError("Invalid cached channel")
        title = _text(title, 256)
        if not title or (station is not None
                         and (not isinstance(station, str) or not CODE.fullmatch(station))):
            raise ValueError("Invalid cached channel")
        numbers.add(number)
        logo = value.get("logo")
        if logo is not None and display_image_url(logo) is None:
            raise ValueError("Invalid cached logo")
        result.append(GuideChannel(number, title, station, logo))
    return tuple(sorted(result, key=lambda channel: channel.number))


def _channel_data(channels):
    return [{"number": channel.number, "title": channel.title,
             "station_id": channel.station_id, "logo": channel.logo} for channel in channels]


def _details(value):
    if not isinstance(value, dict):
        raise ValueError("Invalid cached programme details")
    description = _text(value.get("description", ""), 8192)
    artwork = value.get("artwork")
    if artwork is not None and display_image_url(artwork) is None:
        raise ValueError("Invalid cached programme artwork")
    return {"description": description, "artwork": artwork}


def _last_channel(value):
    if type(value) is not int or not 0 <= value <= 999999:
        raise ValueError("Invalid last channel")
    return value


def _page_identity(start, channels):
    if not isinstance(start, datetime.datetime) or start.utcoffset() is None:
        raise ValueError("Invalid cache window")
    selected = _channels(_channel_data(channels))
    return [int(start.timestamp()), [[item.number, item.station_id] for item in selected]]


def _events(values, identity):
    if not isinstance(values, (list, tuple)) or len(values) > MAX_PROGRAMMES:
        raise ValueError("Invalid cached programmes")
    numbers = {str(item[0]) for item in identity[1]}
    result = []
    for value in values:
        channel = value["tileChannel"]["codename"]
        if not isinstance(channel, str) or channel not in numbers:
            raise ValueError("Invalid cached programme channel")
        start, stop = value["start"], value["stop"]
        if not isinstance(start, str) or not isinstance(stop, str) or max(len(start), len(stop)) > 40:
            raise ValueError("Invalid cached interval")
        start, stop = (datetime.datetime.fromisoformat(item.replace("Z", "+00:00"))
                       for item in (start, stop))
        if start.utcoffset() is None or stop.utcoffset() is None:
            raise ValueError("Invalid cached interval")
        begin, end = start.timestamp(), stop.timestamp()
        if not 0 < end - begin <= EPG_RETENTION:
            raise ValueError("Invalid cached interval")
        title = _text(value["title"], 256)
        program_id = value.get("id", "")
        if not isinstance(program_id, str):
            raise ValueError("Invalid cached programme identifier")
        if program_id and not CODE.fullmatch(program_id):
            program_id = ""
        if end <= identity[0] or begin >= identity[0] + PAGE_SECONDS:
            continue
        event = {"id": program_id, "title": title,
                 "start": start.astimezone(UTC).isoformat(),
                 "stop": stop.astimezone(UTC).isoformat(),
                 "tileChannel": {"codename": channel}}
        for flag in ("is_catchup_enabled", "has_start_over"):
            if flag in value:
                if not isinstance(value[flag], bool):
                    raise ValueError("Invalid cached programme capability")
                event[flag] = value[flag]
        result.append(event)
    return tuple(result)


@contextmanager
def _claim(path):
    """Fixed per-slot locks also bound abandoned temporary files."""
    with open(path, "a+b") as handle:
        if os.path.getsize(path) == 0:
            handle.write(b"\0")
            handle.flush()
        if os.name == "nt":
            import msvcrt
            handle.seek(0)
            acquire = lambda: msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            release = lambda: (handle.seek(0), msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1))
        else:
            import fcntl
            acquire = lambda: fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            release = lambda: fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        try:
            acquire()
        except OSError:
            yield False
        else:
            try:
                yield True
            finally:
                release()


class GuideStore:
    """Slot collisions are misses, including between different accounts."""

    def __init__(self, profile, username, log=lambda message: None, clock=time.time):
        if not isinstance(username, str) or not username.strip():
            raise ValueError("A guide cache needs an account")
        self.root = os.path.join(profile, "guide-cache")
        self.account = _digest(["magenta-at", username.strip()])
        self.log = log
        self.clock = clock
        if os.path.isdir(self.root):
            self.prune()

    def _address(self, kind, identity):
        key = _digest([self.account, kind, identity])
        filename = "{}-{:03}.json".format(kind, int(key[:8], 16) % SLOTS[kind])
        return os.path.join(self.root, filename), key

    def _entry(self, path, retention):
        with open(path, "rb") as handle:
            raw = handle.read(MAX_FILE_BYTES + 1)
        if len(raw) > MAX_FILE_BYTES:
            raise ValueError("Oversized cache entry")
        entry = json.loads(raw)
        if (type(entry["version"]) is not int or entry["version"] != VERSION
                or not isinstance(entry["key"], str) or not CODE.fullmatch(entry["key"])):
            raise ValueError("Invalid cache entry")
        age = self.clock() - _stamp(entry["created"])
        if age < 0:
            raise ValueError("Future cache entry")
        if age >= retention:
            raise _ExpiredEntry()
        return entry

    def _read(self, kind, identity, allow_stale, validate):
        path, key = self._address(kind, identity)
        ttl = CHANNEL_SECONDS if kind == "channels" else EPG_SECONDS
        retention = RETENTION.get(kind, EPG_RETENTION)
        try:
            entry = self._entry(path, retention if allow_stale else ttl)
            if entry["key"] != key:
                return None
            return entry["created"], validate(entry["data"])
        except (FileNotFoundError, _ExpiredEntry):
            return None
        except (OSError, ValueError, TypeError, KeyError, AttributeError,
                OverflowError, RecursionError):
            self.log("Ignoring unreadable guide display cache entry")
            return None

    def _write(self, kind, identity, data, created=None):
        path, key = self._address(kind, identity)
        temp = path + ".tmp"
        try:
            stamp = _stamp(self.clock() if created is None else created)
            payload = json.dumps({"version": VERSION, "key": key, "identity": identity,
                                  "created": stamp, "data": data},
                                 ensure_ascii=True, separators=(",", ":"), allow_nan=False).encode("ascii")
            if len(payload) > MAX_FILE_BYTES:
                self.log("Could not save oversized guide display cache entry")
                return False
            os.makedirs(self.root, exist_ok=True)
            with _claim(path + ".lock") as claimed:
                if not claimed:
                    return False
                try:
                    old = self._entry(path, RETENTION.get(kind, EPG_RETENTION))
                    if old["key"] == key and old["created"] > stamp:
                        return False
                except (FileNotFoundError, _ExpiredEntry):
                    pass
                except (OSError, ValueError, TypeError, KeyError, AttributeError,
                        OverflowError, RecursionError):
                    self.log("Replacing unreadable guide display cache entry")
                try:
                    with open(temp, "wb") as handle:
                        handle.write(payload)
                        handle.flush()
                        os.fsync(handle.fileno())
                    os.replace(temp, path)
                finally:
                    try:
                        os.unlink(temp)
                    except FileNotFoundError:
                        pass
            self.prune()
            return True
        except (OSError, ValueError, TypeError, OverflowError, RecursionError):
            self.log("Could not save guide display cache")
            return False

    def read_channels(self, allow_stale=True):
        entry = self._read("channels", None, allow_stale, _channels)
        return entry[1] if entry is not None else None

    def channels_fresh(self):
        def validate(data):
            channels = _channels(data)
            return all("logo" in item for item in data), channels
        entry = self._read("channels", None, False, validate)
        return entry is not None and entry[1][0]

    def write_channels(self, channels):
        try:
            data = _channel_data(_channels(_channel_data(channels)))
            return self._write("channels", None, data)
        except (ValueError, TypeError, KeyError, AttributeError):
            self.log("Could not save invalid guide channel cache entry")
            return False

    def read_last_channel(self):
        entry = self._read("last", None, True, _last_channel)
        return entry[1] if entry is not None else None

    def write_last_channel(self, channel):
        try:
            return self._write("last", None, _last_channel(channel))
        except ValueError:
            self.log("Could not save invalid last channel")
            return False

    def forget_last_channel(self):
        """Delete only this account's entry; a colliding slot may hold another account."""
        path, key = self._address("last", None)
        try:
            with _claim(path + ".lock") as claimed:
                if not claimed:
                    self.log("Could not forget last channel: cache is busy")
                    return False
                try:
                    if self._entry(path, LAST_RETENTION)["key"] != key:
                        return True
                except (FileNotFoundError, _ExpiredEntry):
                    return True
                except (OSError, ValueError, TypeError, KeyError, AttributeError,
                        OverflowError, RecursionError):
                    pass
                os.unlink(path)
                return True
        except FileNotFoundError:
            return True
        except OSError:
            self.log("Could not forget last channel")
            return False

    def read_details(self, program_id):
        if not isinstance(program_id, str) or not CODE.fullmatch(program_id):
            return None
        entry = self._read("details", program_id, True, _details)
        return entry[1] if entry is not None else None

    def write_details(self, program_id, details):
        try:
            if not isinstance(program_id, str) or not CODE.fullmatch(program_id):
                raise ValueError("Invalid programme id")
            return self._write("details", program_id, _details(details))
        except (ValueError, TypeError, KeyError, AttributeError):
            self.log("Could not save invalid programme details")
            return False

    def read_page(self, start, channels, allow_stale=True):
        try:
            identity = _page_identity(start, channels)
            return self._read("epg", identity, allow_stale, lambda data: _events(data, identity))
        except (ValueError, TypeError, KeyError, AttributeError, OverflowError, OSError):
            self.log("Ignoring invalid guide page cache request")
            return None

    def write_page(self, start, channels, events, created=None):
        try:
            identity = _page_identity(start, channels)
            return self._write("epg", identity, _events(events, identity), created)
        except (ValueError, TypeError, KeyError, AttributeError, OverflowError, OSError):
            self.log("Could not save invalid guide page cache entry")
            return False

    def read_available_page(self, start, channels):
        """Recover overlapping display data after the guide's initial time advances."""
        try:
            target = _page_identity(start, channels)
            wanted = dict(target[1])
        except (ValueError, TypeError, KeyError, AttributeError, OverflowError, OSError):
            self.log("Ignoring invalid guide page cache request")
            return None
        events, stamps = {}, []
        for slot in range(SLOTS["epg"]):
            path = os.path.join(self.root, "epg-{:03}.json".format(slot))
            try:
                entry = self._entry(path, EPG_RETENTION)
                identity = entry["identity"]
                if (not isinstance(identity, list) or len(identity) != 2
                        or type(identity[0]) is not int or not isinstance(identity[1], list)
                        or len(identity[1]) > MAX_CHANNELS
                        or entry["key"] != self._address("epg", identity)[1]):
                    continue
                available = dict(identity[1])
                if not any(wanted.get(number) == station and number in wanted
                           for number, station in available.items()):
                    continue
                if identity[0] + PAGE_SECONDS <= target[0] or identity[0] >= target[0] + PAGE_SECONDS:
                    continue
                selected = [GuideChannel(number, "Cached channel", station)
                            for number, station in identity[1]]
                canonical = _page_identity(datetime.datetime.fromtimestamp(identity[0], UTC), selected)
                if canonical != identity:
                    continue
                matching = []
                for event in _events(entry["data"], identity):
                    number = int(event["tileChannel"]["codename"])
                    if number in wanted and wanted[number] == available[number]:
                        matching.append(event)
                matching = _events(matching, target)
                if matching:
                    stamps.append(entry["created"])
                for event in matching:
                    key = (event["tileChannel"]["codename"], event["start"], event["stop"])
                    previous = events.get(key)
                    if previous is None and len(events) >= MAX_PROGRAMMES:
                        continue
                    if previous is None or previous[0] < entry["created"]:
                        events[key] = (entry["created"], event)
            except (FileNotFoundError, _ExpiredEntry):
                continue
            except (OSError, ValueError, TypeError, KeyError, AttributeError,
                    OverflowError, RecursionError):
                self.log("Ignoring unreadable guide display cache entry")
                continue
        if not events:
            return None
        result = tuple(value[1] for _, value in sorted(events.items()))
        return min(stamps), result

    def prune(self):
        if not os.path.isdir(self.root):
            return
        for kind, slots in SLOTS.items():
            retention = RETENTION.get(kind, EPG_RETENTION)
            for slot in range(slots):
                path = os.path.join(self.root, "{}-{:03}.json".format(kind, slot))
                try:
                    with _claim(path + ".lock") as claimed:
                        if not claimed:
                            continue
                        try:
                            self._entry(path, retention)
                        except FileNotFoundError:
                            pass
                        except _ExpiredEntry:
                            try:
                                os.unlink(path)
                            except FileNotFoundError:
                                pass
                        except (OSError, ValueError, TypeError, KeyError, AttributeError,
                                OverflowError, RecursionError):
                            self.log("Pruning unreadable guide display cache entry")
                            try:
                                os.unlink(path)
                            except FileNotFoundError:
                                pass
                        try:
                            os.unlink(path + ".tmp")
                        except FileNotFoundError:
                            pass
                except OSError:
                    self.log("Could not clean guide display cache entry")
