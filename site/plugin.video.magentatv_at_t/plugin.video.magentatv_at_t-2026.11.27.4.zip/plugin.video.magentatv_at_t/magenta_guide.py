"""Connect Magenta programme data to the adapted simpliTVᵀ guide."""

import datetime
import threading
import time
from collections import OrderedDict

from guide_support import LiveDataCancelled, LiveDataError
from magenta_guide_data import UTC, display_image_url, fetch_schedules
from magenta_guide_store import EPG_RETENTION, EPG_SECONDS
from magenta_playback import PlaybackError
from provider_error import ProviderError


PAGE_HOURS = 4
MAX_CACHED_PAGES = 16
MAX_DETAILS = 64


class ProgrammeDetails:
    def __init__(self, api, store=None):
        self.api = api
        self.store = store
        self.entries = OrderedDict()
        self.lock = threading.Lock()

    def peek(self, program_id):
        with self.lock:
            if program_id in self.entries:
                self.entries.move_to_end(program_id)
                return self.entries[program_id]
            return None

    def _remember(self, program_id, value):
        self.entries[program_id] = value
        self.entries.move_to_end(program_id)
        while len(self.entries) > MAX_DETAILS:
            self.entries.popitem(last=False)

    def load(self, program_id):
        cached = self.peek(program_id)
        if cached is not None:
            return cached
        cached = self.store.read_details(program_id) if self.store else None
        if cached is not None:
            with self.lock:
                self._remember(program_id, cached)
            return cached
        response = self.api.program_details(program_id)
        details = response.get("details")
        description = details.get("description") if isinstance(details, dict) else None
        value = {"description": description.strip()[:8192] if isinstance(description, str) else "",
                 "artwork": display_image_url(response.get("poster_image_url"))}
        with self.lock:
            self._remember(program_id, value)
        if self.store:
            self.store.write_details(program_id, value)
        return value


def guide_events(programmes):
    events = []
    for item in programmes:
        event = {
            "id": item.program_id,
            "title": item.title,
            "start": datetime.datetime.fromtimestamp(item.start, UTC).isoformat(),
            "stop": datetime.datetime.fromtimestamp(item.stop, UTC).isoformat(),
            "tileChannel": {"codename": str(item.channel)},
        }
        if item.catchup is not None:
            event["is_catchup_enabled"] = item.catchup
        if item.start_over is not None:
            event["has_start_over"] = item.start_over
        events.append(event)
    return tuple(events)


class GuideCache:
    def __init__(self, api, channels, store=None, clock=time.time):
        self.api = api
        self.channels = {str(channel.number): channel for channel in channels}
        self.pages = OrderedDict()
        self.created = {}
        self.partial = set()
        self.store = store
        self.clock = clock
        self.lock = threading.RLock()
        self.revision = 0

    def update_channels(self, channels):
        updated = {str(channel.number): channel for channel in channels}
        with self.lock:
            if list(updated.items()) == list(self.channels.items()):
                return False
            self.channels = updated
            self.revision += 1
            self.pages.clear()
            self.created.clear()
            self.partial.clear()
            return True

    def peek(self, start, channels):
        key = (start, tuple(channels))
        with self.lock:
            stamp = self.created.get(key)
            if stamp is not None and not 0 <= self.clock() - stamp < EPG_RETENTION:
                self.pages.pop(key, None)
                self.created.pop(key, None)
                self.partial.discard(key)
            if key in self.pages:
                return self.pages[key]
            if self.store is not None:
                try:
                    selected = [self.channels[channel] for channel in channels]
                except KeyError:
                    return None
                entry = self.store.read_page(start, selected)
                if entry is None:
                    entry = self.store.read_available_page(start, selected)
                    if entry is not None:
                        self.partial.add(key)
                if entry is not None:
                    self._remember(key, entry[1], entry[0])
                    return entry[1]
            return None

    def _remember(self, key, events, created):
        self.pages[key] = events
        self.created[key] = created
        self.pages.move_to_end(key)
        while len(self.pages) > MAX_CACHED_PAGES:
            old, _ = self.pages.popitem(last=False)
            self.created.pop(old, None)
            self.partial.discard(old)

    def needs_refresh(self, start, channels):
        key = (start, tuple(channels))
        self.peek(start, channels)
        with self.lock:
            stamp = self.created.get(key)
            return (key in self.partial or stamp is None
                    or not 0 <= self.clock() - stamp < EPG_SECONDS)

    def load(self, start, channels, cancelled, publish):
        key = (start, tuple(channels))
        if cancelled():
            raise LiveDataCancelled()
        with self.lock:
            previous = self.peek(start, channels)
            if not self.needs_refresh(start, channels):
                return previous
            created = self.clock()
            revision = self.revision
            try:
                selected = [self.channels[channel] for channel in channels]
            except KeyError:
                raise LiveDataError("The selected guide channel is unavailable.") from None

        def request_cancelled():
            if cancelled():
                return True
            with self.lock:
                return revision != self.revision

        try:
            programmes, invalid = fetch_schedules(
                self.api, start, start + datetime.timedelta(hours=PAGE_HOURS),
                selected, request_cancelled,
            )
        except PlaybackError as error:
            if request_cancelled():
                raise LiveDataCancelled() from None
            raise LiveDataError(ProviderError.from_exception(error) or str(error)) from None
        events = guide_events(programmes)
        if request_cancelled():
            raise LiveDataCancelled()
        invalid += sum(channel.station_id is None for channel in selected)
        with self.lock:
            if revision != self.revision:
                raise LiveDataCancelled()
            if invalid:
                if previous is None:
                    publish(events)
                raise LiveDataError("The programme guide is incomplete.")
            self._remember(key, events, created)
            self.partial.discard(key)
            if self.store is not None:
                self.store.write_page(start, selected, events, created)
        return events
