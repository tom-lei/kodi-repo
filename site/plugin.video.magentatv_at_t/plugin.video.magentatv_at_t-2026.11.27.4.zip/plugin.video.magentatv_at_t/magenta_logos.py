"""Fetch public channel art through the same Kodi transport as provider API calls."""

import time
from http.client import HTTPException
from urllib.error import HTTPError
from urllib.request import Request

from channel_logos import MAX_BYTES, LogoCache
from kodi_http import ProxySettingsError, open_provider
from magenta_guide_data import display_image_url


def _fetch(url, headers):
    if not display_image_url(url):
        raise ValueError("Invalid artwork origin")
    try:
        with open_provider(Request(url, headers=headers), timeout=3) as reply:
            parts = bytearray()
            deadline = time.monotonic() + 5
            while len(parts) <= MAX_BYTES and time.monotonic() < deadline:
                chunk = reply.read1(min(65536, MAX_BYTES + 1 - len(parts)))
                if not chunk:
                    return reply.code, reply.headers, bytes(parts)
                parts.extend(chunk)
            raise ValueError("Artwork download limit")
    except HTTPError as error:
        with error:
            return error.code, error.headers, b""
    except (HTTPException, ProxySettingsError) as error:
        raise OSError(type(error).__name__) from None


def channel_artwork(profile, log, translate):
    return LogoCache(profile, _fetch, log, translate)
