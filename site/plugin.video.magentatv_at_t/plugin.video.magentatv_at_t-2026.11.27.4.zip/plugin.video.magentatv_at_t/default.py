"""Magenta TV AT live channel directory and playback entry point."""

import json
import os
import sys
import threading
import time
from urllib.parse import parse_qs, urlencode

import inputstreamhelper
from inputstreamhelper.widevine.widevine import load_widevine_config
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from cdm_check import ensure_widevine
from credential_settings import ADDON_ID, CredentialSettingsError, CredentialsCancelled, device_id
from guide import GUIDE_TEXT, open_guide
from guide_support import LiveDataError
from live_player import StartOver, play_channel
from magenta_auth import SWITCH_SECONDS, AuthError, client_platform, open_session
from magenta_experiment import Bff
from magenta_guide import GuideCache, ProgrammeDetails
from magenta_guide_data import guide_channels
from magenta_guide_store import CHANNEL_SECONDS, GuideStore
from magenta_logos import channel_artwork
from magenta_playback import PlaybackError
from magenta_replay import Airing, opted_in, replay_offer
from magenta_switch import LiveInputs, TuneTiming
from programme_banner import CachedSchedule
from playback_guard import PlaybackGuard, SwitchingMonitor, application_aborted, clear_switch, request_switch
from provider_error import ProviderError
from player_controls import OwnedPlayerWindow


TITLE = "Magenta TV ATᵀ"
VIDEOS_WINDOW = 10025
SELECTION_KEY = "magentatv_at_t.guide.selection.local"
PLAYER_KEYS = ("magentatv_at_t.player.current", "magentatv_at_t.player.previous")
SIGN_IN_REQUIRED = 2840
ACCOUNT_TEXT = (
    {
        "not_configured": "Enter your Magenta TV account and password in the add-on settings.",
        "verified": "Sign-in verified.",
        "check_account": "Check your account in Settings.",
        "settings": "Open settings", "later": "Later",
        "signed_out": "Signed out. Enter another account in Settings.",
        "next_start": "The new account is used from the next channel start.",
        "channel_gone": "The previously selected channel {} is not in this account's channel list.",
    },
    {
        "not_configured": "Gib dein Magenta TV-Konto und das Passwort in den Add-on-Einstellungen ein.",
        "verified": "Anmeldung bestätigt.",
        "check_account": "Prüfe dein Konto in den Einstellungen.",
        "settings": "Einstellungen öffnen", "later": "Später",
        "signed_out": "Abgemeldet. Gib in den Einstellungen ein anderes Konto ein.",
        "next_start": "Das neue Konto wird ab dem nächsten Senderstart verwendet.",
        "channel_gone": "Der zuvor gewählte Sender {} ist nicht in der Senderliste dieses Kontos.",
    },
)


class PlaybackSupportError(PlaybackError):
    pass


def build_url(mode):
    return sys.argv[0] + "?" + urlencode({"mode": mode})


def addon_enabled():
    """Kodi stops only service add-ons on disable/uninstall; plugin scripts must notice."""
    try:
        xbmcaddon.Addon(ADDON_ID)
    except RuntimeError:
        return False
    return True


def playback_url(selection, from_guide=False):
    params = selection.query() if isinstance(selection, (Airing, StartOver)) else {"channel": selection}
    if from_guide:
        params["origin"] = "guide"
    return sys.argv[0] + "?" + urlencode(params)


def account_text(key):
    return ACCOUNT_TEXT[xbmc.getLanguage(xbmc.ISO_639_1) == "de"][key]


def notify(settings, message):
    xbmcgui.Dialog().notification(TITLE, message, settings.getAddonInfo("icon"), 5000)


def log_warning(message):
    xbmc.log("[Magenta TV AT] " + message, xbmc.LOGWARNING)


def read_credentials(settings):
    try:
        values = settings.getSettingString("username"), settings.getSettingString("password")
    except (RuntimeError, TypeError, ValueError):
        raise CredentialSettingsError() from None
    if not all(isinstance(value, str) for value in values):
        raise CredentialSettingsError()
    return values


def configured(values):
    return bool(values[0].strip() and values[1])


def account_store(settings, username):
    if not isinstance(username, str) or not username.strip():
        return None
    try:
        return GuideStore(xbmcvfs.translatePath(settings.getAddonInfo("profile")), username, log_warning)
    except (OSError, TypeError, ValueError):
        return None


def remember_last(settings):
    return settings.getSetting("remember_last_channel") != "false"


def remember_watched_channel(settings, username, number):
    store = account_store(settings, username)
    if store is not None:
        if remember_last(settings):
            store.write_last_channel(number)
        else:
            store.forget_last_channel()


def restore_last_channel(settings):
    """Preselect the last watched channel when this Kodi session has no guide selection yet."""
    window = xbmcgui.Window(10000)
    if window.getProperty(SELECTION_KEY):
        return
    store = account_store(settings, read_credentials(settings)[0])
    if store is None:
        return
    if not remember_last(settings):
        store.forget_last_channel()
        return
    channel = store.read_last_channel()
    if type(channel) is int:
        window.setProperty(SELECTION_KEY, json.dumps({"channel": str(channel)}))


def edit_account(settings, check=True, playing=False):
    """Open Settings; return (account changed, sign-in verified or None).

    The settings are saved before any check, so a failing check never blocks saving.
    """
    before = read_credentials(settings)
    settings.openSettings()
    after = read_credentials(settings)
    if not remember_last(settings):
        for username in {before[0], after[0]}:
            store = account_store(settings, username)
            if store is not None:
                store.forget_last_channel()
    changed = after != before
    verified = None
    if changed and configured(after):
        if playing:
            notify(settings, account_text("next_start"))
        elif check:
            verified = check_sign_in(settings, after)
    before = after = None
    return changed, verified


def open_account_settings(settings, check=True, playing=False):
    return edit_account(settings, check, playing)[0]


def check_sign_in(settings, values):
    """Sign in once with freshly saved credentials and sign out again."""
    session = error = None
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        session = open_session(values[0], values[1], device_id(settings),
                               client_platform(xbmc.getCondVisibility))
        Bff(session).user_account()
    except (AuthError, PlaybackError) as caught:
        error = caught
        log_warning("Credential check failed: " + type(caught).__name__)
    finally:
        if session is not None:
            try:
                session.close()
            except AuthError:
                log_warning("Provider did not confirm sign-out after the credential check")
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    if read_credentials(settings) != values:
        return None
    if error is None:
        notify(settings, account_text("verified"))
        return True
    return show_sign_in_error(settings, error)


def sign_in_message(settings, error):
    """Return (message, offer Settings): provider explanations already name the cause."""
    details = ProviderError.from_exception(error)
    if details is not None and ((details.explained and details.code != SIGN_IN_REQUIRED)
                                or details.status >= 500):
        return details.localized(settings.getLocalizedString), False
    text = details.localized(settings.getLocalizedString) if details is not None else str(error)
    return text + " " + account_text("check_account"), True


def show_sign_in_error(settings, error):
    message, offer_settings = sign_in_message(settings, error)
    if not offer_settings:
        xbmcgui.Dialog().ok(TITLE, message)
        return False
    if not xbmcgui.Dialog().yesno(TITLE, message, nolabel=account_text("later"),
                                  yeslabel=account_text("settings")):
        return False
    return edit_account(settings)[1] is True


def logout(settings):
    """Forget the saved account locally; the device ID and account-scoped caches stay."""
    for key in ("password", "username"):
        if not settings.setSettingString(key, ""):
            raise CredentialSettingsError()
    if xbmc.getCondVisibility("Window.IsVisible(addonsettings)"):
        # Kodi applies the open dialog's queued values first; then save the cleared ones again.
        xbmc.sleep(300)
        values = getattr(settings, "getSettings", lambda: None)()
        if values is not None:
            values.setString("password", "")
            values.setString("username", "")
    window = xbmcgui.Window(10000)
    for key in (SELECTION_KEY,) + PLAYER_KEYS:
        window.clearProperty(key)
    notify(settings, account_text("signed_out"))


def ensure_playback_support(localize):
    helper = inputstreamhelper.Helper("mpd", drm="widevine")
    if not helper.check_inputstream():
        raise PlaybackSupportError("InputStream Adaptive or Widevine is unavailable.")
    ensure_widevine(
        helper, load_widevine_config, xbmc.getCondVisibility("System.Platform.Windows"),
        lambda message: xbmcgui.Dialog().yesno(TITLE, message), localize)


def menu(handle):
    german = xbmc.getLanguage(xbmc.ISO_639_1) == "de"
    for label, route in (("TV-Guide" if german else "TV Guide", "guide"),
                         ("Einstellungen" if german else "Settings", "settings")):
        item = xbmcgui.ListItem(label=label)
        item.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle, build_url(route), item, isFolder=False)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def prepare_guide_anchor(monitor, after_playback=False):
    deadline = time.monotonic() + 10
    root = sys.argv[0].rstrip("/")
    anchor = build_url("recovery")

    def ready(window):
        return (not after_playback or
                (window == VIDEOS_WINDOW and not xbmc.getCondVisibility("Player.HasMedia")))

    while not monitor.abortRequested() and time.monotonic() < deadline:
        window = xbmcgui.getCurrentWindowId()
        folder = xbmc.getInfoLabel("Container.FolderPath")
        if ready(window) and xbmcgui.getCurrentWindowDialogId() in (0, 9999):
            if folder.rstrip("/") == anchor:
                return True
            if folder.rstrip("/") == root:
                xbmc.executebuiltin('Container.Update("{}",replace)'.format(anchor))
                break
        if monitor.waitForAbort(0.05):
            return False
    else:
        xbmc.log("[Magenta TV AT] Guide launch cancelled: menu did not become active", xbmc.LOGWARNING)
        return False
    while not monitor.abortRequested() and time.monotonic() < deadline:
        if (xbmcgui.getCurrentWindowId() == window and ready(window)
                and xbmc.getInfoLabel("Container.FolderPath") == anchor
                and xbmcgui.getCurrentWindowDialogId() in (0, 9999)):
            return True
        if monitor.waitForAbort(0.05):
            return False
    xbmc.log("[Magenta TV AT] Guide launch cancelled: recovery menu did not become active", xbmc.LOGWARNING)
    return False


class Player(xbmc.Player):
    def __init__(self, timing=None):
        super().__init__()
        self.started = False
        self._ended = False
        self.failed = False
        self.timing = timing
        self.direct_url = None

    def _playing_direct(self):
        try:
            return self.isPlayingVideo() and self.getPlayingFile() == self.direct_url
        except RuntimeError:
            return False

    @property
    def finished(self):
        # Kodi broadcasts callbacks. A late stop for A must not stop a playing B.
        return self.failed or (self._ended and (self.direct_url is None or not self._playing_direct()))

    def onAVStarted(self):
        if self.direct_url is not None and not self._playing_direct():
            return
        if self.timing is not None and not self.started:
            self.timing.mark("AV started")
        self.started = True

    def onPlayBackStopped(self):
        if self.started:
            self._ended = True

    def onPlayBackEnded(self):
        if self.started:
            self._ended = True

    def onPlayBackError(self):
        self.failed = True


def list_item(url, drm, title, logo=None):
    item = xbmcgui.ListItem(path=url, offscreen=True)
    item.setInfo("video", {"title": title})
    icon = xbmcaddon.Addon(ADDON_ID).getAddonInfo("icon")
    item.setArt({"icon": logo or icon, "thumb": logo or icon})
    item.setMimeType("application/dash+xml")
    item.setContentLookup(False)
    item.setProperty("inputstream", "inputstream.adaptive")
    item.setProperty("inputstream.adaptive.drm_legacy", drm)
    return item


def session_for(settings, monitor):
    values = read_credentials(settings)
    if not configured(values):
        xbmcgui.Dialog().ok(TITLE, account_text("not_configured"))
        edit_account(settings, check=False)
        values = read_credentials(settings)
        if monitor.abortRequested() or not configured(values):
            raise CredentialsCancelled()
    username, password = values
    values = None
    try:
        session = open_session(username, password, device_id(settings),
                               client_platform(xbmc.getCondVisibility))
        session.guide_cache_username = username
        return session
    finally:
        username = password = None


def close_session(session):
    try:
        session.close()
        return True
    except AuthError as error:
        xbmc.log("[Magenta TV AT] " + str(error), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(TITLE, "The provider did not confirm sign-out.")
        return False


def playback_guard(settings, monitor):
    profile = xbmcvfs.translatePath(settings.getAddonInfo("profile"))
    if not xbmcvfs.exists(profile) and not xbmcvfs.mkdirs(profile):
        raise PlaybackError("The add-on profile is unavailable.")
    switch_path = os.path.join(profile, "playback.switch")
    guard = PlaybackGuard(os.path.join(profile, "playback.lock"),
                          on_busy=lambda: request_switch(switch_path), timeout=30,
                          aborted=monitor.abortRequested)
    return guard, switch_path


def remember_guide_channel(channel):
    window = xbmcgui.Window(10000)
    key = "magentatv_at_t.guide.selection.local"
    try:
        selection = json.loads(window.getProperty(key) or "{}")
    except (TypeError, ValueError):
        selection = {}
    if not isinstance(selection, dict):
        selection = {}
    now = time.time()
    view, anchor = selection.get("view"), selection.get("anchor")
    future_view = isinstance(view, (int, float)) and view > now
    future_anchor = isinstance(anchor, (int, float)) and anchor > now
    if selection.get("channel") != channel or future_view or future_anchor:
        selection.update(channel=channel, programme_id="", programme_start=None)
        if future_view:
            selection.pop("view", None)
        if future_view or future_anchor:
            selection.pop("anchor", None)
    window.setProperty(key, json.dumps(selection))


def focus_played_selection(number, airing):
    # A guide opened during playback may have saved an unrelated channel or date.
    state = {"channel": str(number)}
    if airing is not None:
        state.update(view=airing.start, anchor=airing.start)
        if isinstance(airing, Airing):
            state.update(programme_id=airing.programme, programme_start=airing.start)
    xbmcgui.Window(10000).setProperty(SELECTION_KEY, json.dumps(state))


def remember_playing_channel(channel):
    window = xbmcgui.Window(10000)
    current_key = "magentatv_at_t.player.current"
    previous_key = "magentatv_at_t.player.previous"
    current = window.getProperty(current_key)
    previous = window.getProperty(previous_key)
    value = str(channel)
    if current != value:
        previous = current
        window.setProperty(previous_key, previous)
        window.setProperty(current_key, value)
    return int(previous) if isinstance(previous, str) and previous.isascii() and previous.isdigit() else None


class GuideBackend:
    def __init__(self, credentials=None, session=None, owns_session=True):
        self.credentials = credentials
        self.session = session
        self.api = Bff(session) if session is not None else None
        self.lock = threading.Lock()
        self.owns_session = owns_session

    def _api(self):
        if self.api is None:
            if self.credentials is None:
                raise LiveDataError("Account and password are required to refresh the guide.")
            username, password, identity = self.credentials
            session = None
            try:
                session = open_session(username, password, identity,
                                       client_platform(xbmc.getCondVisibility))
                api = Bff(session)
                api.user_account()
                self.session = session
                self.api = api
                self.credentials = None
            except (AuthError, PlaybackError) as error:
                if session is not None:
                    try:
                        session.close()
                    except AuthError:
                        xbmc.log("[Magenta TV AT] Provider did not confirm guide sign-out", xbmc.LOGWARNING)
                raise LiveDataError(ProviderError.from_exception(error)
                                    or "Could not sign in to refresh the guide.") from None
        return self.api

    def schedules(self, date, offset):
        with self.lock:
            return self._api().schedules(date, offset)

    def channels(self):
        with self.lock:
            api = self._api()
            return guide_channels(api.subscriptions(), api.channel_feed())

    def program_details(self, program_id):
        with self.lock:
            return self._api().program_details(program_id)

    def replay_offer(self, airing, cancelled):
        with self.lock:
            if cancelled():
                return None
            api = self._api()
            if cancelled() or not opted_in(api.replay_consents()) or cancelled():
                return None
            return replay_offer(api.program_actions(airing.programme), airing, time.time())

    def close(self):
        with self.lock:
            if self.session is not None and self.owns_session:
                close_session(self.session)
            self.session = None
            self.credentials = None


def selected_guide_channel():
    try:
        state = json.loads(xbmcgui.Window(10000).getProperty(SELECTION_KEY) or "{}")
    except (TypeError, ValueError):
        return None
    channel = state.get("channel") if isinstance(state, dict) else None
    return channel if isinstance(channel, str) and channel else None


def show_guide(settings, monitor, report_view=None, owned_playback=None, should_close=None,
               session=None, playback_actions=None):
    """Show the guide; reopen it for the new account when Settings changed the credentials."""
    expected = None
    while True:
        result = guide_once(settings, monitor, report_view, owned_playback, should_close,
                            session, playback_actions, expected)
        if not (isinstance(result, tuple) and result[0] == "settings_changed"):
            return result
        expected = result[1]


def guide_once(settings, monitor, report_view, owned_playback, should_close, session,
               playback_actions, expected):
    profile = xbmcvfs.translatePath(settings.getAddonInfo("profile"))
    if session is not None:
        username = getattr(session, "guide_cache_username", None)
        password = None
    else:
        username, password = read_credentials(settings)
    log = lambda message: xbmc.log("[Magenta TV AT] " + message, xbmc.LOGWARNING)
    store = GuideStore(profile, username, log) if isinstance(username, str) and username.strip() else None
    channels = store.read_channels() if store is not None else None
    backend = None
    channel_worker = None
    channel_result = []
    channel_retry_at = 0
    channel_status = ""
    after_settings = {"force": False, "check": None}
    reopen = []
    artwork = channel_artwork(profile, log, xbmcvfs.translatePath)
    try:
        if channels is None:
            owns_session = session is None
            session = session if session is not None else session_for(settings, monitor)
            backend = GuideBackend(session=session, owns_session=owns_session)
            backend.api.user_account()
            channels = backend.channels()
            username = getattr(session, "guide_cache_username", None)
            store = GuideStore(profile, username, log) if isinstance(username, str) and username.strip() else None
            if store is not None:
                store.write_channels(channels)
            channel_retry_at = time.monotonic() + CHANNEL_SECONDS
        else:
            credentials = ((username, password, device_id(settings))
                           if session is None and isinstance(password, str) and password else None)
            backend = GuideBackend(credentials=credentials, session=session, owns_session=session is None)
        password = None
        cache = GuideCache(backend, channels, store=store)
        details = ProgrammeDetails(backend, store=store)
        names = {str(channel.number): channel.title for channel in channels}
        numbers = {str(channel.number): channel.number for channel in channels}
        logos = {str(channel.number): channel.logo for channel in channels}
        if expected is not None and expected[0] not in names:
            notify(settings, account_text("channel_gone").format(expected[1]))

        def channel_label(channel):
            title = names.get(channel)
            return "{} {}".format(channel, title) if title else channel

        def guide_settings():
            channel = selected_guide_channel()
            label = channel_label(channel) if channel else None
            if owned_playback is not None:
                edit_account(settings, check=False, playing=True)
            else:
                changed, verified = edit_account(settings)
                if changed and verified is False:
                    return False
                if changed:
                    reopen.append((channel, label) if channel else None)
                    return True
            after_settings.update(force=True, check=(channel, label) if channel else None)
            return False

        def lookup_replay(key, cancelled):
            channel, program_id, start, stop = key
            with cache.lock:
                station = cache.channels.get(channel)
            if station is None or not station.station_id:
                return None
            airing = Airing(station.number, station.station_id, program_id, int(start), int(stop))
            return backend.replay_offer(airing, cancelled)

        def refresh_channels():
            nonlocal channel_worker, channel_retry_at, channel_status
            if channel_result:
                updated = channel_result.pop()
                channel_worker.join()
                channel_worker = None
                if updated is not None and not isinstance(updated, ProviderError):
                    names.clear()
                    names.update({str(channel.number): channel.title for channel in updated})
                    numbers.clear()
                    numbers.update({str(channel.number): channel.number for channel in updated})
                    logos.clear()
                    logos.update({str(channel.number): channel.logo for channel in updated})
                    cache.update_channels(updated)
                    channel_retry_at = time.monotonic() + CHANNEL_SECONDS
                    channel_status = ""
                    check, after_settings["check"] = after_settings["check"], None
                    if check is not None and check[0] not in names:
                        notify(settings, account_text("channel_gone").format(check[1]))
                    return list(names), channel_status
                after_settings["check"] = None
                channel_retry_at = time.monotonic() + 300
                channel_status = updated or "error"
                return list(names), channel_status
            if channel_worker is None and (after_settings["force"] or (
                    time.monotonic() >= channel_retry_at
                    and (store is None or not store.channels_fresh()))):
                after_settings["force"] = False
                def refresh():
                    try:
                        updated = backend.channels()
                        if not monitor.abortRequested():
                            if store is not None:
                                store.write_channels(updated)
                            channel_result.append(updated)
                        else:
                            channel_result.append(None)
                    except (AuthError, PlaybackError, LiveDataError, OSError, RuntimeError,
                            ValueError, TypeError) as error:
                        details = ProviderError.from_exception(error)
                        log("Could not refresh guide channels" + (": " + str(details) if details else ""))
                        channel_result.append(details)
                channel_worker = threading.Thread(target=refresh, name="magenta-channels", daemon=True)
                channel_worker.start()
            return list(names), channel_status

        result = open_guide(
            list(names), cache.peek, cache.load, names.get,
            settings.getAddonInfo("path"),
            log,
            "local", None, open_settings=guide_settings,
            timeshift_denied=lambda channel: True, monitor=monitor,
            report_view=report_view, refresh_channels=refresh_channels,
            needs_refresh=cache.needs_refresh, owned_playback=owned_playback,
            mini_picture=lambda: settings.getSetting("guide_mini_picture") != "false",
            should_close=should_close, playback_actions=playback_actions,
            peek_branding=lambda: {channel: (None, logo) for channel, logo in logos.items() if logo},
            peek_details=details.peek, load_details=details.load, lookup_replay=lookup_replay,
            localize=settings.getLocalizedString, channel_numbers=numbers,
            addon_enabled=addon_enabled, artwork=artwork,
        )
        if result is None:
            return None
        if result == "settings_changed":
            return "settings_changed", reopen[-1] if reopen else None
        if owned_playback is not None and isinstance(result, dict) and result.get("owned_window") is True:
            return "return"
        channel = result.get("channel") if isinstance(result, dict) else None
        if not isinstance(channel, str) or channel not in names:
            raise PlaybackError("The guide returned an invalid channel selection.")
        if set(result) == {"channel", "catchup"}:
            airing = result["catchup"]
            if not isinstance(airing, Airing) or str(airing.number) != channel:
                raise PlaybackError("The guide returned an invalid Replay selection.")
            return airing
        if set(result) == {"channel", "start_over"}:
            start = result["start_over"]
            if type(start) is not int or start < 0:
                raise PlaybackError("The guide returned an invalid restart selection.")
            return StartOver(numbers[channel], start)
        if set(result) != {"channel"}:
            raise PlaybackError("The guide returned an invalid channel selection.")
        return channel
    except RuntimeError as error:
        raise PlaybackError("The programme guide could not be opened.") from error
    finally:
        artwork.close()
        if channel_worker is not None:
            channel_worker.join()
        if backend is not None:
            backend.close()


def main():
    handle = int(sys.argv[1])
    query = parse_qs(sys.argv[2].lstrip("?"), keep_blank_values=True) if len(sys.argv) > 2 else {}
    settings = xbmcaddon.Addon(ADDON_ID)
    monitor = xbmc.Monitor()
    resolved = False
    directory_done = False
    try:
        mode = query.get("mode")
        if not query or (mode == ["recovery"] and len(query) == 1):
            if handle < 0:
                xbmc.executebuiltin('ActivateWindow(Videos,"{}",return)'.format(sys.argv[0]))
                return
            menu(handle)
            directory_done = True
            if not query:
                xbmc.executebuiltin('RunPlugin("{}")'.format(build_url("guide-start")))
            return
        if mode and len(query) == 1 and len(mode) == 1 and mode[0] in (
                "guide", "guide-start", "settings", "about", "logout"):
            if handle >= 0:
                menu(handle)
                directory_done = True
                return
            if mode[0] == "settings":
                open_account_settings(settings)
                return
            if mode[0] == "logout":
                logout(settings)
                return
            if mode[0] == "about":
                xbmcgui.Dialog().textviewer(
                    settings.getLocalizedString(32005),
                    "\n\n".join(settings.getLocalizedString(label) for label in (32006, 32007, 32008, 32009)))
                return
            if mode[0] == "guide-start" and not prepare_guide_anchor(monitor):
                return
            restore_last_channel(settings)
            guard, switch_path = playback_guard(settings, monitor)
            with guard:
                clear_switch(switch_path)
                selection = show_guide(settings, SwitchingMonitor(monitor, switch_path))
            if selection is not None:
                url = playback_url(selection, from_guide=True)
                xbmc.executebuiltin('PlayMedia("{}")'.format(url))
            return
        from_guide = query.get("origin") == ["guide"]
        if from_guide:
            del query["origin"]
        if (set(query) not in ({"channel"}, {"channel", "start_over"},
                               {"channel", "replay", "station", "start", "stop"})
                or any(len(values) != 1 for values in query.values())):
            raise PlaybackError("Invalid channel selection.")
        raw = query["channel"][0]
        if not raw.isascii() or not raw.isdigit() or len(raw) > 9:
            raise PlaybackError("Invalid channel selection.")
        number = int(raw)
        replay = None
        start_over = None
        if "replay" in query:
            stamps = [query[field][0] for field in ("start", "stop")]
            if not all(s.isascii() and s.isdigit() and len(s) <= 12 for s in stamps):
                raise PlaybackError("Invalid Replay airing.")
            replay = Airing(number, query["station"][0], query["replay"][0], *map(int, stamps))
        if "start_over" in query:
            stamp = query["start_over"][0]
            if not (stamp.isascii() and stamp.isdigit() and len(stamp) <= 12):
                raise PlaybackError("Invalid restart selection.")
            start_over = StartOver(number, int(stamp))
        german = xbmc.getLanguage(xbmc.ISO_639_1) == "de"
        guard, switch_path = playback_guard(settings, monitor)
        with guard:
            clear_switch(switch_path)
            monitor = SwitchingMonitor(monitor, switch_path)
            ensure_playback_support(settings.getLocalizedString)
            profile = xbmcvfs.translatePath(settings.getAddonInfo("profile"))
            artwork = channel_artwork(profile, lambda msg: xbmc.log("[Magenta TV AT] " + msg, xbmc.LOGWARNING),
                                      xbmcvfs.translatePath)
            sources = {}
            def logo_for(channel):
                station = sources.get(channel)
                return artwork.get(station.logo) if station else None

            def prepare_artwork(subscriptions, feed):
                try:
                    sources.update((c.number, c) for c in guide_channels(subscriptions, feed))
                except PlaybackError:
                    xbmc.log("[Magenta TV AT] Station artwork unavailable from channel feed.", xbmc.LOGWARNING)
                    return
                logo_for(number)

            def schedule_store():
                username = getattr(session, "guide_cache_username", None)
                if not isinstance(username, str) or not username.strip():
                    return None
                return GuideStore(profile, username,
                                  lambda msg: xbmc.log("[Magenta TV AT] " + msg, xbmc.LOGWARNING))

            schedule = CachedSchedule(schedule_store, sources.get)
            cache = LiveInputs()
            def timing_log(message):
                xbmc.log("[Magenta TV AT] Timing channel {}: {}".format(number, message), xbmc.LOGINFO)

            timing = TuneTiming(timing_log)
            session = None
            controls = None
            try:
                session = timing.measure("sign-in", session_for, settings, monitor)
                reused = False
                live_window = replay is None and start_over is None

                def renew_session():
                    nonlocal session
                    cache.clear()
                    previous, session = session, None
                    if not timing.measure("sign-out", close_session, previous):
                        raise CredentialsCancelled()  # close_session already notified the user
                    if monitor.abortRequested():
                        raise PlaybackError("Playback was cancelled.")
                    session = timing.measure("fresh sign-in", session_for, settings, monitor)
                    return session

                def resolve(item):
                    nonlocal resolved
                    if not resolved:
                        xbmcplugin.setResolvedUrl(handle, True, item)
                        resolved = True
                    else:
                        # The original plug-in handle is already resolved; use Kodi's native player.
                        player.direct_url = item.getPath()
                        if controls is not None and controls.between_channels:
                            controls.expect_native_start(player)
                        player.play(player.direct_url, item, True)  # existing full-size videowindow

                def make_controls(player, owns, channel, channels, live_window=None):
                    nonlocal controls
                    remember_watched_channel(settings, getattr(session, "guide_cache_username", None),
                                             channel)
                    last_channel = remember_playing_channel(channel)
                    if controls is None:
                        controls = OwnedPlayerWindow(
                            player, owns, channel, channels, settings, profile, last_channel=last_channel,
                            is_replay=replay is not None, logo_for=logo_for, schedule_for=schedule.rows,
                            live_window=live_window)
                    else:
                        controls.bind(player, owns, channel, channels, last_channel,
                                      live_window=live_window)
                    return controls

                def playback_settings():
                    edit_account(settings, check=False, playing=True)
                    return True

                def open_owned_guide(player, owns, should_close):
                    nonlocal from_guide
                    remember_guide_channel(str(number))
                    selection = show_guide(
                        settings, monitor, owned_playback={
                            "player": player, "matches": owns, "owned_window": True,
                        }, should_close=should_close, session=session,
                        playback_actions=lambda: (
                            str(controls.last_channel) if controls.last_channel is not None else None,
                            controls._live_target()))
                    if selection not in (None, "return") and (replay is not None or selection != str(number)):
                        from_guide = True
                    return selection

                prefix = "Replay: " if replay is not None else "Start over: "
                def eligible():
                    return session.can_continue(*read_credentials(settings),
                                                settings.getSettingString("device_id"), timing.selected) is True

                while True:
                    player = Player(timing)
                    next_channel = play_channel(
                        session, number, player, monitor, resolve,
                        lambda url, drm, title: list_item(url, drm, title, logo_for(number)),
                        plugin_url=None if resolved else sys.argv[0] + sys.argv[2],
                        make_controls=make_controls, show_owned_guide=open_owned_guide,
                        replay=replay, report=(lambda event: xbmc.log("[Magenta TV AT] " + prefix + event,
                                                                      xbmc.LOGINFO))
                        if replay is not None or start_over is not None else None,
                        start_over=start_over.start if start_over is not None else None,
                        open_settings=playback_settings,
                        notify=lambda key: notify(settings, GUIDE_TEXT[german][key]),
                        license_log=lambda line: xbmc.log("[Magenta TV AT] " + line, xbmc.LOGINFO),
                        open_manifest=xbmcvfs.File, prepare_artwork=prepare_artwork,
                        cache=cache, renew_session=renew_session if reused else None, timing=timing,
                        persist_live_window=live_window,
                        waiting_for_channel=controls.waiting_for_channel if controls is not None else None,
                    )
                    if monitor.abortRequested():
                        next_channel = None
                        break
                    if (type(next_channel) is not int or replay is not None or start_over is not None
                            or timing.selected is None):
                        break
                    # Keep the guard and the only login owner. Never overlap native players.
                    while (not player.finished and not monitor.abortRequested()
                           and time.monotonic() - timing.selected < SWITCH_SECONDS):
                        monitor.waitForAbort(0.05)
                    if monitor.abortRequested():
                        next_channel = None
                        break
                    if player.isPlaying() or not player.finished:
                        raise PlaybackError("Kodi did not confirm the previous channel stopped.")
                    reused = eligible()
                    number = next_channel
                    sources.clear()
                    timing = TuneTiming(timing_log, timing.selected)
                    if reused:
                        timing.mark("reusing signed-in session")
                    else:
                        renew_session()
            finally:
                try:
                    try:
                        if controls is not None and live_window:
                            controls.close(aborted=application_aborted(monitor))
                    finally:
                        session_closed = session is not None and timing.measure("sign-out", close_session, session)
                finally:
                    cache.clear()
                    artwork.close()
            # Stop and EOF both return None. Stay under the switching guard while
            # the player window unwinds; never navigate back from another Kodi menu.
            if (from_guide and next_channel is None and session_closed and not monitor.abortRequested()
                    and prepare_guide_anchor(monitor, after_playback=True)):
                focus_played_selection(number, replay or start_over)
                next_channel = show_guide(settings, monitor)
            if monitor.abortRequested():
                next_channel = None
        if next_channel is not None and session_closed and not monitor.abortRequested():
            if next_channel == "guide":
                remember_guide_channel(str(number))
                xbmc.executebuiltin('ActivateWindow(Videos,"{}",return)'.format(build_url("recovery")))
                xbmc.executebuiltin('RunPlugin("{}")'.format(build_url("guide-start")))
            else:
                url = playback_url(next_channel, from_guide=from_guide)
                xbmc.executebuiltin('PlayMedia("{}")'.format(url))
    except CredentialsCancelled:
        pass
    except CredentialSettingsError:
        xbmcgui.Dialog().ok(TITLE, "Could not read or save the add-on settings.")
    except AuthError as error:
        show_sign_in_error(settings, error)
    except PlaybackSupportError as error:
        xbmc.log("[Magenta TV AT] Playback failed: " + str(error), xbmc.LOGWARNING)
        text = GUIDE_TEXT[xbmc.getLanguage(xbmc.ISO_639_1) == "de"]["playback_error"]
        xbmcgui.Dialog().notification(TITLE, text, settings.getAddonInfo("icon"), 5000)
    except PlaybackError as error:
        details = ProviderError.from_exception(error)
        xbmcgui.Dialog().ok(TITLE, details.localized(settings.getLocalizedString) if details else str(error))
    finally:
        if "channel" in query and not resolved and handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        elif handle >= 0 and not directory_done and "channel" not in query:
            xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


if __name__ == "__main__":
    main()
