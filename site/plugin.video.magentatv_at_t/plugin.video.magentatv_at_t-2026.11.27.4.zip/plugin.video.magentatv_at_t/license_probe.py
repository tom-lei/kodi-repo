"""Loopback-only Widevine request relay with status and licence-metadata diagnostics."""

import json
import re
import secrets
import socket
import threading
from contextlib import ExitStack
from http.client import HTTPException
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlsplit
from urllib.request import Request

from dash_video import licensed_pixel_limit
from license_metadata import inspect_license
from kodi_http import ProxySettingsError, local_relay_route, open_provider
from magenta_experiment import _BROWSER_USER_AGENT
from magenta_playback import PlaybackError


_MAX_BODY = 5 * 1024 * 1024
_MAX_ERROR_BODY = 65536
_CLIENT_TIMEOUT = 5
_HANDLER_SHUTDOWN_TIMEOUT = 6
_LICENSE_PATH = "/wv/web/ModularDrm/getRawWidevineLicense"
_ACCOUNT_PREFIX = "http://access.auth.theplatform.com/data/Account/"


_URL_TEXT = re.compile(r"\b[a-z][a-z0-9+.-]*://\S+", re.I)
_EMAIL_TEXT = re.compile(r"\S+@\S+")
_WORD = re.compile(r"[A-Za-z0-9+/=_-]+")
_CAMEL = re.compile(r"[A-Z]?[a-z]+(?:[A-Z][a-z]+)*\Z")
_UNSAFE_CHARS = re.compile(r"[^A-Za-z0-9_ .,:;'()\[\]-]+")
_STATUS_NAME = re.compile(r"[A-Z]{2,}(?:_[A-Z]{2,})*\Z")


def _redact_word(match):
    word = match.group(0)
    if len(word) <= 48 and _STATUS_NAME.match(word):
        return word
    if len(word) >= 24 or (len(word) >= 6 and re.search(r"[0-9+/=_]", word)):
        return "[redacted]"
    if len(word) >= 8 and re.search(r"[A-Z]", word) and not _CAMEL.match(word) and not word.isupper():
        return "[redacted]"
    return word


def safe_error_text(value, limit):
    """Return a short, character-allowlisted description with likely identifiers removed."""
    if not isinstance(value, str):
        return None
    text = _URL_TEXT.sub("[url]", value[:4096])
    text = _EMAIL_TEXT.sub("[email]", text)
    text = _WORD.sub(_redact_word, text)
    text = " ".join(_UNSAFE_CHARS.sub(" ", text).split())[:limit].strip()
    return text or None


def _content_category(content_type):
    kind = (content_type or "").partition(";")[0].strip().lower()
    if kind.endswith("json"):
        return "json"
    if kind == "text/plain":
        return "text"
    if kind == "text/html":
        return "html"
    if kind == "application/octet-stream":
        return "octet-stream"
    if kind.endswith("protobuf"):
        return "protobuf"
    return "none" if not kind else "other"


def _error_diagnostics(data, content_type):
    kind = (content_type or "").partition(";")[0].strip().lower()
    events = ["licence error content type: " + _content_category(content_type)]
    try:
        text = data.decode("utf-8")
        body = json.loads(text)
    except UnicodeError:
        events.append("licence error details unrecognized")
        return events
    except ValueError:
        message = safe_error_text(text, 200) if kind in ("text/plain", "") else None
        events.append("licence error message: " + message if message
                      else "licence error details unrecognized")
        return events
    if not isinstance(body, dict):
        events.append("licence error details unrecognized")
        return events
    recognized = False
    for name, label in (("errorCode", "code"), ("responseCode", "responseCode")):
        code = body.get(name)
        if isinstance(code, int) and not isinstance(code, bool) and 0 <= code <= 9999:
            events.append("licence error {} {}".format(label, code))
            recognized = True
    if isinstance(body.get("isException"), bool):
        events.append("licence error isException: " + ("true" if body["isException"] else "false"))
        recognized = True
    for name, limit in (("title", 80), ("description", 200), ("message", 200), ("error", 80)):
        text = safe_error_text(body.get(name), limit)
        if text:
            events.append("licence error {}: {}".format(name, text))
            recognized = True
    if not recognized:
        events.append("licence error details unrecognized")
    return events


class LicenseProbe:
    def __init__(self, drm_config, report, opener=None, on_failure=None, license_log=None,
                 video_ladder=()):
        try:
            system, url, encoded_headers = drm_config.split("|")
            parts = urlsplit(url)
            parsed_headers = parse_qsl(encoded_headers, strict_parsing=True)
            headers = dict(parsed_headers)
            query = parse_qsl(parts.query, strict_parsing=True)
            params = dict(query)
            if (system != "com.widevine.alpha" or parts.scheme != "https"
                    or parts.hostname != "widevine.entitlement.theplatform.eu"
                    or parts.port not in (None, 443) or parts.path != _LICENSE_PATH
                    or parts.username is not None or parts.password is not None or parts.fragment
                    or "\\" in url or any(ord(char) < 32 for char in url)
                    or len(query) != 4
                    or set(params) != {"schema", "releasePid", "token", "account"}
                    or params["schema"] != "1.0"
                    or not params["releasePid"] or not params["token"]
                    or not params["account"].startswith(_ACCOUNT_PREFIX)
                    or params["account"] == _ACCOUNT_PREFIX
                    or len(parsed_headers) != 4
                    or headers != {
                        "User-Agent": _BROWSER_USER_AGENT,
                        "Content-Type": "application/octet-stream",
                        "Origin": "https://tv.magenta.at",
                        "Referer": "https://tv.magenta.at/",
                    }):
                raise ValueError
        except (TypeError, ValueError):
            raise PlaybackError("The Widevine request configuration is invalid.") from None
        self._url = url
        self._headers = headers
        self._report = report
        self._license_log = license_log
        self._video_ladder = video_ladder
        self._opener = opener
        self.proxy_error = None
        self._path = "/" + secrets.token_urlsafe(32)
        self._server = None
        self._thread = None
        self._resources = ExitStack()
        self.denied_status = None
        self.failed = False
        self.in_flight = False
        self._upstream_lock = threading.Lock()
        self._on_failure = on_failure
        self._failure_cleanup_done = False
        self._failure_cleanup_lock = threading.Lock()
        self.failure_cleanup_error = False

    def _run_failure_cleanup(self):
        """Run provider cleanup before Kodi sees the failure; Kodi may hang afterwards."""
        with self._failure_cleanup_lock:
            if self._on_failure is None or self._failure_cleanup_done:
                return
            self._failure_cleanup_done = True
            try:
                self._on_failure()
            except Exception:
                self.failure_cleanup_error = True
                self._report("licence failure cleanup error")

    def _video_limit(self, data, upstream):
        """Only tighten a provider limit; leave licence bytes and all CDM checks intact."""
        match = re.search(r"\bmax=([0-9]{1,10})\b", upstream or "")
        provider = int(match[1]) if match else None
        if provider is not None and not 0 < provider <= 2147483647:
            provider = None
        if not self._video_ladder and self._license_log is None:
            return provider
        lines, content_kids = inspect_license(data)
        limit = licensed_pixel_limit(self._video_ladder, content_kids)
        if provider is not None:
            limit = min(provider, limit) if limit is not None else provider
        if limit is not None:
            lines.append("licence video limit: X-Limit-Video: max={}".format(limit))
        elif self._video_ladder and content_kids:
            lines.append("licence video limit: all video KIDs present; no header"
                         if all(kid in content_kids for _, kid in self._video_ladder)
                         else "licence video limit: no unambiguous licensed ceiling; no header")
        if self._license_log is not None:
            try:
                for line in lines:
                    self._license_log(line)
            except Exception:
                self._report("licence metadata logging failed")
        return limit

    def __enter__(self):
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def setup(self):
                super().setup()
                self.connection.settimeout(_CLIENT_TIMEOUT)

            def log_message(self, format, *args):
                pass

            def do_POST(self):
                if self.path != owner._path:
                    self.send_error(404)
                    return
                try:
                    length = int(self.headers.get("Content-Length", ""))
                except ValueError:
                    self.send_error(400)
                    return
                if length <= 0 or length > _MAX_BODY:
                    self.send_error(413)
                    return
                body = self.rfile.read(length)
                if len(body) != length:
                    self.send_error(400)
                    return
                with owner._upstream_lock:
                    if owner.failed:
                        self.send_error(502)
                        return
                    owner.in_flight = True
                    try:
                        result = self.forward(body)
                        if result is None:
                            # Clean up first: once failed is visible or Kodi sees the error,
                            # Kodi's player threads may block the interpreter.
                            owner._run_failure_cleanup()
                            owner.failed = True
                    except Exception:
                        owner._run_failure_cleanup()
                        owner.failed = True
                        raise
                    finally:
                        owner.in_flight = False
                    if result is None:
                        self.send_error(502)
                        return
                status, content_type, data, video_limit = result
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(data)))
                if video_limit is not None:
                    self.send_header("X-Limit-Video", "max={}".format(video_limit))
                self.end_headers()
                self.wfile.write(data)

            def forward(self, body):
                request = Request(owner._url, body, owner._headers, method="POST")
                try:
                    response = (owner._opener.open(request, timeout=20) if owner._opener is not None
                                else open_provider(request, direct_when_off=True))
                except ProxySettingsError as error:
                    owner.proxy_error = str(error)
                    owner._report(owner.proxy_error)
                    return None
                except HTTPError as error:
                    response = error
                except (URLError, OSError):
                    owner._report("licence transport failure")
                    return None
                with response:
                    status = response.code
                    owner._report("licence HTTP {}".format(status))
                    if not 200 <= status < 300:
                        owner.denied_status = status
                        if status >= 400:
                            try:
                                error_body = response.read(_MAX_ERROR_BODY + 1)
                                if len(error_body) <= _MAX_ERROR_BODY:
                                    for event in _error_diagnostics(
                                            error_body, response.headers.get("Content-Type")):
                                        owner._report(event)
                                else:
                                    owner._report("licence error details unrecognized")
                            except (OSError, HTTPException):
                                owner._report("licence error details unrecognized")
                        return None
                    try:
                        result = response.read(_MAX_BODY + 1)
                    except (OSError, HTTPException):
                        owner._report("licence transport failure")
                        return None
                    if len(result) > _MAX_BODY:
                        owner._report("licence response exceeded limit")
                        return None
                    owner._report("licence response content type: " + _content_category(
                        response.headers.get("Content-Type")))
                    limit = owner._video_limit(result, response.headers.get("X-Limit-Video"))
                    return status, "application/octet-stream", result, limit
        class Server(ThreadingHTTPServer):
            daemon_threads = True

            def __init__(self, *args):
                self._condition = threading.Condition()
                self._connections = set()
                self._closing = False
                super().__init__(*args)

            def process_request(self, request, client_address):
                with self._condition:
                    self._connections.add(request)
                try:
                    super().process_request(request, client_address)
                except BaseException:
                    with self._condition:
                        self._connections.discard(request)
                        self._condition.notify_all()
                    raise

            def process_request_thread(self, request, client_address):
                try:
                    super().process_request_thread(request, client_address)
                finally:
                    with self._condition:
                        self._connections.discard(request)
                        self._condition.notify_all()

            def stop_handlers(self):
                with self._condition:
                    self._closing = True
                    connections = tuple(self._connections)
                for connection in connections:
                    try:
                        connection.shutdown(socket.SHUT_RDWR)
                    except OSError:
                        pass
                with self._condition:
                    return self._condition.wait_for(
                        lambda: not self._connections, timeout=_HANDLER_SHUTDOWN_TIMEOUT
                    )

            def handle_error(self, request, client_address):
                with self._condition:
                    if self._closing:
                        return
                with owner._upstream_lock:
                    owner._run_failure_cleanup()
                    owner.failed = True
                owner._report("licence relay error")

        with ExitStack() as resources:
            if self._opener is None:  # Native Kodi playback rather than a standalone injected transport.
                try:
                    resources.enter_context(local_relay_route())
                except ProxySettingsError as error:
                    raise PlaybackError(str(error)) from None
            self._server = Server(("127.0.0.1", 0), Handler)
            resources.callback(self._server.server_close)
            self._thread = threading.Thread(target=self._server.serve_forever,
                                           kwargs={"poll_interval": 0.05}, daemon=True)
            self._thread.start()
            resources.callback(self._stop_server)
            self._resources = resources.pop_all()
        return "com.widevine.alpha|http://127.0.0.1:{}{}".format(
            self._server.server_address[1], self._path
        )

    def _stop_server(self):
        self._server.shutdown()
        self._thread.join(timeout=25)
        if not self._server.stop_handlers():
            raise PlaybackError("The local licence relay did not finish shutting down.")

    def __exit__(self, exc_type, exc_value, traceback):
        try:
            self._resources.close()
        except ProxySettingsError as error:
            raise PlaybackError(str(error)) from None
