"""Fail-closed helpers for the isolated one-channel experiment."""

import json
import math
import re
import threading
import time
from urllib.parse import quote, urlencode, urlsplit
from urllib.request import Request

from magenta_auth import AuthError, _read_with_status
from provider_error import ProviderError, provider_code


class PlaybackError(Exception):
    pass


class CleanupUnconfirmed(PlaybackError):
    pass


class LockTransportError(PlaybackError):
    def __init__(self, http_status=None, code=None):
        self.http_status = http_status if isinstance(http_status, int) and 100 <= http_status <= 599 else None
        super().__init__(ProviderError(self.http_status, code) if self.http_status else "The provider lock request failed.")


def lock_transport(url):
    try:
        status, data = _read_with_status(Request(url), limit=65536)
        body = json.loads(data.decode("utf-8"))
    except AuthError as error:
        details = ProviderError.from_exception(error)
        if details:
            raise LockTransportError(details.status, details.code) from None
        raise LockTransportError() from None
    except (UnicodeError, ValueError, RecursionError):
        raise LockTransportError() from None
    # A heartbeat denial can arrive in a successful HTTP response.
    if isinstance(body, dict):
        code = provider_code(body.get("responseCode"))
        if code is not None and code != 200:
            raise LockTransportError(status, code)
    return body


class ConcurrencyLease:
    """Own a returned lock; injected transport must reject redirects and raise PlaybackError."""

    def __init__(self, lock, client_id, natco_key, transport, clock=time.monotonic):
        self._lock = dict(lock)
        self._client_id = client_id
        self._natco_key = natco_key
        self._transport = transport
        self._clock = clock
        self._next_update = None
        self._release_attempted = False
        self.unlock_response_received = False
        self._mutex = threading.RLock()

    def _url(self, action):
        try:
            base = self._lock["concurrency_service_url"]
            parts = urlsplit(base)
            if (parts.scheme != "https"
                    or parts.hostname != "concurrency.delivery.theplatform.eu"
                    or parts.port not in (None, 443)
                    or parts.username is not None or parts.password is not None
                    or parts.query or parts.fragment or "\\" in base
                    or any(ord(char) < 32 for char in base)):
                raise ValueError
            params = {
                "_clientId": self._client_id,
                "form": "json",
                "schema": "1.0",
                "natco_key": self._natco_key,
                "_encryptedLock": self._lock["lock"],
                "_id": self._lock["lock_id"],
                "_sequenceToken": self._lock["lock_sequence_token"],
            }
            if not all(isinstance(value, str) and value for value in params.values()):
                raise ValueError
        except (KeyError, TypeError, ValueError):
            raise PlaybackError("The provider lock destination or data is not safe to use.") from None
        query = urlencode(params, quote_via=quote, safe="~!*'()")
        return base.rstrip("/") + "/web/Concurrency/" + action + "?" + query

    def _interval(self):
        interval = self._lock.get("update_lock_interval")
        if (isinstance(interval, bool) or not isinstance(interval, (int, float))
                or not math.isfinite(interval) or interval <= 0):
            raise PlaybackError("The provider lock renewal interval is invalid.")
        return interval

    def start_renewal(self):
        with self._mutex:
            if self._release_attempted:
                raise PlaybackError("The provider lock is already closed.")
            self._next_update = self._clock() + self._interval()

    def renew_if_due(self):
        with self._mutex:
            return self._renew_if_due()

    def _renew_if_due(self):
        if self._release_attempted or self._next_update is None:
            raise PlaybackError("The provider lock is not scheduled for renewal.")
        if self._clock() < self._next_update:
            return False
        response = self._transport(self._url("update"))
        if not isinstance(response, dict) or provider_code(response.get("responseCode", 200)) != 200:
            raise PlaybackError("The provider did not confirm lock renewal.")
        update = response.get("updateResponse")
        if not isinstance(update, dict):
            raise PlaybackError("The provider did not confirm lock renewal.")
        values = [update.get(name) for name in ("encryptedLock", "id", "sequenceToken")]
        if not all(isinstance(value, str) and value for value in values):
            raise PlaybackError("The provider returned incomplete lock renewal data.")
        self._lock.update(zip(("lock", "lock_id", "lock_sequence_token"), values))
        self._next_update = self._clock() + self._interval()
        return True

    def release(self):
        with self._mutex:
            return self._release()

    def _release(self):
        if self._release_attempted:
            if not self.unlock_response_received:
                raise CleanupUnconfirmed("Provider lock release is unconfirmed.")
            return
        self._release_attempted = True
        try:
            url = self._url("unlock")
        except PlaybackError:
            raise CleanupUnconfirmed("Provider lock release is unconfirmed: unsafe destination or lock data.") from None
        try:
            response = self._transport(url)
        except LockTransportError as error:
            if error.http_status is not None and 200 <= error.http_status < 300:
                raise CleanupUnconfirmed("Provider lock release is unconfirmed: no success response.") from None
            detail = "HTTP {}".format(error.http_status) if error.http_status else "request failed"
            raise CleanupUnconfirmed("Provider lock release is unconfirmed: " + detail + ".") from None
        except PlaybackError:
            raise CleanupUnconfirmed("Provider lock release is unconfirmed: request failed.") from None
        acknowledgement = response.get("unlockResponse") if isinstance(response, dict) else None
        if (not isinstance(response, dict) or provider_code(response.get("responseCode", 200)) != 200
                or not (isinstance(acknowledgement, (dict, list)) or acknowledgement)):
            raise CleanupUnconfirmed("Provider lock release is unconfirmed: no success response.")
        self.unlock_response_received = True
        self._lock.clear()


class LockedPlayback:
    """Stop the player before the single lock-release attempt on every exit.

    A hung stop request must not hold the provider lock, so release always follows
    after ``stop_timeout`` seconds; ``stop_completed`` records whether stop returned.
    """

    def __init__(self, player, lease, stop_timeout=15.0):
        self._player = player
        self._lease = lease
        self._stop_timeout = stop_timeout
        self.stop_completed = None

    def __enter__(self):
        return self._lease

    def __exit__(self, exc_type, exc_value, traceback):
        failure = []

        def stop():
            try:
                self._player.stop()
            except BaseException as error:  # reported after release
                failure.append(error)

        worker = threading.Thread(target=stop, name="magenta-player-stop", daemon=True)
        try:
            worker.start()
            worker.join(self._stop_timeout)
            self.stop_completed = not worker.is_alive()
        finally:
            self._lease.release()
        if failure:
            raise failure[0]
        if not self.stop_completed:
            raise PlaybackError("The player did not confirm stop before the timeout.")


def _kodi_seconds(value):
    if not isinstance(value, dict):
        return None
    try:
        parts = [value[name] for name in ("hours", "minutes", "seconds", "milliseconds")]
    except KeyError:
        return None
    if not all(isinstance(part, int) and not isinstance(part, bool) and part >= 0 for part in parts):
        return None
    return parts[0] * 3600 + parts[1] * 60 + parts[2] + parts[3] / 1000.0


def player_stream_events(properties):
    """Return fixed A/V events from a Kodi Player.GetProperties result."""
    events = []
    if not isinstance(properties, dict):
        return events
    video = properties.get("currentvideostream")
    if isinstance(video, dict):
        width, height = video.get("width"), video.get("height")
        if (isinstance(width, int) and isinstance(height, int) and not isinstance(width, bool)
                and not isinstance(height, bool) and 10 <= width <= 99999 and 10 <= height <= 99999):
            events.append("JSON-RPC video stream present")
            events.append("JSON-RPC video {}x{}".format(width, height))
        codec = video.get("codec")
        if isinstance(codec, str) and re.fullmatch(r"[a-z0-9_.-]{1,24}", codec):
            events.append("JSON-RPC video codec " + codec)
    audio = properties.get("currentaudiostream")
    if isinstance(audio, dict):
        channels = audio.get("channels")
        if isinstance(channels, int) and not isinstance(channels, bool) and 1 <= channels <= 99:
            events.append("JSON-RPC audio stream present")
            events.append("JSON-RPC audio channels {}".format(channels))
        codec = audio.get("codec")
        if isinstance(codec, str) and re.fullmatch(r"[a-z0-9_.-]{1,24}", codec):
            events.append("JSON-RPC audio codec " + codec)
    return events


def player_seconds(properties):
    if not isinstance(properties, dict) or properties.get("speed") not in (0, 1):
        return None
    return _kodi_seconds(properties.get("time"))


def entitled_live_media(playinfo):
    """Return the website's first live media item only with explicit rights."""
    try:
        catalog = playinfo["catalogInfoResponse"]
        playback = playinfo["playBackInfoResponse"]
        allowed = catalog["is_subscribe"] is True
        denied_fields = (
            "is_geo_blocked", "is_device_not_compatible", "is_blackout",
            "is_adult", "is_restricted", "is_audio",
        )
        allowed = allowed and all(catalog[field] is False for field in denied_fields)
        if catalog.get("allowed_platforms"):
            raise PlaybackError("Platform-specific playback rights require verification.")
        media_id = playback["service_items"][0]["media_id"]
    except (KeyError, TypeError, IndexError):
        raise PlaybackError("The provider did not return complete playback rights.") from None
    if not allowed:
        raise PlaybackError("The channel is not explicitly available for this test.")
    if not isinstance(media_id, str) or not media_id:
        raise PlaybackError("The provider did not return a live media item.")
    return media_id
