"""Export only fixed diagnostic events from a disposable Kodi test."""

import json
import re
import sys


_EVENTS = {
    "service started", "account dialog ready", "password dialog ready",
    "cancelled before sign-in", "credentials incomplete", "credential settings unavailable",
    "sign-in succeeded", "subscribed channel found",
    "playinfo rights accepted", "requesting media; lock outcome may be unknown if interrupted",
    "starting player", "Kodi video player started", "Kodi fullscreen active",
    "Kodi fullscreen unconfirmed", "Kodi foreground", "Kodi not foreground",
    "Kodi foreground unverified", "playback ready for observation",
    "observation window started", "observation acknowledgement timed out",
    "diagnostic time limit reached", "Kodi fullscreen timed out",
    "Kodi playback started callback", "Kodi AV started callback",
    "player clock advanced", "Kodi reports an audio stream",
    "Kodi playback error callback", "Kodi playback stopped callback",
    "Kodi playback ended callback", "Kodi shutdown requested",
    "observation time expired", "renewal response received",
    "unlock response received", "lock release unconfirmed",
    "logout HTTP success", "logout unconfirmed", "service finished",
    "licence transport failure", "licence response exceeded limit",
    "licence response header invalid", "licence relay error",
    "licence denied or redirected",
    "licence error details unrecognized",
    "early cleanup after licence failure", "licence failure cleanup error",
    "JSON-RPC time advanced", "JSON-RPC video stream present",
    "JSON-RPC audio stream present", "JSON-RPC player properties unavailable",
    "stopped: The player did not confirm stop before the timeout.",
    "live input source: media", "live input source: feed",
    "feed channel inputs accepted",
    "stopped: Unknown live input source.",
    "stopped: The channel list was invalid.",
    "stopped: The channel list did not contain exactly one requested channel.",
    "stopped: The channel list did not contain a usable DASH manifest.",
    "stopped: The channel list did not contain a usable release ID.",
    "stopped: Kodi did not start the video player.",
    "stopped: The test was cancelled.",
    "stopped: The subscribed ORF 1 channel was not found.",
    "stopped: The channel is not explicitly available for this test.",
    "stopped: The provider did not return complete playback rights.",
    "cleanup unconfirmed: Provider lock release is unconfirmed: no success response.",
    "cleanup unconfirmed: Provider lock release is unconfirmed: request failed.",
    "cleanup unconfirmed: Provider lock release is unconfirmed: unsafe destination or lock data.",
}
_HTTP_EVENT = re.compile(r"licence HTTP [1-5][0-9]{2}\Z")
_LICENCE_ERROR_CODE = re.compile(r"licence error code (?:0|[1-9][0-9]{0,3})\Z")
_UNLOCK_HTTP = re.compile(r"cleanup unconfirmed: Provider lock release is unconfirmed: HTTP [1-5][0-9]{2}\.\Z")
_PROVIDER_HTTP = re.compile(
    r"stopped: (?:(?:(?:The provider API request failed|Sign-in request): )?The provider returned HTTP [1-5][0-9]{2}"
    r"|Magenta error (?:0|[1-9][0-9]{0,3}) \(HTTP [1-5][0-9]{2}\))\.\Z")
_FEED_COMPARISON = re.compile(
    r"feed (?:PID matches media PID|manifest host matches media|manifest path matches media): "
    r"(?:yes|no|unavailable)\Z")
_LICENCE_DETAIL = re.compile(
    r"licence (?:error|response) (?:content type: (?:json|text|html|octet-stream|protobuf|none|other)"
    r"|responseCode (?:0|[1-9][0-9]{0,3})|isException: (?:true|false)"
    r"|(?:title|error): [A-Za-z0-9_ .,:;'()\[\]-]{1,80}"
    r"|(?:description|message): [A-Za-z0-9_ .,:;'()\[\]-]{1,200})\Z")
_PLAYER_DETAIL = re.compile(
    r"JSON-RPC (?:video [1-9][0-9]{1,4}x[1-9][0-9]{1,4}|audio channels [1-9][0-9]?"
    r"|(?:video|audio) codec [a-z0-9_.-]{1,24})\Z")


def sanitize_events(events):
    if not isinstance(events, list):
        raise ValueError("Invalid diagnostic event list")
    result = []
    for event in events:
        if isinstance(event, str) and (
                event in _EVENTS or _HTTP_EVENT.fullmatch(event) or _LICENCE_ERROR_CODE.fullmatch(event)
                or _UNLOCK_HTTP.fullmatch(event)
                or _PROVIDER_HTTP.fullmatch(event)
                or _FEED_COMPARISON.fullmatch(event) or _LICENCE_DETAIL.fullmatch(event)
                or _PLAYER_DETAIL.fullmatch(event)):
            result.append(event)
        else:
            result.append("other diagnostic omitted")
    return result


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: diagnostic_record.py input.json output.json")
    with open(sys.argv[1], encoding="utf-8") as source:
        sanitized = sanitize_events(json.load(source))
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(sanitized, destination, indent=2)
