"""Require, on Windows, the Widevine version verified with Magenta's licence server.

Run this after InputStream Helper's own playback-support check so that a CDM it
installs or updates is the one measured. The threshold comes from observations
with Magenta only; it is not a general Widevine minimum.
"""

import re

from magenta_playback import PlaybackError


TESTED_WINDOWS_VERSION = (4, 10, 3112, 0)


def format_version(version):
    return ".".join(str(part) for part in version)


TESTED_WINDOWS_TEXT = format_version(TESTED_WINDOWS_VERSION)


def parse_version(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9]+(?:\.[0-9]+){3}", value):
        return None
    return tuple(int(part) for part in value.split("."))


def installed_version(get_config):
    try:
        config = get_config()
    except (OSError, ValueError):
        return None
    return parse_version(config.get("version")) if isinstance(config, dict) else None


def ensure_widevine(helper, get_config, is_windows, offer_update, localize):
    if not is_windows:
        return
    version = installed_version(get_config)
    if version is None:
        raise PlaybackError(localize(32014).format(required=TESTED_WINDOWS_TEXT))
    if version >= TESTED_WINDOWS_VERSION:
        return
    if not offer_update(localize(32013).format(required=TESTED_WINDOWS_TEXT)):
        raise PlaybackError(localize(32015).format(
            installed=format_version(version), required=TESTED_WINDOWS_TEXT))
    if not helper.install_widevine():
        raise PlaybackError(localize(32016))
    version = installed_version(get_config)
    if version is None or version < TESTED_WINDOWS_VERSION:
        raise PlaybackError(localize(32017))
