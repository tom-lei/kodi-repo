"""Where the active skin draws Kodi's video controls (VideoOSD); from simpliTVᵀ (GPL-3.0-or-later).

Kodi exposes no geometry for skin windows, so the skin's own XML is read: the
VideoOSD window, expanded with the skin's includes, constants and parameters.
"""

import copy
import json
import os
import re
import xml.etree.ElementTree as ET

CACHE_PROPERTY = "magentatv_at_t.osd_layout"
_PARAM = re.compile(r"\$PARAM\[([^\]]+)\]")
_ignored = ("videowindow", "visualisation", "gamewindow")


def _find(folder, name):
    try:
        entries = os.listdir(folder)
    except OSError:
        return None
    for entry in entries:
        if entry.lower() == name.lower():
            return os.path.join(folder, entry)
    return None


def _resolution(skin_path):
    root = ET.parse(os.path.join(skin_path, "addon.xml")).getroot()
    options = root.findall(".//extension[@point='xbmc.gui.skin']/res")
    chosen = next((res for res in options if res.get("default") == "true"), options[0] if options else None)
    if chosen is None:
        raise ValueError("skin declares no resolution")
    return (os.path.join(skin_path, chosen.get("folder")), float(chosen.get("width")),
            float(chosen.get("height")))


def _load_includes(folder, name, includes, constants, seen):
    path = _find(folder, name)
    if path is None or path in seen:
        return
    seen.add(path)
    for node in ET.parse(path).getroot():
        if node.tag == "include" and node.get("file"):
            _load_includes(folder, node.get("file"), includes, constants, seen)
        elif node.tag == "include" and node.get("name"):
            includes.setdefault(node.get("name"), node)
        elif node.tag == "constant" and node.get("name"):
            constants.setdefault(node.get("name"), (node.text or "").strip())


def _substitute(element, params):
    def replace(text):
        return _PARAM.sub(lambda match: params.get(match.group(1), ""), text) if text else text

    for node in element.iter():
        node.text = replace(node.text)
        for key, value in node.attrib.items():
            node.attrib[key] = replace(value)
    return element


class _Expander:
    def __init__(self, includes, condition):
        self.includes, self.condition = includes, condition

    def children(self, element, params, depth=0):
        result = []
        for child in element:
            if child.tag != "include" or child.get("file"):
                if child.tag == "control":
                    node = _substitute(copy.deepcopy(child), params)
                    expanded = self.children(node, params, depth)
                    for old in list(node):
                        node.remove(old)
                    node.extend(expanded)
                    result.append(node)
                else:
                    result.append(_substitute(copy.deepcopy(child), params))
                continue
            name = _substitute(copy.deepcopy(child), params)
            condition = name.get("condition")
            if depth > 20 or (condition and not self.condition(condition)):
                continue
            definition = self.includes.get(name.get("content") or (name.text or "").strip())
            if definition is None:
                continue
            values = {node.get("name"): node.get("default", "")
                      for node in definition.findall("param")}
            values.update({node.get("name"): node.get("value", "")
                           for node in name.findall("param")})
            body = definition.find("definition")
            holder = ET.Element("holder")
            holder.extend(copy.deepcopy(node) for node in (body if body is not None else definition)
                          if node.tag != "param")
            result.extend(self.children(holder, values, depth + 1))
        return result


def _number(element, tag, parent, constants):
    node = element.find(tag)
    if node is None or node.text is None:
        return None
    text = constants.get(node.text.strip(), node.text.strip())
    try:
        if text.endswith("%"):
            return parent * float(text[:-1]) / 100
        return float(text)
    except ValueError:
        return None


def _span(element, start, size, near, far, centre, constants, offset, parent):
    low, high = _number(element, near, parent, constants), _number(element, far, parent, constants)
    length = _number(element, size, parent, constants)
    middle = _number(element, centre, parent, constants)
    if low is not None and length is not None:
        return offset + low, length
    if high is not None and length is not None:
        return offset + parent - high - length, length
    if low is not None or high is not None:
        low, high = low or 0, high or 0
        return offset + low, parent - low - high
    if middle is not None and length is not None:
        return offset + middle - length / 2, length
    return offset, parent if length is None else length


def _walk(controls, box, constants, leaves):
    x, y, width, height = box
    for control in controls:
        if control.tag != "control":
            continue
        visible = control.find("visible")
        if visible is not None and (visible.text or "").strip().lower() == "false":
            continue
        kind = control.get("type", "")
        if kind in _ignored:
            continue
        left, w = _span(control, "left", "width", "left", "right", "centerleft", constants, x, width)
        top, h = _span(control, "top", "height", "top", "bottom", "centertop", constants, y, height)
        if kind == "group":
            _walk(list(control), (left, top, w, h), constants, leaves)
        else:
            leaves.append((kind, control, (left, top, w, h)))


def read_layout(skin_path, condition=lambda _: False):
    """Return {"top": fraction, "slider": [x, y, w, h] fractions or None}."""
    folder, width, height = _resolution(skin_path)
    path = _find(folder, "VideoOSD.xml")
    if path is None:
        raise ValueError("skin has no VideoOSD window")
    includes, constants = {}, {}
    _load_includes(folder, "Includes.xml", includes, constants, set())
    window = ET.parse(path).getroot()
    expander = _Expander(includes, condition)
    holder = window.find("controls")
    if holder is None:
        raise ValueError("VideoOSD has no controls")
    leaves = []
    _walk(expander.children(holder, {}), (0, 0, width, height), constants, leaves)
    top, slider = height, None
    for kind, control, (x, y, w, h) in leaves:
        # Off-screen focus helpers and full-screen click/background areas are not controls.
        if h <= 0 or w <= 0 or y < height / 2 or y >= height or h > height * .4 or x >= width:
            continue
        top = min(top, y)
        info = (control.findtext("info") or "") + (control.findtext("action") or "")
        if slider is None and kind == "slider" and ("Player.Progress" in info or "seek" in info):
            slider = [x / width, y / height, w / width, h / height]
    return {"top": top / height, "slider": slider}


def banner_lift(layout):
    """Return the banner's destination above the seek bar, or the controls' top edge."""
    if not layout:
        return True
    slider = layout.get("slider")
    if slider and len(slider) > 1:
        return slider[1]
    return layout.get("top", True)


def video_osd_layout():
    """Cached layout of the active skin's video controls, or None if it can't be read."""
    try:
        import xbmc
        import xbmcgui
        import xbmcvfs

        home = xbmcgui.Window(10000)
        skin = xbmcvfs.translatePath("special://skin/")
        cached = json.loads(home.getProperty(CACHE_PROPERTY) or "{}")
        if isinstance(cached, dict) and cached.get("skin") == skin:
            return cached.get("layout")
    except Exception:  # Unknown layout: the banner falls back to the top edge.
        return None
    try:
        layout = read_layout(skin, xbmc.getCondVisibility)
    except Exception as error:
        xbmc.log("[Magenta TV AT] Cannot read the skin's video controls: {}".format(
            type(error).__name__), xbmc.LOGWARNING)
        layout = None
    try:
        home.setProperty(CACHE_PROPERTY, json.dumps({"skin": skin, "layout": layout}))
    except Exception:
        pass
    return layout
