# -*- coding: utf-8 -*-
"""3proxy configuration generation and encoding (no Kodi imports)."""
import re
import secrets
import string

from . import netutil

USERNAME_RE = re.compile(r'^[A-Za-z0-9._-]{1,64}$')
# Only characters that cannot appear inside one line of 3proxy.cfg.
_PASSWORD_FORBIDDEN = set('\0\r\n')
# 3proxy 1.0.4 silently truncates HTTP Basic "user:password" to 255 decoded bytes. A configured
# credential of exactly 255 bytes would therefore accept any longer login starting with it; at 254 bytes
# or less a truncated login is always longer than the configured one and is rejected.
MAX_CREDENTIAL_BYTES = 254
WEAK_PASSWORD_LENGTH = 8


class ProxyOptions(object):
    """Desired proxy configuration."""

    def __init__(self, username='kodi', password='', http_port=3128, http_enabled=True,
                 tls_enabled=False, tls_port=3129, socks_enabled=False, socks_port=1080,
                 listen_ipv6=False, allow_list=(), cert_file='', key_file='',
                 log_file='', windows=False, maxconn=100, internal_only=False, unix_sockets=None,
                 accounting_mode='direct'):
        self.username = username
        self.password = password
        self.http_enabled = http_enabled
        self.http_port = int(http_port)
        self.tls_enabled = tls_enabled
        self.tls_port = int(tls_port)
        self.socks_enabled = socks_enabled
        self.socks_port = int(socks_port)
        self.listen_ipv6 = listen_ipv6
        self.allow_list = list(allow_list)
        self.cert_file = cert_file
        self.key_file = key_file
        self.log_file = log_file
        self.windows = windows
        self.maxconn = int(maxconn)
        self.internal_only = internal_only
        self.unix_sockets = unix_sockets or {}
        self.accounting_mode = accounting_mode

    def listeners(self):
        """[(kind, port)] of enabled listeners."""
        result = []
        if self.http_enabled:
            result.append(('http', self.http_port))
        if self.tls_enabled:
            result.append(('tls', self.tls_port))
        if self.socks_enabled:
            result.append(('socks', self.socks_port))
        return result


def generate_password(length=20):
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))


def check_username(username):
    if not username:
        return 'The proxy username must not be empty.'
    if not USERNAME_RE.match(username):
        return 'The proxy username may only contain letters, digits, ".", "_" and "-" (max. 64).'
    return None


def check_password(password, username=''):
    if not password:
        return 'The proxy password must not be empty.'
    if any(c in _PASSWORD_FORBIDDEN for c in password):
        return 'The proxy password must not contain line breaks or NUL characters.'
    length = len(('%s:%s' % (username, password)).encode('utf-8', 'surrogatepass'))
    if length > MAX_CREDENTIAL_BYTES:
        return ('Username and password are too long: "username:password" may have at most %d bytes '
                '(UTF-8, 3proxy limit), it has %d.' % (MAX_CREDENTIAL_BYTES, length))
    return None


def password_warnings(password):
    """Non-blocking hints about a usable password."""
    result = []
    if password and len(password) < WEAK_PASSWORD_LENGTH:
        result.append('The proxy password is short (fewer than %d characters) and easy to guess.'
                      % WEAK_PASSWORD_LENGTH)
    if any(ord(c) > 126 for c in password or ''):
        result.append('The proxy password contains non-ASCII characters; clients that do not send '
                      'UTF-8 will fail to log in.')
    return result


def validate(opts):
    """Return a list of human readable problems (empty if the options are usable)."""
    errors = []
    for msg in (check_username(opts.username), check_password(opts.password, opts.username)):
        if msg:
            errors.append(msg)
    listeners = opts.listeners()
    if not listeners:
        errors.append('No proxy listener is enabled.')
    ports = [p for _, p in listeners]
    for port in ports:
        if not 1 <= port <= 65535:
            errors.append('Invalid port %d.' % port)
    if len(set(ports)) != len(ports):
        errors.append('Each listener needs its own port.')
    if opts.tls_enabled and not (opts.cert_file and opts.key_file):
        errors.append('TLS is enabled but no certificate/key is available.')
    for entry in opts.allow_list:
        if netutil.normalize_allow_entry(entry) != entry:
            errors.append('Invalid allow-list entry: %s' % entry)
    return errors


def _q(value):
    """Quote for 3proxy's parser: inside quotes "" is a literal quote and $$ a literal dollar."""
    value = str(value)
    if any(c in _PASSWORD_FORBIDDEN for c in value):
        raise ValueError('value cannot be quoted for 3proxy: %r' % value)
    return '"%s"' % value.replace('"', '""').replace('$', '$$')


def _path(path, windows):
    return path.replace('\\', '/') if windows else path


def _windows_encoding():
    import ctypes
    return 'cp%d' % ctypes.windll.kernel32.GetACP()


def config_bytes(text, windows=False, config_path=''):
    """Keep credentials UTF-8, but Windows 3proxy's file APIs require ANSI paths."""
    if not windows:
        return text.encode('utf-8')
    encoding = _windows_encoding()

    def path_bytes(value, label):
        try:
            encoded = value.encode(encoding)
            if encoded.decode(encoding) != value:
                raise UnicodeError('path does not round-trip')
        except UnicodeError:
            raise ValueError('%s cannot be represented in Windows ANSI code page %s. '
                             'Use a path supported by that code page.' % (label, encoding)) from None
        return encoded

    if config_path:
        path_bytes(config_path, 'Configuration file path')
    directives = {'log': 'Proxy log path', 'ssl_server_cert': 'TLS certificate path',
                  'ssl_server_key': 'TLS key path'}
    result = []
    for line in text.split('\n'):
        label = directives.get(line.partition(' ')[0])
        result.append(path_bytes(line, label) if label else line.encode('utf-8'))
    return b'\n'.join(result)


def _bind_addresses(opts, kind):
    if kind in opts.unix_sockets:
        return ['unix:@' + opts.unix_sockets[kind]]
    if opts.internal_only:
        return ['127.0.0.1']
    if not opts.listen_ipv6:
        return ['0.0.0.0']
    # Linux sockets bound to :: are dual-stack by default, Windows ones are v6-only.
    return ['0.0.0.0', '::'] if opts.windows else ['::']


def _expand_allow_list(entries):
    """A plain domain also allows its subdomains (3proxy matches hostnames literally)."""
    result = []
    for entry in entries:
        variants = [entry]
        if netutil.is_valid_hostname(entry):
            variants.append('*.' + entry)
        for item in variants:
            if item not in result:
                result.append(item)
    return result


def build_config(opts):
    """Return the 3proxy configuration text for opts. Raises ValueError if invalid."""
    errors = validate(opts)
    if errors:
        raise ValueError('; '.join(errors))
    lines = [
        '# Generated by service.ddnsproxy_t - manual changes will be overwritten.',
        'nscache 65536',
        'nscache6 65536',
        'timeouts 1 5 30 60 180 1800 15 60',
        'maxconn %d' % opts.maxconn,
    ]
    if opts.log_file:
        lines += [
            'log %s D' % _q(_path(opts.log_file, opts.windows)),
            'rotate 7',
            # L selects local time; D/S tags direct/shared entries. %O is client upload, %I download.
            # Keep accounting fields only: never persist proxy destinations or credentials.
            'logformat "L%%Y-%%m-%%d %%H:%%M:%%S %s %%U %%C %%O %%I"' % (
                'S' if opts.accounting_mode == 'shared' else 'D'),
        ]
    lines += [
        'users %s' % _q('%s:CL:%s' % (opts.username, opts.password)),
        'auth strong',
        # Never allow destinations inside private/special networks (checked on the
        # resolved address) or obviously internal hostnames.
        'deny * * %s' % ','.join(netutil.BLOCKED_V4),
        'deny * * %s' % ','.join(netutil.BLOCKED_V6),
        'deny * * %s' % ','.join(netutil.BLOCKED_HOSTNAMES),
    ]
    if opts.internal_only:
        lines.append('deny * * * * BIND,UDPASSOC')
    if opts.allow_list:
        lines.append('allow %s * %s' % (opts.username, ','.join(_expand_allow_list(opts.allow_list))))
    else:
        lines.append('allow %s' % opts.username)
    lines.append('deny *')

    if opts.http_enabled:
        for addr in _bind_addresses(opts, 'http'):
            lines.append('proxy -n -a -p%d -i%s' % (opts.http_port, addr))
    if opts.tls_enabled:
        lines += [
            'ssl_server_cert %s' % _q(_path(opts.cert_file, opts.windows)),
            'ssl_server_key %s' % _q(_path(opts.key_file, opts.windows)),
            'ssl_serv',
        ]
        for addr in _bind_addresses(opts, 'tls'):
            lines.append('proxy -n -a -p%d -i%s' % (opts.tls_port, addr))
        lines.append('ssl_noserv')
    if opts.socks_enabled:
        for addr in _bind_addresses(opts, 'socks'):
            lines.append('socks -p%d -i%s' % (opts.socks_port, addr))
    return '\n'.join(lines) + '\n'
