# -*- coding: utf-8 -*-
"""IP address classification and small network helpers (no Kodi imports)."""
import errno
import ipaddress
import re
import select
import socket
import time

# Destinations the proxy must never reach. Used for the 3proxy ACL and for
# our own classification, so both always agree.
BLOCKED_V4 = (
    '0.0.0.0/8',          # "this" network
    '10.0.0.0/8',         # private
    '100.64.0.0/10',      # CGNAT shared address space
    '127.0.0.0/8',        # loopback
    '169.254.0.0/16',     # link-local
    '172.16.0.0/12',      # private
    '192.0.0.0/24',       # IETF protocol assignments
    '192.0.2.0/24',       # TEST-NET-1
    '192.88.99.0/24',     # deprecated 6to4 relay anycast
    '192.168.0.0/16',     # private
    '198.18.0.0/15',      # benchmarking
    '198.51.100.0/24',    # TEST-NET-2
    '203.0.113.0/24',     # TEST-NET-3
    '224.0.0.0/4',        # multicast
    '240.0.0.0/4',        # reserved + limited broadcast
)

BLOCKED_V6 = (
    '::/128',             # unspecified
    '::1/128',            # loopback
    '::ffff:0:0/96',      # IPv4-mapped (could smuggle private IPv4)
    '64:ff9b::/96',       # NAT64 well-known prefix (could map to private IPv4)
    '64:ff9b:1::/48',     # NAT64 local-use
    '100::/64',           # discard-only
    '2001::/23',          # IETF protocol assignments (Teredo, ORCHID, ...)
    '2001:db8::/32',      # documentation
    '2002::/16',          # 6to4 (embeds arbitrary IPv4)
    '3fff::/20',          # documentation
    'fc00::/7',           # unique local
    'fe80::/10',          # link-local
    'fec0::/10',          # deprecated site-local
    'ff00::/8',           # multicast
)

BLOCKED_HOSTNAMES = (
    'localhost', '*.localhost', '*.local', '*.lan', '*.home', '*.home.arpa',
    '*.internal', '*.intranet', '*.corp', '*.private',
)

_BLOCKED_NETS = tuple(ipaddress.ip_network(n) for n in BLOCKED_V4 + BLOCKED_V6)

_LABEL = r'(?!-)[A-Za-z0-9-]{1,63}(?<!-)'
_HOSTNAME_RE = re.compile(r'^(?=.{1,253}$)%s(?:\.%s)*$' % (_LABEL, _LABEL))


def parse_ip(text):
    """Return an ipaddress object for text, or None."""
    if text is None:
        return None
    if not isinstance(text, str):
        return text if isinstance(text, (ipaddress.IPv4Address, ipaddress.IPv6Address)) else None
    value = text.strip()
    if value.startswith('[') and value.endswith(']'):
        value = value[1:-1]
    value = value.split('%', 1)[0]
    try:
        return ipaddress.ip_address(value)
    except ValueError:
        return None


def is_external(ip):
    """True if ip is a public internet address the proxy may connect to."""
    addr = parse_ip(ip)
    if addr is None:
        return False
    for net in _BLOCKED_NETS:
        if addr.version == net.version and addr in net:
            return False
    return addr.is_global and not addr.is_multicast


def is_valid_hostname(name, require_dot=True):
    if not name or not isinstance(name, str):
        return False
    name = name.rstrip('.')
    if not _HOSTNAME_RE.match(name):
        return False
    if require_dot and '.' not in name:
        return False
    if parse_ip(name) is not None:
        return False
    # a TLD consisting only of digits is not a hostname
    return not name.rsplit('.', 1)[-1].isdigit()


def normalize_allow_entry(entry):
    """Validate one allow-list entry. Returns the normalized entry or None.

    Accepted: example.com, *.example.com, a public IP or a public CIDR range.
    """
    entry = (entry or '').strip().lower()
    if not entry:
        return None
    if entry.startswith('*.'):
        return entry if is_valid_hostname(entry[2:]) else None
    if is_valid_hostname(entry):
        return entry
    try:
        net = ipaddress.ip_network(entry, strict=False)
    except ValueError:
        return None
    for blocked in _BLOCKED_NETS:
        if net.version == blocked.version and net.overlaps(blocked):
            return None
    if not net.network_address.is_global:
        return None
    return str(net) if net.num_addresses > 1 else str(net.network_address)


def parse_allow_list(text):
    """Split a comma/space separated allow list. Returns (valid, invalid)."""
    valid, invalid = [], []
    for raw in re.split(r'[\s,;]+', text or ''):
        if not raw:
            continue
        norm = normalize_allow_entry(raw)
        if norm is None:
            invalid.append(raw)
        elif norm not in valid:
            valid.append(norm)
    return valid, invalid


def resolve(host, family=0):
    """Resolve host with the system resolver. Returns a sorted list of IP strings."""
    try:
        infos = socket.getaddrinfo(host, None, family, socket.SOCK_STREAM)
    except (socket.gaierror, UnicodeError, OSError):
        return []
    result = set()
    for info in infos:
        addr = parse_ip(info[4][0])
        if addr is not None:
            result.add(str(addr))
    return sorted(result)


def local_ip(target='192.0.2.1', family=socket.AF_INET):
    """Local source address used to reach target (no packets are sent)."""
    try:
        sock = socket.socket(family, socket.SOCK_DGRAM)
    except OSError:
        return None
    try:
        sock.connect((target, 9))
        return sock.getsockname()[0]
    except OSError:
        return None
    finally:
        sock.close()


def host_port(host, port):
    """Format host:port, bracketing IPv6 literals."""
    addr = parse_ip(host)
    if addr is not None and addr.version == 6:
        return '[%s]:%d' % (addr, port)
    return '%s:%d' % (host, port)


def tcp_listening(port, host='127.0.0.1', timeout=1.0):
    try:
        sock = socket.create_connection((host, port), timeout)
    except OSError:
        return False
    sock.close()
    return True


def tcp_probe(host, port, timeout=4.0, cancelled=None):
    """Plain TCP connect without data; optionally poll cancellation while connecting."""
    try:
        if cancelled is not None:
            if cancelled():
                return 'cancelled'
            family, kind, protocol, _, address = socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM)[0]
            with socket.socket(family, kind, protocol) as sock:
                sock.setblocking(False)
                error = sock.connect_ex(address)
                pending = (errno.EINPROGRESS, errno.EWOULDBLOCK, errno.EALREADY,
                           getattr(errno, 'WSAEWOULDBLOCK', 10035))
                if error and error not in pending:
                    raise OSError(error, 'TCP connection failed')
                deadline = time.monotonic() + timeout
                while error:
                    if cancelled():
                        return 'cancelled'
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return 'timeout'
                    _, writable, exceptional = select.select([], [sock], [sock], min(0.1, remaining))
                    if writable or exceptional:
                        error = sock.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
                        if error:
                            raise OSError(error, 'TCP connection failed')
                return 'cancelled' if cancelled() else 'open'
        sock = socket.create_connection((host, port), timeout)
    except socket.timeout:
        return 'timeout'
    except ConnectionRefusedError:
        return 'refused'
    except OSError as exc:
        if exc.errno in (errno.ECONNREFUSED, getattr(errno, 'WSAECONNREFUSED', 10061)):
            return 'refused'
        return 'error'
    sock.close()
    return 'open'
