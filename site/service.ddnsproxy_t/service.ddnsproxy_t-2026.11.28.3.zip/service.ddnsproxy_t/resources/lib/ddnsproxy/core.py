# -*- coding: utf-8 -*-
"""Service core: engine supervision, DDNS updates, TLS and port mapping.

No Kodi imports - Kodi specifics are injected through `host`, an object with:
  settings()      -> settings object for config.load()
  set_setting(k, v)
  proxy()         -> Kodi network proxy (httpclient.ProxyConfig or None, raises on error)
  notify(msg, error=False)
  log(msg, debug=False)
  addon_dir       -> add-on installation directory
"""
import os
import queue
import secrets
import socket
import sys
import threading
import time
import traceback

from . import config, ddns, engine, frontend, netutil, portmap, publicip, scheduler, store, threeproxy, tls
from .httpclient import HttpClient, HttpError

BACKOFF = (5, 10, 30, 60, 300)
STABLE_AFTER = 60
PORTMAP_INTERVAL = 300
INSTALL_RETRY = 600


class Core(object):
    def __init__(self, host, paths):
        self.host = host
        self.paths = paths.create()
        self.manifest = engine.load_manifest(os.path.join(host.addon_dir, 'resources', 'engine.json'))
        self.platform = engine.detect_platform()
        self.windows = os.name == 'nt'
        self.lock = threading.RLock()
        self.tasks = queue.Queue()
        self.pending = set()
        self.cfg = None
        self.cfg_fp = None
        self.proc = None
        self.frontend = None
        self.running_hash = None
        self.failures = 0
        self.next_start = 0
        self.engine_info = None
        self.install_error = ''
        self.install_failed_at = 0
        self.tls_info = None
        self.tls_error = ''
        self.mapper = None
        self.mapper_key = None
        self.ddns_due = 0
        self.portmap_due = 0
        self.changed_slots = set()
        self.ddns_paused = False
        self.ddns_state = store.read_json(paths.ddns_state, {})
        self.status = {'proxy': {'state': 'starting', 'message': ''}, 'ddns': {}, 'public': {},
                       'portmap': {'enabled': False}, 'tls': {}, 'engine': {}, 'problems': [],
                       'warnings': [], 'platform': self.platform, 'version': config.VERSION}
        self.dirty = True
        self.stopping = False
        self.worker = threading.Thread(target=self._work, name='ddnsproxy-worker')
        self.worker.daemon = True

    # ----------------------------------------------------------------- helpers
    def log(self, msg, debug=False):
        self.host.log(msg, debug)

    def client(self, user_agent=config.USER_AGENT, cookies=False):
        return HttpClient(self.host.proxy, user_agent, cookies=cookies)

    def set_status(self, key, value):
        with self.lock:
            self.status[key] = value
            self.dirty = True

    def set_proxy_state(self, state, message='', **extra):
        value = {'state': state, 'message': message}
        value.update(extra)
        with self.lock:
            if self.status.get('proxy') != value:
                if self.status.get('proxy', {}).get('message') != message and message:
                    self.log('proxy %s: %s' % (state, message))
                self.status['proxy'] = value
                self.dirty = True

    def flush_status(self):
        with self.lock:
            if not self.dirty:
                return
            self.status['updated'] = time.time()
            data = dict(self.status)
            self.dirty = False
        try:
            store.write_json(self.paths.status, data)
        except (IOError, OSError) as exc:
            self.log('cannot write status: %s' % exc)

    def submit(self, name, func, *args):
        with self.lock:
            if name in self.pending:
                return
            self.pending.add(name)
        self.tasks.put((name, func, args))

    def _work(self):
        while True:
            item = self.tasks.get()
            if item is None:
                return
            name, func, args = item
            try:
                func(*args)
            except Exception:
                self.log('task %s failed:\n%s' % (name, traceback.format_exc()))
            finally:
                with self.lock:
                    self.pending.discard(name)
                self.dirty = True

    # ------------------------------------------------------------- lifecycle
    def start(self):
        self.worker.start()
        self.reload()

    def ensure_password(self, settings):
        if settings.get_string('proxy.password'):
            return False
        password = threeproxy.generate_password()
        self.host.set_setting('proxy.password', password)
        self.log('generated a random proxy password')
        return True

    def reload(self):
        settings = self.host.settings()
        if self.ensure_password(settings):
            settings = self.host.settings()
        cfg = config.load(settings)
        old = self.cfg
        self.cfg = cfg
        fp = cfg.fingerprint()
        if fp == self.cfg_fp:
            return
        self.cfg_fp = fp
        self.log('configuration loaded (%s)' % fp, True)
        for slot, entry in cfg.ddns.items():
            if entry.enabled and (old is None or old.ddns[slot].fingerprint() != entry.fingerprint()
                                  or not old.ddns[slot].enabled):
                if old is not None:
                    self.changed_slots.add(slot)
        self.ddns_due = 0
        self.portmap_due = 0
        self.failures = 0
        self.next_start = 0
        self.install_failed_at = 0
        with self.lock:
            self.status['problems'] = cfg.problems()
            self.status['warnings'] = cfg.warnings()
            self.dirty = True
        blocking = cfg.proxy_problems()
        if blocking:
            self.host.notify('Proxy not started: %s' % blocking[0])
        if cfg.proxy_enabled and cfg.tls_enabled and (old is None or not old.proxy_enabled or
                not old.tls_enabled or old.tls_mode != cfg.tls_mode or
                old.tls_cert_file != cfg.tls_cert_file or old.tls_key_file != cfg.tls_key_file):
            self.host.notify('HTTPS proxy: verify client certificate trust and hostname. See Client setup.')

    def command(self, name):
        self.log('command: %s' % name)
        if name == 'reinstall':
            self.submit('install', self.task_install, True)
        elif name == 'regen_cert':
            self.submit('tls', self.task_tls, True)
        elif name == 'refresh':
            self.ddns_due = 0
            self.portmap_due = 0
        elif name.startswith('ddns_reset'):
            slot = name.split(':', 1)[-1]
            with self.lock:
                self.ddns_state.pop(slot, None)
            self.ddns_due = 0
        elif name == 'restart':
            self.stop_engine()
            self.failures = 0
            self.next_start = 0

    def tick(self):
        """Called periodically from the Kodi service loop."""
        now = time.time()
        try:
            self.supervise(now)
        except Exception:
            self.log('supervise failed:\n%s' % traceback.format_exc())
            self.set_proxy_state('error', 'internal error, see Kodi log')
        if now >= self.ddns_due:
            self.ddns_due = now + self.cfg.ddns_interval * 60
            self.submit('ddns', self.task_ddns)
        if now >= self.portmap_due:
            self.portmap_due = now + PORTMAP_INTERVAL
            self.submit('portmap', self.task_portmap)
        self.flush_status()

    def shutdown(self):
        self.stopping = True
        self.stop_engine()
        self.set_proxy_state('stopped', 'Kodi service stopped')
        mapper = self.mapper
        if mapper is not None and mapper.mappings:
            done = threading.Event()

            def remove():
                try:
                    mapper.remove_all()
                finally:
                    done.set()
            threading.Thread(target=remove).start()
            done.wait(5)
        self.tasks.put(None)
        self.flush_status()

    # ---------------------------------------------------------------- engine
    def stop_engine(self):
        if self.frontend is not None:
            self.frontend.stop()
            self.frontend = None
        if self.proc is not None:
            self.log('stopping 3proxy (pid %s)' % self.proc.pid)
            self.proc.stop()
            self.proc = None
        self.running_hash = None

    def current_engine(self):
        cfg = self.cfg
        if cfg.engine_custom:
            return engine.custom_engine(cfg.engine_path)
        if self.engine_info is None or not os.path.isfile(self.engine_info.binary):
            self.engine_info = engine.load_installed(self.paths.engine_root, self.manifest, self.platform)
        return self.engine_info

    def certificate_files(self):
        """(cert, key) for the TLS listener, or None while not available."""
        cfg = self.cfg
        if cfg.tls_mode == config.TLS_CUSTOM:
            for path in (cfg.tls_cert_file, cfg.tls_key_file):
                if not path or not os.path.isfile(path):
                    raise engine.EngineError('Custom TLS certificate/key file not found: %s' % (path or '(empty)'))
            self.set_status('tls', {'mode': 'custom', 'cert_file': cfg.tls_cert_file})
            return cfg.tls_cert_file, cfg.tls_key_file
        names = self.tls_names()
        info = self.tls_info
        if info is None or info.get('names') != tls.normalize_names(names):
            self.submit('tls', self.task_tls, False)
            return None
        return info['cert_file'], info['key_file']

    def tls_names(self):
        names = list(self.cfg.hostnames())
        local = netutil.local_ip()
        if local:
            names.append(local)
        names.append('localhost')
        return names

    def supervise(self, now):
        cfg = self.cfg
        if not cfg.proxy_enabled:
            self.stop_engine()
            self.set_proxy_state('disabled', 'The proxy is switched off in the settings.')
            return
        errors = cfg.proxy_problems()
        if errors:
            self.stop_engine()
            self.set_proxy_state('error', ' '.join(errors))
            return
        try:
            info = self.current_engine()
        except engine.EngineError as exc:
            self.stop_engine()
            self.set_proxy_state('error', str(exc))
            return
        if info is None:
            self.stop_engine()
            if 'install' in self.pending:
                self.set_proxy_state('installing', 'Downloading and verifying 3proxy %s...' % self.manifest['version'])
            elif self.install_error and now - self.install_failed_at < INSTALL_RETRY:
                self.set_proxy_state('error', 'Engine installation failed: %s' % self.install_error)
            else:
                self.submit('install', self.task_install, False)
                self.set_proxy_state('installing', 'Downloading and verifying 3proxy %s...' % self.manifest['version'])
            return
        self.set_status('engine', info.to_dict())
        cert = key = ''
        if cfg.tls_enabled:
            try:
                files = self.certificate_files()
            except engine.EngineError as exc:
                self.stop_engine()
                self.set_proxy_state('error', str(exc))
                return
            if files is None:
                self.stop_engine()
                if self.tls_error:
                    self.set_proxy_state('error', 'TLS certificate: %s' % self.tls_error)
                else:
                    self.set_proxy_state('starting', 'Preparing the TLS certificate...')
                return
            cert, key = files
        opts = cfg.proxy_options(cert, key, self.paths.proxy_log, self.windows)
        opts.accounting_mode = 'shared' if cfg.single_port else 'direct'
        if cfg.single_port:
            opts.internal_only = True
            for index, (kind, _) in enumerate(opts.listeners()):
                setattr(opts, kind + '_port', index + 1)
        text = threeproxy.build_config(opts)
        wanted = '%s|%s|%s|%s|%s' % (info.binary, text, cfg.single_port, cfg.shared_port, cfg.listen_ipv6)
        if self.proc is not None and wanted == self.running_hash:
            code = self.proc.poll()
            if code is None:
                if cfg.single_port and (self.frontend is None or not self.frontend.alive()):
                    self.stop_engine()
                    delay = BACKOFF[min(self.failures, len(BACKOFF) - 1)]
                    self.failures += 1
                    self.next_start = now + delay
                    self.set_proxy_state('error', 'Shared frontend stopped. Retrying in %ds.' % delay)
                    return
                if self.failures and now - self.proc.started > STABLE_AFTER:
                    self.failures = 0
                self._set_running(cfg, info)
                return
            output = engine.tail(self.paths.output_log, 1500).strip().splitlines()[-5:]
            self.log('3proxy exited with code %s: %s' % (code, ' | '.join(output)))
            self.stop_engine()
            delay = BACKOFF[min(self.failures, len(BACKOFF) - 1)]
            self.failures += 1
            self.next_start = now + delay
            hint = engine_exit_hint(code, output, self.windows)
            self.set_proxy_state('error', '3proxy stopped (exit code %s). %sRetrying in %ds.'
                                 % (code, hint, delay), output=output)
            return
        if now < self.next_start:
            return
        self.stop_engine()
        reserved = []
        if cfg.single_port:
            try:
                self.frontend = frontend.Frontend(cfg.shared_port, cfg.listen_ipv6, {},
                                                  stats_file=self.paths.frontend_traffic)
                self.frontend.bind()
                for kind, _ in opts.listeners():
                    # 3proxy 1.0.4 emits malformed SOCKS replies on Unix listeners.
                    if kind != 'socks' and sys.platform.startswith('linux') and hasattr(socket, 'AF_UNIX'):
                        opts.unix_sockets[kind] = 'ddnsproxy-' + secrets.token_hex(16)
                        self.frontend.backends[kind] = opts.unix_sockets[kind]
                    else:
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        reserved.append(sock)
                        if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
                            sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                        sock.bind(('127.0.0.1', 0))
                        setattr(opts, kind + '_port', sock.getsockname()[1])
                        self.frontend.backends[kind] = sock.getsockname()[1]
                text = threeproxy.build_config(opts)
            except (OSError, ValueError) as exc:
                for sock in reserved:
                    sock.close()
                self.stop_engine()
                self.next_start = now + 5
                self.set_proxy_state('error', 'Cannot bind shared proxy port or allocate private ports: %s' % exc)
                return
        try:
            data = threeproxy.config_bytes(text, self.windows, self.paths.config)
            with open(self.paths.config, 'wb') as handle:
                handle.write(data)
            if not self.windows:
                os.chmod(self.paths.config, 0o600)
            self.proc = engine.EngineProcess(info.binary, self.paths.config, self.paths.run, self.paths.output_log,
                                             self.paths.pid, info.directory if info.libraries else None)
            for sock in reserved:
                sock.close()
            reserved = []
            pid = self.proc.start()
            if cfg.single_port:
                deadline = time.monotonic() + 3
                remaining = dict(self.frontend.backends)
                while remaining and time.monotonic() < deadline and self.proc.poll() is None:
                    for kind, target in list(remaining.items()):
                        if frontend.check_backend(kind, target):
                            del remaining[kind]
                    if remaining:
                        time.sleep(0.05)
                if remaining or self.proc.poll() is not None:
                    raise OSError('3proxy failed to start its private listeners (possible port conflict)')
                self.frontend.start()
        except (OSError, RuntimeError, ValueError) as exc:
            for sock in reserved:
                sock.close()
            self.stop_engine()
            delay = BACKOFF[min(self.failures, len(BACKOFF) - 1)]
            self.failures += 1
            self.next_start = now + delay
            hint = ''
            if self.windows and not os.path.isfile(info.binary):
                hint = ' The binary has disappeared - security software may have quarantined it.'
                self.engine_info = None
            message = 'Cannot start 3proxy: %s.%s' % (exc, hint)
            if isinstance(exc, ValueError) and (self.status.get('proxy') or {}).get('message') != message:
                self.host.notify('Proxy not started: %s' % exc, True)
            self.set_proxy_state('error', message)
            return
        self.running_hash = wanted
        self.log('3proxy started (pid %d) on %s' % (pid, ', '.join('%s:%d' % l for l in cfg.public_listeners())))
        self._set_running(cfg, info)

    def _set_running(self, cfg, info):
        if cfg.single_port and self.frontend is not None:
            accounting_error = self.frontend.accounting_error
            state = {'state': 'incomplete' if accounting_error else 'measured',
                     'message': accounting_error}
            if self.status.get('bandwidth') != state:
                self.set_status('bandwidth', state)
        self.set_proxy_state('running', '3proxy %s is running.' % info.version, pid=self.proc.pid,
                             listeners=[{'kind': k, 'port': p} for k, p in cfg.public_listeners()],
                             since=self.proc.started)

    # ----------------------------------------------------------------- tasks
    def task_install(self, force):
        if self.cfg.engine_custom:
            return
        if force:
            self.stop_engine()
        self.set_proxy_state('installing', 'Downloading and verifying 3proxy %s...' % self.manifest['version'])
        self.flush_status()
        try:
            info = engine.install(self.client(), self.manifest, self.platform, self.paths.engine_root, self.log)
        except (engine.EngineError, HttpError, IOError, OSError) as exc:
            self.install_error = str(exc)
            if self.windows and isinstance(exc, (IOError, OSError)):
                self.install_error += (' - Windows security software may have quarantined 3proxy.exe; '
                                       'see the add-on README.')
            self.install_failed_at = time.time()
            self.engine_info = None
            self.host.notify('Engine installation failed: %s' % self.install_error, True)
            return
        self.install_error = ''
        self.engine_info = info
        self.next_start = 0
        self.host.notify('3proxy %s installed and verified.' % info.version)

    def task_tls(self, force):
        try:
            self.tls_info = tls.ensure(self.paths.tls, self.tls_names(), force, self.log)
            self.tls_error = ''
            info = dict(self.tls_info)
            info['mode'] = 'auto'
            self.set_status('tls', info)
            if info['regenerated'] and force:
                self.host.notify('A new TLS certificate was created.')
        except Exception as exc:
            self.tls_error = str(exc)
            self.log('TLS certificate failed:\n%s' % traceback.format_exc())

    def _public_addresses(self, cfg, client):
        mapped = self.mapper.external_ip if self.mapper is not None else ''
        return public_addresses(cfg, client, mapped)

    def task_ddns(self):
        cfg = self.cfg
        client = self.client()
        public = self._public_addresses(cfg, client)
        self.set_status('public', public)
        changed = set(self.changed_slots)
        self.changed_slots.clear()
        paused = bool(public.get('paused')) and any(e.ipv4 for _, e in cfg.ddns_entries())
        if paused and not self.ddns_paused:
            self.log('DDNS paused: %s' % public['paused'])
            self.host.notify('DDNS paused: Kodi uses a proxy and the router reported no public home '
                             'address. See diagnostics.', True)
        self.ddns_paused = paused
        statuses = {}
        for slot, entry in cfg.ddns_entries(enabled_only=False):
            key = str(slot)
            provider = ddns.make_provider(entry, config.user_agent_for(entry.provider))
            info = {'provider': provider.name, 'hostname': entry.fqdn(), 'enabled': entry.enabled}
            if not entry.enabled:
                statuses[key] = info
                continue
            dns = {4: netutil.resolve(entry.fqdn(), socket.AF_INET),
                   6: netutil.resolve(entry.fqdn(), socket.AF_INET6)}
            info['dns'] = dns
            problems = provider.check()
            state = self.ddns_state.get(key, {})
            if problems:
                result = ddns.Result(ddns.CONFIG, ' '.join(problems))
                self._remember(key, entry, result, state, notify=slot in changed, label=provider.name, slot=slot)
                info.update(self.ddns_state[key])
                info.pop('fingerprint', None)
                statuses[key] = info
                continue
            if public.get('paused') and entry.ipv4:
                info['note'] = 'Updates paused - see "Internet address" above.'
                info['paused'] = public['paused']
                info.update(state)
                info.pop('fingerprint', None)
                statuses[key] = info
                continue
            update, reason = scheduler.decide(state, entry, public.get('ipv4'), public.get('ipv6'), dns)
            info['reason'] = reason
            if update:
                want4, want6 = scheduler.wanted_addresses(entry, public.get('ipv4'), public.get('ipv6'))
                result = None
                if reason == 'configuration changed' and provider.read_only_check:
                    result = provider.validate(client)
                    if result.success or result.state == ddns.UNVERIFIED:
                        result = None
                if result is None:
                    self.log('DDNS %d (%s %s): updating (%s) to %s %s' % (
                        slot, provider.name, entry.fqdn(), reason, want4 or '-', want6 or '-'))
                    result = provider.update(client, want4, want6)
                self.log('DDNS %d result: %r %s' % (slot, result, result.detail))
                new_state = scheduler.apply_result(state, entry, result, public.get('ipv4'),
                                                   public.get('ipv6'), reason)
                with self.lock:
                    self.ddns_state[key] = new_state
                if slot in changed or not result.success:
                    label = '%s %s' % (provider.name, entry.fqdn())
                    old = (state.get('result') or {}).get('state')
                    if slot in changed or old != result.state:
                        self.host.notify('%s: %s' % (label, result.message), not result.success)
            elif slot in changed and reason != 'up to date':
                self.host.notify('%s %s: %s' % (provider.name, entry.fqdn(), reason), False)
            info.update(self.ddns_state.get(key, {}))
            info.pop('fingerprint', None)
            statuses[key] = info
        try:
            store.write_json(self.paths.ddns_state, self.ddns_state)
        except (IOError, OSError) as exc:
            self.log('cannot save DDNS state: %s' % exc)
        self.set_status('ddns', statuses)

    def _remember(self, key, entry, result, state, notify, label, slot):
        new_state = scheduler.apply_result(state, entry, result, None, None)
        with self.lock:
            self.ddns_state[key] = new_state
        if notify:
            self.host.notify('DDNS %d (%s): %s' % (slot, label, result.message), True)

    def task_portmap(self):
        cfg = self.cfg
        proxy_running = self.status.get('proxy', {}).get('state') == 'running'
        if not cfg.portmap_enabled or not proxy_running:
            if self.mapper is not None and self.mapper.mappings:
                self.mapper.remove_all()
            self.set_status('portmap', {'enabled': cfg.portmap_enabled,
                                        'message': 'disabled' if not cfg.portmap_enabled else 'proxy not running'})
            return
        key = (cfg.portmap_method, cfg.portmap_lifetime)
        if self.mapper is None or self.mapper_key != key:
            if self.mapper is not None:
                self.mapper.remove_all()
            self.mapper = portmap.PortMapper(self.client(), cfg.portmap_method, cfg.portmap_lifetime, self.log)
            self.mapper_key = key
        status = self.mapper.ensure(cfg.listener_ports())
        status['enabled'] = True
        status['checked'] = time.time()
        self.set_status('portmap', status)


def public_addresses(cfg, client, mapped='', need6=None):
    """Public addresses that may be published, see publicip.reconcile (also used by the UI)."""
    if need6 is None:
        need6 = any(e.ipv6 for _, e in cfg.ddns_entries()) or cfg.listen_ipv6
    try:
        via_proxy = client.proxy()
    except HttpError as exc:
        return {'error': str(exc), 'ipv4': None, 'ipv6': None}
    public = publicip.detect_all(client, True, need6 and via_proxy is None)
    router_ip, router_info = '', 'router query switched off in the settings'
    if cfg.ddns_router_ip:
        router_ip, router_info = portmap.router_wan_ipv4(client, allow_upnp=via_proxy is None)
    if not router_ip and mapped:
        router_ip, router_info = mapped, 'port mapping'
    local_v6 = None
    if via_proxy is not None and need6:
        local_v6 = netutil.local_ip('2001:4860:4860::8888', socket.AF_INET6)
    public = publicip.reconcile(public, router_ip, router_info,
                                via_proxy.describe() if via_proxy is not None else '', local_v6)
    public['checked'] = time.time()
    return public


def engine_exit_hint(code, output, windows):
    text = ' '.join(output).lower()
    if 'bind' in text or 'address already in use' in text or 'only one usage' in text:
        return 'A port is already used by another program. '
    if 'error while loading shared libraries' in text:
        return 'A system library is missing (%s). ' % ' '.join(output)[-160:]
    if windows and code in (-1073741515, 3221225781):
        return 'A required DLL is missing. '
    return ''
